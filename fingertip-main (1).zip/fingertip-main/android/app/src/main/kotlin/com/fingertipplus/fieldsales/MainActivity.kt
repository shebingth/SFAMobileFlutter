package com.fingertipplus.fieldsales

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
