import 'dart:io';

import 'package:flutter/foundation.dart';

import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:internet_connection_checker_plus/internet_connection_checker_plus.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:rxdart/rxdart.dart';

import '../app/app.logger.dart';
import '../extensions/iterable.dart';
import '../extensions/list.dart';
import '../extensions/string.dart';
import '../models/account.dart';
import '../models/competition.dart';
import '../models/expense.dart';
import '../models/home.dart';
import '../models/invoice.dart';
import '../models/latlng.dart';
import '../models/leaves.dart';
import '../models/order.dart';
import '../models/payment_follow_up.dart';
import '../models/product.dart';
import '../models/stock.dart';
import '../models/ticket.dart';
import '../models/user.dart';
import '../models/visit_plan.dart';
import '../ui/common/app_constants.dart';
import '../ui/common/date_time_utils.dart';
import '../ui/tools/parse.dart';

import 'tables.dart';
import 'tools.dart';

part 'database.g.dart';

@DriftDatabase(tables: [
  Accounts,
  Products,
  Visits,
  DayLogs,
  CartItems,
  Orders,
  OrderItems,
  VisitFiles,
  VisitPlans,
  AccountRoutes,
  Expenses,
  ExpenseItems,
  ExpenseItemFiles,
  Stocks,
  Tickets,
  Competitiors,
  Competitions,
  AccountFiles,
  PaymentFollowUps,
  PaymentReceipts,
  Invoices,
  InvoiceItems,
  Leaves,
])
class DatabaseService extends _$DatabaseService {
  DatabaseService() : super(_openConnection());
  final logger = getLogger("DatabaseService");

  @override
  int get schemaVersion => 1;

  Future<void> clearTables() async {
    await Future.wait([
      delete(visits).go(),
      delete(products).go(),
      delete(accounts).go(),
      delete(dayLogs).go(),
      delete(cartItems).go(),
      delete(orders).go(),
      delete(orderItems).go(),
      delete(visitFiles).go(),
      delete(visitPlans).go(),
      delete(accountRoutes).go(),
      delete(expenses).go(),
      delete(expenseItems).go(),
      delete(expenseItemFiles).go(),
      delete(stocks).go(),
      delete(tickets).go(),
      delete(competitiors).go(),
      delete(competitions).go(),
      delete(accountFiles).go(),
      delete(paymentFollowUps).go(),
      delete(paymentReceipts).go(),
      delete(invoices).go(),
      delete(invoiceItems).go(),
      delete(leaves).go(),
    ]);
  }

  Future<void> clearSyncedData() async {
    await Future.wait([
      (delete(visits)..where((tbl) => tbl.synced.equals(true))).go(),
      delete(products).go(),
      (delete(accounts)..where((tbl) => tbl.synced.equals(true))).go(),
      (delete(dayLogs)..where((tbl) => tbl.synced.equals(true))).go(),
      delete(cartItems).go(),
      (delete(orders)..where((tbl) => tbl.synced.equals(true))).go(),
      delete(orderItems).go(),
      (delete(visitFiles)..where((tbl) => tbl.synced.equals(true))).go(),
      (delete(visitPlans)..where((tbl) => tbl.synced.equals(true))).go(),
      delete(accountRoutes).go(),
      (delete(expenses)..where((tbl) => tbl.synced.equals(true))).go(),
      delete(expenseItems).go(),
      (delete(expenseItemFiles)..where((tbl) => tbl.synced.equals(true))).go(),
      (delete(stocks)..where((tbl) => tbl.synced.equals(true))).go(),
      (delete(tickets)..where((tbl) => tbl.synced.equals(true))).go(),
      delete(competitiors).go(),
      (delete(competitions)..where((tbl) => tbl.synced.equals(true))).go(),
      (delete(accountFiles)..where((tbl) => tbl.synced.equals(true))).go(),
      (delete(paymentFollowUps)..where((tbl) => tbl.synced.equals(true))).go(),
      delete(paymentReceipts).go(),
      delete(invoices).go(),
      delete(invoiceItems).go(),
      (delete(leaves)..where((tbl) => tbl.synced.equals(true))).go(),
    ]);
  }

  Stream<bool> isDataSynced() {
    final internetConnection = InternetConnection();
    return CombineLatestStream<bool, bool>(
      [
        isDayLogSynced(),
        isVisitsSynced(),
        isOrdersSynced(),
        isVisitFilesSynced(),
        isVisitPlansSynced(),
        isAccountsSynced(),
        isExpenseSynced(),
        isStocksSynced(),
        isTicketsSynced(),
        isCompetitionsSynced(),
        isAccountFilesSynced(),
        isExpenseItemFilesSynced(),
        isPaymentFollowUpsSynced(),
        isLeavesSynced(),
        internetConnection.onStatusChange.map((event) {
          return event == InternetStatus.connected;
        })
      ],
      (values) => values.every((element) => element == true),
    );
  }

  Future<void> addNewData(HomeDataModel data) async {
    await Future.wait([
      addAccounts(data.accounts ?? []),
      addProducts(data.products ?? []),
      addVisitPlans(data.visitPlans ?? []),
      addVisits(data.visits ?? []),
      addOrders(data.orders ?? []),
      addDayLogs(data.dayLog),
      addAccountRoutes(data.routes ?? []),
      addExpenses(data.expenses ?? []),
      addCompetitors(data.competitiors ?? []),
      addTickets(data.tickets ?? []),
      addStocks(data.stocks ?? []),
      addCompetitions(data.competitions ?? []),
      addPaymentFollowUps(data.paymentFollowUps ?? []),
      addPaymentReceipt(data.paymentReceipts ?? []),
      addInvoices(data.invoices ?? []),
      addLeaves(data.leaves ?? []),
    ]);
  }

  Future<List<Visit>> getVisitsByAccountId(String appAccountId) async {
    return (select(visits)
          ..where((tbl) => tbl.appAccountId.equals(appAccountId)))
        .get();
  }

  Stream<List<Visit>> watchVisitsByAccountId(String appAccountId) {
    return (select(visits)
          ..where((tbl) => tbl.appAccountId.equals(appAccountId)))
        .watch();
  }

  //AccountRoutes
  Future<void> addAccountRoutes(List<AccountRoute> values) async {
    var newIds = values.map((e) => e.id).whereNotNull().toList();
    await (delete(accountRoutes)..where((tbl) => tbl.id.isNotIn(newIds))).go();
    for (var route in values) {
      await into(accountRoutes).insert(route, mode: InsertMode.insertOrIgnore);
    }
  }

  Future<List<AccountRoute>> getRoutes() {
    return select(accountRoutes).get();
  }

  //Accounts
  Future<bool> addNewAccount({
    required AccountHelper account,
    required AppUser? user,
  }) async {
    try {
      await into(accounts).insert(
        account.toAccount().toCompanion(false).copyWith(
              appAccountId: const Value.absent(),
              synced: const Value(false),
              accountOwnerId: Value.absentIfNull(user?.userId),
              accountOwnerName: Value.absentIfNull(user?.name),
              createdBy: Value.absentIfNull(user?.name),
              createdDate: Value(DateTime.now().toUtc()),
              approvalStatus: const Value("Pending"),
            ),
      );

      return true;
    } catch (e) {
      debugPrint("Account Insert Error : $e ");
      return false;
    }
  }

  Future<bool> updateAccount({
    required AccountHelper account,
    required AppUser? user,
  }) async {
    try {
      await (update(accounts)
            ..where((tbl) {
              return tbl.appAccountId.equals(account.appAccountId!);
            }))
          .write(
        account.toAccount().toCompanion(false).copyWith(
              synced: const Value(false),
              lastModifiedBy: Value.absentIfNull(user?.name),
              lastModifiedDate: Value.absentIfNull(DateTime.now().toUtc()),
            ),
      );

      return true;
    } catch (e) {
      debugPrint("Account Update Error : $e ");
      return false;
    }
  }

  Future<void> addAccounts(List<Account> values) async {
    var offlineAccounts = await getAccounts();
    for (var account in values) {
      if (account.appAccountId.isNotEmptyOrNull) {
        var acc = offlineAccounts.firstWhereOrNull((element) {
          return element.appAccountId == account.appAccountId;
        });

        if (acc == null) {
          await into(accounts).insert(
            account.copyWith(synced: const Value(true)),
            mode: InsertMode.insertOrIgnore,
          );
        } else {
          await (update(accounts)
                ..where((tbl) {
                  return tbl.appAccountId.equals(account.appAccountId!);
                }))
              .write(
            AccountsCompanion(
              id: Value.absentIfNull(account.id),
              approvalStatus: Value.absentIfNull(account.approvalStatus),
              lastModifiedBy: Value.absentIfNull(account.lastModifiedBy),
              lastModifiedDate: Value.absentIfNull(account.lastModifiedDate),
            ),
          );
        }
      } else if (account.id.isNotEmptyOrNull) {
        var acc = offlineAccounts.firstWhereOrNull((element) {
          return element.id == account.id;
        });

        if (acc == null) {
          await into(accounts).insert(account);
        } else {
          await (update(accounts)..where((tbl) => tbl.id.equals(account.id!)))
              .write(
            AccountsCompanion(
              id: Value.absentIfNull(account.id),
              approvalStatus: Value.absentIfNull(account.approvalStatus),
              lastModifiedBy: Value.absentIfNull(account.lastModifiedBy),
              lastModifiedDate: Value.absentIfNull(account.lastModifiedDate),
            ),
          );
        }
      }
    }
  }

  Future<List<Account>> getAccounts() {
    return select(accounts).get();
  }

  Future<List<Account>> getAprovedAccounts() {
    return (select(accounts)
          ..where((tbl) => tbl.approvalStatus.equals(AccountStatus.approved)))
        .get();
  }

  Stream<List<Account>> watchAccounts() {
    return select(accounts).watch();
  }

  Stream<List<Account>> watchDesyncedAccounts() {
    return (select(accounts)..where((tbl) => tbl.synced.equals(false))).watch();
  }

  Future<void> markAccountsAsSynced(List<Account> values) async {
    transaction(() async {
      for (Account element in values) {
        await (update(accounts)
              ..where((tbl) {
                return tbl.appAccountId.equals(element.appAccountId!);
              }))
            .write(const AccountsCompanion(synced: Value(true)));
      }
    });
  }

  Stream<Account?> watchAccount(String appAccountId) {
    return (select(accounts)
          ..where((tbl) => tbl.appAccountId.equals(appAccountId)))
        .watchSingleOrNull();
  }

  Future<Account?> getAccount(String appAccountId) {
    return (select(accounts)
          ..where((tbl) => tbl.appAccountId.equals(appAccountId)))
        .getSingleOrNull();
  }

  Stream<bool> isAccountsSynced() {
    return (select(accounts)..where((tbl) => tbl.synced.equals(false)))
        .watch()
        .map((event) => event.isEmpty);
  }

  Future<List<Account>> getAccountsByAppAccountId(
      List<String> appAccountIds) async {
    return (select(accounts)
          ..where((tbl) => tbl.appAccountId.isIn(appAccountIds)))
        .get();
  }

  //Account Files

  Future<bool> addAccountFiles({
    required String appAccountId,
    required List<File> files,
  }) async {
    try {
      await transaction(() async {
        for (var file in files) {
          await into(accountFiles).insert(
            AccountFilesCompanion(
              appAccountId: Value(appAccountId),
              file: Value(file.readAsBytesSync()),
              fileName: Value(file.path.split('/').last),
              synced: const Value(false),
            ),
          );
        }
      });
      return true;
    } catch (e) {
      debugPrint("Account Files Insert Error : $e ");
      return false;
    }
  }

  Stream<List<AccountFile>> watchDesyncedAccountFiles() {
    return (select(accountFiles)..where((tbl) => tbl.synced.equals(false)))
        .watch();
  }

  Stream<bool> isAccountFilesSynced() {
    return (select(accountFiles)..where((tbl) => tbl.synced.equals(false)))
        .watch()
        .map((event) => event.isEmpty);
  }

  Future<List<Account>> getAccountByAppAccountId(
    List<String> appAccountIds,
  ) async {
    return (select(accounts)
          ..where((tbl) => tbl.appAccountId.isIn(appAccountIds)))
        .get();
  }

  Future<void> markAccountFilesAsSynced(
    List<String> accountFileIds,
  ) async {
    await (update(accountFiles)..where((tbl) => tbl.id.isIn(accountFileIds)))
        .write(const AccountFilesCompanion(synced: Value(true)));
  }

  //Products
  Future<void> addProducts(List<ProductHelper> values) async {
    var newIds = values.map((e) => e.id).whereNotNull().toList();
    await (delete(products)..where((tbl) => tbl.id.isNotIn(newIds))).go();
    var valuesWithIdName = values
        .where((e) => e.id.isNotEmptyOrNull && e.name.isNotEmptyOrNull)
        .toList();
    for (var product in valuesWithIdName) {
      await into(products).insert(
        ProductsCompanion(
          id: Value(product.id!),
          name: Value(product.name!),
          category: Value.absentIfNull(product.category),
          unitPrice: Value(product.unitPrice ?? 0.0),
          taxPercent: Value(product.taxPercent ?? 0.0),
        ),
        mode: InsertMode.insertOrIgnore,
      );
    }
  }

  //DayLog
  Future<void> addDayLogs(DayLogModel? log) async {
    if (log?.isValid == true) {
      var dayDb = await (select(dayLogs)
            ..where((tbl) {
              return tbl.day.equals(DateTimeUtils().currentDateString());
            }))
          .getSingleOrNull();

      if (dayDb == null) {
        await into(dayLogs).insert(
          DayLogsCompanion.insert(
            day: DateTimeUtils().currentDateString(),
            dayStartTime: log!.dayStartTime!,
            startLocation: log.startLocation!,
            dayEndTime: Value.absentIfNull(log.dayEndTime),
            endLocation: Value.absentIfNull(log.endLocation),
            synced: const Value(true),
          ),
        );
      }
    }
  }

  Future<DayLog?> getCurrentDayLog() {
    return (select(dayLogs)
          ..where((tbl) => tbl.day.equals(DateTimeUtils().currentDateString())))
        .getSingleOrNull();
  }

  Stream<DayLog?> watchCurrentDayLog() {
    return (select(dayLogs)
          ..where((tbl) => tbl.day.equals(DateTimeUtils().currentDateString())))
        .watchSingleOrNull();
  }

  Stream<List<DayLog>> watchDesyncedDayLogs() {
    return (select(dayLogs)..where((tbl) => tbl.synced.equals(false))).watch();
  }

  Stream<bool> isDayLogSynced() {
    return (select(dayLogs)..where((tbl) => tbl.synced.equals(false)))
        .watch()
        .map((event) => event.isEmpty);
  }

  Future<bool> startDayLog(LatLng latLng) async {
    try {
      await into(dayLogs).insert(
        DayLogsCompanion(
          day: Value(DateTimeUtils().currentDateString()),
          dayStartTime: Value(DateTime.now().toUtc()),
          startLocation: Value(latLng),
        ),
      );

      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> endDayLog(String day, LatLng latLng) async {
    try {
      await (update(dayLogs)..where((tbl) => tbl.day.equals(day))).write(
        DayLogsCompanion(
          dayEndTime: Value(DateTime.now().toUtc()),
          endLocation: Value(latLng),
          synced: const Value(false),
        ),
      );

      return true;
    } catch (e) {
      return false;
    }
  }

  Future<void> markDayLogsAsSynced(List<DayLog> values) async {
    transaction(() async {
      for (DayLog element in values) {
        await (update(dayLogs)..where((tbl) => tbl.day.equals(element.day)))
            .write(
          const DayLogsCompanion(
            synced: Value(true),
          ),
        );
      }
    });
  }

  //Products
  Future<List<Product>> getProducts() {
    return select(products).get();
  }

  //CartItems
  Stream<List<CartItem>> watchCartItems() {
    return select(cartItems).watch();
  }

  Future<bool> addCartItems(CartItem value) async {
    try {
      if (value.id == null) {
        await into(cartItems).insert(value);
      } else {
        await update(cartItems).replace(value);
      }

      return true;
    } catch (e) {
      debugPrint("$e");
      return false;
    }
  }

  void deleteCartItem(CartItem item) {
    delete(cartItems).delete(item);
  }

  Future<void> deleteCartItems() async {
    await (delete(cartItems)).go();
  }

  //Orders
  Future<List<Order>> getOrders() {
    return select(orders).get();
  }

  Future<Order?> getOrderByAppOrderId({
    required String? appOrderId,
  }) {
    if (appOrderId.isNotEmptyOrNull) {
      return (select(orders)
            ..where((tbl) => tbl.appOrderId.equals(appOrderId!)))
          .getSingleOrNull();
    }

    return Future.value(null);
  }

  Stream<List<Order>> watchOrders() {
    return select(orders).watch();
  }

  Stream<Order?> watchOrder(String appOrderId) {
    return (select(orders)..where((tbl) => tbl.appOrderId.equals(appOrderId)))
        .watchSingleOrNull();
  }

  Future<List<OrderItem>> getOrderItems() {
    return select(orderItems).get();
  }

  Future<void> markOrdersAsSynced(List<Order> values) async {
    transaction(() async {
      for (Order element in values) {
        if (element.appOrderId.isNotEmptyOrNull) {
          await (update(orders)
                ..where((tbl) => tbl.appOrderId.equals(element.appOrderId!)))
              .write(
            const OrdersCompanion(synced: Value(true)),
          );
        }
      }
    });
  }

  Stream<List<Order>> watchDesyncedOrders() {
    return (select(orders)..where((tbl) => tbl.synced.equals(false))).watch();
  }

  Stream<bool> isOrdersSynced() {
    return (select(orders)..where((tbl) => tbl.synced.equals(false)))
        .watch()
        .map((event) => event.isEmpty);
  }

  Future<bool> createOrder({
    required Visit? visit,
    required Account account,
    required List<CartItem> items,
    required double totalRate,
    required double totalTax,
    required double grandTotal,
  }) async {
    try {
      await transaction(() async {
        var orderId = uuid.v6();
        await into(orders).insert(
          OrdersCompanion(
            appOrderId: Value(orderId),
            salesAppId: Value.absentIfNull(visit?.salesAppId),
            accountId: Value.absentIfNull(account.id),
            appAccountId: Value.absentIfNull(account.appAccountId),
            accountName: Value.absentIfNull(account.name),
            orderDate: Value(DateTime.now().toUtc()),
            totalAmount: Value(totalRate),
            totalTax: Value(totalTax),
            grandTotal: Value(grandTotal),
            createdDate: Value(DateTime.now().toUtc()),
            status: const Value(OrderStatus.newOrder),
          ),
        );

        for (var item in items) {
          await into(orderItems).insert(OrderItemsCompanion(
            appOrderId: Value(orderId),
            productId: Value(item.productId),
            productName: Value(item.productName),
            quantity: Value(item.quantity),
            unitPrice: Value(item.unitPrice),
            taxPercent: Value(item.taxPercent),
            taxAmount: Value(item.taxAmount),
            totalAmount: Value(item.totalAmount),
            totalTax: Value(item.totalTax),
            grandTotal: Value(item.grandTotal),
          ));
        }

        await deleteCartItems();
      });

      return true;
    } catch (e) {
      return false;
    }
  }

  Future<List<OrderItem>> getOrderItemsByVisit(String salesAppId) async {
    var lastOrders = await (select(orders)
          ..where((tbl) => tbl.salesAppId.equals(salesAppId)))
        .get();

    var ids = lastOrders.map((e) => e.appOrderId).whereNotNull().toList();

    return (select(orderItems)..where((tbl) => tbl.appOrderId.isIn(ids))).get();
  }

  Future<List<OrderItem>> getOrderItemsByAppOrderId(String appOrderId) async {
    return (select(orderItems)
          ..where((tbl) => tbl.appOrderId.equals(appOrderId)))
        .get();
  }

  Stream<List<OrderItem>> watchOrderItemsByAppOrderId(String appOrderId) {
    return (select(orderItems)
          ..where((tbl) => tbl.appOrderId.equals(appOrderId)))
        .watch();
  }

  Future<void> addOrders(List<OrderModel> values) async {
    var offlineOrders = await getOrders();
    var offlineOrderItems = await getOrderItems();

    for (OrderModel order in values) {
      if (order.appOrderId.isNotEmptyOrNull) {
        var o = offlineOrders.firstWhereOrNull((element) {
          return element.appOrderId == order.appOrderId;
        });

        if (o == null) {
          await into(orders).insert(
            order.toOrder().copyWith(synced: const Value(true)),
            mode: InsertMode.insertOrIgnore,
          );

          for (OrderItemModel item in order.orderItems ?? []) {
            var oi = offlineOrderItems.firstWhereOrNull((element) {
              return element.appOrderId == order.appOrderId &&
                  element.productId == item.productId;
            });

            if (oi == null) {
              await into(orderItems).insert(
                item.toOrderItem(),
                mode: InsertMode.insertOrIgnore,
              );
            }
          }
        } else {
          await (update(orders)
                ..where((tbl) {
                  return tbl.appOrderId.equals(order.appOrderId!);
                }))
              .write(
            OrdersCompanion(
              id: Value.absentIfNull(order.id),
              status: Value.absentIfNull(order.status),
              name: Value.absentIfNull(order.name),
            ),
          );
        }
      } else if (order.id.isNotEmptyOrNull) {
        var o = offlineOrders.firstWhereOrNull((element) {
          return element.id == order.id;
        });

        if (o == null) {
          var appOrderId = uuid.v6();
          await into(orders).insert(
            order.toOrder().copyWith(appOrderId: Value(appOrderId)),
            mode: InsertMode.insertOrIgnore,
          );

          for (OrderItemModel item in order.orderItems ?? []) {
            await into(orderItems).insert(
              item.toOrderItem().copyWith(
                    appOrderId: Value(appOrderId),
                  ),
              mode: InsertMode.insertOrIgnore,
            );
          }
        } else {
          await (update(orders)..where((tbl) => tbl.id.equals(order.id!)))
              .write(
            OrdersCompanion(
              id: Value.absentIfNull(order.id),
              status: Value.absentIfNull(order.status),
              name: Value.absentIfNull(order.name),
            ),
          );
        }
      }
    }
  }

  //VisitFiles
  Future<List<VisitFile>> getVisitFiles() {
    return select(visitFiles).get();
  }

  Future<List<VisitFile>> getVisitFilesBySalesAppId(String salesAppId) {
    return (select(visitFiles)
          ..where((tbl) => tbl.salesAppId.equals(salesAppId)))
        .get();
  }

  Stream<List<VisitFile>> watchDesyncedVisitFiles() {
    return (select(visitFiles)..where((tbl) => tbl.synced.equals(false)))
        .watch();
  }

  Future<void> markVisitFilesAsSynced(List<String> visitFileIds) async {
    await (update(visitFiles)..where((tbl) => tbl.id.isIn(visitFileIds)))
        .write(const VisitFilesCompanion(synced: Value(true)));
  }

  Stream<bool> isVisitFilesSynced() {
    return (select(visitFiles)..where((tbl) => tbl.synced.equals(false)))
        .watch()
        .map((event) => event.isEmpty);
  }

  // Visits
  Future<List<Visit>> getVisits() {
    return select(visits).get();
  }

  Future<List<Visit>> getTodaysVisits() async {
    return (select(visits)
          ..where((tbl) => DateTimeUtils().isCurrentDate(tbl.plannedStartTime)))
        .get();
  }

  Future<void> markVisitAsSyncedAndUpdateId(
    List<PushRecordResponseItemModel> values,
  ) async {
    transaction(() async {
      for (PushRecordResponseItemModel element in values) {
        if (element.salesAppId.isNotEmptyOrNull &&
            element.recordId.isNotEmptyOrNull) {
          await (update(visits)
                ..where((tbl) {
                  return tbl.salesAppId.equals(element.salesAppId!);
                }))
              .write(
            VisitsCompanion(
              id: Value(element.recordId!),
              synced: const Value(true),
            ),
          );
        }
      }
    });
  }

  Future<Visit?> getLastVisit({
    required String salesAppId,
    required String accountId,
  }) async {
    var currentVisit = await getVisitBySalesAppId(salesAppId);

    List<Visit> values = [];
    values = await (select(visits)
          ..where((tbl) {
            return tbl.salesAppId.equals(salesAppId).not() &
                tbl.accountId.equals(accountId);
          }))
        .get();

    return findLatestVisit(
      currentVisit: currentVisit,
      visits: values,
    );
  }

  Stream<List<Visit>> watchTodaysVisits() {
    return (select(visits)
          ..where((tbl) => DateTimeUtils().isCurrentDate(tbl.plannedStartTime)))
        .watch();
  }

  Stream<List<Visit>> watchDesyncedVisits() {
    return (select(visits)..where((tbl) => tbl.synced.equals(false))).watch();
  }

  Stream<bool> isVisitsSynced() {
    return (select(visits)..where((tbl) => tbl.synced.equals(false)))
        .watch()
        .map((event) => event.isEmpty);
  }

  Future<Visit?> getVisitBySalesAppIdOrNull(String salesAppId) {
    return (select(visits)..where((tbl) => tbl.salesAppId.equals(salesAppId)))
        .getSingleOrNull();
  }

  Future<Visit> getVisitBySalesAppId(String salesAppId) {
    return (select(visits)..where((tbl) => tbl.salesAppId.equals(salesAppId)))
        .getSingle();
  }

  Future<List<Visit>> getVisitsBySalesAppIds(List<String> salesAppIds) {
    return (select(visits)..where((tbl) => tbl.salesAppId.isIn(salesAppIds)))
        .get();
  }

  Stream<Visit> watchVisitBySalesAppId(String salesAppId) {
    return (select(visits)..where((tbl) => tbl.salesAppId.equals(salesAppId)))
        .watchSingle();
  }

  Stream<List<Visit>> watchVisitsByAppVisitPlanId(String appVisitPlanId) {
    return (select(visits)
          ..where((tbl) => tbl.appVisitPlanId.equals(appVisitPlanId)))
        .watch();
  }

  Stream<List<Visit>> getVisitsByAppVisitPlanIdDate({
    required String appVisitPlanId,
    required DateTime date,
  }) {
    return (select(visits)
          ..where((tbl) {
            return tbl.appVisitPlanId.equals(appVisitPlanId) &
                DateTimeUtils().isInDate(tbl.plannedStartTime, date);
          }))
        .watch();
  }

  Future<Visit?> getVisitById(String id) {
    return (select(visits)..where((tbl) => tbl.id.equals(id)))
        .getSingleOrNull();
  }

  Future<void> addVisits(List<Visit> values) async {
    var offlineVisits = await getVisits();
    for (var visit in values) {
      if (visit.salesAppId.isNotEmptyOrNull) {
        var v = offlineVisits.firstWhereOrNull((element) {
          return element.salesAppId == visit.salesAppId;
        });

        if (v == null) {
          await into(visits).insert(
            visit.copyWith(synced: const Value(true)),
            mode: InsertMode.insertOrIgnore,
          );
        } else {
          if (visit.id.isNotEmptyOrNull && v.id.isEmptyOrNull) {
            await (update(visits)
                  ..where((tbl) => tbl.salesAppId.equals(visit.salesAppId!)))
                .write(VisitsCompanion(id: Value(visit.id!)));
          }
        }
      } else if (visit.id.isNotEmptyOrNull) {
        var v = offlineVisits.firstWhereOrNull((element) {
          return element.id == visit.id;
        });

        if (v == null) {
          await into(visits).insert(visit);
        }
      }
    }
  }

  Future<bool> addNewVisit({
    required Account account,
    required DateTime date,
    required String visitType,
    VisitPlan? visitPlan,
  }) async {
    try {
      await into(visits).insert(
        VisitsCompanion(
          accountId: Value.absentIfNull(account.id),
          appAccountId: Value.absentIfNull(account.appAccountId),
          accountName: Value.absentIfNull(account.name),
          outstanding: Value.absentIfNull(parseToDouble(account.outstanding)),
          plannedStartTime: Value.absentIfNull(date.toUtc()),
          typeofVisit: Value.absentIfNull(visitType),
          status: const Value(VisitStatus.planned),
          synced: const Value(false),
          visitPlanId: Value.absentIfNull(visitPlan?.id),
          appVisitPlanId: Value.absentIfNull(visitPlan?.appVisitPlanId),
        ),
      );

      return true;
    } catch (e) {
      debugPrint("Visit Insert Error : $e ");
      return false;
    }
  }

  Future<bool> checkIn(String salesAppId, LatLng latLng) async {
    try {
      await (update(visits)..where((tbl) => tbl.salesAppId.equals(salesAppId)))
          .write(
        VisitsCompanion(
          actualStartTime: Value(DateTime.now().toUtc()),
          geoLocation: Value(latLng),
          status: const Value(VisitStatus.inProgress),
          synced: const Value(false),
        ),
      );

      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> checkout({
    required List<File> files,
    required String salesAppId,
    required String comment,
    required LatLng latLng,
  }) async {
    try {
      await transaction(() async {
        await (update(visits)
              ..where((tbl) => tbl.salesAppId.equals(salesAppId)))
            .write(
          VisitsCompanion(
            status: const Value(VisitStatus.completed),
            comments: Value(comment),
            actualEndTime: Value(DateTime.now().toUtc()),
            checkoutLocation: Value(latLng),
            synced: const Value(false),
          ),
        );

        for (var file in files) {
          await into(visitFiles).insert(
            VisitFilesCompanion(
              salesAppId: Value(salesAppId),
              file: Value(file.readAsBytesSync()),
              fileName: Value(file.path.split('/').last),
              synced: const Value(false),
            ),
          );
        }
      });

      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> addVisitFile({
    required File file,
    required String salesAppId,
  }) async {
    try {
      await into(visitFiles).insert(
        VisitFilesCompanion(
          salesAppId: Value(salesAppId),
          file: Value(file.readAsBytesSync()),
          fileName: Value(file.path.split('/').last),
          synced: const Value(false),
        ),
      );

      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> missedVisit(
    Visit visit,
    String reason,
    DateTime? dateTime,
  ) async {
    try {
      await transaction(() async {
        await (update(visits)
              ..where((tbl) => tbl.salesAppId.equals(visit.salesAppId!)))
            .write(
          VisitsCompanion(
            status: const Value(VisitStatus.missed),
            missedReason: Value(reason),
            synced: const Value(false),
          ),
        );

        if (dateTime != null) {
          await into(visits).insert(
            VisitsCompanion(
              accountId: Value(visit.accountId),
              accountName: Value(visit.accountName),
              plannedStartTime: Value(dateTime.toUtc()),
              typeofVisit: Value(visit.typeofVisit),
              status: const Value(VisitStatus.planned),
            ),
          );
        }
      });

      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> deleteVisit(String salesAppId) async {
    try {
      await (delete(visits)..where((tbl) => tbl.salesAppId.equals(salesAppId)))
          .go();
      return true;
    } catch (e) {
      return false;
    }
  }

  // Visit Plan
  Future<bool> addNewVisitPlan({
    required String? name,
    required int? month,
    required int? year,
    required String? frequency,
    required AppUser? user,
  }) async {
    try {
      await into(visitPlans).insert(
        VisitPlansCompanion(
          name: Value(name),
          month: Value(month),
          year: Value(year),
          frequency: Value(frequency),
          executiveId: Value(user?.userId),
          executiveName: Value(user?.name),
          startDate: Value(
            DateTimeUtils.getStartOfMonth(year: year, month: month),
          ),
          endDate: Value(
            DateTimeUtils.getEndOfMonth(year: year, month: month),
          ),
          createdDate: Value(DateTime.now().toUtc()),
          synced: const Value(false),
        ),
      );

      return true;
    } catch (e) {
      debugPrint("Visit Plan Insert Error : $e ");
      return false;
    }
  }

  Future<void> addVisitPlans(List<VisitPlan> values) async {
    var offlineVisitPlans = await getVisitPlans();
    for (var visitPlan in values) {
      if (visitPlan.appVisitPlanId.isNotEmptyOrNull) {
        var v = offlineVisitPlans.firstWhereOrNull((element) {
          return element.appVisitPlanId == visitPlan.appVisitPlanId;
        });

        if (v == null) {
          await into(visitPlans).insert(
            visitPlan.copyWith(synced: const Value(true)),
            mode: InsertMode.insertOrIgnore,
          );
        } else {
          if (visitPlan.id.isNotEmptyOrNull && v.id.isEmptyOrNull) {
            await (update(visitPlans)
                  ..where((tbl) =>
                      tbl.appVisitPlanId.equals(visitPlan.appVisitPlanId!)))
                .write(VisitPlansCompanion(id: Value(visitPlan.id!)));
          }
        }
      } else if (visitPlan.id.isNotEmptyOrNull) {
        var v = offlineVisitPlans.firstWhereOrNull((element) {
          return element.id == visitPlan.id;
        });

        if (v == null) {
          await into(visitPlans).insert(visitPlan);
        }
      }
    }
  }

  Stream<List<VisitPlan>> watchDesyncedVisitPlans() {
    return (select(visitPlans)..where((tbl) => tbl.synced.equals(false)))
        .watch();
  }

  Future<List<VisitPlan>> getVisitPlans() {
    return select(visitPlans).get();
  }

  Stream<List<VisitPlan>> watchVisitPlans() {
    return select(visitPlans).watch();
  }

  Future<VisitPlan?> getVisitPlan({
    required String appVisitPlanId,
  }) {
    return (select(visitPlans)
          ..where((tbl) => tbl.appVisitPlanId.equals(appVisitPlanId)))
        .getSingleOrNull();
  }

  Future<bool> addVisitsToVisitPlan({
    required VisitPlanAddParams params,
  }) async {
    try {
      await transaction(() async {
        for (var v in params.visits) {
          await addNewVisit(
            account: v.account,
            date: v.dateTime,
            visitType: v.visitType!,
            visitPlan: params.visitPlan,
          );
        }
      });

      return true;
    } catch (e) {
      debugPrint("Visit Plan Insert Error : $e ");
      return false;
    }
  }

  Future<void> markVisitPlansAsSynced(List<VisitPlan> values) async {
    transaction(() async {
      for (VisitPlan element in values) {
        await (update(visitPlans)
              ..where((tbl) {
                return tbl.appVisitPlanId.equals(element.appVisitPlanId!);
              }))
            .write(const VisitPlansCompanion(synced: Value(true)));
      }
    });
  }

  Stream<bool> isVisitPlansSynced() {
    return (select(visitPlans)..where((tbl) => tbl.synced.equals(false)))
        .watch()
        .map((event) => event.isEmpty);
  }

  // Expense
  Future<void> addExpenses(List<ExpenseHelper> values) async {
    var offlineExpenses = await getExpenseHelpers();

    for (var expense in values) {
      if (expense.appExpId.isNotEmptyOrNull) {
        var exp = offlineExpenses.firstWhereOrNull((element) {
          return element.appExpId == expense.appExpId;
        });

        if (exp == null) {
          await into(expenses).insert(
            ExpensesCompanion(
              appExpId: Value.absentIfNull(expense.appExpId),
              expenseDate: Value.absentIfNull(expense.expenseDate),
              approvalStatus: Value.absentIfNull(expense.approvalStatus),
              createdBy: Value.absentIfNull(expense.createdBy),
              expenseName: Value.absentIfNull(expense.expenseName),
              executiveId: Value.absentIfNull(expense.executiveId),
              executiveName: Value.absentIfNull(expense.executiveName),
              id: Value.absentIfNull(expense.id),
              synced: const Value(true),
            ),
            mode: InsertMode.insertOrIgnore,
          );

          await (delete(expenseItems)
                ..where((tbl) => tbl.appExpId.equals(expense.appExpId!)))
              .go();

          for (ExpenseItemHelper item in expense.items ?? []) {
            await into(expenseItems).insert(
              item.toCompanion().copyWith(appExpId: Value(expense.appExpId!)),
            );
          }
        } else {
          await (update(expenses)
                ..where((tbl) => tbl.appExpId.equals(expense.appExpId!)))
              .write(
            ExpensesCompanion(
              id: Value.absentIfNull(expense.id),
              approvalStatus: Value.absentIfNull(expense.approvalStatus),
              expenseName: Value.absentIfNull(expense.expenseName),
            ),
          );
        }
      } else if (expense.id.isNotEmptyOrNull) {
        var exp = offlineExpenses.firstWhereOrNull((element) {
          return element.id == expense.id;
        });

        if (exp == null) {
          var appExpId = uuid.v6();
          await into(expenses).insert(
            ExpensesCompanion(
              expenseDate: Value.absentIfNull(expense.expenseDate),
              approvalStatus: Value.absentIfNull(expense.approvalStatus),
              createdBy: Value.absentIfNull(expense.createdBy),
              expenseName: Value.absentIfNull(expense.expenseName),
              executiveId: Value.absentIfNull(expense.executiveId),
              executiveName: Value.absentIfNull(expense.executiveName),
              id: Value.absentIfNull(expense.id),
              synced: const Value(false),
              appExpId: Value(appExpId),
            ),
          );

          for (ExpenseItemHelper item in expense.items ?? []) {
            await into(expenseItems).insert(
              item.toCompanion().copyWith(appExpId: Value(appExpId)),
            );
          }
        } else {
          await (update(expenses)..where((tbl) => tbl.id.equals(expense.id!)))
              .write(
            ExpensesCompanion(
              id: Value.absentIfNull(expense.id),
              approvalStatus: Value.absentIfNull(expense.approvalStatus),
              expenseName: Value.absentIfNull(expense.expenseName),
            ),
          );
        }
      }
    }
  }

  Future<bool> addNewExpense({
    required ExpenseHelper data,
    required AppUser? user,
  }) async {
    try {
      await transaction(() async {
        var appExpId = uuid.v6();
        var now = DateTime.now().toUtc();
        var expenseName =
            "EX-${user?.name}-${now.day}-${now.month}-${now.year}";
        var list = await (select(expenses)
              ..where((tbl) => tbl.expenseName.contains(expenseName)))
            .get();
        if (list.isNotEmpty) {
          expenseName = "$expenseName-${list.length}";
        }

        await into(expenses).insert(
          ExpensesCompanion(
            appExpId: Value(appExpId),
            id: Value.absentIfNull(data.id),
            executiveId: Value.absentIfNull(user?.userId),
            executiveName: Value.absentIfNull(user?.name),
            createdBy: Value.absentIfNull(user?.userId),
            expenseDate: Value.absentIfNull(data.expenseDate?.toUtc()),
            expenseName: Value.absentIfNull(expenseName),
            approvalStatus: const Value("Pending"),
            createdDate: Value(DateTime.now().toUtc()),
            synced: const Value(false),
          ),
        );

        if (data.items.isNotEmptyOrNull) {
          for (var item in data.items!) {
            var appExpItemId = uuid.v6();
            await into(expenseItems).insert(
              ExpenseItemsCompanion(
                appExpItemId: Value(appExpItemId),
                appExpId: Value(appExpId),
                type: Value.absentIfNull(item.type),
                description: Value.absentIfNull(item.description),
                amount: Value.absentIfNull(item.amount),
              ),
            );

            if (item.files.isNotEmptyOrNull) {
              for (var file in item.files!) {
                await into(expenseItemFiles).insert(
                  ExpenseItemFilesCompanion(
                    appExpId: Value(appExpId),
                    appExpItemId: Value(appExpItemId),
                    file: Value(file.readAsBytesSync()),
                    fileName: Value(file.path.split('/').last),
                  ),
                );
              }
            }
          }
        }
      });

      return true;
    } catch (e) {
      debugPrint("Expense Insert Error : $e ");
      return false;
    }
  }

  Future<List<ExpenseHelper>> getExpenseHelpers() async {
    var items = await select(expenses).get();

    return items.map((e) {
      return ExpenseHelper(
        appExpId: e.appExpId,
        id: e.id,
        expenseDate: e.expenseDate,
        expenseName: e.expenseName,
        executiveId: e.executiveId,
        executiveName: e.executiveName,
        createdBy: e.createdBy,
        synced: e.synced,
        approvalStatus: e.approvalStatus,
        createdDate: e.createdDate,
      );
    }).toList();
  }

  Future<List<Expense>> getExpenses() async {
    return select(expenses).get();
  }

  Stream<List<ExpenseHelper>> watchExpenses() {
    return select(expenses).watch().map((event) {
      return event.map((e) {
        return ExpenseHelper(
          appExpId: e.appExpId,
          id: e.id,
          expenseDate: e.expenseDate,
          expenseName: e.expenseName,
          executiveId: e.executiveId,
          executiveName: e.executiveName,
          createdBy: e.createdBy,
          synced: e.synced,
          approvalStatus: e.approvalStatus,
          createdDate: e.createdDate,
        );
      }).toList();
    });
  }

  Stream<List<ExpenseHelper>> watchDesyncedExpenses() {
    return (select(expenses)
          ..where((tbl) => tbl.synced.equals(false))
          ..limit(100))
        .watch()
        .map((event) {
      return event.map((e) {
        return ExpenseHelper(
          appExpId: e.appExpId,
          id: e.id,
          expenseDate: e.expenseDate,
          expenseName: e.expenseName,
          executiveId: e.executiveId,
          executiveName: e.executiveName,
          createdBy: e.createdBy,
          synced: e.synced,
          approvalStatus: e.approvalStatus,
          createdDate: e.createdDate,
        );
      }).toList();
    });
  }

  Stream<List<ExpenseItemHelper>> watchExpenseItems() {
    return select(expenseItems).watch().map((event) {
      return event.map((e) {
        return ExpenseItemHelper(
          appExpItemId: e.appExpItemId,
          appExpId: e.appExpId,
          type: e.type,
          description: e.description,
          amount: e.amount,
        );
      }).toList();
    });
  }

  Future<List<ExpenseItemHelper>> getExpenseItems() async {
    var items = await select(expenseItems).get();

    return items.map((e) {
      return ExpenseItemHelper(
        appExpItemId: e.appExpItemId,
        appExpId: e.appExpId,
        type: e.type,
        description: e.description,
        amount: e.amount,
      );
    }).toList();
  }

  Stream<List<ExpenseItemFile>> watchExpenseItemFiles() {
    return select(expenseItemFiles).watch();
  }

  Future<ExpenseHelper?> getExpenseById(String appExpId) async {
    var expense = await (select(expenses)
          ..where((tbl) => tbl.appExpId.equals(appExpId)))
        .getSingleOrNull();
    var items = await (select(expenseItems)
          ..where((tbl) => tbl.appExpId.equals(appExpId)))
        .get();
    var files = await (select(expenseItemFiles)
          ..where((tbl) => tbl.appExpId.equals(appExpId)))
        .get();
    Directory directory = await getApplicationDocumentsDirectory();

    var expenseHelper = ExpenseHelper(
      appExpId: expense?.appExpId,
      id: expense?.id,
      expenseDate: expense?.expenseDate,
      expenseName: expense?.expenseName,
      executiveId: expense?.executiveId,
      executiveName: expense?.executiveName,
      createdBy: expense?.createdBy,
      synced: expense?.synced,
      approvalStatus: expense?.approvalStatus,
      createdDate: expense?.createdDate,
      items: items.map((e) {
        return ExpenseItemHelper(
          appExpItemId: e.appExpItemId,
          appExpId: e.appExpId,
          type: e.type,
          description: e.description,
          amount: e.amount,
          files: files.where((element) {
            return element.appExpItemId == e.appExpItemId;
          }).map((f) {
            String filePath = '${directory.path}/${f.fileName}';

            File file = File(filePath);
            file.writeAsBytesSync(f.file);

            return file;
          }).toList(),
        );
      }).toList(),
    );

    return expenseHelper;
  }

  Future<void> markExpenseAsSyncedAndUpdateId(
    List<PushRecordResponseItemModel> values,
  ) async {
    transaction(() async {
      for (PushRecordResponseItemModel element in values) {
        if (element.salesAppId.isNotEmptyOrNull &&
            element.recordId.isNotEmptyOrNull) {
          await (update(expenses)
                ..where((tbl) {
                  return tbl.appExpId.equals(element.salesAppId!);
                }))
              .write(
            ExpensesCompanion(
              id: Value(element.recordId!),
              synced: const Value(true),
            ),
          );
        }
      }
    });
  }

  Stream<bool> isExpenseSynced() {
    return (select(expenses)..where((tbl) => tbl.synced.equals(false)))
        .watch()
        .map((event) => event.isEmpty);
  }

  Future<List<Expense>> getExpenseByAppExpId(List<String> appExpIds) async {
    return (select(expenses)..where((tbl) => tbl.appExpId.isIn(appExpIds)))
        .get();
  }

  //Expense Item Files
  Stream<List<ExpenseItemFile>> watchDesyncedExpenseFiles() {
    return (select(expenseItemFiles)..where((tbl) => tbl.synced.equals(false)))
        .watch();
  }

  Future<void> markExpenseItemFilesAsSynced(
    List<String> expenseItemFileIds,
  ) async {
    await (update(expenseItemFiles)
          ..where((tbl) => tbl.id.isIn(expenseItemFileIds)))
        .write(const ExpenseItemFilesCompanion(synced: Value(true)));
  }

  Stream<bool> isExpenseItemFilesSynced() {
    return (select(expenseItemFiles)..where((tbl) => tbl.synced.equals(false)))
        .watch()
        .map((event) => event.isEmpty);
  }

  // Stock
  Future<List<Stock>> getStocks() {
    return select(stocks).get();
  }

  Future<bool> addNewStocks({
    required List<StockHelper> datas,
  }) async {
    try {
      await transaction(() async {
        for (var stock in datas) {
          await into(stocks).insert(
            stock.toCompanion().copyWith(synced: const Value(false)),
          );
        }
      });

      return true;
    } catch (e) {
      debugPrint("Stock Insert Error : $e ");
      return false;
    }
  }

  Stream<List<StockHelper>> watchDesyncedStock() {
    return (select(stocks)..where((tbl) => tbl.synced.equals(false)))
        .watch()
        .map((event) {
      return event.map((e) => StockHelper.fromJson(e.toJson())).toList();
    });
  }

  Future<void> markStockAsSynced(List<StockHelper> values) async {
    transaction(() async {
      for (StockHelper element in values) {
        await (update(stocks)
              ..where((tbl) {
                return tbl.appStockId.equals(element.appStockId!);
              }))
            .write(const StocksCompanion(synced: Value(true)));
      }
    });
  }

  Future<void> addStocks(List<StockHelper> values) async {
    var offlineStocks = await getStocks();
    for (var stock in values) {
      if (stock.appStockId.isNotEmptyOrNull) {
        var acc = offlineStocks.firstWhereOrNull((element) {
          return element.appStockId == stock.appStockId;
        });

        if (acc == null) {
          await into(stocks).insert(
            stock.toCompanion().copyWith(synced: const Value(true)),
            mode: InsertMode.insertOrIgnore,
          );
        } else {
          await (update(stocks)
                ..where((tbl) => tbl.appStockId.equals(stock.appStockId!)))
              .write(
            StocksCompanion(
              id: Value.absentIfNull(stock.id),
            ),
          );
        }
      } else if (stock.id.isNotEmptyOrNull) {
        var acc = offlineStocks.firstWhereOrNull((element) {
          return element.id == stock.id;
        });

        if (acc == null) {
          await into(stocks).insert(stock.toCompanion().copyWith(
                appStockId: const Value.absent(),
              ));
        }
      }
    }
  }

  Stream<bool> isStocksSynced() {
    return (select(stocks)..where((tbl) => tbl.synced.equals(false)))
        .watch()
        .map((event) => event.isEmpty);
  }

  //Ticket
  Future<List<Ticket>> getTickets() {
    return select(tickets).get();
  }

  Stream<List<Ticket>> watchTickets() {
    return select(tickets).watch();
  }

  Stream<Ticket> watchTicketByAppTicketId(String ticketId) {
    return (select(tickets)..where((tbl) => tbl.appTicketId.equals(ticketId)))
        .watchSingle();
  }

  Future<bool> addNewTicket({
    required TicketHelper data,
  }) async {
    try {
      await into(tickets).insert(
        data.toCompanion().copyWith(
              synced: const Value(false),
              status: const Value("Open"),
              createdDate: Value(DateTime.now().toUtc()),
            ),
      );

      return true;
    } catch (e) {
      debugPrint("Ticket Insert Error : $e ");
      return false;
    }
  }

  Stream<List<TicketHelper>> watchDesyncedTicket() {
    return (select(tickets)..where((tbl) => tbl.synced.equals(false)))
        .watch()
        .map((event) {
      return event.map((e) => TicketHelper.fromJson(e.toJson())).toList();
    });
  }

  Future<void> markTicketAsSynced(List<TicketHelper> values) async {
    transaction(() async {
      for (TicketHelper element in values) {
        await (update(tickets)
              ..where((tbl) {
                return tbl.appTicketId.equals(element.appTicketId!);
              }))
            .write(const TicketsCompanion(synced: Value(true)));
      }
    });
  }

  Future<void> addTickets(List<TicketHelper> values) async {
    var offlineTickets = await getTickets();
    for (var ticket in values) {
      if (ticket.appTicketId.isNotEmptyOrNull) {
        var tic = offlineTickets.firstWhereOrNull((element) {
          return element.appTicketId == ticket.appTicketId;
        });

        if (tic == null) {
          await into(tickets).insert(
            ticket.toCompanion().copyWith(synced: const Value(true)),
            mode: InsertMode.insertOrIgnore,
          );
        } else {
          await (update(tickets)
                ..where((tbl) => tbl.appTicketId.equals(ticket.appTicketId!)))
              .write(
            TicketsCompanion(
              id: Value.absentIfNull(ticket.id),
              status: Value.absentIfNull(ticket.status),
            ),
          );
        }
      } else if (ticket.id.isNotEmptyOrNull) {
        var tic = offlineTickets.firstWhereOrNull((element) {
          return element.id == ticket.id;
        });

        if (tic == null) {
          await into(tickets).insert(ticket.toCompanion().copyWith(
                appTicketId: const Value.absent(),
                synced: const Value(false),
              ));
        } else {
          await (update(tickets)..where((tbl) => tbl.id.equals(ticket.id!)))
              .write(
            TicketsCompanion(
              status: Value.absentIfNull(ticket.status),
            ),
          );
        }
      }
    }
  }

  Stream<bool> isTicketsSynced() {
    return (select(tickets)..where((tbl) => tbl.synced.equals(false)))
        .watch()
        .map((event) => event.isEmpty);
  }

  //Competitior
  Future<void> addCompetitors(List<CompetitiorHelper> values) async {
    var newIds = values.map((e) => e.id).whereNotNull().toList();
    await (delete(competitiors)..where((tbl) => tbl.id.isNotIn(newIds))).go();
    for (var competitor in values) {
      await into(competitiors).insert(
        competitor.toCompanion(),
        mode: InsertMode.insertOrIgnore,
      );
    }
  }

  Future<List<Competitior>> getCompetitors() {
    return select(competitiors).get();
  }

  // Competition
  Future<List<Competition>> getCompetitions() {
    return select(competitions).get();
  }

  Future<bool> addNewCompetition({
    required CompetitionHelper data,
  }) async {
    try {
      await into(competitions).insert(
        data.toCompanion().copyWith(synced: const Value(false)),
      );

      return true;
    } catch (e) {
      debugPrint("Competition Insert Error : $e ");
      return false;
    }
  }

  Stream<List<Competition>> watchDesyncedCompetition() {
    return (select(competitions)
          ..where((tbl) => tbl.synced.equals(false))
          ..limit(100))
        .watch();
  }

  Future<void> markCompetitionAsSynced(List<Competition> values) async {
    transaction(() async {
      for (Competition element in values) {
        await (update(competitions)
              ..where((tbl) {
                return tbl.appCompetitionId.equals(element.appCompetitionId!);
              }))
            .write(const CompetitionsCompanion(synced: Value(true)));
      }
    });
  }

  Future<void> addCompetitions(List<CompetitionHelper> values) async {
    var offlineCompetitions = await getCompetitions();
    for (var competition in values) {
      if (competition.appCompetitionId.isNotEmptyOrNull) {
        var acc = offlineCompetitions.firstWhereOrNull((element) {
          return element.appCompetitionId == competition.appCompetitionId;
        });

        if (acc == null) {
          await into(competitions).insert(
            competition.toCompanion().copyWith(synced: const Value(true)),
            mode: InsertMode.insertOrIgnore,
          );
        } else {
          await (update(competitions)
                ..where((tbl) =>
                    tbl.appCompetitionId.equals(competition.appCompetitionId!)))
              .write(
            CompetitionsCompanion(
              id: Value.absentIfNull(competition.id),
            ),
          );
        }
      } else if (competition.id.isNotEmptyOrNull) {
        var acc = offlineCompetitions.firstWhereOrNull((element) {
          return element.id == competition.id;
        });

        if (acc == null) {
          await into(competitions).insert(
            competition
                .toCompanion()
                .copyWith(appCompetitionId: const Value.absent()),
          );
        }
      }
    }
  }

  Stream<bool> isCompetitionsSynced() {
    return (select(competitions)..where((tbl) => tbl.synced.equals(false)))
        .watch()
        .map((event) => event.isEmpty);
  }

  //Payment Follow Ups
  Stream<bool> isPaymentFollowUpsSynced() {
    return (select(paymentFollowUps)..where((tbl) => tbl.synced.equals(false)))
        .watch()
        .map((event) => event.isEmpty);
  }

  Future<bool> addNewPaymentFollowUp({
    required PaymentFollowUpHelper data,
  }) async {
    try {
      var now = DateTime.now().toUtc();
      var name = "PF-${data.accountName}-${now.day}";
      var list = await (select(paymentFollowUps)
            ..where((tbl) => tbl.name.contains(name)))
          .get();
      if (list.isNotEmpty) {
        name = "$name-${list.length}";
      }

      await into(paymentFollowUps).insert(
        PaymentFollowUpsCompanion(
          appPaymentFollowUpId: const Value.absent(),
          id: const Value.absent(),
          synced: const Value(false),
          name: Value(name),
          expectedPaymentDate:
              Value.absentIfNull(data.expectedPaymentDate?.toUtc()),
          expectedAmount: Value.absentIfNull(data.expectedAmount),
          comment: Value.absentIfNull(data.comment),
          appAccountId: Value.absentIfNull(data.appAccountId),
          accountId: Value.absentIfNull(data.accountId),
          accountName: Value.absentIfNull(data.accountName),
          appVisitId: Value.absentIfNull(data.appVisitId),
          visitId: Value.absentIfNull(data.visitId),
        ),
      );

      return true;
    } catch (e) {
      debugPrint("Payment Follow Insert Error : $e ");
      return false;
    }
  }

  Future<List<PaymentFollowUp>> getPaymentFollowUpsByAccountId(
    String appAccountId,
  ) async {
    return (select(paymentFollowUps)
          ..where((tbl) => tbl.appAccountId.equals(appAccountId)))
        .get();
  }

  Stream<List<PaymentFollowUp>> watchPaymentFollowUpsByAccountId(
    String appAccountId,
  ) {
    return (select(paymentFollowUps)
          ..where((tbl) => tbl.appAccountId.equals(appAccountId)))
        .watch();
  }

  Stream<PaymentFollowUp> watchPaymentFollowUpsByAppPaymentFollowUpsId(
    String appPaymentFollowUpId,
  ) {
    return (select(paymentFollowUps)
          ..where(
              (tbl) => tbl.appPaymentFollowUpId.equals(appPaymentFollowUpId)))
        .watchSingle();
  }

  Future<List<PaymentFollowUp>> getPaymentFollowUps() {
    return select(paymentFollowUps).get();
  }

  Future<void> addPaymentFollowUps(List<PaymentFollowUpHelper> values) async {
    var offlinePaymentFollowUps = await getPaymentFollowUps();
    for (var item in values) {
      if (item.appPaymentFollowUpId.isNotEmptyOrNull) {
        var pfu = offlinePaymentFollowUps.firstWhereOrNull((element) {
          return element.appPaymentFollowUpId == item.appPaymentFollowUpId;
        });

        if (pfu == null) {
          await into(paymentFollowUps).insert(
            item.toCompanion().copyWith(synced: const Value(true)),
            mode: InsertMode.insertOrIgnore,
          );
        } else {
          await (update(paymentFollowUps)
                ..where((tbl) => tbl.appPaymentFollowUpId
                    .equals(item.appPaymentFollowUpId!)))
              .write(
            PaymentFollowUpsCompanion(
              id: Value.absentIfNull(item.id),
              name: Value.absentIfNull(item.name),
            ),
          );
        }
      } else if (item.id.isNotEmptyOrNull) {
        var acc = offlinePaymentFollowUps.firstWhereOrNull((element) {
          return element.id == item.id;
        });

        if (acc == null) {
          await into(paymentFollowUps).insert(
            item.toCompanion().copyWith(
                  appPaymentFollowUpId: const Value.absent(),
                ),
          );
        } else {
          await (update(paymentFollowUps)
                ..where((tbl) => tbl.id.equals(item.id!)))
              .write(
            PaymentFollowUpsCompanion(
              id: Value.absentIfNull(item.id),
              name: Value.absentIfNull(item.name),
            ),
          );
        }
      }
    }
  }

  Stream<List<PaymentFollowUp>> watchDesyncedPaymentFollowUps() {
    return (select(paymentFollowUps)..where((tbl) => tbl.synced.equals(false)))
        .watch();
  }

  Future<void> markPaymentFollowUpsAsSynced(
    List<PaymentFollowUp> values,
  ) async {
    transaction(() async {
      for (PaymentFollowUp element in values) {
        await (update(paymentFollowUps)
              ..where((tbl) {
                return tbl.appPaymentFollowUpId
                    .equals(element.appPaymentFollowUpId!);
              }))
            .write(const PaymentFollowUpsCompanion(synced: Value(true)));
      }
    });
  }

  //Payment Receipt
  Future<void> addPaymentReceipt(List<PaymentReceipt> values) async {
    var newIds = values.map((e) => e.id).whereNotNull().toList();
    await (delete(paymentReceipts)..where((tbl) => tbl.id.isNotIn(newIds)))
        .go();
    for (var item in values) {
      await into(paymentReceipts).insert(
        item,
        mode: InsertMode.insertOrIgnore,
      );
    }
  }

  Future<List<PaymentReceipt>> getPaymentReceipts() async {
    return select(paymentReceipts).get();
  }

  Future<List<PaymentReceipt>> getPaymentReceiptByAccountId({
    required String appAccountId,
    String? accountId,
  }) {
    if (accountId.isNotEmptyOrNull) {
      return (select(paymentReceipts)
            ..where((tbl) => tbl.accountId.equals(accountId!)))
          .get();
    }
    return (select(paymentReceipts)
          ..where((tbl) => tbl.appAccountId.equals(appAccountId)))
        .get();
  }

  Stream<List<PaymentReceipt>> watchPaymentReceiptByAccountId({
    required String appAccountId,
    String? accountId,
  }) {
    if (accountId.isNotEmptyOrNull) {
      return (select(paymentReceipts)
            ..where((tbl) => tbl.accountId.equals(accountId!)))
          .watch();
    }
    return (select(paymentReceipts)
          ..where((tbl) => tbl.appAccountId.equals(appAccountId)))
        .watch();
  }

  Stream<PaymentReceipt> watchPaymentReceiptByPaymentReceiptId(
    String paymentReceiptId,
  ) {
    return (select(paymentReceipts)
          ..where((tbl) => tbl.id.equals(paymentReceiptId)))
        .watchSingle();
  }

  Stream<List<PaymentReceipt>> watchPaymentReceipts() {
    return select(paymentReceipts).watch();
  }

  //Invoice
  Future<List<Invoice>> getInvoices() {
    return select(invoices).get();
  }

  Stream<List<Invoice>> watchInvoices() {
    return select(invoices).watch();
  }

  Future<List<InvoiceItem>> getInvoiceItems() {
    return select(invoiceItems).get();
  }

  Future<void> addInvoices(List<InvoiceHelper> values) async {
    await Future.wait([
      delete(invoices).go(),
      delete(invoiceItems).go(),
    ]);

    for (InvoiceHelper invoice in values) {
      var appInvoiceId = uuid.v6();
      await into(invoices).insert(
        invoice.toCompanion().copyWith(appInvoiceId: Value(appInvoiceId)),
        mode: InsertMode.insertOrIgnore,
      );

      for (InvoiceItemHelper item in invoice.items ?? []) {
        await into(invoiceItems).insert(
          item.toCompanion().copyWith(appInvoiceId: Value(appInvoiceId)),
          mode: InsertMode.insertOrIgnore,
        );
      }
    }
/* 
    for (InvoiceHelper invoice in values) {
      if (invoice.appInvoiceId.isNotEmptyOrNull) {
        var i = offlineInvoices.firstWhereOrNull((element) {
          return element.appInvoiceId == invoice.appInvoiceId;
        });

        if (i == null) {
          await into(invoices).insert(
            invoice.toCompanion(),
            mode: InsertMode.insertOrIgnore,
          );

          for (InvoiceItemHelper item in invoice.items ?? []) {
            var j = offlineInvoiceItems.firstWhereOrNull((element) {
              return element.appInvoiceId == invoice.appInvoiceId &&
                  element.productId == item.productId;
            });

            if (j == null) {
              await into(invoiceItems).insert(
                item.toCompanion(),
                mode: InsertMode.insertOrIgnore,
              );
            }
          }
        } else {
          await (update(invoices)
                ..where(
                    (tbl) => tbl.appInvoiceId.equals(invoice.appInvoiceId!)))
              .write(
            InvoicesCompanion(
              id: Value.absentIfNull(invoice.id),
              status: Value.absentIfNull(invoice.status),
              name: Value.absentIfNull(invoice.name),
            ),
          );
        }
      } else if (invoice.id.isNotEmptyOrNull) {
        var i = offlineInvoices.firstWhereOrNull((element) {
          return element.id == invoice.id;
        });

        if (i == null) {
          var appInvoiceId = uuid.v6();
          await into(invoices).insert(
            invoice.toCompanion().copyWith(appInvoiceId: Value(appInvoiceId)),
            mode: InsertMode.insertOrIgnore,
          );

          for (InvoiceItemHelper item in invoice.items ?? []) {
            await into(invoiceItems).insert(
              item.toCompanion().copyWith(
                    appInvoiceId: Value(appInvoiceId),
                  ),
              mode: InsertMode.insertOrIgnore,
            );
          }
        } else {
          await (update(invoices)..where((tbl) => tbl.id.equals(invoice.id!)))
              .write(
            InvoicesCompanion(
              name: Value.absentIfNull(invoice.name),
              status: Value.absentIfNull(invoice.status),
            ),
          );
        }
      }
    } 
  */
  }

  Stream<Invoice> watchInvoiceByInvoiceId(String invoiceId) {
    return (select(invoices)
          ..where((tbl) => tbl.appInvoiceId.equals(invoiceId)))
        .watchSingle();
  }

  Future<List<InvoiceItem>> getInvoiceItemsByInvoiceId(String invoiceId) {
    return (select(invoiceItems)
          ..where((tbl) => tbl.appInvoiceId.equals(invoiceId)))
        .get();
  }

  Stream<List<InvoiceItem>> watchInvoiceItemsByInvoiceId(String invoiceId) {
    return (select(invoiceItems)
          ..where((tbl) => tbl.appInvoiceId.equals(invoiceId)))
        .watch();
  }

  //Leaves
  Future<List<Leave>> getLeaves() {
    return select(leaves).get();
  }

  Stream<List<Leave>> watchLeaves() {
    return select(leaves).watch();
  }

  Stream<Leave> watchLeaveByLeaveId(String leaveId) {
    return (select(leaves)..where((tbl) => tbl.appLeaveId.equals(leaveId)))
        .watchSingle();
  }

  Stream<List<LeaveHelper>> watchDesyncedLeaves() {
    return (select(leaves)..where((tbl) => tbl.synced.equals(false)))
        .watch()
        .map((event) {
      return event.map((e) => LeaveHelper.fromJson(e.toJson())).toList();
    });
  }

  Future<void> addLeaves(List<LeaveHelper> values) async {
    var offlineLeaves = await getLeaves();
    for (var item in values) {
      if (item.appLeaveId.isNotEmptyOrNull) {
        var lv = offlineLeaves.firstWhereOrNull((element) {
          return element.appLeaveId == item.appLeaveId;
        });

        if (lv == null) {
          await into(leaves).insert(
            item.toCompanion().copyWith(synced: const Value(true)),
            mode: InsertMode.insertOrIgnore,
          );
        } else {
          await (update(leaves)
                ..where((tbl) => tbl.appLeaveId.equals(item.appLeaveId!)))
              .write(
            LeavesCompanion(
              id: Value.absentIfNull(item.id),
              name: Value.absentIfNull(item.name),
              leaveStatus: Value.absentIfNull(item.leaveStatus),
            ),
          );
        }
      } else if (item.id.isNotEmptyOrNull) {
        var acc = offlineLeaves.firstWhereOrNull((element) {
          return element.id == item.id;
        });

        if (acc == null) {
          await into(leaves).insert(
            item.toCompanion().copyWith(appLeaveId: const Value.absent()),
          );
        } else {
          await (update(leaves)..where((tbl) => tbl.id.equals(item.id!))).write(
            LeavesCompanion(
              name: Value.absentIfNull(item.name),
              leaveStatus: Value.absentIfNull(item.leaveStatus),
              lastModifiedDate: Value.absentIfNull(item.lastModifiedDate),
            ),
          );
        }
      }
    }
  }

  Future<bool> addNewLeave({
    required LeaveHelper data,
    required AppUser? user,
  }) async {
    try {
      await into(leaves).insert(
        LeavesCompanion(
          appLeaveId: const Value.absent(),
          id: const Value.absent(),
          name: const Value.absent(),
          synced: const Value(false),
          leaveStatus: const Value(LeaveStatus.pending),
          lastModifiedDate: Value(DateTime.now().toUtc()),
          comments: Value.absentIfNull(data.comments),
          startDate: Value.absentIfNull(data.startDate?.toUtc()),
          endDate: Value.absentIfNull(data.endDate?.toUtc()),
          executiveId: Value.absentIfNull(user?.userId),
          executiveName: Value.absentIfNull(user?.name),
          duration: Value.absentIfNull(data.duration),
          firstSecond: Value.absentIfNull(data.firstSecond),
          leaveType: Value.absentIfNull(data.leaveType),
          reason: Value.absentIfNull(data.reason),
          createdDate: Value(DateTime.now().toUtc()),
        ),
      );

      return true;
    } catch (e) {
      debugPrint("Add leave error: $e");
      return false;
    }
  }

  Stream<bool> isLeavesSynced() {
    return (select(leaves)..where((tbl) => tbl.synced.equals(false)))
        .watch()
        .map((event) => event.isEmpty);
  }

  Future<void> markLeavesAsSynced(
    List<LeaveHelper> values,
  ) async {
    transaction(() async {
      for (LeaveHelper element in values) {
        await (update(leaves)
              ..where((tbl) {
                return tbl.appLeaveId.equals(element.appLeaveId!);
              }))
            .write(const LeavesCompanion(synced: Value(true)));
      }
    });
  }
}

LazyDatabase _openConnection() {
  return LazyDatabase(() async {
    final dbFolder = await getApplicationDocumentsDirectory();
    final file = File(p.join(dbFolder.path, 'db.sqlite'));
    return NativeDatabase.createInBackground(file, logStatements: false);
  });
}
