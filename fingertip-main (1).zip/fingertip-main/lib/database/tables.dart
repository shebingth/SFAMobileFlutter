import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';

import '../models/latlng.dart';
import '../ui/common/app_constants.dart';

const uuid = Uuid();

class Accounts extends Table {
  TextColumn get appAccountId =>
      text().nullable().clientDefault(() => uuid.v6())();
  TextColumn get id => text().nullable()();
  TextColumn get name => text().nullable()();
  TextColumn get accountOwnerId => text().nullable()();
  TextColumn get accountOwnerName => text().nullable()();
  TextColumn get contactPersonName => text().nullable()();
  TextColumn get email => text().nullable()();
  TextColumn get mobile => text().nullable()();
  TextColumn get alternateMobile => text().nullable()();
  TextColumn get gstNo => text().nullable()();
  TextColumn get description => text().nullable()();
  TextColumn get liquidation => text().nullable()();
  TextColumn get paymentType => text().nullable()();
  TextColumn get accountClassification => text().nullable()();
  TextColumn get grade => text().nullable()();
  TextColumn get routesId => text().nullable()();
  TextColumn get routesName => text().nullable()();
  @JsonKey('actlong')
  TextColumn get longitude => text().nullable()();
  @JsonKey('actlat')
  TextColumn get latitude => text().nullable()();
  TextColumn get parentAccountId => text().nullable()();
  TextColumn get parentAccountName => text().nullable()();
  TextColumn get outstanding => text().nullable()();
  TextColumn get avgCreditDays => text().nullable()();
  TextColumn get openingBalance => text().nullable()();
  TextColumn get streetName => text().nullable()();
  TextColumn get panchayat => text().nullable()();
  TextColumn get city => text().nullable()();
  TextColumn get state => text().nullable()();
  TextColumn get district => text().nullable()();
  TextColumn get pincode => text().nullable()();
  TextColumn get approvalStatus => text().nullable()();
  @JsonKey('lastmodifiedDate')
  DateTimeColumn get lastModifiedDate => dateTime().nullable()();
  @JsonKey('lastmodifiedBy')
  TextColumn get lastModifiedBy => text().nullable()();
  DateTimeColumn get createdDate => dateTime().nullable()();
  TextColumn get createdBy => text().nullable()();
  BoolColumn get synced =>
      boolean().nullable().withDefault(const Constant(false))();

  @override
  Set<Column<Object>>? get primaryKey => {appAccountId};
}

class AccountFiles extends Table {
  TextColumn get id => text().nullable().clientDefault(() => uuid.v6())();
  TextColumn get appAccountId => text().references(Accounts, #appAccountId)();
  BlobColumn get file => blob()();
  TextColumn get fileName => text().nullable()();
  BoolColumn get synced =>
      boolean().nullable().withDefault(const Constant(false))();

  @override
  Set<Column<Object>>? get primaryKey => {id};
}

class Products extends Table {
  TextColumn get id => text()();
  TextColumn get name => text()();
  TextColumn get category => text().nullable()();
  RealColumn get unitPrice => real()();
  RealColumn get taxPercent => real()();

  @override
  Set<Column<Object>>? get primaryKey => {id};
}

class Visits extends Table {
  TextColumn get salesAppId =>
      text().nullable().clientDefault(() => uuid.v6())();
  TextColumn get id => text().nullable()();
  @JsonKey('acccountId')
  TextColumn get accountId => text().references(Accounts, #id).nullable()();
  TextColumn get appAccountId =>
      text().references(Accounts, #appAccountId).nullable()();
  TextColumn get accountName => text().nullable()();
  TextColumn get status =>
      text().nullable().withDefault(const Constant(VisitStatus.planned))();
  DateTimeColumn get plannedStartTime => dateTime()();
  DateTimeColumn get plannedEndTime => dateTime().nullable()();
  DateTimeColumn get actualStartTime => dateTime().nullable()();
  DateTimeColumn get actualEndTime => dateTime().nullable()();
  TextColumn get comments => text().nullable()();
  TextColumn get missedReason => text().nullable()();
  TextColumn get lastVisitComment => text().nullable()();
  DateTimeColumn get lastVisitDate => dateTime().nullable()();
  TextColumn get geoLocation =>
      text().map(const LatLngConverter()).nullable()();
  TextColumn get checkoutLocation =>
      text().map(const LatLngConverter()).nullable()();
  RealColumn get outstanding => real().nullable()();
  TextColumn get typeofVisit => text().nullable()();
  TextColumn get appVisitPlanId => text().nullable()();
  TextColumn get visitPlanId => text().nullable().references(VisitPlans, #id)();
  BoolColumn get synced =>
      boolean().nullable().withDefault(const Constant(false))();

  @override
  Set<Column<Object>>? get primaryKey => {salesAppId};
}

class VisitFiles extends Table {
  TextColumn get id => text().nullable().clientDefault(() => uuid.v6())();
  TextColumn get salesAppId => text().references(Visits, #salesAppId)();
  BlobColumn get file => blob()();
  TextColumn get fileName => text().nullable()();
  BoolColumn get synced =>
      boolean().nullable().withDefault(const Constant(false))();

  @override
  Set<Column<Object>>? get primaryKey => {id};
}

class DayLogs extends Table {
  TextColumn get day => text()();
  DateTimeColumn get dayStartTime => dateTime()();
  DateTimeColumn get dayEndTime => dateTime().nullable()();
  TextColumn get startLocation => text().map(const LatLngConverter())();
  TextColumn get endLocation =>
      text().map(const LatLngConverter()).nullable()();
  BoolColumn get synced =>
      boolean().nullable().withDefault(const Constant(false))();

  @override
  Set<Column<Object>>? get primaryKey => {day};
}

class CartItems extends Table {
  IntColumn get id => integer().nullable().autoIncrement()();
  TextColumn get productId => text()();
  TextColumn get productName => text()();
  IntColumn get quantity => integer()();
  RealColumn get unitPrice => real()();
  RealColumn get taxPercent => real()();
  RealColumn get taxAmount => real()();
  RealColumn get totalAmount => real()();
  RealColumn get totalTax => real()();
  RealColumn get grandTotal => real()();

  @override
  Set<Column<Object>>? get primaryKey => {id};
}

class Orders extends Table {
  TextColumn get appOrderId => text().nullable()();
  TextColumn get id => text().nullable()();
  TextColumn get salesAppId => text().nullable()();
  @JsonKey('acccountId')
  TextColumn get accountId => text().nullable()();
  TextColumn get appAccountId => text().nullable()();
  TextColumn get accountName => text().nullable()();
  RealColumn get grandTotal => real().nullable()();
  RealColumn get totalAmount => real().nullable()();
  RealColumn get totalTax => real().nullable()();
  TextColumn get status =>
      text().withDefault(const Constant(OrderStatus.newOrder)).nullable()();
  DateTimeColumn get orderDate => dateTime().nullable()();
  @JsonKey('Name')
  TextColumn get name => text().nullable()();
  TextColumn get description => text().nullable()();
  DateTimeColumn get createdDate => dateTime().nullable()();
  BoolColumn get synced =>
      boolean().nullable().withDefault(const Constant(false))();

  @override
  Set<Column<Object>>? get primaryKey => {appOrderId};
}

class OrderItems extends Table {
  IntColumn get id => integer().nullable().autoIncrement()();
  TextColumn get appOrderId => text().nullable()();
  TextColumn get productId => text().nullable()();
  TextColumn get productName => text().nullable()();
  IntColumn get quantity => integer().nullable()();
  RealColumn get unitPrice => real().nullable()();
  RealColumn get taxPercent => real().nullable()();
  RealColumn get taxAmount => real().nullable()();
  RealColumn get totalAmount => real().nullable()();
  RealColumn get totalTax => real().nullable()();
  RealColumn get grandTotal => real().nullable()();

  @override
  Set<Column<Object>>? get primaryKey => {id};
}

class VisitPlans extends Table {
  @JsonKey('appVisitPlanid')
  TextColumn get appVisitPlanId =>
      text().nullable().clientDefault(() => uuid.v6())();
  TextColumn get id => text().nullable()();
  TextColumn get name => text().nullable()();
  IntColumn get month => integer().nullable()();
  IntColumn get year => integer().nullable()();
  TextColumn get frequency => text().nullable()();
  DateTimeColumn get startDate => dateTime().nullable()();
  DateTimeColumn get endDate => dateTime().nullable()();
  TextColumn get executiveId => text().nullable()();
  TextColumn get executiveName => text().nullable()();
  DateTimeColumn get createdDate => dateTime().nullable()();
  BoolColumn get synced =>
      boolean().nullable().withDefault(const Constant(false))();

  @override
  Set<Column<Object>>? get primaryKey => {appVisitPlanId};
}

class AccountRoutes extends Table {
  TextColumn get id => text().nullable()();
  TextColumn get name => text().nullable()();
  TextColumn get warehouseId => text().nullable()();
  TextColumn get warehouseName => text().nullable()();

  @override
  Set<Column<Object>>? get primaryKey => {id};
}

class Expenses extends Table {
  TextColumn get appExpId => text().nullable().clientDefault(() => uuid.v6())();
  TextColumn get id => text().nullable()();
  DateTimeColumn get expenseDate => dateTime().nullable()();
  TextColumn get expenseName => text().nullable()();
  TextColumn get executiveId => text().nullable()();
  TextColumn get executiveName => text().nullable()();
  TextColumn get createdBy => text().nullable()();
  DateTimeColumn get createdDate => dateTime().nullable()();
  BoolColumn get synced =>
      boolean().nullable().withDefault(const Constant(false))();
  TextColumn get approvalStatus => text().nullable()();

  @override
  Set<Column<Object>>? get primaryKey => {appExpId};
}

class ExpenseItems extends Table {
  TextColumn get appExpItemId =>
      text().nullable().clientDefault(() => uuid.v6())();
  TextColumn get appExpId =>
      text().references(Expenses, #appExpId).nullable()();
  TextColumn get type => text().nullable()();
  TextColumn get description => text().nullable()();
  TextColumn get amount => text().nullable()();

  @override
  Set<Column<Object>>? get primaryKey => {appExpItemId};
}

class ExpenseItemFiles extends Table {
  TextColumn get id => text().nullable().clientDefault(() => uuid.v6())();
  TextColumn get appExpItemId =>
      text().references(ExpenseItems, #appExpItemId).nullable()();
  TextColumn get appExpId =>
      text().references(Expenses, #appExpId).nullable()();
  BlobColumn get file => blob()();
  TextColumn get fileName => text().nullable()();
  BoolColumn get synced =>
      boolean().nullable().withDefault(const Constant(false))();

  @override
  Set<Column<Object>>? get primaryKey => {id};
}

class Stocks extends Table {
  TextColumn get appStockId =>
      text().nullable().clientDefault(() => uuid.v6())();
  TextColumn get salesAppId =>
      text().nullable().references(Visits, #salesAppId)();
  @JsonKey('Id')
  TextColumn get id => text().nullable()();
  TextColumn get productId => text().nullable()();
  TextColumn get productName => text().nullable()();
  TextColumn get productCategory => text().nullable()();
  @JsonKey('unitPice')
  RealColumn get unitPrice => real().nullable()();
  IntColumn get quantity => integer().nullable()();
  TextColumn get accountId => text().nullable()();
  TextColumn get accountName => text().nullable()();
  BoolColumn get synced =>
      boolean().nullable().withDefault(const Constant(false))();

  @override
  Set<Column<Object>>? get primaryKey => {appStockId};
}

class Tickets extends Table {
  TextColumn get appTicketId =>
      text().nullable().clientDefault(() => uuid.v6())();
  TextColumn get salesAppId => text().nullable()();
  TextColumn get visitId => text().nullable()();
  @JsonKey('Id')
  TextColumn get id => text().nullable()();
  TextColumn get complaintType => text().nullable()();
  @JsonKey('decription')
  TextColumn get description => text().nullable()();
  TextColumn get status => text().nullable()();
  TextColumn get subject => text().nullable()();
  TextColumn get accountId => text().nullable()();
  TextColumn get appAccountId => text().nullable()();
  TextColumn get accountName => text().nullable()();
  DateTimeColumn get createdDate => dateTime().nullable()();
  BoolColumn get synced =>
      boolean().nullable().withDefault(const Constant(false))();

  @override
  Set<Column<Object>>? get primaryKey => {appTicketId};
}

class Competitiors extends Table {
  TextColumn get id => text().nullable()();
  TextColumn get name => text().nullable()();

  @override
  Set<Column<Object>>? get primaryKey => {id};
}

class Competitions extends Table {
  TextColumn get appCompetitionId =>
      text().nullable().clientDefault(() => uuid.v6())();
  TextColumn get salesAppId =>
      text().nullable().references(Visits, #salesAppId)();
  @JsonKey('Id')
  TextColumn get id => text().nullable()();
  TextColumn get productId => text().nullable()();
  TextColumn get productName => text().nullable()();
  TextColumn get currentStock => text().nullable()();
  RealColumn get rate => real().nullable()();
  TextColumn get accountId => text().nullable()();
  TextColumn get accountName => text().nullable()();
  TextColumn get competitorId => text().nullable()();
  TextColumn get competitorName => text().nullable()();
  BoolColumn get synced =>
      boolean().nullable().withDefault(const Constant(false))();

  @override
  Set<Column<Object>>? get primaryKey => {appCompetitionId};
}

class PaymentFollowUps extends Table {
  @JsonKey('appPaymentFllowUpId')
  TextColumn get appPaymentFollowUpId =>
      text().nullable().clientDefault(() => uuid.v6())();
  @JsonKey('Id')
  TextColumn get id => text().nullable()();
  TextColumn get name => text().nullable()();
  @JsonKey('expectedPaymentdate')
  DateTimeColumn get expectedPaymentDate => dateTime().nullable()();
  TextColumn get expectedAmount => text().nullable()();
  TextColumn get comment => text().nullable()();
  TextColumn get appAccountId => text().nullable()();
  TextColumn get accountId => text().nullable()();
  TextColumn get accountName => text().nullable()();
  TextColumn get visitId => text().nullable()();
  TextColumn get appVisitId => text().nullable()();
  BoolColumn get synced =>
      boolean().nullable().withDefault(const Constant(false))();

  @override
  Set<Column<Object>>? get primaryKey => {appPaymentFollowUpId};
}

class PaymentReceipts extends Table {
  @JsonKey('Id')
  TextColumn get id => text().nullable()();
  TextColumn get status => text().nullable()();
  TextColumn get remark => text().nullable()();
  TextColumn get paymentType => text().nullable()();
  DateTimeColumn get paymentDate => dateTime().nullable()();
  TextColumn get name => text().nullable()();
  TextColumn get invoiceName => text().nullable()();
  TextColumn get checkNo => text().nullable()();
  DateTimeColumn get checkDate => dateTime().nullable()();
  @JsonKey('appInvoiceid')
  TextColumn get appInvoiceId => text().nullable()();
  TextColumn get appAccountId => text().nullable()();
  RealColumn get amount => real().nullable()();
  TextColumn get accountName => text().nullable()();
  TextColumn get accountId => text().nullable()();
  DateTimeColumn get createdDate => dateTime().nullable()();

  @override
  Set<Column<Object>>? get primaryKey => {id};
}

class Invoices extends Table {
  TextColumn get id => text().nullable()();
  TextColumn get appInvoiceId =>
      text().nullable().clientDefault(() => uuid.v6())();
  @JsonKey('Name')
  TextColumn get name => text().nullable()();
  TextColumn get status => text().nullable()();
  IntColumn get totalQuantity => integer().nullable()();
  RealColumn get totalAmount => real().nullable()();
  RealColumn get grandTotal => real().nullable()();
  RealColumn get balance => real().nullable()();
  DateTimeColumn get invoiceDate => dateTime().nullable()();
  DateTimeColumn get dueDate => dateTime().nullable()();
  TextColumn get accountName => text().nullable()();
  TextColumn get accountId => text().nullable()();
  DateTimeColumn get createdDate => dateTime().nullable()();

  @override
  Set<Column<Object>>? get primaryKey => {appInvoiceId};
}

class InvoiceItems extends Table {
  IntColumn get id => integer().nullable().autoIncrement()();
  TextColumn get appInvoiceId => text().nullable()();
  TextColumn get productId => text().nullable()();
  TextColumn get productName => text().nullable()();
  IntColumn get quantity => integer().nullable()();
  RealColumn get unitPrice => real().nullable()();
  RealColumn get taxPercent => real().nullable()();
  RealColumn get taxAmount => real().nullable()();
  RealColumn get totalAmount => real().nullable()();
  RealColumn get totalTax => real().nullable()();
  RealColumn get grandTotal => real().nullable()();

  @override
  Set<Column<Object>>? get primaryKey => {id};
}

class Leaves extends Table {
  TextColumn get id => text().nullable()();
  TextColumn get appLeaveId =>
      text().nullable().clientDefault(() => uuid.v6())();
  TextColumn get name => text().nullable()();
  DateTimeColumn get startDate => dateTime().nullable()();
  DateTimeColumn get endDate => dateTime().nullable()();
  TextColumn get comments => text().nullable()();
  TextColumn get reason => text().nullable()();
  TextColumn get leaveType => text().nullable()();
  TextColumn get leaveStatus => text().nullable()();
  DateTimeColumn get lastModifiedDate => dateTime().nullable()();
  TextColumn get firstSecond => text().nullable()();
  TextColumn get duration => text().nullable()();
  TextColumn get executiveName => text().nullable()();
  TextColumn get executiveId => text().nullable()();
  DateTimeColumn get createdDate => dateTime().nullable()();
  BoolColumn get synced =>
      boolean().nullable().withDefault(const Constant(false))();

  @override
  Set<Column<Object>>? get primaryKey => {appLeaveId};
}
