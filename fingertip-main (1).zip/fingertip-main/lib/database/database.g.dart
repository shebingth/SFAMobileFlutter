// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $AccountsTable extends Accounts with TableInfo<$AccountsTable, Account> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AccountsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _appAccountIdMeta =
      const VerificationMeta('appAccountId');
  @override
  late final GeneratedColumn<String> appAccountId = GeneratedColumn<String>(
      'app_account_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      clientDefault: () => uuid.v6());
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _accountOwnerIdMeta =
      const VerificationMeta('accountOwnerId');
  @override
  late final GeneratedColumn<String> accountOwnerId = GeneratedColumn<String>(
      'account_owner_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _accountOwnerNameMeta =
      const VerificationMeta('accountOwnerName');
  @override
  late final GeneratedColumn<String> accountOwnerName = GeneratedColumn<String>(
      'account_owner_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _contactPersonNameMeta =
      const VerificationMeta('contactPersonName');
  @override
  late final GeneratedColumn<String> contactPersonName =
      GeneratedColumn<String>('contact_person_name', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _mobileMeta = const VerificationMeta('mobile');
  @override
  late final GeneratedColumn<String> mobile = GeneratedColumn<String>(
      'mobile', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _alternateMobileMeta =
      const VerificationMeta('alternateMobile');
  @override
  late final GeneratedColumn<String> alternateMobile = GeneratedColumn<String>(
      'alternate_mobile', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _gstNoMeta = const VerificationMeta('gstNo');
  @override
  late final GeneratedColumn<String> gstNo = GeneratedColumn<String>(
      'gst_no', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _descriptionMeta =
      const VerificationMeta('description');
  @override
  late final GeneratedColumn<String> description = GeneratedColumn<String>(
      'description', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _liquidationMeta =
      const VerificationMeta('liquidation');
  @override
  late final GeneratedColumn<String> liquidation = GeneratedColumn<String>(
      'liquidation', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _paymentTypeMeta =
      const VerificationMeta('paymentType');
  @override
  late final GeneratedColumn<String> paymentType = GeneratedColumn<String>(
      'payment_type', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _accountClassificationMeta =
      const VerificationMeta('accountClassification');
  @override
  late final GeneratedColumn<String> accountClassification =
      GeneratedColumn<String>('account_classification', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _gradeMeta = const VerificationMeta('grade');
  @override
  late final GeneratedColumn<String> grade = GeneratedColumn<String>(
      'grade', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _routesIdMeta =
      const VerificationMeta('routesId');
  @override
  late final GeneratedColumn<String> routesId = GeneratedColumn<String>(
      'routes_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _routesNameMeta =
      const VerificationMeta('routesName');
  @override
  late final GeneratedColumn<String> routesName = GeneratedColumn<String>(
      'routes_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _longitudeMeta =
      const VerificationMeta('longitude');
  @override
  late final GeneratedColumn<String> longitude = GeneratedColumn<String>(
      'longitude', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _latitudeMeta =
      const VerificationMeta('latitude');
  @override
  late final GeneratedColumn<String> latitude = GeneratedColumn<String>(
      'latitude', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _parentAccountIdMeta =
      const VerificationMeta('parentAccountId');
  @override
  late final GeneratedColumn<String> parentAccountId = GeneratedColumn<String>(
      'parent_account_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _parentAccountNameMeta =
      const VerificationMeta('parentAccountName');
  @override
  late final GeneratedColumn<String> parentAccountName =
      GeneratedColumn<String>('parent_account_name', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _outstandingMeta =
      const VerificationMeta('outstanding');
  @override
  late final GeneratedColumn<String> outstanding = GeneratedColumn<String>(
      'outstanding', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _avgCreditDaysMeta =
      const VerificationMeta('avgCreditDays');
  @override
  late final GeneratedColumn<String> avgCreditDays = GeneratedColumn<String>(
      'avg_credit_days', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _openingBalanceMeta =
      const VerificationMeta('openingBalance');
  @override
  late final GeneratedColumn<String> openingBalance = GeneratedColumn<String>(
      'opening_balance', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _streetNameMeta =
      const VerificationMeta('streetName');
  @override
  late final GeneratedColumn<String> streetName = GeneratedColumn<String>(
      'street_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _panchayatMeta =
      const VerificationMeta('panchayat');
  @override
  late final GeneratedColumn<String> panchayat = GeneratedColumn<String>(
      'panchayat', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _cityMeta = const VerificationMeta('city');
  @override
  late final GeneratedColumn<String> city = GeneratedColumn<String>(
      'city', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _stateMeta = const VerificationMeta('state');
  @override
  late final GeneratedColumn<String> state = GeneratedColumn<String>(
      'state', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _districtMeta =
      const VerificationMeta('district');
  @override
  late final GeneratedColumn<String> district = GeneratedColumn<String>(
      'district', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _pincodeMeta =
      const VerificationMeta('pincode');
  @override
  late final GeneratedColumn<String> pincode = GeneratedColumn<String>(
      'pincode', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _approvalStatusMeta =
      const VerificationMeta('approvalStatus');
  @override
  late final GeneratedColumn<String> approvalStatus = GeneratedColumn<String>(
      'approval_status', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _lastModifiedDateMeta =
      const VerificationMeta('lastModifiedDate');
  @override
  late final GeneratedColumn<DateTime> lastModifiedDate =
      GeneratedColumn<DateTime>('last_modified_date', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _lastModifiedByMeta =
      const VerificationMeta('lastModifiedBy');
  @override
  late final GeneratedColumn<String> lastModifiedBy = GeneratedColumn<String>(
      'last_modified_by', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdDateMeta =
      const VerificationMeta('createdDate');
  @override
  late final GeneratedColumn<DateTime> createdDate = GeneratedColumn<DateTime>(
      'created_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _createdByMeta =
      const VerificationMeta('createdBy');
  @override
  late final GeneratedColumn<String> createdBy = GeneratedColumn<String>(
      'created_by', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _syncedMeta = const VerificationMeta('synced');
  @override
  late final GeneratedColumn<bool> synced = GeneratedColumn<bool>(
      'synced', aliasedName, true,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("synced" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        appAccountId,
        id,
        name,
        accountOwnerId,
        accountOwnerName,
        contactPersonName,
        email,
        mobile,
        alternateMobile,
        gstNo,
        description,
        liquidation,
        paymentType,
        accountClassification,
        grade,
        routesId,
        routesName,
        longitude,
        latitude,
        parentAccountId,
        parentAccountName,
        outstanding,
        avgCreditDays,
        openingBalance,
        streetName,
        panchayat,
        city,
        state,
        district,
        pincode,
        approvalStatus,
        lastModifiedDate,
        lastModifiedBy,
        createdDate,
        createdBy,
        synced
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'accounts';
  @override
  VerificationContext validateIntegrity(Insertable<Account> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('app_account_id')) {
      context.handle(
          _appAccountIdMeta,
          appAccountId.isAcceptableOrUnknown(
              data['app_account_id']!, _appAccountIdMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    }
    if (data.containsKey('account_owner_id')) {
      context.handle(
          _accountOwnerIdMeta,
          accountOwnerId.isAcceptableOrUnknown(
              data['account_owner_id']!, _accountOwnerIdMeta));
    }
    if (data.containsKey('account_owner_name')) {
      context.handle(
          _accountOwnerNameMeta,
          accountOwnerName.isAcceptableOrUnknown(
              data['account_owner_name']!, _accountOwnerNameMeta));
    }
    if (data.containsKey('contact_person_name')) {
      context.handle(
          _contactPersonNameMeta,
          contactPersonName.isAcceptableOrUnknown(
              data['contact_person_name']!, _contactPersonNameMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('mobile')) {
      context.handle(_mobileMeta,
          mobile.isAcceptableOrUnknown(data['mobile']!, _mobileMeta));
    }
    if (data.containsKey('alternate_mobile')) {
      context.handle(
          _alternateMobileMeta,
          alternateMobile.isAcceptableOrUnknown(
              data['alternate_mobile']!, _alternateMobileMeta));
    }
    if (data.containsKey('gst_no')) {
      context.handle(
          _gstNoMeta, gstNo.isAcceptableOrUnknown(data['gst_no']!, _gstNoMeta));
    }
    if (data.containsKey('description')) {
      context.handle(
          _descriptionMeta,
          description.isAcceptableOrUnknown(
              data['description']!, _descriptionMeta));
    }
    if (data.containsKey('liquidation')) {
      context.handle(
          _liquidationMeta,
          liquidation.isAcceptableOrUnknown(
              data['liquidation']!, _liquidationMeta));
    }
    if (data.containsKey('payment_type')) {
      context.handle(
          _paymentTypeMeta,
          paymentType.isAcceptableOrUnknown(
              data['payment_type']!, _paymentTypeMeta));
    }
    if (data.containsKey('account_classification')) {
      context.handle(
          _accountClassificationMeta,
          accountClassification.isAcceptableOrUnknown(
              data['account_classification']!, _accountClassificationMeta));
    }
    if (data.containsKey('grade')) {
      context.handle(
          _gradeMeta, grade.isAcceptableOrUnknown(data['grade']!, _gradeMeta));
    }
    if (data.containsKey('routes_id')) {
      context.handle(_routesIdMeta,
          routesId.isAcceptableOrUnknown(data['routes_id']!, _routesIdMeta));
    }
    if (data.containsKey('routes_name')) {
      context.handle(
          _routesNameMeta,
          routesName.isAcceptableOrUnknown(
              data['routes_name']!, _routesNameMeta));
    }
    if (data.containsKey('longitude')) {
      context.handle(_longitudeMeta,
          longitude.isAcceptableOrUnknown(data['longitude']!, _longitudeMeta));
    }
    if (data.containsKey('latitude')) {
      context.handle(_latitudeMeta,
          latitude.isAcceptableOrUnknown(data['latitude']!, _latitudeMeta));
    }
    if (data.containsKey('parent_account_id')) {
      context.handle(
          _parentAccountIdMeta,
          parentAccountId.isAcceptableOrUnknown(
              data['parent_account_id']!, _parentAccountIdMeta));
    }
    if (data.containsKey('parent_account_name')) {
      context.handle(
          _parentAccountNameMeta,
          parentAccountName.isAcceptableOrUnknown(
              data['parent_account_name']!, _parentAccountNameMeta));
    }
    if (data.containsKey('outstanding')) {
      context.handle(
          _outstandingMeta,
          outstanding.isAcceptableOrUnknown(
              data['outstanding']!, _outstandingMeta));
    }
    if (data.containsKey('avg_credit_days')) {
      context.handle(
          _avgCreditDaysMeta,
          avgCreditDays.isAcceptableOrUnknown(
              data['avg_credit_days']!, _avgCreditDaysMeta));
    }
    if (data.containsKey('opening_balance')) {
      context.handle(
          _openingBalanceMeta,
          openingBalance.isAcceptableOrUnknown(
              data['opening_balance']!, _openingBalanceMeta));
    }
    if (data.containsKey('street_name')) {
      context.handle(
          _streetNameMeta,
          streetName.isAcceptableOrUnknown(
              data['street_name']!, _streetNameMeta));
    }
    if (data.containsKey('panchayat')) {
      context.handle(_panchayatMeta,
          panchayat.isAcceptableOrUnknown(data['panchayat']!, _panchayatMeta));
    }
    if (data.containsKey('city')) {
      context.handle(
          _cityMeta, city.isAcceptableOrUnknown(data['city']!, _cityMeta));
    }
    if (data.containsKey('state')) {
      context.handle(
          _stateMeta, state.isAcceptableOrUnknown(data['state']!, _stateMeta));
    }
    if (data.containsKey('district')) {
      context.handle(_districtMeta,
          district.isAcceptableOrUnknown(data['district']!, _districtMeta));
    }
    if (data.containsKey('pincode')) {
      context.handle(_pincodeMeta,
          pincode.isAcceptableOrUnknown(data['pincode']!, _pincodeMeta));
    }
    if (data.containsKey('approval_status')) {
      context.handle(
          _approvalStatusMeta,
          approvalStatus.isAcceptableOrUnknown(
              data['approval_status']!, _approvalStatusMeta));
    }
    if (data.containsKey('last_modified_date')) {
      context.handle(
          _lastModifiedDateMeta,
          lastModifiedDate.isAcceptableOrUnknown(
              data['last_modified_date']!, _lastModifiedDateMeta));
    }
    if (data.containsKey('last_modified_by')) {
      context.handle(
          _lastModifiedByMeta,
          lastModifiedBy.isAcceptableOrUnknown(
              data['last_modified_by']!, _lastModifiedByMeta));
    }
    if (data.containsKey('created_date')) {
      context.handle(
          _createdDateMeta,
          createdDate.isAcceptableOrUnknown(
              data['created_date']!, _createdDateMeta));
    }
    if (data.containsKey('created_by')) {
      context.handle(_createdByMeta,
          createdBy.isAcceptableOrUnknown(data['created_by']!, _createdByMeta));
    }
    if (data.containsKey('synced')) {
      context.handle(_syncedMeta,
          synced.isAcceptableOrUnknown(data['synced']!, _syncedMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {appAccountId};
  @override
  Account map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Account(
      appAccountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_account_id']),
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id']),
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name']),
      accountOwnerId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}account_owner_id']),
      accountOwnerName: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}account_owner_name']),
      contactPersonName: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}contact_person_name']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      mobile: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}mobile']),
      alternateMobile: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}alternate_mobile']),
      gstNo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}gst_no']),
      description: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}description']),
      liquidation: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}liquidation']),
      paymentType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}payment_type']),
      accountClassification: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}account_classification']),
      grade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}grade']),
      routesId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}routes_id']),
      routesName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}routes_name']),
      longitude: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}longitude']),
      latitude: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}latitude']),
      parentAccountId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}parent_account_id']),
      parentAccountName: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}parent_account_name']),
      outstanding: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}outstanding']),
      avgCreditDays: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}avg_credit_days']),
      openingBalance: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}opening_balance']),
      streetName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}street_name']),
      panchayat: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}panchayat']),
      city: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}city']),
      state: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}state']),
      district: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}district']),
      pincode: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pincode']),
      approvalStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}approval_status']),
      lastModifiedDate: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}last_modified_date']),
      lastModifiedBy: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}last_modified_by']),
      createdDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_date']),
      createdBy: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_by']),
      synced: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}synced']),
    );
  }

  @override
  $AccountsTable createAlias(String alias) {
    return $AccountsTable(attachedDatabase, alias);
  }
}

class Account extends DataClass implements Insertable<Account> {
  final String? appAccountId;
  final String? id;
  final String? name;
  final String? accountOwnerId;
  final String? accountOwnerName;
  final String? contactPersonName;
  final String? email;
  final String? mobile;
  final String? alternateMobile;
  final String? gstNo;
  final String? description;
  final String? liquidation;
  final String? paymentType;
  final String? accountClassification;
  final String? grade;
  final String? routesId;
  final String? routesName;
  final String? longitude;
  final String? latitude;
  final String? parentAccountId;
  final String? parentAccountName;
  final String? outstanding;
  final String? avgCreditDays;
  final String? openingBalance;
  final String? streetName;
  final String? panchayat;
  final String? city;
  final String? state;
  final String? district;
  final String? pincode;
  final String? approvalStatus;
  final DateTime? lastModifiedDate;
  final String? lastModifiedBy;
  final DateTime? createdDate;
  final String? createdBy;
  final bool? synced;
  const Account(
      {this.appAccountId,
      this.id,
      this.name,
      this.accountOwnerId,
      this.accountOwnerName,
      this.contactPersonName,
      this.email,
      this.mobile,
      this.alternateMobile,
      this.gstNo,
      this.description,
      this.liquidation,
      this.paymentType,
      this.accountClassification,
      this.grade,
      this.routesId,
      this.routesName,
      this.longitude,
      this.latitude,
      this.parentAccountId,
      this.parentAccountName,
      this.outstanding,
      this.avgCreditDays,
      this.openingBalance,
      this.streetName,
      this.panchayat,
      this.city,
      this.state,
      this.district,
      this.pincode,
      this.approvalStatus,
      this.lastModifiedDate,
      this.lastModifiedBy,
      this.createdDate,
      this.createdBy,
      this.synced});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || appAccountId != null) {
      map['app_account_id'] = Variable<String>(appAccountId);
    }
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<String>(id);
    }
    if (!nullToAbsent || name != null) {
      map['name'] = Variable<String>(name);
    }
    if (!nullToAbsent || accountOwnerId != null) {
      map['account_owner_id'] = Variable<String>(accountOwnerId);
    }
    if (!nullToAbsent || accountOwnerName != null) {
      map['account_owner_name'] = Variable<String>(accountOwnerName);
    }
    if (!nullToAbsent || contactPersonName != null) {
      map['contact_person_name'] = Variable<String>(contactPersonName);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || mobile != null) {
      map['mobile'] = Variable<String>(mobile);
    }
    if (!nullToAbsent || alternateMobile != null) {
      map['alternate_mobile'] = Variable<String>(alternateMobile);
    }
    if (!nullToAbsent || gstNo != null) {
      map['gst_no'] = Variable<String>(gstNo);
    }
    if (!nullToAbsent || description != null) {
      map['description'] = Variable<String>(description);
    }
    if (!nullToAbsent || liquidation != null) {
      map['liquidation'] = Variable<String>(liquidation);
    }
    if (!nullToAbsent || paymentType != null) {
      map['payment_type'] = Variable<String>(paymentType);
    }
    if (!nullToAbsent || accountClassification != null) {
      map['account_classification'] = Variable<String>(accountClassification);
    }
    if (!nullToAbsent || grade != null) {
      map['grade'] = Variable<String>(grade);
    }
    if (!nullToAbsent || routesId != null) {
      map['routes_id'] = Variable<String>(routesId);
    }
    if (!nullToAbsent || routesName != null) {
      map['routes_name'] = Variable<String>(routesName);
    }
    if (!nullToAbsent || longitude != null) {
      map['longitude'] = Variable<String>(longitude);
    }
    if (!nullToAbsent || latitude != null) {
      map['latitude'] = Variable<String>(latitude);
    }
    if (!nullToAbsent || parentAccountId != null) {
      map['parent_account_id'] = Variable<String>(parentAccountId);
    }
    if (!nullToAbsent || parentAccountName != null) {
      map['parent_account_name'] = Variable<String>(parentAccountName);
    }
    if (!nullToAbsent || outstanding != null) {
      map['outstanding'] = Variable<String>(outstanding);
    }
    if (!nullToAbsent || avgCreditDays != null) {
      map['avg_credit_days'] = Variable<String>(avgCreditDays);
    }
    if (!nullToAbsent || openingBalance != null) {
      map['opening_balance'] = Variable<String>(openingBalance);
    }
    if (!nullToAbsent || streetName != null) {
      map['street_name'] = Variable<String>(streetName);
    }
    if (!nullToAbsent || panchayat != null) {
      map['panchayat'] = Variable<String>(panchayat);
    }
    if (!nullToAbsent || city != null) {
      map['city'] = Variable<String>(city);
    }
    if (!nullToAbsent || state != null) {
      map['state'] = Variable<String>(state);
    }
    if (!nullToAbsent || district != null) {
      map['district'] = Variable<String>(district);
    }
    if (!nullToAbsent || pincode != null) {
      map['pincode'] = Variable<String>(pincode);
    }
    if (!nullToAbsent || approvalStatus != null) {
      map['approval_status'] = Variable<String>(approvalStatus);
    }
    if (!nullToAbsent || lastModifiedDate != null) {
      map['last_modified_date'] = Variable<DateTime>(lastModifiedDate);
    }
    if (!nullToAbsent || lastModifiedBy != null) {
      map['last_modified_by'] = Variable<String>(lastModifiedBy);
    }
    if (!nullToAbsent || createdDate != null) {
      map['created_date'] = Variable<DateTime>(createdDate);
    }
    if (!nullToAbsent || createdBy != null) {
      map['created_by'] = Variable<String>(createdBy);
    }
    if (!nullToAbsent || synced != null) {
      map['synced'] = Variable<bool>(synced);
    }
    return map;
  }

  AccountsCompanion toCompanion(bool nullToAbsent) {
    return AccountsCompanion(
      appAccountId: appAccountId == null && nullToAbsent
          ? const Value.absent()
          : Value(appAccountId),
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      name: name == null && nullToAbsent ? const Value.absent() : Value(name),
      accountOwnerId: accountOwnerId == null && nullToAbsent
          ? const Value.absent()
          : Value(accountOwnerId),
      accountOwnerName: accountOwnerName == null && nullToAbsent
          ? const Value.absent()
          : Value(accountOwnerName),
      contactPersonName: contactPersonName == null && nullToAbsent
          ? const Value.absent()
          : Value(contactPersonName),
      email:
          email == null && nullToAbsent ? const Value.absent() : Value(email),
      mobile:
          mobile == null && nullToAbsent ? const Value.absent() : Value(mobile),
      alternateMobile: alternateMobile == null && nullToAbsent
          ? const Value.absent()
          : Value(alternateMobile),
      gstNo:
          gstNo == null && nullToAbsent ? const Value.absent() : Value(gstNo),
      description: description == null && nullToAbsent
          ? const Value.absent()
          : Value(description),
      liquidation: liquidation == null && nullToAbsent
          ? const Value.absent()
          : Value(liquidation),
      paymentType: paymentType == null && nullToAbsent
          ? const Value.absent()
          : Value(paymentType),
      accountClassification: accountClassification == null && nullToAbsent
          ? const Value.absent()
          : Value(accountClassification),
      grade:
          grade == null && nullToAbsent ? const Value.absent() : Value(grade),
      routesId: routesId == null && nullToAbsent
          ? const Value.absent()
          : Value(routesId),
      routesName: routesName == null && nullToAbsent
          ? const Value.absent()
          : Value(routesName),
      longitude: longitude == null && nullToAbsent
          ? const Value.absent()
          : Value(longitude),
      latitude: latitude == null && nullToAbsent
          ? const Value.absent()
          : Value(latitude),
      parentAccountId: parentAccountId == null && nullToAbsent
          ? const Value.absent()
          : Value(parentAccountId),
      parentAccountName: parentAccountName == null && nullToAbsent
          ? const Value.absent()
          : Value(parentAccountName),
      outstanding: outstanding == null && nullToAbsent
          ? const Value.absent()
          : Value(outstanding),
      avgCreditDays: avgCreditDays == null && nullToAbsent
          ? const Value.absent()
          : Value(avgCreditDays),
      openingBalance: openingBalance == null && nullToAbsent
          ? const Value.absent()
          : Value(openingBalance),
      streetName: streetName == null && nullToAbsent
          ? const Value.absent()
          : Value(streetName),
      panchayat: panchayat == null && nullToAbsent
          ? const Value.absent()
          : Value(panchayat),
      city: city == null && nullToAbsent ? const Value.absent() : Value(city),
      state:
          state == null && nullToAbsent ? const Value.absent() : Value(state),
      district: district == null && nullToAbsent
          ? const Value.absent()
          : Value(district),
      pincode: pincode == null && nullToAbsent
          ? const Value.absent()
          : Value(pincode),
      approvalStatus: approvalStatus == null && nullToAbsent
          ? const Value.absent()
          : Value(approvalStatus),
      lastModifiedDate: lastModifiedDate == null && nullToAbsent
          ? const Value.absent()
          : Value(lastModifiedDate),
      lastModifiedBy: lastModifiedBy == null && nullToAbsent
          ? const Value.absent()
          : Value(lastModifiedBy),
      createdDate: createdDate == null && nullToAbsent
          ? const Value.absent()
          : Value(createdDate),
      createdBy: createdBy == null && nullToAbsent
          ? const Value.absent()
          : Value(createdBy),
      synced:
          synced == null && nullToAbsent ? const Value.absent() : Value(synced),
    );
  }

  factory Account.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Account(
      appAccountId: serializer.fromJson<String?>(json['appAccountId']),
      id: serializer.fromJson<String?>(json['id']),
      name: serializer.fromJson<String?>(json['name']),
      accountOwnerId: serializer.fromJson<String?>(json['accountOwnerId']),
      accountOwnerName: serializer.fromJson<String?>(json['accountOwnerName']),
      contactPersonName:
          serializer.fromJson<String?>(json['contactPersonName']),
      email: serializer.fromJson<String?>(json['email']),
      mobile: serializer.fromJson<String?>(json['mobile']),
      alternateMobile: serializer.fromJson<String?>(json['alternateMobile']),
      gstNo: serializer.fromJson<String?>(json['gstNo']),
      description: serializer.fromJson<String?>(json['description']),
      liquidation: serializer.fromJson<String?>(json['liquidation']),
      paymentType: serializer.fromJson<String?>(json['paymentType']),
      accountClassification:
          serializer.fromJson<String?>(json['accountClassification']),
      grade: serializer.fromJson<String?>(json['grade']),
      routesId: serializer.fromJson<String?>(json['routesId']),
      routesName: serializer.fromJson<String?>(json['routesName']),
      longitude: serializer.fromJson<String?>(json['actlong']),
      latitude: serializer.fromJson<String?>(json['actlat']),
      parentAccountId: serializer.fromJson<String?>(json['parentAccountId']),
      parentAccountName:
          serializer.fromJson<String?>(json['parentAccountName']),
      outstanding: serializer.fromJson<String?>(json['outstanding']),
      avgCreditDays: serializer.fromJson<String?>(json['avgCreditDays']),
      openingBalance: serializer.fromJson<String?>(json['openingBalance']),
      streetName: serializer.fromJson<String?>(json['streetName']),
      panchayat: serializer.fromJson<String?>(json['panchayat']),
      city: serializer.fromJson<String?>(json['city']),
      state: serializer.fromJson<String?>(json['state']),
      district: serializer.fromJson<String?>(json['district']),
      pincode: serializer.fromJson<String?>(json['pincode']),
      approvalStatus: serializer.fromJson<String?>(json['approvalStatus']),
      lastModifiedDate:
          serializer.fromJson<DateTime?>(json['lastmodifiedDate']),
      lastModifiedBy: serializer.fromJson<String?>(json['lastmodifiedBy']),
      createdDate: serializer.fromJson<DateTime?>(json['createdDate']),
      createdBy: serializer.fromJson<String?>(json['createdBy']),
      synced: serializer.fromJson<bool?>(json['synced']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'appAccountId': serializer.toJson<String?>(appAccountId),
      'id': serializer.toJson<String?>(id),
      'name': serializer.toJson<String?>(name),
      'accountOwnerId': serializer.toJson<String?>(accountOwnerId),
      'accountOwnerName': serializer.toJson<String?>(accountOwnerName),
      'contactPersonName': serializer.toJson<String?>(contactPersonName),
      'email': serializer.toJson<String?>(email),
      'mobile': serializer.toJson<String?>(mobile),
      'alternateMobile': serializer.toJson<String?>(alternateMobile),
      'gstNo': serializer.toJson<String?>(gstNo),
      'description': serializer.toJson<String?>(description),
      'liquidation': serializer.toJson<String?>(liquidation),
      'paymentType': serializer.toJson<String?>(paymentType),
      'accountClassification':
          serializer.toJson<String?>(accountClassification),
      'grade': serializer.toJson<String?>(grade),
      'routesId': serializer.toJson<String?>(routesId),
      'routesName': serializer.toJson<String?>(routesName),
      'actlong': serializer.toJson<String?>(longitude),
      'actlat': serializer.toJson<String?>(latitude),
      'parentAccountId': serializer.toJson<String?>(parentAccountId),
      'parentAccountName': serializer.toJson<String?>(parentAccountName),
      'outstanding': serializer.toJson<String?>(outstanding),
      'avgCreditDays': serializer.toJson<String?>(avgCreditDays),
      'openingBalance': serializer.toJson<String?>(openingBalance),
      'streetName': serializer.toJson<String?>(streetName),
      'panchayat': serializer.toJson<String?>(panchayat),
      'city': serializer.toJson<String?>(city),
      'state': serializer.toJson<String?>(state),
      'district': serializer.toJson<String?>(district),
      'pincode': serializer.toJson<String?>(pincode),
      'approvalStatus': serializer.toJson<String?>(approvalStatus),
      'lastmodifiedDate': serializer.toJson<DateTime?>(lastModifiedDate),
      'lastmodifiedBy': serializer.toJson<String?>(lastModifiedBy),
      'createdDate': serializer.toJson<DateTime?>(createdDate),
      'createdBy': serializer.toJson<String?>(createdBy),
      'synced': serializer.toJson<bool?>(synced),
    };
  }

  Account copyWith(
          {Value<String?> appAccountId = const Value.absent(),
          Value<String?> id = const Value.absent(),
          Value<String?> name = const Value.absent(),
          Value<String?> accountOwnerId = const Value.absent(),
          Value<String?> accountOwnerName = const Value.absent(),
          Value<String?> contactPersonName = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> mobile = const Value.absent(),
          Value<String?> alternateMobile = const Value.absent(),
          Value<String?> gstNo = const Value.absent(),
          Value<String?> description = const Value.absent(),
          Value<String?> liquidation = const Value.absent(),
          Value<String?> paymentType = const Value.absent(),
          Value<String?> accountClassification = const Value.absent(),
          Value<String?> grade = const Value.absent(),
          Value<String?> routesId = const Value.absent(),
          Value<String?> routesName = const Value.absent(),
          Value<String?> longitude = const Value.absent(),
          Value<String?> latitude = const Value.absent(),
          Value<String?> parentAccountId = const Value.absent(),
          Value<String?> parentAccountName = const Value.absent(),
          Value<String?> outstanding = const Value.absent(),
          Value<String?> avgCreditDays = const Value.absent(),
          Value<String?> openingBalance = const Value.absent(),
          Value<String?> streetName = const Value.absent(),
          Value<String?> panchayat = const Value.absent(),
          Value<String?> city = const Value.absent(),
          Value<String?> state = const Value.absent(),
          Value<String?> district = const Value.absent(),
          Value<String?> pincode = const Value.absent(),
          Value<String?> approvalStatus = const Value.absent(),
          Value<DateTime?> lastModifiedDate = const Value.absent(),
          Value<String?> lastModifiedBy = const Value.absent(),
          Value<DateTime?> createdDate = const Value.absent(),
          Value<String?> createdBy = const Value.absent(),
          Value<bool?> synced = const Value.absent()}) =>
      Account(
        appAccountId:
            appAccountId.present ? appAccountId.value : this.appAccountId,
        id: id.present ? id.value : this.id,
        name: name.present ? name.value : this.name,
        accountOwnerId:
            accountOwnerId.present ? accountOwnerId.value : this.accountOwnerId,
        accountOwnerName: accountOwnerName.present
            ? accountOwnerName.value
            : this.accountOwnerName,
        contactPersonName: contactPersonName.present
            ? contactPersonName.value
            : this.contactPersonName,
        email: email.present ? email.value : this.email,
        mobile: mobile.present ? mobile.value : this.mobile,
        alternateMobile: alternateMobile.present
            ? alternateMobile.value
            : this.alternateMobile,
        gstNo: gstNo.present ? gstNo.value : this.gstNo,
        description: description.present ? description.value : this.description,
        liquidation: liquidation.present ? liquidation.value : this.liquidation,
        paymentType: paymentType.present ? paymentType.value : this.paymentType,
        accountClassification: accountClassification.present
            ? accountClassification.value
            : this.accountClassification,
        grade: grade.present ? grade.value : this.grade,
        routesId: routesId.present ? routesId.value : this.routesId,
        routesName: routesName.present ? routesName.value : this.routesName,
        longitude: longitude.present ? longitude.value : this.longitude,
        latitude: latitude.present ? latitude.value : this.latitude,
        parentAccountId: parentAccountId.present
            ? parentAccountId.value
            : this.parentAccountId,
        parentAccountName: parentAccountName.present
            ? parentAccountName.value
            : this.parentAccountName,
        outstanding: outstanding.present ? outstanding.value : this.outstanding,
        avgCreditDays:
            avgCreditDays.present ? avgCreditDays.value : this.avgCreditDays,
        openingBalance:
            openingBalance.present ? openingBalance.value : this.openingBalance,
        streetName: streetName.present ? streetName.value : this.streetName,
        panchayat: panchayat.present ? panchayat.value : this.panchayat,
        city: city.present ? city.value : this.city,
        state: state.present ? state.value : this.state,
        district: district.present ? district.value : this.district,
        pincode: pincode.present ? pincode.value : this.pincode,
        approvalStatus:
            approvalStatus.present ? approvalStatus.value : this.approvalStatus,
        lastModifiedDate: lastModifiedDate.present
            ? lastModifiedDate.value
            : this.lastModifiedDate,
        lastModifiedBy:
            lastModifiedBy.present ? lastModifiedBy.value : this.lastModifiedBy,
        createdDate: createdDate.present ? createdDate.value : this.createdDate,
        createdBy: createdBy.present ? createdBy.value : this.createdBy,
        synced: synced.present ? synced.value : this.synced,
      );
  @override
  String toString() {
    return (StringBuffer('Account(')
          ..write('appAccountId: $appAccountId, ')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('accountOwnerId: $accountOwnerId, ')
          ..write('accountOwnerName: $accountOwnerName, ')
          ..write('contactPersonName: $contactPersonName, ')
          ..write('email: $email, ')
          ..write('mobile: $mobile, ')
          ..write('alternateMobile: $alternateMobile, ')
          ..write('gstNo: $gstNo, ')
          ..write('description: $description, ')
          ..write('liquidation: $liquidation, ')
          ..write('paymentType: $paymentType, ')
          ..write('accountClassification: $accountClassification, ')
          ..write('grade: $grade, ')
          ..write('routesId: $routesId, ')
          ..write('routesName: $routesName, ')
          ..write('longitude: $longitude, ')
          ..write('latitude: $latitude, ')
          ..write('parentAccountId: $parentAccountId, ')
          ..write('parentAccountName: $parentAccountName, ')
          ..write('outstanding: $outstanding, ')
          ..write('avgCreditDays: $avgCreditDays, ')
          ..write('openingBalance: $openingBalance, ')
          ..write('streetName: $streetName, ')
          ..write('panchayat: $panchayat, ')
          ..write('city: $city, ')
          ..write('state: $state, ')
          ..write('district: $district, ')
          ..write('pincode: $pincode, ')
          ..write('approvalStatus: $approvalStatus, ')
          ..write('lastModifiedDate: $lastModifiedDate, ')
          ..write('lastModifiedBy: $lastModifiedBy, ')
          ..write('createdDate: $createdDate, ')
          ..write('createdBy: $createdBy, ')
          ..write('synced: $synced')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        appAccountId,
        id,
        name,
        accountOwnerId,
        accountOwnerName,
        contactPersonName,
        email,
        mobile,
        alternateMobile,
        gstNo,
        description,
        liquidation,
        paymentType,
        accountClassification,
        grade,
        routesId,
        routesName,
        longitude,
        latitude,
        parentAccountId,
        parentAccountName,
        outstanding,
        avgCreditDays,
        openingBalance,
        streetName,
        panchayat,
        city,
        state,
        district,
        pincode,
        approvalStatus,
        lastModifiedDate,
        lastModifiedBy,
        createdDate,
        createdBy,
        synced
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Account &&
          other.appAccountId == this.appAccountId &&
          other.id == this.id &&
          other.name == this.name &&
          other.accountOwnerId == this.accountOwnerId &&
          other.accountOwnerName == this.accountOwnerName &&
          other.contactPersonName == this.contactPersonName &&
          other.email == this.email &&
          other.mobile == this.mobile &&
          other.alternateMobile == this.alternateMobile &&
          other.gstNo == this.gstNo &&
          other.description == this.description &&
          other.liquidation == this.liquidation &&
          other.paymentType == this.paymentType &&
          other.accountClassification == this.accountClassification &&
          other.grade == this.grade &&
          other.routesId == this.routesId &&
          other.routesName == this.routesName &&
          other.longitude == this.longitude &&
          other.latitude == this.latitude &&
          other.parentAccountId == this.parentAccountId &&
          other.parentAccountName == this.parentAccountName &&
          other.outstanding == this.outstanding &&
          other.avgCreditDays == this.avgCreditDays &&
          other.openingBalance == this.openingBalance &&
          other.streetName == this.streetName &&
          other.panchayat == this.panchayat &&
          other.city == this.city &&
          other.state == this.state &&
          other.district == this.district &&
          other.pincode == this.pincode &&
          other.approvalStatus == this.approvalStatus &&
          other.lastModifiedDate == this.lastModifiedDate &&
          other.lastModifiedBy == this.lastModifiedBy &&
          other.createdDate == this.createdDate &&
          other.createdBy == this.createdBy &&
          other.synced == this.synced);
}

class AccountsCompanion extends UpdateCompanion<Account> {
  final Value<String?> appAccountId;
  final Value<String?> id;
  final Value<String?> name;
  final Value<String?> accountOwnerId;
  final Value<String?> accountOwnerName;
  final Value<String?> contactPersonName;
  final Value<String?> email;
  final Value<String?> mobile;
  final Value<String?> alternateMobile;
  final Value<String?> gstNo;
  final Value<String?> description;
  final Value<String?> liquidation;
  final Value<String?> paymentType;
  final Value<String?> accountClassification;
  final Value<String?> grade;
  final Value<String?> routesId;
  final Value<String?> routesName;
  final Value<String?> longitude;
  final Value<String?> latitude;
  final Value<String?> parentAccountId;
  final Value<String?> parentAccountName;
  final Value<String?> outstanding;
  final Value<String?> avgCreditDays;
  final Value<String?> openingBalance;
  final Value<String?> streetName;
  final Value<String?> panchayat;
  final Value<String?> city;
  final Value<String?> state;
  final Value<String?> district;
  final Value<String?> pincode;
  final Value<String?> approvalStatus;
  final Value<DateTime?> lastModifiedDate;
  final Value<String?> lastModifiedBy;
  final Value<DateTime?> createdDate;
  final Value<String?> createdBy;
  final Value<bool?> synced;
  final Value<int> rowid;
  const AccountsCompanion({
    this.appAccountId = const Value.absent(),
    this.id = const Value.absent(),
    this.name = const Value.absent(),
    this.accountOwnerId = const Value.absent(),
    this.accountOwnerName = const Value.absent(),
    this.contactPersonName = const Value.absent(),
    this.email = const Value.absent(),
    this.mobile = const Value.absent(),
    this.alternateMobile = const Value.absent(),
    this.gstNo = const Value.absent(),
    this.description = const Value.absent(),
    this.liquidation = const Value.absent(),
    this.paymentType = const Value.absent(),
    this.accountClassification = const Value.absent(),
    this.grade = const Value.absent(),
    this.routesId = const Value.absent(),
    this.routesName = const Value.absent(),
    this.longitude = const Value.absent(),
    this.latitude = const Value.absent(),
    this.parentAccountId = const Value.absent(),
    this.parentAccountName = const Value.absent(),
    this.outstanding = const Value.absent(),
    this.avgCreditDays = const Value.absent(),
    this.openingBalance = const Value.absent(),
    this.streetName = const Value.absent(),
    this.panchayat = const Value.absent(),
    this.city = const Value.absent(),
    this.state = const Value.absent(),
    this.district = const Value.absent(),
    this.pincode = const Value.absent(),
    this.approvalStatus = const Value.absent(),
    this.lastModifiedDate = const Value.absent(),
    this.lastModifiedBy = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.createdBy = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  AccountsCompanion.insert({
    this.appAccountId = const Value.absent(),
    this.id = const Value.absent(),
    this.name = const Value.absent(),
    this.accountOwnerId = const Value.absent(),
    this.accountOwnerName = const Value.absent(),
    this.contactPersonName = const Value.absent(),
    this.email = const Value.absent(),
    this.mobile = const Value.absent(),
    this.alternateMobile = const Value.absent(),
    this.gstNo = const Value.absent(),
    this.description = const Value.absent(),
    this.liquidation = const Value.absent(),
    this.paymentType = const Value.absent(),
    this.accountClassification = const Value.absent(),
    this.grade = const Value.absent(),
    this.routesId = const Value.absent(),
    this.routesName = const Value.absent(),
    this.longitude = const Value.absent(),
    this.latitude = const Value.absent(),
    this.parentAccountId = const Value.absent(),
    this.parentAccountName = const Value.absent(),
    this.outstanding = const Value.absent(),
    this.avgCreditDays = const Value.absent(),
    this.openingBalance = const Value.absent(),
    this.streetName = const Value.absent(),
    this.panchayat = const Value.absent(),
    this.city = const Value.absent(),
    this.state = const Value.absent(),
    this.district = const Value.absent(),
    this.pincode = const Value.absent(),
    this.approvalStatus = const Value.absent(),
    this.lastModifiedDate = const Value.absent(),
    this.lastModifiedBy = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.createdBy = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  static Insertable<Account> custom({
    Expression<String>? appAccountId,
    Expression<String>? id,
    Expression<String>? name,
    Expression<String>? accountOwnerId,
    Expression<String>? accountOwnerName,
    Expression<String>? contactPersonName,
    Expression<String>? email,
    Expression<String>? mobile,
    Expression<String>? alternateMobile,
    Expression<String>? gstNo,
    Expression<String>? description,
    Expression<String>? liquidation,
    Expression<String>? paymentType,
    Expression<String>? accountClassification,
    Expression<String>? grade,
    Expression<String>? routesId,
    Expression<String>? routesName,
    Expression<String>? longitude,
    Expression<String>? latitude,
    Expression<String>? parentAccountId,
    Expression<String>? parentAccountName,
    Expression<String>? outstanding,
    Expression<String>? avgCreditDays,
    Expression<String>? openingBalance,
    Expression<String>? streetName,
    Expression<String>? panchayat,
    Expression<String>? city,
    Expression<String>? state,
    Expression<String>? district,
    Expression<String>? pincode,
    Expression<String>? approvalStatus,
    Expression<DateTime>? lastModifiedDate,
    Expression<String>? lastModifiedBy,
    Expression<DateTime>? createdDate,
    Expression<String>? createdBy,
    Expression<bool>? synced,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (appAccountId != null) 'app_account_id': appAccountId,
      if (id != null) 'id': id,
      if (name != null) 'name': name,
      if (accountOwnerId != null) 'account_owner_id': accountOwnerId,
      if (accountOwnerName != null) 'account_owner_name': accountOwnerName,
      if (contactPersonName != null) 'contact_person_name': contactPersonName,
      if (email != null) 'email': email,
      if (mobile != null) 'mobile': mobile,
      if (alternateMobile != null) 'alternate_mobile': alternateMobile,
      if (gstNo != null) 'gst_no': gstNo,
      if (description != null) 'description': description,
      if (liquidation != null) 'liquidation': liquidation,
      if (paymentType != null) 'payment_type': paymentType,
      if (accountClassification != null)
        'account_classification': accountClassification,
      if (grade != null) 'grade': grade,
      if (routesId != null) 'routes_id': routesId,
      if (routesName != null) 'routes_name': routesName,
      if (longitude != null) 'longitude': longitude,
      if (latitude != null) 'latitude': latitude,
      if (parentAccountId != null) 'parent_account_id': parentAccountId,
      if (parentAccountName != null) 'parent_account_name': parentAccountName,
      if (outstanding != null) 'outstanding': outstanding,
      if (avgCreditDays != null) 'avg_credit_days': avgCreditDays,
      if (openingBalance != null) 'opening_balance': openingBalance,
      if (streetName != null) 'street_name': streetName,
      if (panchayat != null) 'panchayat': panchayat,
      if (city != null) 'city': city,
      if (state != null) 'state': state,
      if (district != null) 'district': district,
      if (pincode != null) 'pincode': pincode,
      if (approvalStatus != null) 'approval_status': approvalStatus,
      if (lastModifiedDate != null) 'last_modified_date': lastModifiedDate,
      if (lastModifiedBy != null) 'last_modified_by': lastModifiedBy,
      if (createdDate != null) 'created_date': createdDate,
      if (createdBy != null) 'created_by': createdBy,
      if (synced != null) 'synced': synced,
      if (rowid != null) 'rowid': rowid,
    });
  }

  AccountsCompanion copyWith(
      {Value<String?>? appAccountId,
      Value<String?>? id,
      Value<String?>? name,
      Value<String?>? accountOwnerId,
      Value<String?>? accountOwnerName,
      Value<String?>? contactPersonName,
      Value<String?>? email,
      Value<String?>? mobile,
      Value<String?>? alternateMobile,
      Value<String?>? gstNo,
      Value<String?>? description,
      Value<String?>? liquidation,
      Value<String?>? paymentType,
      Value<String?>? accountClassification,
      Value<String?>? grade,
      Value<String?>? routesId,
      Value<String?>? routesName,
      Value<String?>? longitude,
      Value<String?>? latitude,
      Value<String?>? parentAccountId,
      Value<String?>? parentAccountName,
      Value<String?>? outstanding,
      Value<String?>? avgCreditDays,
      Value<String?>? openingBalance,
      Value<String?>? streetName,
      Value<String?>? panchayat,
      Value<String?>? city,
      Value<String?>? state,
      Value<String?>? district,
      Value<String?>? pincode,
      Value<String?>? approvalStatus,
      Value<DateTime?>? lastModifiedDate,
      Value<String?>? lastModifiedBy,
      Value<DateTime?>? createdDate,
      Value<String?>? createdBy,
      Value<bool?>? synced,
      Value<int>? rowid}) {
    return AccountsCompanion(
      appAccountId: appAccountId ?? this.appAccountId,
      id: id ?? this.id,
      name: name ?? this.name,
      accountOwnerId: accountOwnerId ?? this.accountOwnerId,
      accountOwnerName: accountOwnerName ?? this.accountOwnerName,
      contactPersonName: contactPersonName ?? this.contactPersonName,
      email: email ?? this.email,
      mobile: mobile ?? this.mobile,
      alternateMobile: alternateMobile ?? this.alternateMobile,
      gstNo: gstNo ?? this.gstNo,
      description: description ?? this.description,
      liquidation: liquidation ?? this.liquidation,
      paymentType: paymentType ?? this.paymentType,
      accountClassification:
          accountClassification ?? this.accountClassification,
      grade: grade ?? this.grade,
      routesId: routesId ?? this.routesId,
      routesName: routesName ?? this.routesName,
      longitude: longitude ?? this.longitude,
      latitude: latitude ?? this.latitude,
      parentAccountId: parentAccountId ?? this.parentAccountId,
      parentAccountName: parentAccountName ?? this.parentAccountName,
      outstanding: outstanding ?? this.outstanding,
      avgCreditDays: avgCreditDays ?? this.avgCreditDays,
      openingBalance: openingBalance ?? this.openingBalance,
      streetName: streetName ?? this.streetName,
      panchayat: panchayat ?? this.panchayat,
      city: city ?? this.city,
      state: state ?? this.state,
      district: district ?? this.district,
      pincode: pincode ?? this.pincode,
      approvalStatus: approvalStatus ?? this.approvalStatus,
      lastModifiedDate: lastModifiedDate ?? this.lastModifiedDate,
      lastModifiedBy: lastModifiedBy ?? this.lastModifiedBy,
      createdDate: createdDate ?? this.createdDate,
      createdBy: createdBy ?? this.createdBy,
      synced: synced ?? this.synced,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (appAccountId.present) {
      map['app_account_id'] = Variable<String>(appAccountId.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (accountOwnerId.present) {
      map['account_owner_id'] = Variable<String>(accountOwnerId.value);
    }
    if (accountOwnerName.present) {
      map['account_owner_name'] = Variable<String>(accountOwnerName.value);
    }
    if (contactPersonName.present) {
      map['contact_person_name'] = Variable<String>(contactPersonName.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (mobile.present) {
      map['mobile'] = Variable<String>(mobile.value);
    }
    if (alternateMobile.present) {
      map['alternate_mobile'] = Variable<String>(alternateMobile.value);
    }
    if (gstNo.present) {
      map['gst_no'] = Variable<String>(gstNo.value);
    }
    if (description.present) {
      map['description'] = Variable<String>(description.value);
    }
    if (liquidation.present) {
      map['liquidation'] = Variable<String>(liquidation.value);
    }
    if (paymentType.present) {
      map['payment_type'] = Variable<String>(paymentType.value);
    }
    if (accountClassification.present) {
      map['account_classification'] =
          Variable<String>(accountClassification.value);
    }
    if (grade.present) {
      map['grade'] = Variable<String>(grade.value);
    }
    if (routesId.present) {
      map['routes_id'] = Variable<String>(routesId.value);
    }
    if (routesName.present) {
      map['routes_name'] = Variable<String>(routesName.value);
    }
    if (longitude.present) {
      map['longitude'] = Variable<String>(longitude.value);
    }
    if (latitude.present) {
      map['latitude'] = Variable<String>(latitude.value);
    }
    if (parentAccountId.present) {
      map['parent_account_id'] = Variable<String>(parentAccountId.value);
    }
    if (parentAccountName.present) {
      map['parent_account_name'] = Variable<String>(parentAccountName.value);
    }
    if (outstanding.present) {
      map['outstanding'] = Variable<String>(outstanding.value);
    }
    if (avgCreditDays.present) {
      map['avg_credit_days'] = Variable<String>(avgCreditDays.value);
    }
    if (openingBalance.present) {
      map['opening_balance'] = Variable<String>(openingBalance.value);
    }
    if (streetName.present) {
      map['street_name'] = Variable<String>(streetName.value);
    }
    if (panchayat.present) {
      map['panchayat'] = Variable<String>(panchayat.value);
    }
    if (city.present) {
      map['city'] = Variable<String>(city.value);
    }
    if (state.present) {
      map['state'] = Variable<String>(state.value);
    }
    if (district.present) {
      map['district'] = Variable<String>(district.value);
    }
    if (pincode.present) {
      map['pincode'] = Variable<String>(pincode.value);
    }
    if (approvalStatus.present) {
      map['approval_status'] = Variable<String>(approvalStatus.value);
    }
    if (lastModifiedDate.present) {
      map['last_modified_date'] = Variable<DateTime>(lastModifiedDate.value);
    }
    if (lastModifiedBy.present) {
      map['last_modified_by'] = Variable<String>(lastModifiedBy.value);
    }
    if (createdDate.present) {
      map['created_date'] = Variable<DateTime>(createdDate.value);
    }
    if (createdBy.present) {
      map['created_by'] = Variable<String>(createdBy.value);
    }
    if (synced.present) {
      map['synced'] = Variable<bool>(synced.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AccountsCompanion(')
          ..write('appAccountId: $appAccountId, ')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('accountOwnerId: $accountOwnerId, ')
          ..write('accountOwnerName: $accountOwnerName, ')
          ..write('contactPersonName: $contactPersonName, ')
          ..write('email: $email, ')
          ..write('mobile: $mobile, ')
          ..write('alternateMobile: $alternateMobile, ')
          ..write('gstNo: $gstNo, ')
          ..write('description: $description, ')
          ..write('liquidation: $liquidation, ')
          ..write('paymentType: $paymentType, ')
          ..write('accountClassification: $accountClassification, ')
          ..write('grade: $grade, ')
          ..write('routesId: $routesId, ')
          ..write('routesName: $routesName, ')
          ..write('longitude: $longitude, ')
          ..write('latitude: $latitude, ')
          ..write('parentAccountId: $parentAccountId, ')
          ..write('parentAccountName: $parentAccountName, ')
          ..write('outstanding: $outstanding, ')
          ..write('avgCreditDays: $avgCreditDays, ')
          ..write('openingBalance: $openingBalance, ')
          ..write('streetName: $streetName, ')
          ..write('panchayat: $panchayat, ')
          ..write('city: $city, ')
          ..write('state: $state, ')
          ..write('district: $district, ')
          ..write('pincode: $pincode, ')
          ..write('approvalStatus: $approvalStatus, ')
          ..write('lastModifiedDate: $lastModifiedDate, ')
          ..write('lastModifiedBy: $lastModifiedBy, ')
          ..write('createdDate: $createdDate, ')
          ..write('createdBy: $createdBy, ')
          ..write('synced: $synced, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ProductsTable extends Products with TableInfo<$ProductsTable, Product> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProductsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _categoryMeta =
      const VerificationMeta('category');
  @override
  late final GeneratedColumn<String> category = GeneratedColumn<String>(
      'category', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _unitPriceMeta =
      const VerificationMeta('unitPrice');
  @override
  late final GeneratedColumn<double> unitPrice = GeneratedColumn<double>(
      'unit_price', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _taxPercentMeta =
      const VerificationMeta('taxPercent');
  @override
  late final GeneratedColumn<double> taxPercent = GeneratedColumn<double>(
      'tax_percent', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns =>
      [id, name, category, unitPrice, taxPercent];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'products';
  @override
  VerificationContext validateIntegrity(Insertable<Product> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('category')) {
      context.handle(_categoryMeta,
          category.isAcceptableOrUnknown(data['category']!, _categoryMeta));
    }
    if (data.containsKey('unit_price')) {
      context.handle(_unitPriceMeta,
          unitPrice.isAcceptableOrUnknown(data['unit_price']!, _unitPriceMeta));
    } else if (isInserting) {
      context.missing(_unitPriceMeta);
    }
    if (data.containsKey('tax_percent')) {
      context.handle(
          _taxPercentMeta,
          taxPercent.isAcceptableOrUnknown(
              data['tax_percent']!, _taxPercentMeta));
    } else if (isInserting) {
      context.missing(_taxPercentMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Product map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Product(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      category: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}category']),
      unitPrice: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}unit_price'])!,
      taxPercent: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}tax_percent'])!,
    );
  }

  @override
  $ProductsTable createAlias(String alias) {
    return $ProductsTable(attachedDatabase, alias);
  }
}

class Product extends DataClass implements Insertable<Product> {
  final String id;
  final String name;
  final String? category;
  final double unitPrice;
  final double taxPercent;
  const Product(
      {required this.id,
      required this.name,
      this.category,
      required this.unitPrice,
      required this.taxPercent});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['name'] = Variable<String>(name);
    if (!nullToAbsent || category != null) {
      map['category'] = Variable<String>(category);
    }
    map['unit_price'] = Variable<double>(unitPrice);
    map['tax_percent'] = Variable<double>(taxPercent);
    return map;
  }

  ProductsCompanion toCompanion(bool nullToAbsent) {
    return ProductsCompanion(
      id: Value(id),
      name: Value(name),
      category: category == null && nullToAbsent
          ? const Value.absent()
          : Value(category),
      unitPrice: Value(unitPrice),
      taxPercent: Value(taxPercent),
    );
  }

  factory Product.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Product(
      id: serializer.fromJson<String>(json['id']),
      name: serializer.fromJson<String>(json['name']),
      category: serializer.fromJson<String?>(json['category']),
      unitPrice: serializer.fromJson<double>(json['unitPrice']),
      taxPercent: serializer.fromJson<double>(json['taxPercent']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'name': serializer.toJson<String>(name),
      'category': serializer.toJson<String?>(category),
      'unitPrice': serializer.toJson<double>(unitPrice),
      'taxPercent': serializer.toJson<double>(taxPercent),
    };
  }

  Product copyWith(
          {String? id,
          String? name,
          Value<String?> category = const Value.absent(),
          double? unitPrice,
          double? taxPercent}) =>
      Product(
        id: id ?? this.id,
        name: name ?? this.name,
        category: category.present ? category.value : this.category,
        unitPrice: unitPrice ?? this.unitPrice,
        taxPercent: taxPercent ?? this.taxPercent,
      );
  @override
  String toString() {
    return (StringBuffer('Product(')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('category: $category, ')
          ..write('unitPrice: $unitPrice, ')
          ..write('taxPercent: $taxPercent')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, name, category, unitPrice, taxPercent);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Product &&
          other.id == this.id &&
          other.name == this.name &&
          other.category == this.category &&
          other.unitPrice == this.unitPrice &&
          other.taxPercent == this.taxPercent);
}

class ProductsCompanion extends UpdateCompanion<Product> {
  final Value<String> id;
  final Value<String> name;
  final Value<String?> category;
  final Value<double> unitPrice;
  final Value<double> taxPercent;
  final Value<int> rowid;
  const ProductsCompanion({
    this.id = const Value.absent(),
    this.name = const Value.absent(),
    this.category = const Value.absent(),
    this.unitPrice = const Value.absent(),
    this.taxPercent = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ProductsCompanion.insert({
    required String id,
    required String name,
    this.category = const Value.absent(),
    required double unitPrice,
    required double taxPercent,
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        name = Value(name),
        unitPrice = Value(unitPrice),
        taxPercent = Value(taxPercent);
  static Insertable<Product> custom({
    Expression<String>? id,
    Expression<String>? name,
    Expression<String>? category,
    Expression<double>? unitPrice,
    Expression<double>? taxPercent,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (name != null) 'name': name,
      if (category != null) 'category': category,
      if (unitPrice != null) 'unit_price': unitPrice,
      if (taxPercent != null) 'tax_percent': taxPercent,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ProductsCompanion copyWith(
      {Value<String>? id,
      Value<String>? name,
      Value<String?>? category,
      Value<double>? unitPrice,
      Value<double>? taxPercent,
      Value<int>? rowid}) {
    return ProductsCompanion(
      id: id ?? this.id,
      name: name ?? this.name,
      category: category ?? this.category,
      unitPrice: unitPrice ?? this.unitPrice,
      taxPercent: taxPercent ?? this.taxPercent,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (category.present) {
      map['category'] = Variable<String>(category.value);
    }
    if (unitPrice.present) {
      map['unit_price'] = Variable<double>(unitPrice.value);
    }
    if (taxPercent.present) {
      map['tax_percent'] = Variable<double>(taxPercent.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProductsCompanion(')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('category: $category, ')
          ..write('unitPrice: $unitPrice, ')
          ..write('taxPercent: $taxPercent, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $VisitPlansTable extends VisitPlans
    with TableInfo<$VisitPlansTable, VisitPlan> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $VisitPlansTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _appVisitPlanIdMeta =
      const VerificationMeta('appVisitPlanId');
  @override
  late final GeneratedColumn<String> appVisitPlanId = GeneratedColumn<String>(
      'app_visit_plan_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      clientDefault: () => uuid.v6());
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _monthMeta = const VerificationMeta('month');
  @override
  late final GeneratedColumn<int> month = GeneratedColumn<int>(
      'month', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _yearMeta = const VerificationMeta('year');
  @override
  late final GeneratedColumn<int> year = GeneratedColumn<int>(
      'year', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _frequencyMeta =
      const VerificationMeta('frequency');
  @override
  late final GeneratedColumn<String> frequency = GeneratedColumn<String>(
      'frequency', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _startDateMeta =
      const VerificationMeta('startDate');
  @override
  late final GeneratedColumn<DateTime> startDate = GeneratedColumn<DateTime>(
      'start_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _endDateMeta =
      const VerificationMeta('endDate');
  @override
  late final GeneratedColumn<DateTime> endDate = GeneratedColumn<DateTime>(
      'end_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _executiveIdMeta =
      const VerificationMeta('executiveId');
  @override
  late final GeneratedColumn<String> executiveId = GeneratedColumn<String>(
      'executive_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _executiveNameMeta =
      const VerificationMeta('executiveName');
  @override
  late final GeneratedColumn<String> executiveName = GeneratedColumn<String>(
      'executive_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdDateMeta =
      const VerificationMeta('createdDate');
  @override
  late final GeneratedColumn<DateTime> createdDate = GeneratedColumn<DateTime>(
      'created_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _syncedMeta = const VerificationMeta('synced');
  @override
  late final GeneratedColumn<bool> synced = GeneratedColumn<bool>(
      'synced', aliasedName, true,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("synced" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        appVisitPlanId,
        id,
        name,
        month,
        year,
        frequency,
        startDate,
        endDate,
        executiveId,
        executiveName,
        createdDate,
        synced
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'visit_plans';
  @override
  VerificationContext validateIntegrity(Insertable<VisitPlan> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('app_visit_plan_id')) {
      context.handle(
          _appVisitPlanIdMeta,
          appVisitPlanId.isAcceptableOrUnknown(
              data['app_visit_plan_id']!, _appVisitPlanIdMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    }
    if (data.containsKey('month')) {
      context.handle(
          _monthMeta, month.isAcceptableOrUnknown(data['month']!, _monthMeta));
    }
    if (data.containsKey('year')) {
      context.handle(
          _yearMeta, year.isAcceptableOrUnknown(data['year']!, _yearMeta));
    }
    if (data.containsKey('frequency')) {
      context.handle(_frequencyMeta,
          frequency.isAcceptableOrUnknown(data['frequency']!, _frequencyMeta));
    }
    if (data.containsKey('start_date')) {
      context.handle(_startDateMeta,
          startDate.isAcceptableOrUnknown(data['start_date']!, _startDateMeta));
    }
    if (data.containsKey('end_date')) {
      context.handle(_endDateMeta,
          endDate.isAcceptableOrUnknown(data['end_date']!, _endDateMeta));
    }
    if (data.containsKey('executive_id')) {
      context.handle(
          _executiveIdMeta,
          executiveId.isAcceptableOrUnknown(
              data['executive_id']!, _executiveIdMeta));
    }
    if (data.containsKey('executive_name')) {
      context.handle(
          _executiveNameMeta,
          executiveName.isAcceptableOrUnknown(
              data['executive_name']!, _executiveNameMeta));
    }
    if (data.containsKey('created_date')) {
      context.handle(
          _createdDateMeta,
          createdDate.isAcceptableOrUnknown(
              data['created_date']!, _createdDateMeta));
    }
    if (data.containsKey('synced')) {
      context.handle(_syncedMeta,
          synced.isAcceptableOrUnknown(data['synced']!, _syncedMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {appVisitPlanId};
  @override
  VisitPlan map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return VisitPlan(
      appVisitPlanId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}app_visit_plan_id']),
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id']),
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name']),
      month: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}month']),
      year: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}year']),
      frequency: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}frequency']),
      startDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}start_date']),
      endDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}end_date']),
      executiveId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}executive_id']),
      executiveName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}executive_name']),
      createdDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_date']),
      synced: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}synced']),
    );
  }

  @override
  $VisitPlansTable createAlias(String alias) {
    return $VisitPlansTable(attachedDatabase, alias);
  }
}

class VisitPlan extends DataClass implements Insertable<VisitPlan> {
  final String? appVisitPlanId;
  final String? id;
  final String? name;
  final int? month;
  final int? year;
  final String? frequency;
  final DateTime? startDate;
  final DateTime? endDate;
  final String? executiveId;
  final String? executiveName;
  final DateTime? createdDate;
  final bool? synced;
  const VisitPlan(
      {this.appVisitPlanId,
      this.id,
      this.name,
      this.month,
      this.year,
      this.frequency,
      this.startDate,
      this.endDate,
      this.executiveId,
      this.executiveName,
      this.createdDate,
      this.synced});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || appVisitPlanId != null) {
      map['app_visit_plan_id'] = Variable<String>(appVisitPlanId);
    }
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<String>(id);
    }
    if (!nullToAbsent || name != null) {
      map['name'] = Variable<String>(name);
    }
    if (!nullToAbsent || month != null) {
      map['month'] = Variable<int>(month);
    }
    if (!nullToAbsent || year != null) {
      map['year'] = Variable<int>(year);
    }
    if (!nullToAbsent || frequency != null) {
      map['frequency'] = Variable<String>(frequency);
    }
    if (!nullToAbsent || startDate != null) {
      map['start_date'] = Variable<DateTime>(startDate);
    }
    if (!nullToAbsent || endDate != null) {
      map['end_date'] = Variable<DateTime>(endDate);
    }
    if (!nullToAbsent || executiveId != null) {
      map['executive_id'] = Variable<String>(executiveId);
    }
    if (!nullToAbsent || executiveName != null) {
      map['executive_name'] = Variable<String>(executiveName);
    }
    if (!nullToAbsent || createdDate != null) {
      map['created_date'] = Variable<DateTime>(createdDate);
    }
    if (!nullToAbsent || synced != null) {
      map['synced'] = Variable<bool>(synced);
    }
    return map;
  }

  VisitPlansCompanion toCompanion(bool nullToAbsent) {
    return VisitPlansCompanion(
      appVisitPlanId: appVisitPlanId == null && nullToAbsent
          ? const Value.absent()
          : Value(appVisitPlanId),
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      name: name == null && nullToAbsent ? const Value.absent() : Value(name),
      month:
          month == null && nullToAbsent ? const Value.absent() : Value(month),
      year: year == null && nullToAbsent ? const Value.absent() : Value(year),
      frequency: frequency == null && nullToAbsent
          ? const Value.absent()
          : Value(frequency),
      startDate: startDate == null && nullToAbsent
          ? const Value.absent()
          : Value(startDate),
      endDate: endDate == null && nullToAbsent
          ? const Value.absent()
          : Value(endDate),
      executiveId: executiveId == null && nullToAbsent
          ? const Value.absent()
          : Value(executiveId),
      executiveName: executiveName == null && nullToAbsent
          ? const Value.absent()
          : Value(executiveName),
      createdDate: createdDate == null && nullToAbsent
          ? const Value.absent()
          : Value(createdDate),
      synced:
          synced == null && nullToAbsent ? const Value.absent() : Value(synced),
    );
  }

  factory VisitPlan.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return VisitPlan(
      appVisitPlanId: serializer.fromJson<String?>(json['appVisitPlanid']),
      id: serializer.fromJson<String?>(json['id']),
      name: serializer.fromJson<String?>(json['name']),
      month: serializer.fromJson<int?>(json['month']),
      year: serializer.fromJson<int?>(json['year']),
      frequency: serializer.fromJson<String?>(json['frequency']),
      startDate: serializer.fromJson<DateTime?>(json['startDate']),
      endDate: serializer.fromJson<DateTime?>(json['endDate']),
      executiveId: serializer.fromJson<String?>(json['executiveId']),
      executiveName: serializer.fromJson<String?>(json['executiveName']),
      createdDate: serializer.fromJson<DateTime?>(json['createdDate']),
      synced: serializer.fromJson<bool?>(json['synced']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'appVisitPlanid': serializer.toJson<String?>(appVisitPlanId),
      'id': serializer.toJson<String?>(id),
      'name': serializer.toJson<String?>(name),
      'month': serializer.toJson<int?>(month),
      'year': serializer.toJson<int?>(year),
      'frequency': serializer.toJson<String?>(frequency),
      'startDate': serializer.toJson<DateTime?>(startDate),
      'endDate': serializer.toJson<DateTime?>(endDate),
      'executiveId': serializer.toJson<String?>(executiveId),
      'executiveName': serializer.toJson<String?>(executiveName),
      'createdDate': serializer.toJson<DateTime?>(createdDate),
      'synced': serializer.toJson<bool?>(synced),
    };
  }

  VisitPlan copyWith(
          {Value<String?> appVisitPlanId = const Value.absent(),
          Value<String?> id = const Value.absent(),
          Value<String?> name = const Value.absent(),
          Value<int?> month = const Value.absent(),
          Value<int?> year = const Value.absent(),
          Value<String?> frequency = const Value.absent(),
          Value<DateTime?> startDate = const Value.absent(),
          Value<DateTime?> endDate = const Value.absent(),
          Value<String?> executiveId = const Value.absent(),
          Value<String?> executiveName = const Value.absent(),
          Value<DateTime?> createdDate = const Value.absent(),
          Value<bool?> synced = const Value.absent()}) =>
      VisitPlan(
        appVisitPlanId:
            appVisitPlanId.present ? appVisitPlanId.value : this.appVisitPlanId,
        id: id.present ? id.value : this.id,
        name: name.present ? name.value : this.name,
        month: month.present ? month.value : this.month,
        year: year.present ? year.value : this.year,
        frequency: frequency.present ? frequency.value : this.frequency,
        startDate: startDate.present ? startDate.value : this.startDate,
        endDate: endDate.present ? endDate.value : this.endDate,
        executiveId: executiveId.present ? executiveId.value : this.executiveId,
        executiveName:
            executiveName.present ? executiveName.value : this.executiveName,
        createdDate: createdDate.present ? createdDate.value : this.createdDate,
        synced: synced.present ? synced.value : this.synced,
      );
  @override
  String toString() {
    return (StringBuffer('VisitPlan(')
          ..write('appVisitPlanId: $appVisitPlanId, ')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('month: $month, ')
          ..write('year: $year, ')
          ..write('frequency: $frequency, ')
          ..write('startDate: $startDate, ')
          ..write('endDate: $endDate, ')
          ..write('executiveId: $executiveId, ')
          ..write('executiveName: $executiveName, ')
          ..write('createdDate: $createdDate, ')
          ..write('synced: $synced')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      appVisitPlanId,
      id,
      name,
      month,
      year,
      frequency,
      startDate,
      endDate,
      executiveId,
      executiveName,
      createdDate,
      synced);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is VisitPlan &&
          other.appVisitPlanId == this.appVisitPlanId &&
          other.id == this.id &&
          other.name == this.name &&
          other.month == this.month &&
          other.year == this.year &&
          other.frequency == this.frequency &&
          other.startDate == this.startDate &&
          other.endDate == this.endDate &&
          other.executiveId == this.executiveId &&
          other.executiveName == this.executiveName &&
          other.createdDate == this.createdDate &&
          other.synced == this.synced);
}

class VisitPlansCompanion extends UpdateCompanion<VisitPlan> {
  final Value<String?> appVisitPlanId;
  final Value<String?> id;
  final Value<String?> name;
  final Value<int?> month;
  final Value<int?> year;
  final Value<String?> frequency;
  final Value<DateTime?> startDate;
  final Value<DateTime?> endDate;
  final Value<String?> executiveId;
  final Value<String?> executiveName;
  final Value<DateTime?> createdDate;
  final Value<bool?> synced;
  final Value<int> rowid;
  const VisitPlansCompanion({
    this.appVisitPlanId = const Value.absent(),
    this.id = const Value.absent(),
    this.name = const Value.absent(),
    this.month = const Value.absent(),
    this.year = const Value.absent(),
    this.frequency = const Value.absent(),
    this.startDate = const Value.absent(),
    this.endDate = const Value.absent(),
    this.executiveId = const Value.absent(),
    this.executiveName = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  VisitPlansCompanion.insert({
    this.appVisitPlanId = const Value.absent(),
    this.id = const Value.absent(),
    this.name = const Value.absent(),
    this.month = const Value.absent(),
    this.year = const Value.absent(),
    this.frequency = const Value.absent(),
    this.startDate = const Value.absent(),
    this.endDate = const Value.absent(),
    this.executiveId = const Value.absent(),
    this.executiveName = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  static Insertable<VisitPlan> custom({
    Expression<String>? appVisitPlanId,
    Expression<String>? id,
    Expression<String>? name,
    Expression<int>? month,
    Expression<int>? year,
    Expression<String>? frequency,
    Expression<DateTime>? startDate,
    Expression<DateTime>? endDate,
    Expression<String>? executiveId,
    Expression<String>? executiveName,
    Expression<DateTime>? createdDate,
    Expression<bool>? synced,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (appVisitPlanId != null) 'app_visit_plan_id': appVisitPlanId,
      if (id != null) 'id': id,
      if (name != null) 'name': name,
      if (month != null) 'month': month,
      if (year != null) 'year': year,
      if (frequency != null) 'frequency': frequency,
      if (startDate != null) 'start_date': startDate,
      if (endDate != null) 'end_date': endDate,
      if (executiveId != null) 'executive_id': executiveId,
      if (executiveName != null) 'executive_name': executiveName,
      if (createdDate != null) 'created_date': createdDate,
      if (synced != null) 'synced': synced,
      if (rowid != null) 'rowid': rowid,
    });
  }

  VisitPlansCompanion copyWith(
      {Value<String?>? appVisitPlanId,
      Value<String?>? id,
      Value<String?>? name,
      Value<int?>? month,
      Value<int?>? year,
      Value<String?>? frequency,
      Value<DateTime?>? startDate,
      Value<DateTime?>? endDate,
      Value<String?>? executiveId,
      Value<String?>? executiveName,
      Value<DateTime?>? createdDate,
      Value<bool?>? synced,
      Value<int>? rowid}) {
    return VisitPlansCompanion(
      appVisitPlanId: appVisitPlanId ?? this.appVisitPlanId,
      id: id ?? this.id,
      name: name ?? this.name,
      month: month ?? this.month,
      year: year ?? this.year,
      frequency: frequency ?? this.frequency,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      executiveId: executiveId ?? this.executiveId,
      executiveName: executiveName ?? this.executiveName,
      createdDate: createdDate ?? this.createdDate,
      synced: synced ?? this.synced,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (appVisitPlanId.present) {
      map['app_visit_plan_id'] = Variable<String>(appVisitPlanId.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (month.present) {
      map['month'] = Variable<int>(month.value);
    }
    if (year.present) {
      map['year'] = Variable<int>(year.value);
    }
    if (frequency.present) {
      map['frequency'] = Variable<String>(frequency.value);
    }
    if (startDate.present) {
      map['start_date'] = Variable<DateTime>(startDate.value);
    }
    if (endDate.present) {
      map['end_date'] = Variable<DateTime>(endDate.value);
    }
    if (executiveId.present) {
      map['executive_id'] = Variable<String>(executiveId.value);
    }
    if (executiveName.present) {
      map['executive_name'] = Variable<String>(executiveName.value);
    }
    if (createdDate.present) {
      map['created_date'] = Variable<DateTime>(createdDate.value);
    }
    if (synced.present) {
      map['synced'] = Variable<bool>(synced.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('VisitPlansCompanion(')
          ..write('appVisitPlanId: $appVisitPlanId, ')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('month: $month, ')
          ..write('year: $year, ')
          ..write('frequency: $frequency, ')
          ..write('startDate: $startDate, ')
          ..write('endDate: $endDate, ')
          ..write('executiveId: $executiveId, ')
          ..write('executiveName: $executiveName, ')
          ..write('createdDate: $createdDate, ')
          ..write('synced: $synced, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $VisitsTable extends Visits with TableInfo<$VisitsTable, Visit> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $VisitsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _salesAppIdMeta =
      const VerificationMeta('salesAppId');
  @override
  late final GeneratedColumn<String> salesAppId = GeneratedColumn<String>(
      'sales_app_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      clientDefault: () => uuid.v6());
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _accountIdMeta =
      const VerificationMeta('accountId');
  @override
  late final GeneratedColumn<String> accountId = GeneratedColumn<String>(
      'account_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('REFERENCES accounts (id)'));
  static const VerificationMeta _appAccountIdMeta =
      const VerificationMeta('appAccountId');
  @override
  late final GeneratedColumn<String> appAccountId = GeneratedColumn<String>(
      'app_account_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultConstraints: GeneratedColumn.constraintIsAlways(
          'REFERENCES accounts (app_account_id)'));
  static const VerificationMeta _accountNameMeta =
      const VerificationMeta('accountName');
  @override
  late final GeneratedColumn<String> accountName = GeneratedColumn<String>(
      'account_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(VisitStatus.planned));
  static const VerificationMeta _plannedStartTimeMeta =
      const VerificationMeta('plannedStartTime');
  @override
  late final GeneratedColumn<DateTime> plannedStartTime =
      GeneratedColumn<DateTime>('planned_start_time', aliasedName, false,
          type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _plannedEndTimeMeta =
      const VerificationMeta('plannedEndTime');
  @override
  late final GeneratedColumn<DateTime> plannedEndTime =
      GeneratedColumn<DateTime>('planned_end_time', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _actualStartTimeMeta =
      const VerificationMeta('actualStartTime');
  @override
  late final GeneratedColumn<DateTime> actualStartTime =
      GeneratedColumn<DateTime>('actual_start_time', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _actualEndTimeMeta =
      const VerificationMeta('actualEndTime');
  @override
  late final GeneratedColumn<DateTime> actualEndTime =
      GeneratedColumn<DateTime>('actual_end_time', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _commentsMeta =
      const VerificationMeta('comments');
  @override
  late final GeneratedColumn<String> comments = GeneratedColumn<String>(
      'comments', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _missedReasonMeta =
      const VerificationMeta('missedReason');
  @override
  late final GeneratedColumn<String> missedReason = GeneratedColumn<String>(
      'missed_reason', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _lastVisitCommentMeta =
      const VerificationMeta('lastVisitComment');
  @override
  late final GeneratedColumn<String> lastVisitComment = GeneratedColumn<String>(
      'last_visit_comment', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _lastVisitDateMeta =
      const VerificationMeta('lastVisitDate');
  @override
  late final GeneratedColumn<DateTime> lastVisitDate =
      GeneratedColumn<DateTime>('last_visit_date', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _geoLocationMeta =
      const VerificationMeta('geoLocation');
  @override
  late final GeneratedColumnWithTypeConverter<LatLng?, String> geoLocation =
      GeneratedColumn<String>('geo_location', aliasedName, true,
              type: DriftSqlType.string, requiredDuringInsert: false)
          .withConverter<LatLng?>($VisitsTable.$convertergeoLocationn);
  static const VerificationMeta _checkoutLocationMeta =
      const VerificationMeta('checkoutLocation');
  @override
  late final GeneratedColumnWithTypeConverter<LatLng?, String>
      checkoutLocation = GeneratedColumn<String>(
              'checkout_location', aliasedName, true,
              type: DriftSqlType.string, requiredDuringInsert: false)
          .withConverter<LatLng?>($VisitsTable.$convertercheckoutLocationn);
  static const VerificationMeta _outstandingMeta =
      const VerificationMeta('outstanding');
  @override
  late final GeneratedColumn<double> outstanding = GeneratedColumn<double>(
      'outstanding', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _typeofVisitMeta =
      const VerificationMeta('typeofVisit');
  @override
  late final GeneratedColumn<String> typeofVisit = GeneratedColumn<String>(
      'typeof_visit', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _appVisitPlanIdMeta =
      const VerificationMeta('appVisitPlanId');
  @override
  late final GeneratedColumn<String> appVisitPlanId = GeneratedColumn<String>(
      'app_visit_plan_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _visitPlanIdMeta =
      const VerificationMeta('visitPlanId');
  @override
  late final GeneratedColumn<String> visitPlanId = GeneratedColumn<String>(
      'visit_plan_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('REFERENCES visit_plans (id)'));
  static const VerificationMeta _syncedMeta = const VerificationMeta('synced');
  @override
  late final GeneratedColumn<bool> synced = GeneratedColumn<bool>(
      'synced', aliasedName, true,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("synced" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        salesAppId,
        id,
        accountId,
        appAccountId,
        accountName,
        status,
        plannedStartTime,
        plannedEndTime,
        actualStartTime,
        actualEndTime,
        comments,
        missedReason,
        lastVisitComment,
        lastVisitDate,
        geoLocation,
        checkoutLocation,
        outstanding,
        typeofVisit,
        appVisitPlanId,
        visitPlanId,
        synced
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'visits';
  @override
  VerificationContext validateIntegrity(Insertable<Visit> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('sales_app_id')) {
      context.handle(
          _salesAppIdMeta,
          salesAppId.isAcceptableOrUnknown(
              data['sales_app_id']!, _salesAppIdMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('account_id')) {
      context.handle(_accountIdMeta,
          accountId.isAcceptableOrUnknown(data['account_id']!, _accountIdMeta));
    }
    if (data.containsKey('app_account_id')) {
      context.handle(
          _appAccountIdMeta,
          appAccountId.isAcceptableOrUnknown(
              data['app_account_id']!, _appAccountIdMeta));
    }
    if (data.containsKey('account_name')) {
      context.handle(
          _accountNameMeta,
          accountName.isAcceptableOrUnknown(
              data['account_name']!, _accountNameMeta));
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('planned_start_time')) {
      context.handle(
          _plannedStartTimeMeta,
          plannedStartTime.isAcceptableOrUnknown(
              data['planned_start_time']!, _plannedStartTimeMeta));
    } else if (isInserting) {
      context.missing(_plannedStartTimeMeta);
    }
    if (data.containsKey('planned_end_time')) {
      context.handle(
          _plannedEndTimeMeta,
          plannedEndTime.isAcceptableOrUnknown(
              data['planned_end_time']!, _plannedEndTimeMeta));
    }
    if (data.containsKey('actual_start_time')) {
      context.handle(
          _actualStartTimeMeta,
          actualStartTime.isAcceptableOrUnknown(
              data['actual_start_time']!, _actualStartTimeMeta));
    }
    if (data.containsKey('actual_end_time')) {
      context.handle(
          _actualEndTimeMeta,
          actualEndTime.isAcceptableOrUnknown(
              data['actual_end_time']!, _actualEndTimeMeta));
    }
    if (data.containsKey('comments')) {
      context.handle(_commentsMeta,
          comments.isAcceptableOrUnknown(data['comments']!, _commentsMeta));
    }
    if (data.containsKey('missed_reason')) {
      context.handle(
          _missedReasonMeta,
          missedReason.isAcceptableOrUnknown(
              data['missed_reason']!, _missedReasonMeta));
    }
    if (data.containsKey('last_visit_comment')) {
      context.handle(
          _lastVisitCommentMeta,
          lastVisitComment.isAcceptableOrUnknown(
              data['last_visit_comment']!, _lastVisitCommentMeta));
    }
    if (data.containsKey('last_visit_date')) {
      context.handle(
          _lastVisitDateMeta,
          lastVisitDate.isAcceptableOrUnknown(
              data['last_visit_date']!, _lastVisitDateMeta));
    }
    context.handle(_geoLocationMeta, const VerificationResult.success());
    context.handle(_checkoutLocationMeta, const VerificationResult.success());
    if (data.containsKey('outstanding')) {
      context.handle(
          _outstandingMeta,
          outstanding.isAcceptableOrUnknown(
              data['outstanding']!, _outstandingMeta));
    }
    if (data.containsKey('typeof_visit')) {
      context.handle(
          _typeofVisitMeta,
          typeofVisit.isAcceptableOrUnknown(
              data['typeof_visit']!, _typeofVisitMeta));
    }
    if (data.containsKey('app_visit_plan_id')) {
      context.handle(
          _appVisitPlanIdMeta,
          appVisitPlanId.isAcceptableOrUnknown(
              data['app_visit_plan_id']!, _appVisitPlanIdMeta));
    }
    if (data.containsKey('visit_plan_id')) {
      context.handle(
          _visitPlanIdMeta,
          visitPlanId.isAcceptableOrUnknown(
              data['visit_plan_id']!, _visitPlanIdMeta));
    }
    if (data.containsKey('synced')) {
      context.handle(_syncedMeta,
          synced.isAcceptableOrUnknown(data['synced']!, _syncedMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {salesAppId};
  @override
  Visit map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Visit(
      salesAppId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sales_app_id']),
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id']),
      accountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}account_id']),
      appAccountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_account_id']),
      accountName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}account_name']),
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status']),
      plannedStartTime: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}planned_start_time'])!,
      plannedEndTime: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}planned_end_time']),
      actualStartTime: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}actual_start_time']),
      actualEndTime: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}actual_end_time']),
      comments: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}comments']),
      missedReason: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}missed_reason']),
      lastVisitComment: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}last_visit_comment']),
      lastVisitDate: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}last_visit_date']),
      geoLocation: $VisitsTable.$convertergeoLocationn.fromSql(attachedDatabase
          .typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}geo_location'])),
      checkoutLocation: $VisitsTable.$convertercheckoutLocationn.fromSql(
          attachedDatabase.typeMapping.read(DriftSqlType.string,
              data['${effectivePrefix}checkout_location'])),
      outstanding: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}outstanding']),
      typeofVisit: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}typeof_visit']),
      appVisitPlanId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}app_visit_plan_id']),
      visitPlanId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}visit_plan_id']),
      synced: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}synced']),
    );
  }

  @override
  $VisitsTable createAlias(String alias) {
    return $VisitsTable(attachedDatabase, alias);
  }

  static TypeConverter<LatLng, String> $convertergeoLocation =
      const LatLngConverter();
  static TypeConverter<LatLng?, String?> $convertergeoLocationn =
      NullAwareTypeConverter.wrap($convertergeoLocation);
  static TypeConverter<LatLng, String> $convertercheckoutLocation =
      const LatLngConverter();
  static TypeConverter<LatLng?, String?> $convertercheckoutLocationn =
      NullAwareTypeConverter.wrap($convertercheckoutLocation);
}

class Visit extends DataClass implements Insertable<Visit> {
  final String? salesAppId;
  final String? id;
  final String? accountId;
  final String? appAccountId;
  final String? accountName;
  final String? status;
  final DateTime plannedStartTime;
  final DateTime? plannedEndTime;
  final DateTime? actualStartTime;
  final DateTime? actualEndTime;
  final String? comments;
  final String? missedReason;
  final String? lastVisitComment;
  final DateTime? lastVisitDate;
  final LatLng? geoLocation;
  final LatLng? checkoutLocation;
  final double? outstanding;
  final String? typeofVisit;
  final String? appVisitPlanId;
  final String? visitPlanId;
  final bool? synced;
  const Visit(
      {this.salesAppId,
      this.id,
      this.accountId,
      this.appAccountId,
      this.accountName,
      this.status,
      required this.plannedStartTime,
      this.plannedEndTime,
      this.actualStartTime,
      this.actualEndTime,
      this.comments,
      this.missedReason,
      this.lastVisitComment,
      this.lastVisitDate,
      this.geoLocation,
      this.checkoutLocation,
      this.outstanding,
      this.typeofVisit,
      this.appVisitPlanId,
      this.visitPlanId,
      this.synced});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || salesAppId != null) {
      map['sales_app_id'] = Variable<String>(salesAppId);
    }
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<String>(id);
    }
    if (!nullToAbsent || accountId != null) {
      map['account_id'] = Variable<String>(accountId);
    }
    if (!nullToAbsent || appAccountId != null) {
      map['app_account_id'] = Variable<String>(appAccountId);
    }
    if (!nullToAbsent || accountName != null) {
      map['account_name'] = Variable<String>(accountName);
    }
    if (!nullToAbsent || status != null) {
      map['status'] = Variable<String>(status);
    }
    map['planned_start_time'] = Variable<DateTime>(plannedStartTime);
    if (!nullToAbsent || plannedEndTime != null) {
      map['planned_end_time'] = Variable<DateTime>(plannedEndTime);
    }
    if (!nullToAbsent || actualStartTime != null) {
      map['actual_start_time'] = Variable<DateTime>(actualStartTime);
    }
    if (!nullToAbsent || actualEndTime != null) {
      map['actual_end_time'] = Variable<DateTime>(actualEndTime);
    }
    if (!nullToAbsent || comments != null) {
      map['comments'] = Variable<String>(comments);
    }
    if (!nullToAbsent || missedReason != null) {
      map['missed_reason'] = Variable<String>(missedReason);
    }
    if (!nullToAbsent || lastVisitComment != null) {
      map['last_visit_comment'] = Variable<String>(lastVisitComment);
    }
    if (!nullToAbsent || lastVisitDate != null) {
      map['last_visit_date'] = Variable<DateTime>(lastVisitDate);
    }
    if (!nullToAbsent || geoLocation != null) {
      map['geo_location'] = Variable<String>(
          $VisitsTable.$convertergeoLocationn.toSql(geoLocation));
    }
    if (!nullToAbsent || checkoutLocation != null) {
      map['checkout_location'] = Variable<String>(
          $VisitsTable.$convertercheckoutLocationn.toSql(checkoutLocation));
    }
    if (!nullToAbsent || outstanding != null) {
      map['outstanding'] = Variable<double>(outstanding);
    }
    if (!nullToAbsent || typeofVisit != null) {
      map['typeof_visit'] = Variable<String>(typeofVisit);
    }
    if (!nullToAbsent || appVisitPlanId != null) {
      map['app_visit_plan_id'] = Variable<String>(appVisitPlanId);
    }
    if (!nullToAbsent || visitPlanId != null) {
      map['visit_plan_id'] = Variable<String>(visitPlanId);
    }
    if (!nullToAbsent || synced != null) {
      map['synced'] = Variable<bool>(synced);
    }
    return map;
  }

  VisitsCompanion toCompanion(bool nullToAbsent) {
    return VisitsCompanion(
      salesAppId: salesAppId == null && nullToAbsent
          ? const Value.absent()
          : Value(salesAppId),
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      accountId: accountId == null && nullToAbsent
          ? const Value.absent()
          : Value(accountId),
      appAccountId: appAccountId == null && nullToAbsent
          ? const Value.absent()
          : Value(appAccountId),
      accountName: accountName == null && nullToAbsent
          ? const Value.absent()
          : Value(accountName),
      status:
          status == null && nullToAbsent ? const Value.absent() : Value(status),
      plannedStartTime: Value(plannedStartTime),
      plannedEndTime: plannedEndTime == null && nullToAbsent
          ? const Value.absent()
          : Value(plannedEndTime),
      actualStartTime: actualStartTime == null && nullToAbsent
          ? const Value.absent()
          : Value(actualStartTime),
      actualEndTime: actualEndTime == null && nullToAbsent
          ? const Value.absent()
          : Value(actualEndTime),
      comments: comments == null && nullToAbsent
          ? const Value.absent()
          : Value(comments),
      missedReason: missedReason == null && nullToAbsent
          ? const Value.absent()
          : Value(missedReason),
      lastVisitComment: lastVisitComment == null && nullToAbsent
          ? const Value.absent()
          : Value(lastVisitComment),
      lastVisitDate: lastVisitDate == null && nullToAbsent
          ? const Value.absent()
          : Value(lastVisitDate),
      geoLocation: geoLocation == null && nullToAbsent
          ? const Value.absent()
          : Value(geoLocation),
      checkoutLocation: checkoutLocation == null && nullToAbsent
          ? const Value.absent()
          : Value(checkoutLocation),
      outstanding: outstanding == null && nullToAbsent
          ? const Value.absent()
          : Value(outstanding),
      typeofVisit: typeofVisit == null && nullToAbsent
          ? const Value.absent()
          : Value(typeofVisit),
      appVisitPlanId: appVisitPlanId == null && nullToAbsent
          ? const Value.absent()
          : Value(appVisitPlanId),
      visitPlanId: visitPlanId == null && nullToAbsent
          ? const Value.absent()
          : Value(visitPlanId),
      synced:
          synced == null && nullToAbsent ? const Value.absent() : Value(synced),
    );
  }

  factory Visit.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Visit(
      salesAppId: serializer.fromJson<String?>(json['salesAppId']),
      id: serializer.fromJson<String?>(json['id']),
      accountId: serializer.fromJson<String?>(json['acccountId']),
      appAccountId: serializer.fromJson<String?>(json['appAccountId']),
      accountName: serializer.fromJson<String?>(json['accountName']),
      status: serializer.fromJson<String?>(json['status']),
      plannedStartTime: serializer.fromJson<DateTime>(json['plannedStartTime']),
      plannedEndTime: serializer.fromJson<DateTime?>(json['plannedEndTime']),
      actualStartTime: serializer.fromJson<DateTime?>(json['actualStartTime']),
      actualEndTime: serializer.fromJson<DateTime?>(json['actualEndTime']),
      comments: serializer.fromJson<String?>(json['comments']),
      missedReason: serializer.fromJson<String?>(json['missedReason']),
      lastVisitComment: serializer.fromJson<String?>(json['lastVisitComment']),
      lastVisitDate: serializer.fromJson<DateTime?>(json['lastVisitDate']),
      geoLocation: serializer.fromJson<LatLng?>(json['geoLocation']),
      checkoutLocation: serializer.fromJson<LatLng?>(json['checkoutLocation']),
      outstanding: serializer.fromJson<double?>(json['outstanding']),
      typeofVisit: serializer.fromJson<String?>(json['typeofVisit']),
      appVisitPlanId: serializer.fromJson<String?>(json['appVisitPlanId']),
      visitPlanId: serializer.fromJson<String?>(json['visitPlanId']),
      synced: serializer.fromJson<bool?>(json['synced']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'salesAppId': serializer.toJson<String?>(salesAppId),
      'id': serializer.toJson<String?>(id),
      'acccountId': serializer.toJson<String?>(accountId),
      'appAccountId': serializer.toJson<String?>(appAccountId),
      'accountName': serializer.toJson<String?>(accountName),
      'status': serializer.toJson<String?>(status),
      'plannedStartTime': serializer.toJson<DateTime>(plannedStartTime),
      'plannedEndTime': serializer.toJson<DateTime?>(plannedEndTime),
      'actualStartTime': serializer.toJson<DateTime?>(actualStartTime),
      'actualEndTime': serializer.toJson<DateTime?>(actualEndTime),
      'comments': serializer.toJson<String?>(comments),
      'missedReason': serializer.toJson<String?>(missedReason),
      'lastVisitComment': serializer.toJson<String?>(lastVisitComment),
      'lastVisitDate': serializer.toJson<DateTime?>(lastVisitDate),
      'geoLocation': serializer.toJson<LatLng?>(geoLocation),
      'checkoutLocation': serializer.toJson<LatLng?>(checkoutLocation),
      'outstanding': serializer.toJson<double?>(outstanding),
      'typeofVisit': serializer.toJson<String?>(typeofVisit),
      'appVisitPlanId': serializer.toJson<String?>(appVisitPlanId),
      'visitPlanId': serializer.toJson<String?>(visitPlanId),
      'synced': serializer.toJson<bool?>(synced),
    };
  }

  Visit copyWith(
          {Value<String?> salesAppId = const Value.absent(),
          Value<String?> id = const Value.absent(),
          Value<String?> accountId = const Value.absent(),
          Value<String?> appAccountId = const Value.absent(),
          Value<String?> accountName = const Value.absent(),
          Value<String?> status = const Value.absent(),
          DateTime? plannedStartTime,
          Value<DateTime?> plannedEndTime = const Value.absent(),
          Value<DateTime?> actualStartTime = const Value.absent(),
          Value<DateTime?> actualEndTime = const Value.absent(),
          Value<String?> comments = const Value.absent(),
          Value<String?> missedReason = const Value.absent(),
          Value<String?> lastVisitComment = const Value.absent(),
          Value<DateTime?> lastVisitDate = const Value.absent(),
          Value<LatLng?> geoLocation = const Value.absent(),
          Value<LatLng?> checkoutLocation = const Value.absent(),
          Value<double?> outstanding = const Value.absent(),
          Value<String?> typeofVisit = const Value.absent(),
          Value<String?> appVisitPlanId = const Value.absent(),
          Value<String?> visitPlanId = const Value.absent(),
          Value<bool?> synced = const Value.absent()}) =>
      Visit(
        salesAppId: salesAppId.present ? salesAppId.value : this.salesAppId,
        id: id.present ? id.value : this.id,
        accountId: accountId.present ? accountId.value : this.accountId,
        appAccountId:
            appAccountId.present ? appAccountId.value : this.appAccountId,
        accountName: accountName.present ? accountName.value : this.accountName,
        status: status.present ? status.value : this.status,
        plannedStartTime: plannedStartTime ?? this.plannedStartTime,
        plannedEndTime:
            plannedEndTime.present ? plannedEndTime.value : this.plannedEndTime,
        actualStartTime: actualStartTime.present
            ? actualStartTime.value
            : this.actualStartTime,
        actualEndTime:
            actualEndTime.present ? actualEndTime.value : this.actualEndTime,
        comments: comments.present ? comments.value : this.comments,
        missedReason:
            missedReason.present ? missedReason.value : this.missedReason,
        lastVisitComment: lastVisitComment.present
            ? lastVisitComment.value
            : this.lastVisitComment,
        lastVisitDate:
            lastVisitDate.present ? lastVisitDate.value : this.lastVisitDate,
        geoLocation: geoLocation.present ? geoLocation.value : this.geoLocation,
        checkoutLocation: checkoutLocation.present
            ? checkoutLocation.value
            : this.checkoutLocation,
        outstanding: outstanding.present ? outstanding.value : this.outstanding,
        typeofVisit: typeofVisit.present ? typeofVisit.value : this.typeofVisit,
        appVisitPlanId:
            appVisitPlanId.present ? appVisitPlanId.value : this.appVisitPlanId,
        visitPlanId: visitPlanId.present ? visitPlanId.value : this.visitPlanId,
        synced: synced.present ? synced.value : this.synced,
      );
  @override
  String toString() {
    return (StringBuffer('Visit(')
          ..write('salesAppId: $salesAppId, ')
          ..write('id: $id, ')
          ..write('accountId: $accountId, ')
          ..write('appAccountId: $appAccountId, ')
          ..write('accountName: $accountName, ')
          ..write('status: $status, ')
          ..write('plannedStartTime: $plannedStartTime, ')
          ..write('plannedEndTime: $plannedEndTime, ')
          ..write('actualStartTime: $actualStartTime, ')
          ..write('actualEndTime: $actualEndTime, ')
          ..write('comments: $comments, ')
          ..write('missedReason: $missedReason, ')
          ..write('lastVisitComment: $lastVisitComment, ')
          ..write('lastVisitDate: $lastVisitDate, ')
          ..write('geoLocation: $geoLocation, ')
          ..write('checkoutLocation: $checkoutLocation, ')
          ..write('outstanding: $outstanding, ')
          ..write('typeofVisit: $typeofVisit, ')
          ..write('appVisitPlanId: $appVisitPlanId, ')
          ..write('visitPlanId: $visitPlanId, ')
          ..write('synced: $synced')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        salesAppId,
        id,
        accountId,
        appAccountId,
        accountName,
        status,
        plannedStartTime,
        plannedEndTime,
        actualStartTime,
        actualEndTime,
        comments,
        missedReason,
        lastVisitComment,
        lastVisitDate,
        geoLocation,
        checkoutLocation,
        outstanding,
        typeofVisit,
        appVisitPlanId,
        visitPlanId,
        synced
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Visit &&
          other.salesAppId == this.salesAppId &&
          other.id == this.id &&
          other.accountId == this.accountId &&
          other.appAccountId == this.appAccountId &&
          other.accountName == this.accountName &&
          other.status == this.status &&
          other.plannedStartTime == this.plannedStartTime &&
          other.plannedEndTime == this.plannedEndTime &&
          other.actualStartTime == this.actualStartTime &&
          other.actualEndTime == this.actualEndTime &&
          other.comments == this.comments &&
          other.missedReason == this.missedReason &&
          other.lastVisitComment == this.lastVisitComment &&
          other.lastVisitDate == this.lastVisitDate &&
          other.geoLocation == this.geoLocation &&
          other.checkoutLocation == this.checkoutLocation &&
          other.outstanding == this.outstanding &&
          other.typeofVisit == this.typeofVisit &&
          other.appVisitPlanId == this.appVisitPlanId &&
          other.visitPlanId == this.visitPlanId &&
          other.synced == this.synced);
}

class VisitsCompanion extends UpdateCompanion<Visit> {
  final Value<String?> salesAppId;
  final Value<String?> id;
  final Value<String?> accountId;
  final Value<String?> appAccountId;
  final Value<String?> accountName;
  final Value<String?> status;
  final Value<DateTime> plannedStartTime;
  final Value<DateTime?> plannedEndTime;
  final Value<DateTime?> actualStartTime;
  final Value<DateTime?> actualEndTime;
  final Value<String?> comments;
  final Value<String?> missedReason;
  final Value<String?> lastVisitComment;
  final Value<DateTime?> lastVisitDate;
  final Value<LatLng?> geoLocation;
  final Value<LatLng?> checkoutLocation;
  final Value<double?> outstanding;
  final Value<String?> typeofVisit;
  final Value<String?> appVisitPlanId;
  final Value<String?> visitPlanId;
  final Value<bool?> synced;
  final Value<int> rowid;
  const VisitsCompanion({
    this.salesAppId = const Value.absent(),
    this.id = const Value.absent(),
    this.accountId = const Value.absent(),
    this.appAccountId = const Value.absent(),
    this.accountName = const Value.absent(),
    this.status = const Value.absent(),
    this.plannedStartTime = const Value.absent(),
    this.plannedEndTime = const Value.absent(),
    this.actualStartTime = const Value.absent(),
    this.actualEndTime = const Value.absent(),
    this.comments = const Value.absent(),
    this.missedReason = const Value.absent(),
    this.lastVisitComment = const Value.absent(),
    this.lastVisitDate = const Value.absent(),
    this.geoLocation = const Value.absent(),
    this.checkoutLocation = const Value.absent(),
    this.outstanding = const Value.absent(),
    this.typeofVisit = const Value.absent(),
    this.appVisitPlanId = const Value.absent(),
    this.visitPlanId = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  VisitsCompanion.insert({
    this.salesAppId = const Value.absent(),
    this.id = const Value.absent(),
    this.accountId = const Value.absent(),
    this.appAccountId = const Value.absent(),
    this.accountName = const Value.absent(),
    this.status = const Value.absent(),
    required DateTime plannedStartTime,
    this.plannedEndTime = const Value.absent(),
    this.actualStartTime = const Value.absent(),
    this.actualEndTime = const Value.absent(),
    this.comments = const Value.absent(),
    this.missedReason = const Value.absent(),
    this.lastVisitComment = const Value.absent(),
    this.lastVisitDate = const Value.absent(),
    this.geoLocation = const Value.absent(),
    this.checkoutLocation = const Value.absent(),
    this.outstanding = const Value.absent(),
    this.typeofVisit = const Value.absent(),
    this.appVisitPlanId = const Value.absent(),
    this.visitPlanId = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  }) : plannedStartTime = Value(plannedStartTime);
  static Insertable<Visit> custom({
    Expression<String>? salesAppId,
    Expression<String>? id,
    Expression<String>? accountId,
    Expression<String>? appAccountId,
    Expression<String>? accountName,
    Expression<String>? status,
    Expression<DateTime>? plannedStartTime,
    Expression<DateTime>? plannedEndTime,
    Expression<DateTime>? actualStartTime,
    Expression<DateTime>? actualEndTime,
    Expression<String>? comments,
    Expression<String>? missedReason,
    Expression<String>? lastVisitComment,
    Expression<DateTime>? lastVisitDate,
    Expression<String>? geoLocation,
    Expression<String>? checkoutLocation,
    Expression<double>? outstanding,
    Expression<String>? typeofVisit,
    Expression<String>? appVisitPlanId,
    Expression<String>? visitPlanId,
    Expression<bool>? synced,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (salesAppId != null) 'sales_app_id': salesAppId,
      if (id != null) 'id': id,
      if (accountId != null) 'account_id': accountId,
      if (appAccountId != null) 'app_account_id': appAccountId,
      if (accountName != null) 'account_name': accountName,
      if (status != null) 'status': status,
      if (plannedStartTime != null) 'planned_start_time': plannedStartTime,
      if (plannedEndTime != null) 'planned_end_time': plannedEndTime,
      if (actualStartTime != null) 'actual_start_time': actualStartTime,
      if (actualEndTime != null) 'actual_end_time': actualEndTime,
      if (comments != null) 'comments': comments,
      if (missedReason != null) 'missed_reason': missedReason,
      if (lastVisitComment != null) 'last_visit_comment': lastVisitComment,
      if (lastVisitDate != null) 'last_visit_date': lastVisitDate,
      if (geoLocation != null) 'geo_location': geoLocation,
      if (checkoutLocation != null) 'checkout_location': checkoutLocation,
      if (outstanding != null) 'outstanding': outstanding,
      if (typeofVisit != null) 'typeof_visit': typeofVisit,
      if (appVisitPlanId != null) 'app_visit_plan_id': appVisitPlanId,
      if (visitPlanId != null) 'visit_plan_id': visitPlanId,
      if (synced != null) 'synced': synced,
      if (rowid != null) 'rowid': rowid,
    });
  }

  VisitsCompanion copyWith(
      {Value<String?>? salesAppId,
      Value<String?>? id,
      Value<String?>? accountId,
      Value<String?>? appAccountId,
      Value<String?>? accountName,
      Value<String?>? status,
      Value<DateTime>? plannedStartTime,
      Value<DateTime?>? plannedEndTime,
      Value<DateTime?>? actualStartTime,
      Value<DateTime?>? actualEndTime,
      Value<String?>? comments,
      Value<String?>? missedReason,
      Value<String?>? lastVisitComment,
      Value<DateTime?>? lastVisitDate,
      Value<LatLng?>? geoLocation,
      Value<LatLng?>? checkoutLocation,
      Value<double?>? outstanding,
      Value<String?>? typeofVisit,
      Value<String?>? appVisitPlanId,
      Value<String?>? visitPlanId,
      Value<bool?>? synced,
      Value<int>? rowid}) {
    return VisitsCompanion(
      salesAppId: salesAppId ?? this.salesAppId,
      id: id ?? this.id,
      accountId: accountId ?? this.accountId,
      appAccountId: appAccountId ?? this.appAccountId,
      accountName: accountName ?? this.accountName,
      status: status ?? this.status,
      plannedStartTime: plannedStartTime ?? this.plannedStartTime,
      plannedEndTime: plannedEndTime ?? this.plannedEndTime,
      actualStartTime: actualStartTime ?? this.actualStartTime,
      actualEndTime: actualEndTime ?? this.actualEndTime,
      comments: comments ?? this.comments,
      missedReason: missedReason ?? this.missedReason,
      lastVisitComment: lastVisitComment ?? this.lastVisitComment,
      lastVisitDate: lastVisitDate ?? this.lastVisitDate,
      geoLocation: geoLocation ?? this.geoLocation,
      checkoutLocation: checkoutLocation ?? this.checkoutLocation,
      outstanding: outstanding ?? this.outstanding,
      typeofVisit: typeofVisit ?? this.typeofVisit,
      appVisitPlanId: appVisitPlanId ?? this.appVisitPlanId,
      visitPlanId: visitPlanId ?? this.visitPlanId,
      synced: synced ?? this.synced,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (salesAppId.present) {
      map['sales_app_id'] = Variable<String>(salesAppId.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (accountId.present) {
      map['account_id'] = Variable<String>(accountId.value);
    }
    if (appAccountId.present) {
      map['app_account_id'] = Variable<String>(appAccountId.value);
    }
    if (accountName.present) {
      map['account_name'] = Variable<String>(accountName.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (plannedStartTime.present) {
      map['planned_start_time'] = Variable<DateTime>(plannedStartTime.value);
    }
    if (plannedEndTime.present) {
      map['planned_end_time'] = Variable<DateTime>(plannedEndTime.value);
    }
    if (actualStartTime.present) {
      map['actual_start_time'] = Variable<DateTime>(actualStartTime.value);
    }
    if (actualEndTime.present) {
      map['actual_end_time'] = Variable<DateTime>(actualEndTime.value);
    }
    if (comments.present) {
      map['comments'] = Variable<String>(comments.value);
    }
    if (missedReason.present) {
      map['missed_reason'] = Variable<String>(missedReason.value);
    }
    if (lastVisitComment.present) {
      map['last_visit_comment'] = Variable<String>(lastVisitComment.value);
    }
    if (lastVisitDate.present) {
      map['last_visit_date'] = Variable<DateTime>(lastVisitDate.value);
    }
    if (geoLocation.present) {
      map['geo_location'] = Variable<String>(
          $VisitsTable.$convertergeoLocationn.toSql(geoLocation.value));
    }
    if (checkoutLocation.present) {
      map['checkout_location'] = Variable<String>($VisitsTable
          .$convertercheckoutLocationn
          .toSql(checkoutLocation.value));
    }
    if (outstanding.present) {
      map['outstanding'] = Variable<double>(outstanding.value);
    }
    if (typeofVisit.present) {
      map['typeof_visit'] = Variable<String>(typeofVisit.value);
    }
    if (appVisitPlanId.present) {
      map['app_visit_plan_id'] = Variable<String>(appVisitPlanId.value);
    }
    if (visitPlanId.present) {
      map['visit_plan_id'] = Variable<String>(visitPlanId.value);
    }
    if (synced.present) {
      map['synced'] = Variable<bool>(synced.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('VisitsCompanion(')
          ..write('salesAppId: $salesAppId, ')
          ..write('id: $id, ')
          ..write('accountId: $accountId, ')
          ..write('appAccountId: $appAccountId, ')
          ..write('accountName: $accountName, ')
          ..write('status: $status, ')
          ..write('plannedStartTime: $plannedStartTime, ')
          ..write('plannedEndTime: $plannedEndTime, ')
          ..write('actualStartTime: $actualStartTime, ')
          ..write('actualEndTime: $actualEndTime, ')
          ..write('comments: $comments, ')
          ..write('missedReason: $missedReason, ')
          ..write('lastVisitComment: $lastVisitComment, ')
          ..write('lastVisitDate: $lastVisitDate, ')
          ..write('geoLocation: $geoLocation, ')
          ..write('checkoutLocation: $checkoutLocation, ')
          ..write('outstanding: $outstanding, ')
          ..write('typeofVisit: $typeofVisit, ')
          ..write('appVisitPlanId: $appVisitPlanId, ')
          ..write('visitPlanId: $visitPlanId, ')
          ..write('synced: $synced, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $DayLogsTable extends DayLogs with TableInfo<$DayLogsTable, DayLog> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $DayLogsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _dayMeta = const VerificationMeta('day');
  @override
  late final GeneratedColumn<String> day = GeneratedColumn<String>(
      'day', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _dayStartTimeMeta =
      const VerificationMeta('dayStartTime');
  @override
  late final GeneratedColumn<DateTime> dayStartTime = GeneratedColumn<DateTime>(
      'day_start_time', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _dayEndTimeMeta =
      const VerificationMeta('dayEndTime');
  @override
  late final GeneratedColumn<DateTime> dayEndTime = GeneratedColumn<DateTime>(
      'day_end_time', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _startLocationMeta =
      const VerificationMeta('startLocation');
  @override
  late final GeneratedColumnWithTypeConverter<LatLng, String> startLocation =
      GeneratedColumn<String>('start_location', aliasedName, false,
              type: DriftSqlType.string, requiredDuringInsert: true)
          .withConverter<LatLng>($DayLogsTable.$converterstartLocation);
  static const VerificationMeta _endLocationMeta =
      const VerificationMeta('endLocation');
  @override
  late final GeneratedColumnWithTypeConverter<LatLng?, String> endLocation =
      GeneratedColumn<String>('end_location', aliasedName, true,
              type: DriftSqlType.string, requiredDuringInsert: false)
          .withConverter<LatLng?>($DayLogsTable.$converterendLocationn);
  static const VerificationMeta _syncedMeta = const VerificationMeta('synced');
  @override
  late final GeneratedColumn<bool> synced = GeneratedColumn<bool>(
      'synced', aliasedName, true,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("synced" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns =>
      [day, dayStartTime, dayEndTime, startLocation, endLocation, synced];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'day_logs';
  @override
  VerificationContext validateIntegrity(Insertable<DayLog> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('day')) {
      context.handle(
          _dayMeta, day.isAcceptableOrUnknown(data['day']!, _dayMeta));
    } else if (isInserting) {
      context.missing(_dayMeta);
    }
    if (data.containsKey('day_start_time')) {
      context.handle(
          _dayStartTimeMeta,
          dayStartTime.isAcceptableOrUnknown(
              data['day_start_time']!, _dayStartTimeMeta));
    } else if (isInserting) {
      context.missing(_dayStartTimeMeta);
    }
    if (data.containsKey('day_end_time')) {
      context.handle(
          _dayEndTimeMeta,
          dayEndTime.isAcceptableOrUnknown(
              data['day_end_time']!, _dayEndTimeMeta));
    }
    context.handle(_startLocationMeta, const VerificationResult.success());
    context.handle(_endLocationMeta, const VerificationResult.success());
    if (data.containsKey('synced')) {
      context.handle(_syncedMeta,
          synced.isAcceptableOrUnknown(data['synced']!, _syncedMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {day};
  @override
  DayLog map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return DayLog(
      day: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}day'])!,
      dayStartTime: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}day_start_time'])!,
      dayEndTime: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}day_end_time']),
      startLocation: $DayLogsTable.$converterstartLocation.fromSql(
          attachedDatabase.typeMapping.read(
              DriftSqlType.string, data['${effectivePrefix}start_location'])!),
      endLocation: $DayLogsTable.$converterendLocationn.fromSql(attachedDatabase
          .typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}end_location'])),
      synced: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}synced']),
    );
  }

  @override
  $DayLogsTable createAlias(String alias) {
    return $DayLogsTable(attachedDatabase, alias);
  }

  static TypeConverter<LatLng, String> $converterstartLocation =
      const LatLngConverter();
  static TypeConverter<LatLng, String> $converterendLocation =
      const LatLngConverter();
  static TypeConverter<LatLng?, String?> $converterendLocationn =
      NullAwareTypeConverter.wrap($converterendLocation);
}

class DayLog extends DataClass implements Insertable<DayLog> {
  final String day;
  final DateTime dayStartTime;
  final DateTime? dayEndTime;
  final LatLng startLocation;
  final LatLng? endLocation;
  final bool? synced;
  const DayLog(
      {required this.day,
      required this.dayStartTime,
      this.dayEndTime,
      required this.startLocation,
      this.endLocation,
      this.synced});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['day'] = Variable<String>(day);
    map['day_start_time'] = Variable<DateTime>(dayStartTime);
    if (!nullToAbsent || dayEndTime != null) {
      map['day_end_time'] = Variable<DateTime>(dayEndTime);
    }
    {
      map['start_location'] = Variable<String>(
          $DayLogsTable.$converterstartLocation.toSql(startLocation));
    }
    if (!nullToAbsent || endLocation != null) {
      map['end_location'] = Variable<String>(
          $DayLogsTable.$converterendLocationn.toSql(endLocation));
    }
    if (!nullToAbsent || synced != null) {
      map['synced'] = Variable<bool>(synced);
    }
    return map;
  }

  DayLogsCompanion toCompanion(bool nullToAbsent) {
    return DayLogsCompanion(
      day: Value(day),
      dayStartTime: Value(dayStartTime),
      dayEndTime: dayEndTime == null && nullToAbsent
          ? const Value.absent()
          : Value(dayEndTime),
      startLocation: Value(startLocation),
      endLocation: endLocation == null && nullToAbsent
          ? const Value.absent()
          : Value(endLocation),
      synced:
          synced == null && nullToAbsent ? const Value.absent() : Value(synced),
    );
  }

  factory DayLog.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return DayLog(
      day: serializer.fromJson<String>(json['day']),
      dayStartTime: serializer.fromJson<DateTime>(json['dayStartTime']),
      dayEndTime: serializer.fromJson<DateTime?>(json['dayEndTime']),
      startLocation: serializer.fromJson<LatLng>(json['startLocation']),
      endLocation: serializer.fromJson<LatLng?>(json['endLocation']),
      synced: serializer.fromJson<bool?>(json['synced']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'day': serializer.toJson<String>(day),
      'dayStartTime': serializer.toJson<DateTime>(dayStartTime),
      'dayEndTime': serializer.toJson<DateTime?>(dayEndTime),
      'startLocation': serializer.toJson<LatLng>(startLocation),
      'endLocation': serializer.toJson<LatLng?>(endLocation),
      'synced': serializer.toJson<bool?>(synced),
    };
  }

  DayLog copyWith(
          {String? day,
          DateTime? dayStartTime,
          Value<DateTime?> dayEndTime = const Value.absent(),
          LatLng? startLocation,
          Value<LatLng?> endLocation = const Value.absent(),
          Value<bool?> synced = const Value.absent()}) =>
      DayLog(
        day: day ?? this.day,
        dayStartTime: dayStartTime ?? this.dayStartTime,
        dayEndTime: dayEndTime.present ? dayEndTime.value : this.dayEndTime,
        startLocation: startLocation ?? this.startLocation,
        endLocation: endLocation.present ? endLocation.value : this.endLocation,
        synced: synced.present ? synced.value : this.synced,
      );
  @override
  String toString() {
    return (StringBuffer('DayLog(')
          ..write('day: $day, ')
          ..write('dayStartTime: $dayStartTime, ')
          ..write('dayEndTime: $dayEndTime, ')
          ..write('startLocation: $startLocation, ')
          ..write('endLocation: $endLocation, ')
          ..write('synced: $synced')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      day, dayStartTime, dayEndTime, startLocation, endLocation, synced);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is DayLog &&
          other.day == this.day &&
          other.dayStartTime == this.dayStartTime &&
          other.dayEndTime == this.dayEndTime &&
          other.startLocation == this.startLocation &&
          other.endLocation == this.endLocation &&
          other.synced == this.synced);
}

class DayLogsCompanion extends UpdateCompanion<DayLog> {
  final Value<String> day;
  final Value<DateTime> dayStartTime;
  final Value<DateTime?> dayEndTime;
  final Value<LatLng> startLocation;
  final Value<LatLng?> endLocation;
  final Value<bool?> synced;
  final Value<int> rowid;
  const DayLogsCompanion({
    this.day = const Value.absent(),
    this.dayStartTime = const Value.absent(),
    this.dayEndTime = const Value.absent(),
    this.startLocation = const Value.absent(),
    this.endLocation = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  DayLogsCompanion.insert({
    required String day,
    required DateTime dayStartTime,
    this.dayEndTime = const Value.absent(),
    required LatLng startLocation,
    this.endLocation = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : day = Value(day),
        dayStartTime = Value(dayStartTime),
        startLocation = Value(startLocation);
  static Insertable<DayLog> custom({
    Expression<String>? day,
    Expression<DateTime>? dayStartTime,
    Expression<DateTime>? dayEndTime,
    Expression<String>? startLocation,
    Expression<String>? endLocation,
    Expression<bool>? synced,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (day != null) 'day': day,
      if (dayStartTime != null) 'day_start_time': dayStartTime,
      if (dayEndTime != null) 'day_end_time': dayEndTime,
      if (startLocation != null) 'start_location': startLocation,
      if (endLocation != null) 'end_location': endLocation,
      if (synced != null) 'synced': synced,
      if (rowid != null) 'rowid': rowid,
    });
  }

  DayLogsCompanion copyWith(
      {Value<String>? day,
      Value<DateTime>? dayStartTime,
      Value<DateTime?>? dayEndTime,
      Value<LatLng>? startLocation,
      Value<LatLng?>? endLocation,
      Value<bool?>? synced,
      Value<int>? rowid}) {
    return DayLogsCompanion(
      day: day ?? this.day,
      dayStartTime: dayStartTime ?? this.dayStartTime,
      dayEndTime: dayEndTime ?? this.dayEndTime,
      startLocation: startLocation ?? this.startLocation,
      endLocation: endLocation ?? this.endLocation,
      synced: synced ?? this.synced,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (day.present) {
      map['day'] = Variable<String>(day.value);
    }
    if (dayStartTime.present) {
      map['day_start_time'] = Variable<DateTime>(dayStartTime.value);
    }
    if (dayEndTime.present) {
      map['day_end_time'] = Variable<DateTime>(dayEndTime.value);
    }
    if (startLocation.present) {
      map['start_location'] = Variable<String>(
          $DayLogsTable.$converterstartLocation.toSql(startLocation.value));
    }
    if (endLocation.present) {
      map['end_location'] = Variable<String>(
          $DayLogsTable.$converterendLocationn.toSql(endLocation.value));
    }
    if (synced.present) {
      map['synced'] = Variable<bool>(synced.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('DayLogsCompanion(')
          ..write('day: $day, ')
          ..write('dayStartTime: $dayStartTime, ')
          ..write('dayEndTime: $dayEndTime, ')
          ..write('startLocation: $startLocation, ')
          ..write('endLocation: $endLocation, ')
          ..write('synced: $synced, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $CartItemsTable extends CartItems
    with TableInfo<$CartItemsTable, CartItem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CartItemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _productIdMeta =
      const VerificationMeta('productId');
  @override
  late final GeneratedColumn<String> productId = GeneratedColumn<String>(
      'product_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _productNameMeta =
      const VerificationMeta('productName');
  @override
  late final GeneratedColumn<String> productName = GeneratedColumn<String>(
      'product_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _quantityMeta =
      const VerificationMeta('quantity');
  @override
  late final GeneratedColumn<int> quantity = GeneratedColumn<int>(
      'quantity', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _unitPriceMeta =
      const VerificationMeta('unitPrice');
  @override
  late final GeneratedColumn<double> unitPrice = GeneratedColumn<double>(
      'unit_price', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _taxPercentMeta =
      const VerificationMeta('taxPercent');
  @override
  late final GeneratedColumn<double> taxPercent = GeneratedColumn<double>(
      'tax_percent', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _taxAmountMeta =
      const VerificationMeta('taxAmount');
  @override
  late final GeneratedColumn<double> taxAmount = GeneratedColumn<double>(
      'tax_amount', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _totalAmountMeta =
      const VerificationMeta('totalAmount');
  @override
  late final GeneratedColumn<double> totalAmount = GeneratedColumn<double>(
      'total_amount', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _totalTaxMeta =
      const VerificationMeta('totalTax');
  @override
  late final GeneratedColumn<double> totalTax = GeneratedColumn<double>(
      'total_tax', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _grandTotalMeta =
      const VerificationMeta('grandTotal');
  @override
  late final GeneratedColumn<double> grandTotal = GeneratedColumn<double>(
      'grand_total', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        productId,
        productName,
        quantity,
        unitPrice,
        taxPercent,
        taxAmount,
        totalAmount,
        totalTax,
        grandTotal
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cart_items';
  @override
  VerificationContext validateIntegrity(Insertable<CartItem> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('product_id')) {
      context.handle(_productIdMeta,
          productId.isAcceptableOrUnknown(data['product_id']!, _productIdMeta));
    } else if (isInserting) {
      context.missing(_productIdMeta);
    }
    if (data.containsKey('product_name')) {
      context.handle(
          _productNameMeta,
          productName.isAcceptableOrUnknown(
              data['product_name']!, _productNameMeta));
    } else if (isInserting) {
      context.missing(_productNameMeta);
    }
    if (data.containsKey('quantity')) {
      context.handle(_quantityMeta,
          quantity.isAcceptableOrUnknown(data['quantity']!, _quantityMeta));
    } else if (isInserting) {
      context.missing(_quantityMeta);
    }
    if (data.containsKey('unit_price')) {
      context.handle(_unitPriceMeta,
          unitPrice.isAcceptableOrUnknown(data['unit_price']!, _unitPriceMeta));
    } else if (isInserting) {
      context.missing(_unitPriceMeta);
    }
    if (data.containsKey('tax_percent')) {
      context.handle(
          _taxPercentMeta,
          taxPercent.isAcceptableOrUnknown(
              data['tax_percent']!, _taxPercentMeta));
    } else if (isInserting) {
      context.missing(_taxPercentMeta);
    }
    if (data.containsKey('tax_amount')) {
      context.handle(_taxAmountMeta,
          taxAmount.isAcceptableOrUnknown(data['tax_amount']!, _taxAmountMeta));
    } else if (isInserting) {
      context.missing(_taxAmountMeta);
    }
    if (data.containsKey('total_amount')) {
      context.handle(
          _totalAmountMeta,
          totalAmount.isAcceptableOrUnknown(
              data['total_amount']!, _totalAmountMeta));
    } else if (isInserting) {
      context.missing(_totalAmountMeta);
    }
    if (data.containsKey('total_tax')) {
      context.handle(_totalTaxMeta,
          totalTax.isAcceptableOrUnknown(data['total_tax']!, _totalTaxMeta));
    } else if (isInserting) {
      context.missing(_totalTaxMeta);
    }
    if (data.containsKey('grand_total')) {
      context.handle(
          _grandTotalMeta,
          grandTotal.isAcceptableOrUnknown(
              data['grand_total']!, _grandTotalMeta));
    } else if (isInserting) {
      context.missing(_grandTotalMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CartItem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CartItem(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      productId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}product_id'])!,
      productName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}product_name'])!,
      quantity: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}quantity'])!,
      unitPrice: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}unit_price'])!,
      taxPercent: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}tax_percent'])!,
      taxAmount: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}tax_amount'])!,
      totalAmount: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}total_amount'])!,
      totalTax: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}total_tax'])!,
      grandTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}grand_total'])!,
    );
  }

  @override
  $CartItemsTable createAlias(String alias) {
    return $CartItemsTable(attachedDatabase, alias);
  }
}

class CartItem extends DataClass implements Insertable<CartItem> {
  final int? id;
  final String productId;
  final String productName;
  final int quantity;
  final double unitPrice;
  final double taxPercent;
  final double taxAmount;
  final double totalAmount;
  final double totalTax;
  final double grandTotal;
  const CartItem(
      {this.id,
      required this.productId,
      required this.productName,
      required this.quantity,
      required this.unitPrice,
      required this.taxPercent,
      required this.taxAmount,
      required this.totalAmount,
      required this.totalTax,
      required this.grandTotal});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    map['product_id'] = Variable<String>(productId);
    map['product_name'] = Variable<String>(productName);
    map['quantity'] = Variable<int>(quantity);
    map['unit_price'] = Variable<double>(unitPrice);
    map['tax_percent'] = Variable<double>(taxPercent);
    map['tax_amount'] = Variable<double>(taxAmount);
    map['total_amount'] = Variable<double>(totalAmount);
    map['total_tax'] = Variable<double>(totalTax);
    map['grand_total'] = Variable<double>(grandTotal);
    return map;
  }

  CartItemsCompanion toCompanion(bool nullToAbsent) {
    return CartItemsCompanion(
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      productId: Value(productId),
      productName: Value(productName),
      quantity: Value(quantity),
      unitPrice: Value(unitPrice),
      taxPercent: Value(taxPercent),
      taxAmount: Value(taxAmount),
      totalAmount: Value(totalAmount),
      totalTax: Value(totalTax),
      grandTotal: Value(grandTotal),
    );
  }

  factory CartItem.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CartItem(
      id: serializer.fromJson<int?>(json['id']),
      productId: serializer.fromJson<String>(json['productId']),
      productName: serializer.fromJson<String>(json['productName']),
      quantity: serializer.fromJson<int>(json['quantity']),
      unitPrice: serializer.fromJson<double>(json['unitPrice']),
      taxPercent: serializer.fromJson<double>(json['taxPercent']),
      taxAmount: serializer.fromJson<double>(json['taxAmount']),
      totalAmount: serializer.fromJson<double>(json['totalAmount']),
      totalTax: serializer.fromJson<double>(json['totalTax']),
      grandTotal: serializer.fromJson<double>(json['grandTotal']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'productId': serializer.toJson<String>(productId),
      'productName': serializer.toJson<String>(productName),
      'quantity': serializer.toJson<int>(quantity),
      'unitPrice': serializer.toJson<double>(unitPrice),
      'taxPercent': serializer.toJson<double>(taxPercent),
      'taxAmount': serializer.toJson<double>(taxAmount),
      'totalAmount': serializer.toJson<double>(totalAmount),
      'totalTax': serializer.toJson<double>(totalTax),
      'grandTotal': serializer.toJson<double>(grandTotal),
    };
  }

  CartItem copyWith(
          {Value<int?> id = const Value.absent(),
          String? productId,
          String? productName,
          int? quantity,
          double? unitPrice,
          double? taxPercent,
          double? taxAmount,
          double? totalAmount,
          double? totalTax,
          double? grandTotal}) =>
      CartItem(
        id: id.present ? id.value : this.id,
        productId: productId ?? this.productId,
        productName: productName ?? this.productName,
        quantity: quantity ?? this.quantity,
        unitPrice: unitPrice ?? this.unitPrice,
        taxPercent: taxPercent ?? this.taxPercent,
        taxAmount: taxAmount ?? this.taxAmount,
        totalAmount: totalAmount ?? this.totalAmount,
        totalTax: totalTax ?? this.totalTax,
        grandTotal: grandTotal ?? this.grandTotal,
      );
  @override
  String toString() {
    return (StringBuffer('CartItem(')
          ..write('id: $id, ')
          ..write('productId: $productId, ')
          ..write('productName: $productName, ')
          ..write('quantity: $quantity, ')
          ..write('unitPrice: $unitPrice, ')
          ..write('taxPercent: $taxPercent, ')
          ..write('taxAmount: $taxAmount, ')
          ..write('totalAmount: $totalAmount, ')
          ..write('totalTax: $totalTax, ')
          ..write('grandTotal: $grandTotal')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, productId, productName, quantity,
      unitPrice, taxPercent, taxAmount, totalAmount, totalTax, grandTotal);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CartItem &&
          other.id == this.id &&
          other.productId == this.productId &&
          other.productName == this.productName &&
          other.quantity == this.quantity &&
          other.unitPrice == this.unitPrice &&
          other.taxPercent == this.taxPercent &&
          other.taxAmount == this.taxAmount &&
          other.totalAmount == this.totalAmount &&
          other.totalTax == this.totalTax &&
          other.grandTotal == this.grandTotal);
}

class CartItemsCompanion extends UpdateCompanion<CartItem> {
  final Value<int?> id;
  final Value<String> productId;
  final Value<String> productName;
  final Value<int> quantity;
  final Value<double> unitPrice;
  final Value<double> taxPercent;
  final Value<double> taxAmount;
  final Value<double> totalAmount;
  final Value<double> totalTax;
  final Value<double> grandTotal;
  const CartItemsCompanion({
    this.id = const Value.absent(),
    this.productId = const Value.absent(),
    this.productName = const Value.absent(),
    this.quantity = const Value.absent(),
    this.unitPrice = const Value.absent(),
    this.taxPercent = const Value.absent(),
    this.taxAmount = const Value.absent(),
    this.totalAmount = const Value.absent(),
    this.totalTax = const Value.absent(),
    this.grandTotal = const Value.absent(),
  });
  CartItemsCompanion.insert({
    this.id = const Value.absent(),
    required String productId,
    required String productName,
    required int quantity,
    required double unitPrice,
    required double taxPercent,
    required double taxAmount,
    required double totalAmount,
    required double totalTax,
    required double grandTotal,
  })  : productId = Value(productId),
        productName = Value(productName),
        quantity = Value(quantity),
        unitPrice = Value(unitPrice),
        taxPercent = Value(taxPercent),
        taxAmount = Value(taxAmount),
        totalAmount = Value(totalAmount),
        totalTax = Value(totalTax),
        grandTotal = Value(grandTotal);
  static Insertable<CartItem> custom({
    Expression<int>? id,
    Expression<String>? productId,
    Expression<String>? productName,
    Expression<int>? quantity,
    Expression<double>? unitPrice,
    Expression<double>? taxPercent,
    Expression<double>? taxAmount,
    Expression<double>? totalAmount,
    Expression<double>? totalTax,
    Expression<double>? grandTotal,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (productId != null) 'product_id': productId,
      if (productName != null) 'product_name': productName,
      if (quantity != null) 'quantity': quantity,
      if (unitPrice != null) 'unit_price': unitPrice,
      if (taxPercent != null) 'tax_percent': taxPercent,
      if (taxAmount != null) 'tax_amount': taxAmount,
      if (totalAmount != null) 'total_amount': totalAmount,
      if (totalTax != null) 'total_tax': totalTax,
      if (grandTotal != null) 'grand_total': grandTotal,
    });
  }

  CartItemsCompanion copyWith(
      {Value<int?>? id,
      Value<String>? productId,
      Value<String>? productName,
      Value<int>? quantity,
      Value<double>? unitPrice,
      Value<double>? taxPercent,
      Value<double>? taxAmount,
      Value<double>? totalAmount,
      Value<double>? totalTax,
      Value<double>? grandTotal}) {
    return CartItemsCompanion(
      id: id ?? this.id,
      productId: productId ?? this.productId,
      productName: productName ?? this.productName,
      quantity: quantity ?? this.quantity,
      unitPrice: unitPrice ?? this.unitPrice,
      taxPercent: taxPercent ?? this.taxPercent,
      taxAmount: taxAmount ?? this.taxAmount,
      totalAmount: totalAmount ?? this.totalAmount,
      totalTax: totalTax ?? this.totalTax,
      grandTotal: grandTotal ?? this.grandTotal,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (productId.present) {
      map['product_id'] = Variable<String>(productId.value);
    }
    if (productName.present) {
      map['product_name'] = Variable<String>(productName.value);
    }
    if (quantity.present) {
      map['quantity'] = Variable<int>(quantity.value);
    }
    if (unitPrice.present) {
      map['unit_price'] = Variable<double>(unitPrice.value);
    }
    if (taxPercent.present) {
      map['tax_percent'] = Variable<double>(taxPercent.value);
    }
    if (taxAmount.present) {
      map['tax_amount'] = Variable<double>(taxAmount.value);
    }
    if (totalAmount.present) {
      map['total_amount'] = Variable<double>(totalAmount.value);
    }
    if (totalTax.present) {
      map['total_tax'] = Variable<double>(totalTax.value);
    }
    if (grandTotal.present) {
      map['grand_total'] = Variable<double>(grandTotal.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CartItemsCompanion(')
          ..write('id: $id, ')
          ..write('productId: $productId, ')
          ..write('productName: $productName, ')
          ..write('quantity: $quantity, ')
          ..write('unitPrice: $unitPrice, ')
          ..write('taxPercent: $taxPercent, ')
          ..write('taxAmount: $taxAmount, ')
          ..write('totalAmount: $totalAmount, ')
          ..write('totalTax: $totalTax, ')
          ..write('grandTotal: $grandTotal')
          ..write(')'))
        .toString();
  }
}

class $OrdersTable extends Orders with TableInfo<$OrdersTable, Order> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $OrdersTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _appOrderIdMeta =
      const VerificationMeta('appOrderId');
  @override
  late final GeneratedColumn<String> appOrderId = GeneratedColumn<String>(
      'app_order_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _salesAppIdMeta =
      const VerificationMeta('salesAppId');
  @override
  late final GeneratedColumn<String> salesAppId = GeneratedColumn<String>(
      'sales_app_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _accountIdMeta =
      const VerificationMeta('accountId');
  @override
  late final GeneratedColumn<String> accountId = GeneratedColumn<String>(
      'account_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _appAccountIdMeta =
      const VerificationMeta('appAccountId');
  @override
  late final GeneratedColumn<String> appAccountId = GeneratedColumn<String>(
      'app_account_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _accountNameMeta =
      const VerificationMeta('accountName');
  @override
  late final GeneratedColumn<String> accountName = GeneratedColumn<String>(
      'account_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _grandTotalMeta =
      const VerificationMeta('grandTotal');
  @override
  late final GeneratedColumn<double> grandTotal = GeneratedColumn<double>(
      'grand_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _totalAmountMeta =
      const VerificationMeta('totalAmount');
  @override
  late final GeneratedColumn<double> totalAmount = GeneratedColumn<double>(
      'total_amount', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _totalTaxMeta =
      const VerificationMeta('totalTax');
  @override
  late final GeneratedColumn<double> totalTax = GeneratedColumn<double>(
      'total_tax', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(OrderStatus.newOrder));
  static const VerificationMeta _orderDateMeta =
      const VerificationMeta('orderDate');
  @override
  late final GeneratedColumn<DateTime> orderDate = GeneratedColumn<DateTime>(
      'order_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _descriptionMeta =
      const VerificationMeta('description');
  @override
  late final GeneratedColumn<String> description = GeneratedColumn<String>(
      'description', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdDateMeta =
      const VerificationMeta('createdDate');
  @override
  late final GeneratedColumn<DateTime> createdDate = GeneratedColumn<DateTime>(
      'created_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _syncedMeta = const VerificationMeta('synced');
  @override
  late final GeneratedColumn<bool> synced = GeneratedColumn<bool>(
      'synced', aliasedName, true,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("synced" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        appOrderId,
        id,
        salesAppId,
        accountId,
        appAccountId,
        accountName,
        grandTotal,
        totalAmount,
        totalTax,
        status,
        orderDate,
        name,
        description,
        createdDate,
        synced
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'orders';
  @override
  VerificationContext validateIntegrity(Insertable<Order> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('app_order_id')) {
      context.handle(
          _appOrderIdMeta,
          appOrderId.isAcceptableOrUnknown(
              data['app_order_id']!, _appOrderIdMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('sales_app_id')) {
      context.handle(
          _salesAppIdMeta,
          salesAppId.isAcceptableOrUnknown(
              data['sales_app_id']!, _salesAppIdMeta));
    }
    if (data.containsKey('account_id')) {
      context.handle(_accountIdMeta,
          accountId.isAcceptableOrUnknown(data['account_id']!, _accountIdMeta));
    }
    if (data.containsKey('app_account_id')) {
      context.handle(
          _appAccountIdMeta,
          appAccountId.isAcceptableOrUnknown(
              data['app_account_id']!, _appAccountIdMeta));
    }
    if (data.containsKey('account_name')) {
      context.handle(
          _accountNameMeta,
          accountName.isAcceptableOrUnknown(
              data['account_name']!, _accountNameMeta));
    }
    if (data.containsKey('grand_total')) {
      context.handle(
          _grandTotalMeta,
          grandTotal.isAcceptableOrUnknown(
              data['grand_total']!, _grandTotalMeta));
    }
    if (data.containsKey('total_amount')) {
      context.handle(
          _totalAmountMeta,
          totalAmount.isAcceptableOrUnknown(
              data['total_amount']!, _totalAmountMeta));
    }
    if (data.containsKey('total_tax')) {
      context.handle(_totalTaxMeta,
          totalTax.isAcceptableOrUnknown(data['total_tax']!, _totalTaxMeta));
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('order_date')) {
      context.handle(_orderDateMeta,
          orderDate.isAcceptableOrUnknown(data['order_date']!, _orderDateMeta));
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    }
    if (data.containsKey('description')) {
      context.handle(
          _descriptionMeta,
          description.isAcceptableOrUnknown(
              data['description']!, _descriptionMeta));
    }
    if (data.containsKey('created_date')) {
      context.handle(
          _createdDateMeta,
          createdDate.isAcceptableOrUnknown(
              data['created_date']!, _createdDateMeta));
    }
    if (data.containsKey('synced')) {
      context.handle(_syncedMeta,
          synced.isAcceptableOrUnknown(data['synced']!, _syncedMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {appOrderId};
  @override
  Order map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Order(
      appOrderId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_order_id']),
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id']),
      salesAppId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sales_app_id']),
      accountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}account_id']),
      appAccountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_account_id']),
      accountName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}account_name']),
      grandTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}grand_total']),
      totalAmount: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}total_amount']),
      totalTax: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}total_tax']),
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status']),
      orderDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}order_date']),
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name']),
      description: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}description']),
      createdDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_date']),
      synced: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}synced']),
    );
  }

  @override
  $OrdersTable createAlias(String alias) {
    return $OrdersTable(attachedDatabase, alias);
  }
}

class Order extends DataClass implements Insertable<Order> {
  final String? appOrderId;
  final String? id;
  final String? salesAppId;
  final String? accountId;
  final String? appAccountId;
  final String? accountName;
  final double? grandTotal;
  final double? totalAmount;
  final double? totalTax;
  final String? status;
  final DateTime? orderDate;
  final String? name;
  final String? description;
  final DateTime? createdDate;
  final bool? synced;
  const Order(
      {this.appOrderId,
      this.id,
      this.salesAppId,
      this.accountId,
      this.appAccountId,
      this.accountName,
      this.grandTotal,
      this.totalAmount,
      this.totalTax,
      this.status,
      this.orderDate,
      this.name,
      this.description,
      this.createdDate,
      this.synced});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || appOrderId != null) {
      map['app_order_id'] = Variable<String>(appOrderId);
    }
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<String>(id);
    }
    if (!nullToAbsent || salesAppId != null) {
      map['sales_app_id'] = Variable<String>(salesAppId);
    }
    if (!nullToAbsent || accountId != null) {
      map['account_id'] = Variable<String>(accountId);
    }
    if (!nullToAbsent || appAccountId != null) {
      map['app_account_id'] = Variable<String>(appAccountId);
    }
    if (!nullToAbsent || accountName != null) {
      map['account_name'] = Variable<String>(accountName);
    }
    if (!nullToAbsent || grandTotal != null) {
      map['grand_total'] = Variable<double>(grandTotal);
    }
    if (!nullToAbsent || totalAmount != null) {
      map['total_amount'] = Variable<double>(totalAmount);
    }
    if (!nullToAbsent || totalTax != null) {
      map['total_tax'] = Variable<double>(totalTax);
    }
    if (!nullToAbsent || status != null) {
      map['status'] = Variable<String>(status);
    }
    if (!nullToAbsent || orderDate != null) {
      map['order_date'] = Variable<DateTime>(orderDate);
    }
    if (!nullToAbsent || name != null) {
      map['name'] = Variable<String>(name);
    }
    if (!nullToAbsent || description != null) {
      map['description'] = Variable<String>(description);
    }
    if (!nullToAbsent || createdDate != null) {
      map['created_date'] = Variable<DateTime>(createdDate);
    }
    if (!nullToAbsent || synced != null) {
      map['synced'] = Variable<bool>(synced);
    }
    return map;
  }

  OrdersCompanion toCompanion(bool nullToAbsent) {
    return OrdersCompanion(
      appOrderId: appOrderId == null && nullToAbsent
          ? const Value.absent()
          : Value(appOrderId),
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      salesAppId: salesAppId == null && nullToAbsent
          ? const Value.absent()
          : Value(salesAppId),
      accountId: accountId == null && nullToAbsent
          ? const Value.absent()
          : Value(accountId),
      appAccountId: appAccountId == null && nullToAbsent
          ? const Value.absent()
          : Value(appAccountId),
      accountName: accountName == null && nullToAbsent
          ? const Value.absent()
          : Value(accountName),
      grandTotal: grandTotal == null && nullToAbsent
          ? const Value.absent()
          : Value(grandTotal),
      totalAmount: totalAmount == null && nullToAbsent
          ? const Value.absent()
          : Value(totalAmount),
      totalTax: totalTax == null && nullToAbsent
          ? const Value.absent()
          : Value(totalTax),
      status:
          status == null && nullToAbsent ? const Value.absent() : Value(status),
      orderDate: orderDate == null && nullToAbsent
          ? const Value.absent()
          : Value(orderDate),
      name: name == null && nullToAbsent ? const Value.absent() : Value(name),
      description: description == null && nullToAbsent
          ? const Value.absent()
          : Value(description),
      createdDate: createdDate == null && nullToAbsent
          ? const Value.absent()
          : Value(createdDate),
      synced:
          synced == null && nullToAbsent ? const Value.absent() : Value(synced),
    );
  }

  factory Order.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Order(
      appOrderId: serializer.fromJson<String?>(json['appOrderId']),
      id: serializer.fromJson<String?>(json['id']),
      salesAppId: serializer.fromJson<String?>(json['salesAppId']),
      accountId: serializer.fromJson<String?>(json['acccountId']),
      appAccountId: serializer.fromJson<String?>(json['appAccountId']),
      accountName: serializer.fromJson<String?>(json['accountName']),
      grandTotal: serializer.fromJson<double?>(json['grandTotal']),
      totalAmount: serializer.fromJson<double?>(json['totalAmount']),
      totalTax: serializer.fromJson<double?>(json['totalTax']),
      status: serializer.fromJson<String?>(json['status']),
      orderDate: serializer.fromJson<DateTime?>(json['orderDate']),
      name: serializer.fromJson<String?>(json['Name']),
      description: serializer.fromJson<String?>(json['description']),
      createdDate: serializer.fromJson<DateTime?>(json['createdDate']),
      synced: serializer.fromJson<bool?>(json['synced']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'appOrderId': serializer.toJson<String?>(appOrderId),
      'id': serializer.toJson<String?>(id),
      'salesAppId': serializer.toJson<String?>(salesAppId),
      'acccountId': serializer.toJson<String?>(accountId),
      'appAccountId': serializer.toJson<String?>(appAccountId),
      'accountName': serializer.toJson<String?>(accountName),
      'grandTotal': serializer.toJson<double?>(grandTotal),
      'totalAmount': serializer.toJson<double?>(totalAmount),
      'totalTax': serializer.toJson<double?>(totalTax),
      'status': serializer.toJson<String?>(status),
      'orderDate': serializer.toJson<DateTime?>(orderDate),
      'Name': serializer.toJson<String?>(name),
      'description': serializer.toJson<String?>(description),
      'createdDate': serializer.toJson<DateTime?>(createdDate),
      'synced': serializer.toJson<bool?>(synced),
    };
  }

  Order copyWith(
          {Value<String?> appOrderId = const Value.absent(),
          Value<String?> id = const Value.absent(),
          Value<String?> salesAppId = const Value.absent(),
          Value<String?> accountId = const Value.absent(),
          Value<String?> appAccountId = const Value.absent(),
          Value<String?> accountName = const Value.absent(),
          Value<double?> grandTotal = const Value.absent(),
          Value<double?> totalAmount = const Value.absent(),
          Value<double?> totalTax = const Value.absent(),
          Value<String?> status = const Value.absent(),
          Value<DateTime?> orderDate = const Value.absent(),
          Value<String?> name = const Value.absent(),
          Value<String?> description = const Value.absent(),
          Value<DateTime?> createdDate = const Value.absent(),
          Value<bool?> synced = const Value.absent()}) =>
      Order(
        appOrderId: appOrderId.present ? appOrderId.value : this.appOrderId,
        id: id.present ? id.value : this.id,
        salesAppId: salesAppId.present ? salesAppId.value : this.salesAppId,
        accountId: accountId.present ? accountId.value : this.accountId,
        appAccountId:
            appAccountId.present ? appAccountId.value : this.appAccountId,
        accountName: accountName.present ? accountName.value : this.accountName,
        grandTotal: grandTotal.present ? grandTotal.value : this.grandTotal,
        totalAmount: totalAmount.present ? totalAmount.value : this.totalAmount,
        totalTax: totalTax.present ? totalTax.value : this.totalTax,
        status: status.present ? status.value : this.status,
        orderDate: orderDate.present ? orderDate.value : this.orderDate,
        name: name.present ? name.value : this.name,
        description: description.present ? description.value : this.description,
        createdDate: createdDate.present ? createdDate.value : this.createdDate,
        synced: synced.present ? synced.value : this.synced,
      );
  @override
  String toString() {
    return (StringBuffer('Order(')
          ..write('appOrderId: $appOrderId, ')
          ..write('id: $id, ')
          ..write('salesAppId: $salesAppId, ')
          ..write('accountId: $accountId, ')
          ..write('appAccountId: $appAccountId, ')
          ..write('accountName: $accountName, ')
          ..write('grandTotal: $grandTotal, ')
          ..write('totalAmount: $totalAmount, ')
          ..write('totalTax: $totalTax, ')
          ..write('status: $status, ')
          ..write('orderDate: $orderDate, ')
          ..write('name: $name, ')
          ..write('description: $description, ')
          ..write('createdDate: $createdDate, ')
          ..write('synced: $synced')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      appOrderId,
      id,
      salesAppId,
      accountId,
      appAccountId,
      accountName,
      grandTotal,
      totalAmount,
      totalTax,
      status,
      orderDate,
      name,
      description,
      createdDate,
      synced);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Order &&
          other.appOrderId == this.appOrderId &&
          other.id == this.id &&
          other.salesAppId == this.salesAppId &&
          other.accountId == this.accountId &&
          other.appAccountId == this.appAccountId &&
          other.accountName == this.accountName &&
          other.grandTotal == this.grandTotal &&
          other.totalAmount == this.totalAmount &&
          other.totalTax == this.totalTax &&
          other.status == this.status &&
          other.orderDate == this.orderDate &&
          other.name == this.name &&
          other.description == this.description &&
          other.createdDate == this.createdDate &&
          other.synced == this.synced);
}

class OrdersCompanion extends UpdateCompanion<Order> {
  final Value<String?> appOrderId;
  final Value<String?> id;
  final Value<String?> salesAppId;
  final Value<String?> accountId;
  final Value<String?> appAccountId;
  final Value<String?> accountName;
  final Value<double?> grandTotal;
  final Value<double?> totalAmount;
  final Value<double?> totalTax;
  final Value<String?> status;
  final Value<DateTime?> orderDate;
  final Value<String?> name;
  final Value<String?> description;
  final Value<DateTime?> createdDate;
  final Value<bool?> synced;
  final Value<int> rowid;
  const OrdersCompanion({
    this.appOrderId = const Value.absent(),
    this.id = const Value.absent(),
    this.salesAppId = const Value.absent(),
    this.accountId = const Value.absent(),
    this.appAccountId = const Value.absent(),
    this.accountName = const Value.absent(),
    this.grandTotal = const Value.absent(),
    this.totalAmount = const Value.absent(),
    this.totalTax = const Value.absent(),
    this.status = const Value.absent(),
    this.orderDate = const Value.absent(),
    this.name = const Value.absent(),
    this.description = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  OrdersCompanion.insert({
    this.appOrderId = const Value.absent(),
    this.id = const Value.absent(),
    this.salesAppId = const Value.absent(),
    this.accountId = const Value.absent(),
    this.appAccountId = const Value.absent(),
    this.accountName = const Value.absent(),
    this.grandTotal = const Value.absent(),
    this.totalAmount = const Value.absent(),
    this.totalTax = const Value.absent(),
    this.status = const Value.absent(),
    this.orderDate = const Value.absent(),
    this.name = const Value.absent(),
    this.description = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  static Insertable<Order> custom({
    Expression<String>? appOrderId,
    Expression<String>? id,
    Expression<String>? salesAppId,
    Expression<String>? accountId,
    Expression<String>? appAccountId,
    Expression<String>? accountName,
    Expression<double>? grandTotal,
    Expression<double>? totalAmount,
    Expression<double>? totalTax,
    Expression<String>? status,
    Expression<DateTime>? orderDate,
    Expression<String>? name,
    Expression<String>? description,
    Expression<DateTime>? createdDate,
    Expression<bool>? synced,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (appOrderId != null) 'app_order_id': appOrderId,
      if (id != null) 'id': id,
      if (salesAppId != null) 'sales_app_id': salesAppId,
      if (accountId != null) 'account_id': accountId,
      if (appAccountId != null) 'app_account_id': appAccountId,
      if (accountName != null) 'account_name': accountName,
      if (grandTotal != null) 'grand_total': grandTotal,
      if (totalAmount != null) 'total_amount': totalAmount,
      if (totalTax != null) 'total_tax': totalTax,
      if (status != null) 'status': status,
      if (orderDate != null) 'order_date': orderDate,
      if (name != null) 'name': name,
      if (description != null) 'description': description,
      if (createdDate != null) 'created_date': createdDate,
      if (synced != null) 'synced': synced,
      if (rowid != null) 'rowid': rowid,
    });
  }

  OrdersCompanion copyWith(
      {Value<String?>? appOrderId,
      Value<String?>? id,
      Value<String?>? salesAppId,
      Value<String?>? accountId,
      Value<String?>? appAccountId,
      Value<String?>? accountName,
      Value<double?>? grandTotal,
      Value<double?>? totalAmount,
      Value<double?>? totalTax,
      Value<String?>? status,
      Value<DateTime?>? orderDate,
      Value<String?>? name,
      Value<String?>? description,
      Value<DateTime?>? createdDate,
      Value<bool?>? synced,
      Value<int>? rowid}) {
    return OrdersCompanion(
      appOrderId: appOrderId ?? this.appOrderId,
      id: id ?? this.id,
      salesAppId: salesAppId ?? this.salesAppId,
      accountId: accountId ?? this.accountId,
      appAccountId: appAccountId ?? this.appAccountId,
      accountName: accountName ?? this.accountName,
      grandTotal: grandTotal ?? this.grandTotal,
      totalAmount: totalAmount ?? this.totalAmount,
      totalTax: totalTax ?? this.totalTax,
      status: status ?? this.status,
      orderDate: orderDate ?? this.orderDate,
      name: name ?? this.name,
      description: description ?? this.description,
      createdDate: createdDate ?? this.createdDate,
      synced: synced ?? this.synced,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (appOrderId.present) {
      map['app_order_id'] = Variable<String>(appOrderId.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (salesAppId.present) {
      map['sales_app_id'] = Variable<String>(salesAppId.value);
    }
    if (accountId.present) {
      map['account_id'] = Variable<String>(accountId.value);
    }
    if (appAccountId.present) {
      map['app_account_id'] = Variable<String>(appAccountId.value);
    }
    if (accountName.present) {
      map['account_name'] = Variable<String>(accountName.value);
    }
    if (grandTotal.present) {
      map['grand_total'] = Variable<double>(grandTotal.value);
    }
    if (totalAmount.present) {
      map['total_amount'] = Variable<double>(totalAmount.value);
    }
    if (totalTax.present) {
      map['total_tax'] = Variable<double>(totalTax.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (orderDate.present) {
      map['order_date'] = Variable<DateTime>(orderDate.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (description.present) {
      map['description'] = Variable<String>(description.value);
    }
    if (createdDate.present) {
      map['created_date'] = Variable<DateTime>(createdDate.value);
    }
    if (synced.present) {
      map['synced'] = Variable<bool>(synced.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('OrdersCompanion(')
          ..write('appOrderId: $appOrderId, ')
          ..write('id: $id, ')
          ..write('salesAppId: $salesAppId, ')
          ..write('accountId: $accountId, ')
          ..write('appAccountId: $appAccountId, ')
          ..write('accountName: $accountName, ')
          ..write('grandTotal: $grandTotal, ')
          ..write('totalAmount: $totalAmount, ')
          ..write('totalTax: $totalTax, ')
          ..write('status: $status, ')
          ..write('orderDate: $orderDate, ')
          ..write('name: $name, ')
          ..write('description: $description, ')
          ..write('createdDate: $createdDate, ')
          ..write('synced: $synced, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $OrderItemsTable extends OrderItems
    with TableInfo<$OrderItemsTable, OrderItem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $OrderItemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _appOrderIdMeta =
      const VerificationMeta('appOrderId');
  @override
  late final GeneratedColumn<String> appOrderId = GeneratedColumn<String>(
      'app_order_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _productIdMeta =
      const VerificationMeta('productId');
  @override
  late final GeneratedColumn<String> productId = GeneratedColumn<String>(
      'product_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _productNameMeta =
      const VerificationMeta('productName');
  @override
  late final GeneratedColumn<String> productName = GeneratedColumn<String>(
      'product_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _quantityMeta =
      const VerificationMeta('quantity');
  @override
  late final GeneratedColumn<int> quantity = GeneratedColumn<int>(
      'quantity', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _unitPriceMeta =
      const VerificationMeta('unitPrice');
  @override
  late final GeneratedColumn<double> unitPrice = GeneratedColumn<double>(
      'unit_price', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxPercentMeta =
      const VerificationMeta('taxPercent');
  @override
  late final GeneratedColumn<double> taxPercent = GeneratedColumn<double>(
      'tax_percent', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxAmountMeta =
      const VerificationMeta('taxAmount');
  @override
  late final GeneratedColumn<double> taxAmount = GeneratedColumn<double>(
      'tax_amount', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _totalAmountMeta =
      const VerificationMeta('totalAmount');
  @override
  late final GeneratedColumn<double> totalAmount = GeneratedColumn<double>(
      'total_amount', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _totalTaxMeta =
      const VerificationMeta('totalTax');
  @override
  late final GeneratedColumn<double> totalTax = GeneratedColumn<double>(
      'total_tax', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _grandTotalMeta =
      const VerificationMeta('grandTotal');
  @override
  late final GeneratedColumn<double> grandTotal = GeneratedColumn<double>(
      'grand_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        appOrderId,
        productId,
        productName,
        quantity,
        unitPrice,
        taxPercent,
        taxAmount,
        totalAmount,
        totalTax,
        grandTotal
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'order_items';
  @override
  VerificationContext validateIntegrity(Insertable<OrderItem> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('app_order_id')) {
      context.handle(
          _appOrderIdMeta,
          appOrderId.isAcceptableOrUnknown(
              data['app_order_id']!, _appOrderIdMeta));
    }
    if (data.containsKey('product_id')) {
      context.handle(_productIdMeta,
          productId.isAcceptableOrUnknown(data['product_id']!, _productIdMeta));
    }
    if (data.containsKey('product_name')) {
      context.handle(
          _productNameMeta,
          productName.isAcceptableOrUnknown(
              data['product_name']!, _productNameMeta));
    }
    if (data.containsKey('quantity')) {
      context.handle(_quantityMeta,
          quantity.isAcceptableOrUnknown(data['quantity']!, _quantityMeta));
    }
    if (data.containsKey('unit_price')) {
      context.handle(_unitPriceMeta,
          unitPrice.isAcceptableOrUnknown(data['unit_price']!, _unitPriceMeta));
    }
    if (data.containsKey('tax_percent')) {
      context.handle(
          _taxPercentMeta,
          taxPercent.isAcceptableOrUnknown(
              data['tax_percent']!, _taxPercentMeta));
    }
    if (data.containsKey('tax_amount')) {
      context.handle(_taxAmountMeta,
          taxAmount.isAcceptableOrUnknown(data['tax_amount']!, _taxAmountMeta));
    }
    if (data.containsKey('total_amount')) {
      context.handle(
          _totalAmountMeta,
          totalAmount.isAcceptableOrUnknown(
              data['total_amount']!, _totalAmountMeta));
    }
    if (data.containsKey('total_tax')) {
      context.handle(_totalTaxMeta,
          totalTax.isAcceptableOrUnknown(data['total_tax']!, _totalTaxMeta));
    }
    if (data.containsKey('grand_total')) {
      context.handle(
          _grandTotalMeta,
          grandTotal.isAcceptableOrUnknown(
              data['grand_total']!, _grandTotalMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  OrderItem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return OrderItem(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      appOrderId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_order_id']),
      productId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}product_id']),
      productName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}product_name']),
      quantity: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}quantity']),
      unitPrice: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}unit_price']),
      taxPercent: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}tax_percent']),
      taxAmount: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}tax_amount']),
      totalAmount: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}total_amount']),
      totalTax: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}total_tax']),
      grandTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}grand_total']),
    );
  }

  @override
  $OrderItemsTable createAlias(String alias) {
    return $OrderItemsTable(attachedDatabase, alias);
  }
}

class OrderItem extends DataClass implements Insertable<OrderItem> {
  final int? id;
  final String? appOrderId;
  final String? productId;
  final String? productName;
  final int? quantity;
  final double? unitPrice;
  final double? taxPercent;
  final double? taxAmount;
  final double? totalAmount;
  final double? totalTax;
  final double? grandTotal;
  const OrderItem(
      {this.id,
      this.appOrderId,
      this.productId,
      this.productName,
      this.quantity,
      this.unitPrice,
      this.taxPercent,
      this.taxAmount,
      this.totalAmount,
      this.totalTax,
      this.grandTotal});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || appOrderId != null) {
      map['app_order_id'] = Variable<String>(appOrderId);
    }
    if (!nullToAbsent || productId != null) {
      map['product_id'] = Variable<String>(productId);
    }
    if (!nullToAbsent || productName != null) {
      map['product_name'] = Variable<String>(productName);
    }
    if (!nullToAbsent || quantity != null) {
      map['quantity'] = Variable<int>(quantity);
    }
    if (!nullToAbsent || unitPrice != null) {
      map['unit_price'] = Variable<double>(unitPrice);
    }
    if (!nullToAbsent || taxPercent != null) {
      map['tax_percent'] = Variable<double>(taxPercent);
    }
    if (!nullToAbsent || taxAmount != null) {
      map['tax_amount'] = Variable<double>(taxAmount);
    }
    if (!nullToAbsent || totalAmount != null) {
      map['total_amount'] = Variable<double>(totalAmount);
    }
    if (!nullToAbsent || totalTax != null) {
      map['total_tax'] = Variable<double>(totalTax);
    }
    if (!nullToAbsent || grandTotal != null) {
      map['grand_total'] = Variable<double>(grandTotal);
    }
    return map;
  }

  OrderItemsCompanion toCompanion(bool nullToAbsent) {
    return OrderItemsCompanion(
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      appOrderId: appOrderId == null && nullToAbsent
          ? const Value.absent()
          : Value(appOrderId),
      productId: productId == null && nullToAbsent
          ? const Value.absent()
          : Value(productId),
      productName: productName == null && nullToAbsent
          ? const Value.absent()
          : Value(productName),
      quantity: quantity == null && nullToAbsent
          ? const Value.absent()
          : Value(quantity),
      unitPrice: unitPrice == null && nullToAbsent
          ? const Value.absent()
          : Value(unitPrice),
      taxPercent: taxPercent == null && nullToAbsent
          ? const Value.absent()
          : Value(taxPercent),
      taxAmount: taxAmount == null && nullToAbsent
          ? const Value.absent()
          : Value(taxAmount),
      totalAmount: totalAmount == null && nullToAbsent
          ? const Value.absent()
          : Value(totalAmount),
      totalTax: totalTax == null && nullToAbsent
          ? const Value.absent()
          : Value(totalTax),
      grandTotal: grandTotal == null && nullToAbsent
          ? const Value.absent()
          : Value(grandTotal),
    );
  }

  factory OrderItem.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return OrderItem(
      id: serializer.fromJson<int?>(json['id']),
      appOrderId: serializer.fromJson<String?>(json['appOrderId']),
      productId: serializer.fromJson<String?>(json['productId']),
      productName: serializer.fromJson<String?>(json['productName']),
      quantity: serializer.fromJson<int?>(json['quantity']),
      unitPrice: serializer.fromJson<double?>(json['unitPrice']),
      taxPercent: serializer.fromJson<double?>(json['taxPercent']),
      taxAmount: serializer.fromJson<double?>(json['taxAmount']),
      totalAmount: serializer.fromJson<double?>(json['totalAmount']),
      totalTax: serializer.fromJson<double?>(json['totalTax']),
      grandTotal: serializer.fromJson<double?>(json['grandTotal']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'appOrderId': serializer.toJson<String?>(appOrderId),
      'productId': serializer.toJson<String?>(productId),
      'productName': serializer.toJson<String?>(productName),
      'quantity': serializer.toJson<int?>(quantity),
      'unitPrice': serializer.toJson<double?>(unitPrice),
      'taxPercent': serializer.toJson<double?>(taxPercent),
      'taxAmount': serializer.toJson<double?>(taxAmount),
      'totalAmount': serializer.toJson<double?>(totalAmount),
      'totalTax': serializer.toJson<double?>(totalTax),
      'grandTotal': serializer.toJson<double?>(grandTotal),
    };
  }

  OrderItem copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> appOrderId = const Value.absent(),
          Value<String?> productId = const Value.absent(),
          Value<String?> productName = const Value.absent(),
          Value<int?> quantity = const Value.absent(),
          Value<double?> unitPrice = const Value.absent(),
          Value<double?> taxPercent = const Value.absent(),
          Value<double?> taxAmount = const Value.absent(),
          Value<double?> totalAmount = const Value.absent(),
          Value<double?> totalTax = const Value.absent(),
          Value<double?> grandTotal = const Value.absent()}) =>
      OrderItem(
        id: id.present ? id.value : this.id,
        appOrderId: appOrderId.present ? appOrderId.value : this.appOrderId,
        productId: productId.present ? productId.value : this.productId,
        productName: productName.present ? productName.value : this.productName,
        quantity: quantity.present ? quantity.value : this.quantity,
        unitPrice: unitPrice.present ? unitPrice.value : this.unitPrice,
        taxPercent: taxPercent.present ? taxPercent.value : this.taxPercent,
        taxAmount: taxAmount.present ? taxAmount.value : this.taxAmount,
        totalAmount: totalAmount.present ? totalAmount.value : this.totalAmount,
        totalTax: totalTax.present ? totalTax.value : this.totalTax,
        grandTotal: grandTotal.present ? grandTotal.value : this.grandTotal,
      );
  @override
  String toString() {
    return (StringBuffer('OrderItem(')
          ..write('id: $id, ')
          ..write('appOrderId: $appOrderId, ')
          ..write('productId: $productId, ')
          ..write('productName: $productName, ')
          ..write('quantity: $quantity, ')
          ..write('unitPrice: $unitPrice, ')
          ..write('taxPercent: $taxPercent, ')
          ..write('taxAmount: $taxAmount, ')
          ..write('totalAmount: $totalAmount, ')
          ..write('totalTax: $totalTax, ')
          ..write('grandTotal: $grandTotal')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      appOrderId,
      productId,
      productName,
      quantity,
      unitPrice,
      taxPercent,
      taxAmount,
      totalAmount,
      totalTax,
      grandTotal);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is OrderItem &&
          other.id == this.id &&
          other.appOrderId == this.appOrderId &&
          other.productId == this.productId &&
          other.productName == this.productName &&
          other.quantity == this.quantity &&
          other.unitPrice == this.unitPrice &&
          other.taxPercent == this.taxPercent &&
          other.taxAmount == this.taxAmount &&
          other.totalAmount == this.totalAmount &&
          other.totalTax == this.totalTax &&
          other.grandTotal == this.grandTotal);
}

class OrderItemsCompanion extends UpdateCompanion<OrderItem> {
  final Value<int?> id;
  final Value<String?> appOrderId;
  final Value<String?> productId;
  final Value<String?> productName;
  final Value<int?> quantity;
  final Value<double?> unitPrice;
  final Value<double?> taxPercent;
  final Value<double?> taxAmount;
  final Value<double?> totalAmount;
  final Value<double?> totalTax;
  final Value<double?> grandTotal;
  const OrderItemsCompanion({
    this.id = const Value.absent(),
    this.appOrderId = const Value.absent(),
    this.productId = const Value.absent(),
    this.productName = const Value.absent(),
    this.quantity = const Value.absent(),
    this.unitPrice = const Value.absent(),
    this.taxPercent = const Value.absent(),
    this.taxAmount = const Value.absent(),
    this.totalAmount = const Value.absent(),
    this.totalTax = const Value.absent(),
    this.grandTotal = const Value.absent(),
  });
  OrderItemsCompanion.insert({
    this.id = const Value.absent(),
    this.appOrderId = const Value.absent(),
    this.productId = const Value.absent(),
    this.productName = const Value.absent(),
    this.quantity = const Value.absent(),
    this.unitPrice = const Value.absent(),
    this.taxPercent = const Value.absent(),
    this.taxAmount = const Value.absent(),
    this.totalAmount = const Value.absent(),
    this.totalTax = const Value.absent(),
    this.grandTotal = const Value.absent(),
  });
  static Insertable<OrderItem> custom({
    Expression<int>? id,
    Expression<String>? appOrderId,
    Expression<String>? productId,
    Expression<String>? productName,
    Expression<int>? quantity,
    Expression<double>? unitPrice,
    Expression<double>? taxPercent,
    Expression<double>? taxAmount,
    Expression<double>? totalAmount,
    Expression<double>? totalTax,
    Expression<double>? grandTotal,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (appOrderId != null) 'app_order_id': appOrderId,
      if (productId != null) 'product_id': productId,
      if (productName != null) 'product_name': productName,
      if (quantity != null) 'quantity': quantity,
      if (unitPrice != null) 'unit_price': unitPrice,
      if (taxPercent != null) 'tax_percent': taxPercent,
      if (taxAmount != null) 'tax_amount': taxAmount,
      if (totalAmount != null) 'total_amount': totalAmount,
      if (totalTax != null) 'total_tax': totalTax,
      if (grandTotal != null) 'grand_total': grandTotal,
    });
  }

  OrderItemsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? appOrderId,
      Value<String?>? productId,
      Value<String?>? productName,
      Value<int?>? quantity,
      Value<double?>? unitPrice,
      Value<double?>? taxPercent,
      Value<double?>? taxAmount,
      Value<double?>? totalAmount,
      Value<double?>? totalTax,
      Value<double?>? grandTotal}) {
    return OrderItemsCompanion(
      id: id ?? this.id,
      appOrderId: appOrderId ?? this.appOrderId,
      productId: productId ?? this.productId,
      productName: productName ?? this.productName,
      quantity: quantity ?? this.quantity,
      unitPrice: unitPrice ?? this.unitPrice,
      taxPercent: taxPercent ?? this.taxPercent,
      taxAmount: taxAmount ?? this.taxAmount,
      totalAmount: totalAmount ?? this.totalAmount,
      totalTax: totalTax ?? this.totalTax,
      grandTotal: grandTotal ?? this.grandTotal,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (appOrderId.present) {
      map['app_order_id'] = Variable<String>(appOrderId.value);
    }
    if (productId.present) {
      map['product_id'] = Variable<String>(productId.value);
    }
    if (productName.present) {
      map['product_name'] = Variable<String>(productName.value);
    }
    if (quantity.present) {
      map['quantity'] = Variable<int>(quantity.value);
    }
    if (unitPrice.present) {
      map['unit_price'] = Variable<double>(unitPrice.value);
    }
    if (taxPercent.present) {
      map['tax_percent'] = Variable<double>(taxPercent.value);
    }
    if (taxAmount.present) {
      map['tax_amount'] = Variable<double>(taxAmount.value);
    }
    if (totalAmount.present) {
      map['total_amount'] = Variable<double>(totalAmount.value);
    }
    if (totalTax.present) {
      map['total_tax'] = Variable<double>(totalTax.value);
    }
    if (grandTotal.present) {
      map['grand_total'] = Variable<double>(grandTotal.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('OrderItemsCompanion(')
          ..write('id: $id, ')
          ..write('appOrderId: $appOrderId, ')
          ..write('productId: $productId, ')
          ..write('productName: $productName, ')
          ..write('quantity: $quantity, ')
          ..write('unitPrice: $unitPrice, ')
          ..write('taxPercent: $taxPercent, ')
          ..write('taxAmount: $taxAmount, ')
          ..write('totalAmount: $totalAmount, ')
          ..write('totalTax: $totalTax, ')
          ..write('grandTotal: $grandTotal')
          ..write(')'))
        .toString();
  }
}

class $VisitFilesTable extends VisitFiles
    with TableInfo<$VisitFilesTable, VisitFile> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $VisitFilesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      clientDefault: () => uuid.v6());
  static const VerificationMeta _salesAppIdMeta =
      const VerificationMeta('salesAppId');
  @override
  late final GeneratedColumn<String> salesAppId = GeneratedColumn<String>(
      'sales_app_id', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: true,
      defaultConstraints: GeneratedColumn.constraintIsAlways(
          'REFERENCES visits (sales_app_id)'));
  static const VerificationMeta _fileMeta = const VerificationMeta('file');
  @override
  late final GeneratedColumn<Uint8List> file = GeneratedColumn<Uint8List>(
      'file', aliasedName, false,
      type: DriftSqlType.blob, requiredDuringInsert: true);
  static const VerificationMeta _fileNameMeta =
      const VerificationMeta('fileName');
  @override
  late final GeneratedColumn<String> fileName = GeneratedColumn<String>(
      'file_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _syncedMeta = const VerificationMeta('synced');
  @override
  late final GeneratedColumn<bool> synced = GeneratedColumn<bool>(
      'synced', aliasedName, true,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("synced" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns =>
      [id, salesAppId, file, fileName, synced];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'visit_files';
  @override
  VerificationContext validateIntegrity(Insertable<VisitFile> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('sales_app_id')) {
      context.handle(
          _salesAppIdMeta,
          salesAppId.isAcceptableOrUnknown(
              data['sales_app_id']!, _salesAppIdMeta));
    } else if (isInserting) {
      context.missing(_salesAppIdMeta);
    }
    if (data.containsKey('file')) {
      context.handle(
          _fileMeta, file.isAcceptableOrUnknown(data['file']!, _fileMeta));
    } else if (isInserting) {
      context.missing(_fileMeta);
    }
    if (data.containsKey('file_name')) {
      context.handle(_fileNameMeta,
          fileName.isAcceptableOrUnknown(data['file_name']!, _fileNameMeta));
    }
    if (data.containsKey('synced')) {
      context.handle(_syncedMeta,
          synced.isAcceptableOrUnknown(data['synced']!, _syncedMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  VisitFile map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return VisitFile(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id']),
      salesAppId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sales_app_id'])!,
      file: attachedDatabase.typeMapping
          .read(DriftSqlType.blob, data['${effectivePrefix}file'])!,
      fileName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}file_name']),
      synced: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}synced']),
    );
  }

  @override
  $VisitFilesTable createAlias(String alias) {
    return $VisitFilesTable(attachedDatabase, alias);
  }
}

class VisitFile extends DataClass implements Insertable<VisitFile> {
  final String? id;
  final String salesAppId;
  final Uint8List file;
  final String? fileName;
  final bool? synced;
  const VisitFile(
      {this.id,
      required this.salesAppId,
      required this.file,
      this.fileName,
      this.synced});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<String>(id);
    }
    map['sales_app_id'] = Variable<String>(salesAppId);
    map['file'] = Variable<Uint8List>(file);
    if (!nullToAbsent || fileName != null) {
      map['file_name'] = Variable<String>(fileName);
    }
    if (!nullToAbsent || synced != null) {
      map['synced'] = Variable<bool>(synced);
    }
    return map;
  }

  VisitFilesCompanion toCompanion(bool nullToAbsent) {
    return VisitFilesCompanion(
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      salesAppId: Value(salesAppId),
      file: Value(file),
      fileName: fileName == null && nullToAbsent
          ? const Value.absent()
          : Value(fileName),
      synced:
          synced == null && nullToAbsent ? const Value.absent() : Value(synced),
    );
  }

  factory VisitFile.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return VisitFile(
      id: serializer.fromJson<String?>(json['id']),
      salesAppId: serializer.fromJson<String>(json['salesAppId']),
      file: serializer.fromJson<Uint8List>(json['file']),
      fileName: serializer.fromJson<String?>(json['fileName']),
      synced: serializer.fromJson<bool?>(json['synced']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String?>(id),
      'salesAppId': serializer.toJson<String>(salesAppId),
      'file': serializer.toJson<Uint8List>(file),
      'fileName': serializer.toJson<String?>(fileName),
      'synced': serializer.toJson<bool?>(synced),
    };
  }

  VisitFile copyWith(
          {Value<String?> id = const Value.absent(),
          String? salesAppId,
          Uint8List? file,
          Value<String?> fileName = const Value.absent(),
          Value<bool?> synced = const Value.absent()}) =>
      VisitFile(
        id: id.present ? id.value : this.id,
        salesAppId: salesAppId ?? this.salesAppId,
        file: file ?? this.file,
        fileName: fileName.present ? fileName.value : this.fileName,
        synced: synced.present ? synced.value : this.synced,
      );
  @override
  String toString() {
    return (StringBuffer('VisitFile(')
          ..write('id: $id, ')
          ..write('salesAppId: $salesAppId, ')
          ..write('file: $file, ')
          ..write('fileName: $fileName, ')
          ..write('synced: $synced')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, salesAppId, $driftBlobEquality.hash(file), fileName, synced);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is VisitFile &&
          other.id == this.id &&
          other.salesAppId == this.salesAppId &&
          $driftBlobEquality.equals(other.file, this.file) &&
          other.fileName == this.fileName &&
          other.synced == this.synced);
}

class VisitFilesCompanion extends UpdateCompanion<VisitFile> {
  final Value<String?> id;
  final Value<String> salesAppId;
  final Value<Uint8List> file;
  final Value<String?> fileName;
  final Value<bool?> synced;
  final Value<int> rowid;
  const VisitFilesCompanion({
    this.id = const Value.absent(),
    this.salesAppId = const Value.absent(),
    this.file = const Value.absent(),
    this.fileName = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  VisitFilesCompanion.insert({
    this.id = const Value.absent(),
    required String salesAppId,
    required Uint8List file,
    this.fileName = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : salesAppId = Value(salesAppId),
        file = Value(file);
  static Insertable<VisitFile> custom({
    Expression<String>? id,
    Expression<String>? salesAppId,
    Expression<Uint8List>? file,
    Expression<String>? fileName,
    Expression<bool>? synced,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (salesAppId != null) 'sales_app_id': salesAppId,
      if (file != null) 'file': file,
      if (fileName != null) 'file_name': fileName,
      if (synced != null) 'synced': synced,
      if (rowid != null) 'rowid': rowid,
    });
  }

  VisitFilesCompanion copyWith(
      {Value<String?>? id,
      Value<String>? salesAppId,
      Value<Uint8List>? file,
      Value<String?>? fileName,
      Value<bool?>? synced,
      Value<int>? rowid}) {
    return VisitFilesCompanion(
      id: id ?? this.id,
      salesAppId: salesAppId ?? this.salesAppId,
      file: file ?? this.file,
      fileName: fileName ?? this.fileName,
      synced: synced ?? this.synced,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (salesAppId.present) {
      map['sales_app_id'] = Variable<String>(salesAppId.value);
    }
    if (file.present) {
      map['file'] = Variable<Uint8List>(file.value);
    }
    if (fileName.present) {
      map['file_name'] = Variable<String>(fileName.value);
    }
    if (synced.present) {
      map['synced'] = Variable<bool>(synced.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('VisitFilesCompanion(')
          ..write('id: $id, ')
          ..write('salesAppId: $salesAppId, ')
          ..write('file: $file, ')
          ..write('fileName: $fileName, ')
          ..write('synced: $synced, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $AccountRoutesTable extends AccountRoutes
    with TableInfo<$AccountRoutesTable, AccountRoute> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AccountRoutesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _warehouseIdMeta =
      const VerificationMeta('warehouseId');
  @override
  late final GeneratedColumn<String> warehouseId = GeneratedColumn<String>(
      'warehouse_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _warehouseNameMeta =
      const VerificationMeta('warehouseName');
  @override
  late final GeneratedColumn<String> warehouseName = GeneratedColumn<String>(
      'warehouse_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, name, warehouseId, warehouseName];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'account_routes';
  @override
  VerificationContext validateIntegrity(Insertable<AccountRoute> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    }
    if (data.containsKey('warehouse_id')) {
      context.handle(
          _warehouseIdMeta,
          warehouseId.isAcceptableOrUnknown(
              data['warehouse_id']!, _warehouseIdMeta));
    }
    if (data.containsKey('warehouse_name')) {
      context.handle(
          _warehouseNameMeta,
          warehouseName.isAcceptableOrUnknown(
              data['warehouse_name']!, _warehouseNameMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  AccountRoute map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return AccountRoute(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id']),
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name']),
      warehouseId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}warehouse_id']),
      warehouseName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}warehouse_name']),
    );
  }

  @override
  $AccountRoutesTable createAlias(String alias) {
    return $AccountRoutesTable(attachedDatabase, alias);
  }
}

class AccountRoute extends DataClass implements Insertable<AccountRoute> {
  final String? id;
  final String? name;
  final String? warehouseId;
  final String? warehouseName;
  const AccountRoute(
      {this.id, this.name, this.warehouseId, this.warehouseName});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<String>(id);
    }
    if (!nullToAbsent || name != null) {
      map['name'] = Variable<String>(name);
    }
    if (!nullToAbsent || warehouseId != null) {
      map['warehouse_id'] = Variable<String>(warehouseId);
    }
    if (!nullToAbsent || warehouseName != null) {
      map['warehouse_name'] = Variable<String>(warehouseName);
    }
    return map;
  }

  AccountRoutesCompanion toCompanion(bool nullToAbsent) {
    return AccountRoutesCompanion(
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      name: name == null && nullToAbsent ? const Value.absent() : Value(name),
      warehouseId: warehouseId == null && nullToAbsent
          ? const Value.absent()
          : Value(warehouseId),
      warehouseName: warehouseName == null && nullToAbsent
          ? const Value.absent()
          : Value(warehouseName),
    );
  }

  factory AccountRoute.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return AccountRoute(
      id: serializer.fromJson<String?>(json['id']),
      name: serializer.fromJson<String?>(json['name']),
      warehouseId: serializer.fromJson<String?>(json['warehouseId']),
      warehouseName: serializer.fromJson<String?>(json['warehouseName']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String?>(id),
      'name': serializer.toJson<String?>(name),
      'warehouseId': serializer.toJson<String?>(warehouseId),
      'warehouseName': serializer.toJson<String?>(warehouseName),
    };
  }

  AccountRoute copyWith(
          {Value<String?> id = const Value.absent(),
          Value<String?> name = const Value.absent(),
          Value<String?> warehouseId = const Value.absent(),
          Value<String?> warehouseName = const Value.absent()}) =>
      AccountRoute(
        id: id.present ? id.value : this.id,
        name: name.present ? name.value : this.name,
        warehouseId: warehouseId.present ? warehouseId.value : this.warehouseId,
        warehouseName:
            warehouseName.present ? warehouseName.value : this.warehouseName,
      );
  @override
  String toString() {
    return (StringBuffer('AccountRoute(')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('warehouseId: $warehouseId, ')
          ..write('warehouseName: $warehouseName')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, name, warehouseId, warehouseName);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is AccountRoute &&
          other.id == this.id &&
          other.name == this.name &&
          other.warehouseId == this.warehouseId &&
          other.warehouseName == this.warehouseName);
}

class AccountRoutesCompanion extends UpdateCompanion<AccountRoute> {
  final Value<String?> id;
  final Value<String?> name;
  final Value<String?> warehouseId;
  final Value<String?> warehouseName;
  final Value<int> rowid;
  const AccountRoutesCompanion({
    this.id = const Value.absent(),
    this.name = const Value.absent(),
    this.warehouseId = const Value.absent(),
    this.warehouseName = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  AccountRoutesCompanion.insert({
    this.id = const Value.absent(),
    this.name = const Value.absent(),
    this.warehouseId = const Value.absent(),
    this.warehouseName = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  static Insertable<AccountRoute> custom({
    Expression<String>? id,
    Expression<String>? name,
    Expression<String>? warehouseId,
    Expression<String>? warehouseName,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (name != null) 'name': name,
      if (warehouseId != null) 'warehouse_id': warehouseId,
      if (warehouseName != null) 'warehouse_name': warehouseName,
      if (rowid != null) 'rowid': rowid,
    });
  }

  AccountRoutesCompanion copyWith(
      {Value<String?>? id,
      Value<String?>? name,
      Value<String?>? warehouseId,
      Value<String?>? warehouseName,
      Value<int>? rowid}) {
    return AccountRoutesCompanion(
      id: id ?? this.id,
      name: name ?? this.name,
      warehouseId: warehouseId ?? this.warehouseId,
      warehouseName: warehouseName ?? this.warehouseName,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (warehouseId.present) {
      map['warehouse_id'] = Variable<String>(warehouseId.value);
    }
    if (warehouseName.present) {
      map['warehouse_name'] = Variable<String>(warehouseName.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AccountRoutesCompanion(')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('warehouseId: $warehouseId, ')
          ..write('warehouseName: $warehouseName, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ExpensesTable extends Expenses with TableInfo<$ExpensesTable, Expense> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ExpensesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _appExpIdMeta =
      const VerificationMeta('appExpId');
  @override
  late final GeneratedColumn<String> appExpId = GeneratedColumn<String>(
      'app_exp_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      clientDefault: () => uuid.v6());
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _expenseDateMeta =
      const VerificationMeta('expenseDate');
  @override
  late final GeneratedColumn<DateTime> expenseDate = GeneratedColumn<DateTime>(
      'expense_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _expenseNameMeta =
      const VerificationMeta('expenseName');
  @override
  late final GeneratedColumn<String> expenseName = GeneratedColumn<String>(
      'expense_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _executiveIdMeta =
      const VerificationMeta('executiveId');
  @override
  late final GeneratedColumn<String> executiveId = GeneratedColumn<String>(
      'executive_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _executiveNameMeta =
      const VerificationMeta('executiveName');
  @override
  late final GeneratedColumn<String> executiveName = GeneratedColumn<String>(
      'executive_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdByMeta =
      const VerificationMeta('createdBy');
  @override
  late final GeneratedColumn<String> createdBy = GeneratedColumn<String>(
      'created_by', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdDateMeta =
      const VerificationMeta('createdDate');
  @override
  late final GeneratedColumn<DateTime> createdDate = GeneratedColumn<DateTime>(
      'created_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _syncedMeta = const VerificationMeta('synced');
  @override
  late final GeneratedColumn<bool> synced = GeneratedColumn<bool>(
      'synced', aliasedName, true,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("synced" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _approvalStatusMeta =
      const VerificationMeta('approvalStatus');
  @override
  late final GeneratedColumn<String> approvalStatus = GeneratedColumn<String>(
      'approval_status', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        appExpId,
        id,
        expenseDate,
        expenseName,
        executiveId,
        executiveName,
        createdBy,
        createdDate,
        synced,
        approvalStatus
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'expenses';
  @override
  VerificationContext validateIntegrity(Insertable<Expense> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('app_exp_id')) {
      context.handle(_appExpIdMeta,
          appExpId.isAcceptableOrUnknown(data['app_exp_id']!, _appExpIdMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('expense_date')) {
      context.handle(
          _expenseDateMeta,
          expenseDate.isAcceptableOrUnknown(
              data['expense_date']!, _expenseDateMeta));
    }
    if (data.containsKey('expense_name')) {
      context.handle(
          _expenseNameMeta,
          expenseName.isAcceptableOrUnknown(
              data['expense_name']!, _expenseNameMeta));
    }
    if (data.containsKey('executive_id')) {
      context.handle(
          _executiveIdMeta,
          executiveId.isAcceptableOrUnknown(
              data['executive_id']!, _executiveIdMeta));
    }
    if (data.containsKey('executive_name')) {
      context.handle(
          _executiveNameMeta,
          executiveName.isAcceptableOrUnknown(
              data['executive_name']!, _executiveNameMeta));
    }
    if (data.containsKey('created_by')) {
      context.handle(_createdByMeta,
          createdBy.isAcceptableOrUnknown(data['created_by']!, _createdByMeta));
    }
    if (data.containsKey('created_date')) {
      context.handle(
          _createdDateMeta,
          createdDate.isAcceptableOrUnknown(
              data['created_date']!, _createdDateMeta));
    }
    if (data.containsKey('synced')) {
      context.handle(_syncedMeta,
          synced.isAcceptableOrUnknown(data['synced']!, _syncedMeta));
    }
    if (data.containsKey('approval_status')) {
      context.handle(
          _approvalStatusMeta,
          approvalStatus.isAcceptableOrUnknown(
              data['approval_status']!, _approvalStatusMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {appExpId};
  @override
  Expense map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Expense(
      appExpId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_exp_id']),
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id']),
      expenseDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}expense_date']),
      expenseName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}expense_name']),
      executiveId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}executive_id']),
      executiveName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}executive_name']),
      createdBy: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_by']),
      createdDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_date']),
      synced: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}synced']),
      approvalStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}approval_status']),
    );
  }

  @override
  $ExpensesTable createAlias(String alias) {
    return $ExpensesTable(attachedDatabase, alias);
  }
}

class Expense extends DataClass implements Insertable<Expense> {
  final String? appExpId;
  final String? id;
  final DateTime? expenseDate;
  final String? expenseName;
  final String? executiveId;
  final String? executiveName;
  final String? createdBy;
  final DateTime? createdDate;
  final bool? synced;
  final String? approvalStatus;
  const Expense(
      {this.appExpId,
      this.id,
      this.expenseDate,
      this.expenseName,
      this.executiveId,
      this.executiveName,
      this.createdBy,
      this.createdDate,
      this.synced,
      this.approvalStatus});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || appExpId != null) {
      map['app_exp_id'] = Variable<String>(appExpId);
    }
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<String>(id);
    }
    if (!nullToAbsent || expenseDate != null) {
      map['expense_date'] = Variable<DateTime>(expenseDate);
    }
    if (!nullToAbsent || expenseName != null) {
      map['expense_name'] = Variable<String>(expenseName);
    }
    if (!nullToAbsent || executiveId != null) {
      map['executive_id'] = Variable<String>(executiveId);
    }
    if (!nullToAbsent || executiveName != null) {
      map['executive_name'] = Variable<String>(executiveName);
    }
    if (!nullToAbsent || createdBy != null) {
      map['created_by'] = Variable<String>(createdBy);
    }
    if (!nullToAbsent || createdDate != null) {
      map['created_date'] = Variable<DateTime>(createdDate);
    }
    if (!nullToAbsent || synced != null) {
      map['synced'] = Variable<bool>(synced);
    }
    if (!nullToAbsent || approvalStatus != null) {
      map['approval_status'] = Variable<String>(approvalStatus);
    }
    return map;
  }

  ExpensesCompanion toCompanion(bool nullToAbsent) {
    return ExpensesCompanion(
      appExpId: appExpId == null && nullToAbsent
          ? const Value.absent()
          : Value(appExpId),
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      expenseDate: expenseDate == null && nullToAbsent
          ? const Value.absent()
          : Value(expenseDate),
      expenseName: expenseName == null && nullToAbsent
          ? const Value.absent()
          : Value(expenseName),
      executiveId: executiveId == null && nullToAbsent
          ? const Value.absent()
          : Value(executiveId),
      executiveName: executiveName == null && nullToAbsent
          ? const Value.absent()
          : Value(executiveName),
      createdBy: createdBy == null && nullToAbsent
          ? const Value.absent()
          : Value(createdBy),
      createdDate: createdDate == null && nullToAbsent
          ? const Value.absent()
          : Value(createdDate),
      synced:
          synced == null && nullToAbsent ? const Value.absent() : Value(synced),
      approvalStatus: approvalStatus == null && nullToAbsent
          ? const Value.absent()
          : Value(approvalStatus),
    );
  }

  factory Expense.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Expense(
      appExpId: serializer.fromJson<String?>(json['appExpId']),
      id: serializer.fromJson<String?>(json['id']),
      expenseDate: serializer.fromJson<DateTime?>(json['expenseDate']),
      expenseName: serializer.fromJson<String?>(json['expenseName']),
      executiveId: serializer.fromJson<String?>(json['executiveId']),
      executiveName: serializer.fromJson<String?>(json['executiveName']),
      createdBy: serializer.fromJson<String?>(json['createdBy']),
      createdDate: serializer.fromJson<DateTime?>(json['createdDate']),
      synced: serializer.fromJson<bool?>(json['synced']),
      approvalStatus: serializer.fromJson<String?>(json['approvalStatus']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'appExpId': serializer.toJson<String?>(appExpId),
      'id': serializer.toJson<String?>(id),
      'expenseDate': serializer.toJson<DateTime?>(expenseDate),
      'expenseName': serializer.toJson<String?>(expenseName),
      'executiveId': serializer.toJson<String?>(executiveId),
      'executiveName': serializer.toJson<String?>(executiveName),
      'createdBy': serializer.toJson<String?>(createdBy),
      'createdDate': serializer.toJson<DateTime?>(createdDate),
      'synced': serializer.toJson<bool?>(synced),
      'approvalStatus': serializer.toJson<String?>(approvalStatus),
    };
  }

  Expense copyWith(
          {Value<String?> appExpId = const Value.absent(),
          Value<String?> id = const Value.absent(),
          Value<DateTime?> expenseDate = const Value.absent(),
          Value<String?> expenseName = const Value.absent(),
          Value<String?> executiveId = const Value.absent(),
          Value<String?> executiveName = const Value.absent(),
          Value<String?> createdBy = const Value.absent(),
          Value<DateTime?> createdDate = const Value.absent(),
          Value<bool?> synced = const Value.absent(),
          Value<String?> approvalStatus = const Value.absent()}) =>
      Expense(
        appExpId: appExpId.present ? appExpId.value : this.appExpId,
        id: id.present ? id.value : this.id,
        expenseDate: expenseDate.present ? expenseDate.value : this.expenseDate,
        expenseName: expenseName.present ? expenseName.value : this.expenseName,
        executiveId: executiveId.present ? executiveId.value : this.executiveId,
        executiveName:
            executiveName.present ? executiveName.value : this.executiveName,
        createdBy: createdBy.present ? createdBy.value : this.createdBy,
        createdDate: createdDate.present ? createdDate.value : this.createdDate,
        synced: synced.present ? synced.value : this.synced,
        approvalStatus:
            approvalStatus.present ? approvalStatus.value : this.approvalStatus,
      );
  @override
  String toString() {
    return (StringBuffer('Expense(')
          ..write('appExpId: $appExpId, ')
          ..write('id: $id, ')
          ..write('expenseDate: $expenseDate, ')
          ..write('expenseName: $expenseName, ')
          ..write('executiveId: $executiveId, ')
          ..write('executiveName: $executiveName, ')
          ..write('createdBy: $createdBy, ')
          ..write('createdDate: $createdDate, ')
          ..write('synced: $synced, ')
          ..write('approvalStatus: $approvalStatus')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      appExpId,
      id,
      expenseDate,
      expenseName,
      executiveId,
      executiveName,
      createdBy,
      createdDate,
      synced,
      approvalStatus);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Expense &&
          other.appExpId == this.appExpId &&
          other.id == this.id &&
          other.expenseDate == this.expenseDate &&
          other.expenseName == this.expenseName &&
          other.executiveId == this.executiveId &&
          other.executiveName == this.executiveName &&
          other.createdBy == this.createdBy &&
          other.createdDate == this.createdDate &&
          other.synced == this.synced &&
          other.approvalStatus == this.approvalStatus);
}

class ExpensesCompanion extends UpdateCompanion<Expense> {
  final Value<String?> appExpId;
  final Value<String?> id;
  final Value<DateTime?> expenseDate;
  final Value<String?> expenseName;
  final Value<String?> executiveId;
  final Value<String?> executiveName;
  final Value<String?> createdBy;
  final Value<DateTime?> createdDate;
  final Value<bool?> synced;
  final Value<String?> approvalStatus;
  final Value<int> rowid;
  const ExpensesCompanion({
    this.appExpId = const Value.absent(),
    this.id = const Value.absent(),
    this.expenseDate = const Value.absent(),
    this.expenseName = const Value.absent(),
    this.executiveId = const Value.absent(),
    this.executiveName = const Value.absent(),
    this.createdBy = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.synced = const Value.absent(),
    this.approvalStatus = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ExpensesCompanion.insert({
    this.appExpId = const Value.absent(),
    this.id = const Value.absent(),
    this.expenseDate = const Value.absent(),
    this.expenseName = const Value.absent(),
    this.executiveId = const Value.absent(),
    this.executiveName = const Value.absent(),
    this.createdBy = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.synced = const Value.absent(),
    this.approvalStatus = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  static Insertable<Expense> custom({
    Expression<String>? appExpId,
    Expression<String>? id,
    Expression<DateTime>? expenseDate,
    Expression<String>? expenseName,
    Expression<String>? executiveId,
    Expression<String>? executiveName,
    Expression<String>? createdBy,
    Expression<DateTime>? createdDate,
    Expression<bool>? synced,
    Expression<String>? approvalStatus,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (appExpId != null) 'app_exp_id': appExpId,
      if (id != null) 'id': id,
      if (expenseDate != null) 'expense_date': expenseDate,
      if (expenseName != null) 'expense_name': expenseName,
      if (executiveId != null) 'executive_id': executiveId,
      if (executiveName != null) 'executive_name': executiveName,
      if (createdBy != null) 'created_by': createdBy,
      if (createdDate != null) 'created_date': createdDate,
      if (synced != null) 'synced': synced,
      if (approvalStatus != null) 'approval_status': approvalStatus,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ExpensesCompanion copyWith(
      {Value<String?>? appExpId,
      Value<String?>? id,
      Value<DateTime?>? expenseDate,
      Value<String?>? expenseName,
      Value<String?>? executiveId,
      Value<String?>? executiveName,
      Value<String?>? createdBy,
      Value<DateTime?>? createdDate,
      Value<bool?>? synced,
      Value<String?>? approvalStatus,
      Value<int>? rowid}) {
    return ExpensesCompanion(
      appExpId: appExpId ?? this.appExpId,
      id: id ?? this.id,
      expenseDate: expenseDate ?? this.expenseDate,
      expenseName: expenseName ?? this.expenseName,
      executiveId: executiveId ?? this.executiveId,
      executiveName: executiveName ?? this.executiveName,
      createdBy: createdBy ?? this.createdBy,
      createdDate: createdDate ?? this.createdDate,
      synced: synced ?? this.synced,
      approvalStatus: approvalStatus ?? this.approvalStatus,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (appExpId.present) {
      map['app_exp_id'] = Variable<String>(appExpId.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (expenseDate.present) {
      map['expense_date'] = Variable<DateTime>(expenseDate.value);
    }
    if (expenseName.present) {
      map['expense_name'] = Variable<String>(expenseName.value);
    }
    if (executiveId.present) {
      map['executive_id'] = Variable<String>(executiveId.value);
    }
    if (executiveName.present) {
      map['executive_name'] = Variable<String>(executiveName.value);
    }
    if (createdBy.present) {
      map['created_by'] = Variable<String>(createdBy.value);
    }
    if (createdDate.present) {
      map['created_date'] = Variable<DateTime>(createdDate.value);
    }
    if (synced.present) {
      map['synced'] = Variable<bool>(synced.value);
    }
    if (approvalStatus.present) {
      map['approval_status'] = Variable<String>(approvalStatus.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ExpensesCompanion(')
          ..write('appExpId: $appExpId, ')
          ..write('id: $id, ')
          ..write('expenseDate: $expenseDate, ')
          ..write('expenseName: $expenseName, ')
          ..write('executiveId: $executiveId, ')
          ..write('executiveName: $executiveName, ')
          ..write('createdBy: $createdBy, ')
          ..write('createdDate: $createdDate, ')
          ..write('synced: $synced, ')
          ..write('approvalStatus: $approvalStatus, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ExpenseItemsTable extends ExpenseItems
    with TableInfo<$ExpenseItemsTable, ExpenseItem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ExpenseItemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _appExpItemIdMeta =
      const VerificationMeta('appExpItemId');
  @override
  late final GeneratedColumn<String> appExpItemId = GeneratedColumn<String>(
      'app_exp_item_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      clientDefault: () => uuid.v6());
  static const VerificationMeta _appExpIdMeta =
      const VerificationMeta('appExpId');
  @override
  late final GeneratedColumn<String> appExpId = GeneratedColumn<String>(
      'app_exp_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultConstraints: GeneratedColumn.constraintIsAlways(
          'REFERENCES expenses (app_exp_id)'));
  static const VerificationMeta _typeMeta = const VerificationMeta('type');
  @override
  late final GeneratedColumn<String> type = GeneratedColumn<String>(
      'type', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _descriptionMeta =
      const VerificationMeta('description');
  @override
  late final GeneratedColumn<String> description = GeneratedColumn<String>(
      'description', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _amountMeta = const VerificationMeta('amount');
  @override
  late final GeneratedColumn<String> amount = GeneratedColumn<String>(
      'amount', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [appExpItemId, appExpId, type, description, amount];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'expense_items';
  @override
  VerificationContext validateIntegrity(Insertable<ExpenseItem> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('app_exp_item_id')) {
      context.handle(
          _appExpItemIdMeta,
          appExpItemId.isAcceptableOrUnknown(
              data['app_exp_item_id']!, _appExpItemIdMeta));
    }
    if (data.containsKey('app_exp_id')) {
      context.handle(_appExpIdMeta,
          appExpId.isAcceptableOrUnknown(data['app_exp_id']!, _appExpIdMeta));
    }
    if (data.containsKey('type')) {
      context.handle(
          _typeMeta, type.isAcceptableOrUnknown(data['type']!, _typeMeta));
    }
    if (data.containsKey('description')) {
      context.handle(
          _descriptionMeta,
          description.isAcceptableOrUnknown(
              data['description']!, _descriptionMeta));
    }
    if (data.containsKey('amount')) {
      context.handle(_amountMeta,
          amount.isAcceptableOrUnknown(data['amount']!, _amountMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {appExpItemId};
  @override
  ExpenseItem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ExpenseItem(
      appExpItemId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_exp_item_id']),
      appExpId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_exp_id']),
      type: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}type']),
      description: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}description']),
      amount: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}amount']),
    );
  }

  @override
  $ExpenseItemsTable createAlias(String alias) {
    return $ExpenseItemsTable(attachedDatabase, alias);
  }
}

class ExpenseItem extends DataClass implements Insertable<ExpenseItem> {
  final String? appExpItemId;
  final String? appExpId;
  final String? type;
  final String? description;
  final String? amount;
  const ExpenseItem(
      {this.appExpItemId,
      this.appExpId,
      this.type,
      this.description,
      this.amount});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || appExpItemId != null) {
      map['app_exp_item_id'] = Variable<String>(appExpItemId);
    }
    if (!nullToAbsent || appExpId != null) {
      map['app_exp_id'] = Variable<String>(appExpId);
    }
    if (!nullToAbsent || type != null) {
      map['type'] = Variable<String>(type);
    }
    if (!nullToAbsent || description != null) {
      map['description'] = Variable<String>(description);
    }
    if (!nullToAbsent || amount != null) {
      map['amount'] = Variable<String>(amount);
    }
    return map;
  }

  ExpenseItemsCompanion toCompanion(bool nullToAbsent) {
    return ExpenseItemsCompanion(
      appExpItemId: appExpItemId == null && nullToAbsent
          ? const Value.absent()
          : Value(appExpItemId),
      appExpId: appExpId == null && nullToAbsent
          ? const Value.absent()
          : Value(appExpId),
      type: type == null && nullToAbsent ? const Value.absent() : Value(type),
      description: description == null && nullToAbsent
          ? const Value.absent()
          : Value(description),
      amount:
          amount == null && nullToAbsent ? const Value.absent() : Value(amount),
    );
  }

  factory ExpenseItem.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ExpenseItem(
      appExpItemId: serializer.fromJson<String?>(json['appExpItemId']),
      appExpId: serializer.fromJson<String?>(json['appExpId']),
      type: serializer.fromJson<String?>(json['type']),
      description: serializer.fromJson<String?>(json['description']),
      amount: serializer.fromJson<String?>(json['amount']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'appExpItemId': serializer.toJson<String?>(appExpItemId),
      'appExpId': serializer.toJson<String?>(appExpId),
      'type': serializer.toJson<String?>(type),
      'description': serializer.toJson<String?>(description),
      'amount': serializer.toJson<String?>(amount),
    };
  }

  ExpenseItem copyWith(
          {Value<String?> appExpItemId = const Value.absent(),
          Value<String?> appExpId = const Value.absent(),
          Value<String?> type = const Value.absent(),
          Value<String?> description = const Value.absent(),
          Value<String?> amount = const Value.absent()}) =>
      ExpenseItem(
        appExpItemId:
            appExpItemId.present ? appExpItemId.value : this.appExpItemId,
        appExpId: appExpId.present ? appExpId.value : this.appExpId,
        type: type.present ? type.value : this.type,
        description: description.present ? description.value : this.description,
        amount: amount.present ? amount.value : this.amount,
      );
  @override
  String toString() {
    return (StringBuffer('ExpenseItem(')
          ..write('appExpItemId: $appExpItemId, ')
          ..write('appExpId: $appExpId, ')
          ..write('type: $type, ')
          ..write('description: $description, ')
          ..write('amount: $amount')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(appExpItemId, appExpId, type, description, amount);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ExpenseItem &&
          other.appExpItemId == this.appExpItemId &&
          other.appExpId == this.appExpId &&
          other.type == this.type &&
          other.description == this.description &&
          other.amount == this.amount);
}

class ExpenseItemsCompanion extends UpdateCompanion<ExpenseItem> {
  final Value<String?> appExpItemId;
  final Value<String?> appExpId;
  final Value<String?> type;
  final Value<String?> description;
  final Value<String?> amount;
  final Value<int> rowid;
  const ExpenseItemsCompanion({
    this.appExpItemId = const Value.absent(),
    this.appExpId = const Value.absent(),
    this.type = const Value.absent(),
    this.description = const Value.absent(),
    this.amount = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ExpenseItemsCompanion.insert({
    this.appExpItemId = const Value.absent(),
    this.appExpId = const Value.absent(),
    this.type = const Value.absent(),
    this.description = const Value.absent(),
    this.amount = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  static Insertable<ExpenseItem> custom({
    Expression<String>? appExpItemId,
    Expression<String>? appExpId,
    Expression<String>? type,
    Expression<String>? description,
    Expression<String>? amount,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (appExpItemId != null) 'app_exp_item_id': appExpItemId,
      if (appExpId != null) 'app_exp_id': appExpId,
      if (type != null) 'type': type,
      if (description != null) 'description': description,
      if (amount != null) 'amount': amount,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ExpenseItemsCompanion copyWith(
      {Value<String?>? appExpItemId,
      Value<String?>? appExpId,
      Value<String?>? type,
      Value<String?>? description,
      Value<String?>? amount,
      Value<int>? rowid}) {
    return ExpenseItemsCompanion(
      appExpItemId: appExpItemId ?? this.appExpItemId,
      appExpId: appExpId ?? this.appExpId,
      type: type ?? this.type,
      description: description ?? this.description,
      amount: amount ?? this.amount,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (appExpItemId.present) {
      map['app_exp_item_id'] = Variable<String>(appExpItemId.value);
    }
    if (appExpId.present) {
      map['app_exp_id'] = Variable<String>(appExpId.value);
    }
    if (type.present) {
      map['type'] = Variable<String>(type.value);
    }
    if (description.present) {
      map['description'] = Variable<String>(description.value);
    }
    if (amount.present) {
      map['amount'] = Variable<String>(amount.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ExpenseItemsCompanion(')
          ..write('appExpItemId: $appExpItemId, ')
          ..write('appExpId: $appExpId, ')
          ..write('type: $type, ')
          ..write('description: $description, ')
          ..write('amount: $amount, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ExpenseItemFilesTable extends ExpenseItemFiles
    with TableInfo<$ExpenseItemFilesTable, ExpenseItemFile> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ExpenseItemFilesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      clientDefault: () => uuid.v6());
  static const VerificationMeta _appExpItemIdMeta =
      const VerificationMeta('appExpItemId');
  @override
  late final GeneratedColumn<String> appExpItemId = GeneratedColumn<String>(
      'app_exp_item_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultConstraints: GeneratedColumn.constraintIsAlways(
          'REFERENCES expense_items (app_exp_item_id)'));
  static const VerificationMeta _appExpIdMeta =
      const VerificationMeta('appExpId');
  @override
  late final GeneratedColumn<String> appExpId = GeneratedColumn<String>(
      'app_exp_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultConstraints: GeneratedColumn.constraintIsAlways(
          'REFERENCES expenses (app_exp_id)'));
  static const VerificationMeta _fileMeta = const VerificationMeta('file');
  @override
  late final GeneratedColumn<Uint8List> file = GeneratedColumn<Uint8List>(
      'file', aliasedName, false,
      type: DriftSqlType.blob, requiredDuringInsert: true);
  static const VerificationMeta _fileNameMeta =
      const VerificationMeta('fileName');
  @override
  late final GeneratedColumn<String> fileName = GeneratedColumn<String>(
      'file_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _syncedMeta = const VerificationMeta('synced');
  @override
  late final GeneratedColumn<bool> synced = GeneratedColumn<bool>(
      'synced', aliasedName, true,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("synced" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns =>
      [id, appExpItemId, appExpId, file, fileName, synced];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'expense_item_files';
  @override
  VerificationContext validateIntegrity(Insertable<ExpenseItemFile> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('app_exp_item_id')) {
      context.handle(
          _appExpItemIdMeta,
          appExpItemId.isAcceptableOrUnknown(
              data['app_exp_item_id']!, _appExpItemIdMeta));
    }
    if (data.containsKey('app_exp_id')) {
      context.handle(_appExpIdMeta,
          appExpId.isAcceptableOrUnknown(data['app_exp_id']!, _appExpIdMeta));
    }
    if (data.containsKey('file')) {
      context.handle(
          _fileMeta, file.isAcceptableOrUnknown(data['file']!, _fileMeta));
    } else if (isInserting) {
      context.missing(_fileMeta);
    }
    if (data.containsKey('file_name')) {
      context.handle(_fileNameMeta,
          fileName.isAcceptableOrUnknown(data['file_name']!, _fileNameMeta));
    }
    if (data.containsKey('synced')) {
      context.handle(_syncedMeta,
          synced.isAcceptableOrUnknown(data['synced']!, _syncedMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ExpenseItemFile map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ExpenseItemFile(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id']),
      appExpItemId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_exp_item_id']),
      appExpId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_exp_id']),
      file: attachedDatabase.typeMapping
          .read(DriftSqlType.blob, data['${effectivePrefix}file'])!,
      fileName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}file_name']),
      synced: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}synced']),
    );
  }

  @override
  $ExpenseItemFilesTable createAlias(String alias) {
    return $ExpenseItemFilesTable(attachedDatabase, alias);
  }
}

class ExpenseItemFile extends DataClass implements Insertable<ExpenseItemFile> {
  final String? id;
  final String? appExpItemId;
  final String? appExpId;
  final Uint8List file;
  final String? fileName;
  final bool? synced;
  const ExpenseItemFile(
      {this.id,
      this.appExpItemId,
      this.appExpId,
      required this.file,
      this.fileName,
      this.synced});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<String>(id);
    }
    if (!nullToAbsent || appExpItemId != null) {
      map['app_exp_item_id'] = Variable<String>(appExpItemId);
    }
    if (!nullToAbsent || appExpId != null) {
      map['app_exp_id'] = Variable<String>(appExpId);
    }
    map['file'] = Variable<Uint8List>(file);
    if (!nullToAbsent || fileName != null) {
      map['file_name'] = Variable<String>(fileName);
    }
    if (!nullToAbsent || synced != null) {
      map['synced'] = Variable<bool>(synced);
    }
    return map;
  }

  ExpenseItemFilesCompanion toCompanion(bool nullToAbsent) {
    return ExpenseItemFilesCompanion(
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      appExpItemId: appExpItemId == null && nullToAbsent
          ? const Value.absent()
          : Value(appExpItemId),
      appExpId: appExpId == null && nullToAbsent
          ? const Value.absent()
          : Value(appExpId),
      file: Value(file),
      fileName: fileName == null && nullToAbsent
          ? const Value.absent()
          : Value(fileName),
      synced:
          synced == null && nullToAbsent ? const Value.absent() : Value(synced),
    );
  }

  factory ExpenseItemFile.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ExpenseItemFile(
      id: serializer.fromJson<String?>(json['id']),
      appExpItemId: serializer.fromJson<String?>(json['appExpItemId']),
      appExpId: serializer.fromJson<String?>(json['appExpId']),
      file: serializer.fromJson<Uint8List>(json['file']),
      fileName: serializer.fromJson<String?>(json['fileName']),
      synced: serializer.fromJson<bool?>(json['synced']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String?>(id),
      'appExpItemId': serializer.toJson<String?>(appExpItemId),
      'appExpId': serializer.toJson<String?>(appExpId),
      'file': serializer.toJson<Uint8List>(file),
      'fileName': serializer.toJson<String?>(fileName),
      'synced': serializer.toJson<bool?>(synced),
    };
  }

  ExpenseItemFile copyWith(
          {Value<String?> id = const Value.absent(),
          Value<String?> appExpItemId = const Value.absent(),
          Value<String?> appExpId = const Value.absent(),
          Uint8List? file,
          Value<String?> fileName = const Value.absent(),
          Value<bool?> synced = const Value.absent()}) =>
      ExpenseItemFile(
        id: id.present ? id.value : this.id,
        appExpItemId:
            appExpItemId.present ? appExpItemId.value : this.appExpItemId,
        appExpId: appExpId.present ? appExpId.value : this.appExpId,
        file: file ?? this.file,
        fileName: fileName.present ? fileName.value : this.fileName,
        synced: synced.present ? synced.value : this.synced,
      );
  @override
  String toString() {
    return (StringBuffer('ExpenseItemFile(')
          ..write('id: $id, ')
          ..write('appExpItemId: $appExpItemId, ')
          ..write('appExpId: $appExpId, ')
          ..write('file: $file, ')
          ..write('fileName: $fileName, ')
          ..write('synced: $synced')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, appExpItemId, appExpId,
      $driftBlobEquality.hash(file), fileName, synced);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ExpenseItemFile &&
          other.id == this.id &&
          other.appExpItemId == this.appExpItemId &&
          other.appExpId == this.appExpId &&
          $driftBlobEquality.equals(other.file, this.file) &&
          other.fileName == this.fileName &&
          other.synced == this.synced);
}

class ExpenseItemFilesCompanion extends UpdateCompanion<ExpenseItemFile> {
  final Value<String?> id;
  final Value<String?> appExpItemId;
  final Value<String?> appExpId;
  final Value<Uint8List> file;
  final Value<String?> fileName;
  final Value<bool?> synced;
  final Value<int> rowid;
  const ExpenseItemFilesCompanion({
    this.id = const Value.absent(),
    this.appExpItemId = const Value.absent(),
    this.appExpId = const Value.absent(),
    this.file = const Value.absent(),
    this.fileName = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ExpenseItemFilesCompanion.insert({
    this.id = const Value.absent(),
    this.appExpItemId = const Value.absent(),
    this.appExpId = const Value.absent(),
    required Uint8List file,
    this.fileName = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  }) : file = Value(file);
  static Insertable<ExpenseItemFile> custom({
    Expression<String>? id,
    Expression<String>? appExpItemId,
    Expression<String>? appExpId,
    Expression<Uint8List>? file,
    Expression<String>? fileName,
    Expression<bool>? synced,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (appExpItemId != null) 'app_exp_item_id': appExpItemId,
      if (appExpId != null) 'app_exp_id': appExpId,
      if (file != null) 'file': file,
      if (fileName != null) 'file_name': fileName,
      if (synced != null) 'synced': synced,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ExpenseItemFilesCompanion copyWith(
      {Value<String?>? id,
      Value<String?>? appExpItemId,
      Value<String?>? appExpId,
      Value<Uint8List>? file,
      Value<String?>? fileName,
      Value<bool?>? synced,
      Value<int>? rowid}) {
    return ExpenseItemFilesCompanion(
      id: id ?? this.id,
      appExpItemId: appExpItemId ?? this.appExpItemId,
      appExpId: appExpId ?? this.appExpId,
      file: file ?? this.file,
      fileName: fileName ?? this.fileName,
      synced: synced ?? this.synced,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (appExpItemId.present) {
      map['app_exp_item_id'] = Variable<String>(appExpItemId.value);
    }
    if (appExpId.present) {
      map['app_exp_id'] = Variable<String>(appExpId.value);
    }
    if (file.present) {
      map['file'] = Variable<Uint8List>(file.value);
    }
    if (fileName.present) {
      map['file_name'] = Variable<String>(fileName.value);
    }
    if (synced.present) {
      map['synced'] = Variable<bool>(synced.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ExpenseItemFilesCompanion(')
          ..write('id: $id, ')
          ..write('appExpItemId: $appExpItemId, ')
          ..write('appExpId: $appExpId, ')
          ..write('file: $file, ')
          ..write('fileName: $fileName, ')
          ..write('synced: $synced, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $StocksTable extends Stocks with TableInfo<$StocksTable, Stock> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $StocksTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _appStockIdMeta =
      const VerificationMeta('appStockId');
  @override
  late final GeneratedColumn<String> appStockId = GeneratedColumn<String>(
      'app_stock_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      clientDefault: () => uuid.v6());
  static const VerificationMeta _salesAppIdMeta =
      const VerificationMeta('salesAppId');
  @override
  late final GeneratedColumn<String> salesAppId = GeneratedColumn<String>(
      'sales_app_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultConstraints: GeneratedColumn.constraintIsAlways(
          'REFERENCES visits (sales_app_id)'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _productIdMeta =
      const VerificationMeta('productId');
  @override
  late final GeneratedColumn<String> productId = GeneratedColumn<String>(
      'product_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _productNameMeta =
      const VerificationMeta('productName');
  @override
  late final GeneratedColumn<String> productName = GeneratedColumn<String>(
      'product_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _productCategoryMeta =
      const VerificationMeta('productCategory');
  @override
  late final GeneratedColumn<String> productCategory = GeneratedColumn<String>(
      'product_category', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _unitPriceMeta =
      const VerificationMeta('unitPrice');
  @override
  late final GeneratedColumn<double> unitPrice = GeneratedColumn<double>(
      'unit_price', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _quantityMeta =
      const VerificationMeta('quantity');
  @override
  late final GeneratedColumn<int> quantity = GeneratedColumn<int>(
      'quantity', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _accountIdMeta =
      const VerificationMeta('accountId');
  @override
  late final GeneratedColumn<String> accountId = GeneratedColumn<String>(
      'account_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _accountNameMeta =
      const VerificationMeta('accountName');
  @override
  late final GeneratedColumn<String> accountName = GeneratedColumn<String>(
      'account_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _syncedMeta = const VerificationMeta('synced');
  @override
  late final GeneratedColumn<bool> synced = GeneratedColumn<bool>(
      'synced', aliasedName, true,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("synced" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        appStockId,
        salesAppId,
        id,
        productId,
        productName,
        productCategory,
        unitPrice,
        quantity,
        accountId,
        accountName,
        synced
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'stocks';
  @override
  VerificationContext validateIntegrity(Insertable<Stock> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('app_stock_id')) {
      context.handle(
          _appStockIdMeta,
          appStockId.isAcceptableOrUnknown(
              data['app_stock_id']!, _appStockIdMeta));
    }
    if (data.containsKey('sales_app_id')) {
      context.handle(
          _salesAppIdMeta,
          salesAppId.isAcceptableOrUnknown(
              data['sales_app_id']!, _salesAppIdMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('product_id')) {
      context.handle(_productIdMeta,
          productId.isAcceptableOrUnknown(data['product_id']!, _productIdMeta));
    }
    if (data.containsKey('product_name')) {
      context.handle(
          _productNameMeta,
          productName.isAcceptableOrUnknown(
              data['product_name']!, _productNameMeta));
    }
    if (data.containsKey('product_category')) {
      context.handle(
          _productCategoryMeta,
          productCategory.isAcceptableOrUnknown(
              data['product_category']!, _productCategoryMeta));
    }
    if (data.containsKey('unit_price')) {
      context.handle(_unitPriceMeta,
          unitPrice.isAcceptableOrUnknown(data['unit_price']!, _unitPriceMeta));
    }
    if (data.containsKey('quantity')) {
      context.handle(_quantityMeta,
          quantity.isAcceptableOrUnknown(data['quantity']!, _quantityMeta));
    }
    if (data.containsKey('account_id')) {
      context.handle(_accountIdMeta,
          accountId.isAcceptableOrUnknown(data['account_id']!, _accountIdMeta));
    }
    if (data.containsKey('account_name')) {
      context.handle(
          _accountNameMeta,
          accountName.isAcceptableOrUnknown(
              data['account_name']!, _accountNameMeta));
    }
    if (data.containsKey('synced')) {
      context.handle(_syncedMeta,
          synced.isAcceptableOrUnknown(data['synced']!, _syncedMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {appStockId};
  @override
  Stock map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Stock(
      appStockId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_stock_id']),
      salesAppId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sales_app_id']),
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id']),
      productId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}product_id']),
      productName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}product_name']),
      productCategory: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}product_category']),
      unitPrice: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}unit_price']),
      quantity: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}quantity']),
      accountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}account_id']),
      accountName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}account_name']),
      synced: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}synced']),
    );
  }

  @override
  $StocksTable createAlias(String alias) {
    return $StocksTable(attachedDatabase, alias);
  }
}

class Stock extends DataClass implements Insertable<Stock> {
  final String? appStockId;
  final String? salesAppId;
  final String? id;
  final String? productId;
  final String? productName;
  final String? productCategory;
  final double? unitPrice;
  final int? quantity;
  final String? accountId;
  final String? accountName;
  final bool? synced;
  const Stock(
      {this.appStockId,
      this.salesAppId,
      this.id,
      this.productId,
      this.productName,
      this.productCategory,
      this.unitPrice,
      this.quantity,
      this.accountId,
      this.accountName,
      this.synced});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || appStockId != null) {
      map['app_stock_id'] = Variable<String>(appStockId);
    }
    if (!nullToAbsent || salesAppId != null) {
      map['sales_app_id'] = Variable<String>(salesAppId);
    }
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<String>(id);
    }
    if (!nullToAbsent || productId != null) {
      map['product_id'] = Variable<String>(productId);
    }
    if (!nullToAbsent || productName != null) {
      map['product_name'] = Variable<String>(productName);
    }
    if (!nullToAbsent || productCategory != null) {
      map['product_category'] = Variable<String>(productCategory);
    }
    if (!nullToAbsent || unitPrice != null) {
      map['unit_price'] = Variable<double>(unitPrice);
    }
    if (!nullToAbsent || quantity != null) {
      map['quantity'] = Variable<int>(quantity);
    }
    if (!nullToAbsent || accountId != null) {
      map['account_id'] = Variable<String>(accountId);
    }
    if (!nullToAbsent || accountName != null) {
      map['account_name'] = Variable<String>(accountName);
    }
    if (!nullToAbsent || synced != null) {
      map['synced'] = Variable<bool>(synced);
    }
    return map;
  }

  StocksCompanion toCompanion(bool nullToAbsent) {
    return StocksCompanion(
      appStockId: appStockId == null && nullToAbsent
          ? const Value.absent()
          : Value(appStockId),
      salesAppId: salesAppId == null && nullToAbsent
          ? const Value.absent()
          : Value(salesAppId),
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      productId: productId == null && nullToAbsent
          ? const Value.absent()
          : Value(productId),
      productName: productName == null && nullToAbsent
          ? const Value.absent()
          : Value(productName),
      productCategory: productCategory == null && nullToAbsent
          ? const Value.absent()
          : Value(productCategory),
      unitPrice: unitPrice == null && nullToAbsent
          ? const Value.absent()
          : Value(unitPrice),
      quantity: quantity == null && nullToAbsent
          ? const Value.absent()
          : Value(quantity),
      accountId: accountId == null && nullToAbsent
          ? const Value.absent()
          : Value(accountId),
      accountName: accountName == null && nullToAbsent
          ? const Value.absent()
          : Value(accountName),
      synced:
          synced == null && nullToAbsent ? const Value.absent() : Value(synced),
    );
  }

  factory Stock.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Stock(
      appStockId: serializer.fromJson<String?>(json['appStockId']),
      salesAppId: serializer.fromJson<String?>(json['salesAppId']),
      id: serializer.fromJson<String?>(json['Id']),
      productId: serializer.fromJson<String?>(json['productId']),
      productName: serializer.fromJson<String?>(json['productName']),
      productCategory: serializer.fromJson<String?>(json['productCategory']),
      unitPrice: serializer.fromJson<double?>(json['unitPice']),
      quantity: serializer.fromJson<int?>(json['quantity']),
      accountId: serializer.fromJson<String?>(json['accountId']),
      accountName: serializer.fromJson<String?>(json['accountName']),
      synced: serializer.fromJson<bool?>(json['synced']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'appStockId': serializer.toJson<String?>(appStockId),
      'salesAppId': serializer.toJson<String?>(salesAppId),
      'Id': serializer.toJson<String?>(id),
      'productId': serializer.toJson<String?>(productId),
      'productName': serializer.toJson<String?>(productName),
      'productCategory': serializer.toJson<String?>(productCategory),
      'unitPice': serializer.toJson<double?>(unitPrice),
      'quantity': serializer.toJson<int?>(quantity),
      'accountId': serializer.toJson<String?>(accountId),
      'accountName': serializer.toJson<String?>(accountName),
      'synced': serializer.toJson<bool?>(synced),
    };
  }

  Stock copyWith(
          {Value<String?> appStockId = const Value.absent(),
          Value<String?> salesAppId = const Value.absent(),
          Value<String?> id = const Value.absent(),
          Value<String?> productId = const Value.absent(),
          Value<String?> productName = const Value.absent(),
          Value<String?> productCategory = const Value.absent(),
          Value<double?> unitPrice = const Value.absent(),
          Value<int?> quantity = const Value.absent(),
          Value<String?> accountId = const Value.absent(),
          Value<String?> accountName = const Value.absent(),
          Value<bool?> synced = const Value.absent()}) =>
      Stock(
        appStockId: appStockId.present ? appStockId.value : this.appStockId,
        salesAppId: salesAppId.present ? salesAppId.value : this.salesAppId,
        id: id.present ? id.value : this.id,
        productId: productId.present ? productId.value : this.productId,
        productName: productName.present ? productName.value : this.productName,
        productCategory: productCategory.present
            ? productCategory.value
            : this.productCategory,
        unitPrice: unitPrice.present ? unitPrice.value : this.unitPrice,
        quantity: quantity.present ? quantity.value : this.quantity,
        accountId: accountId.present ? accountId.value : this.accountId,
        accountName: accountName.present ? accountName.value : this.accountName,
        synced: synced.present ? synced.value : this.synced,
      );
  @override
  String toString() {
    return (StringBuffer('Stock(')
          ..write('appStockId: $appStockId, ')
          ..write('salesAppId: $salesAppId, ')
          ..write('id: $id, ')
          ..write('productId: $productId, ')
          ..write('productName: $productName, ')
          ..write('productCategory: $productCategory, ')
          ..write('unitPrice: $unitPrice, ')
          ..write('quantity: $quantity, ')
          ..write('accountId: $accountId, ')
          ..write('accountName: $accountName, ')
          ..write('synced: $synced')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      appStockId,
      salesAppId,
      id,
      productId,
      productName,
      productCategory,
      unitPrice,
      quantity,
      accountId,
      accountName,
      synced);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Stock &&
          other.appStockId == this.appStockId &&
          other.salesAppId == this.salesAppId &&
          other.id == this.id &&
          other.productId == this.productId &&
          other.productName == this.productName &&
          other.productCategory == this.productCategory &&
          other.unitPrice == this.unitPrice &&
          other.quantity == this.quantity &&
          other.accountId == this.accountId &&
          other.accountName == this.accountName &&
          other.synced == this.synced);
}

class StocksCompanion extends UpdateCompanion<Stock> {
  final Value<String?> appStockId;
  final Value<String?> salesAppId;
  final Value<String?> id;
  final Value<String?> productId;
  final Value<String?> productName;
  final Value<String?> productCategory;
  final Value<double?> unitPrice;
  final Value<int?> quantity;
  final Value<String?> accountId;
  final Value<String?> accountName;
  final Value<bool?> synced;
  final Value<int> rowid;
  const StocksCompanion({
    this.appStockId = const Value.absent(),
    this.salesAppId = const Value.absent(),
    this.id = const Value.absent(),
    this.productId = const Value.absent(),
    this.productName = const Value.absent(),
    this.productCategory = const Value.absent(),
    this.unitPrice = const Value.absent(),
    this.quantity = const Value.absent(),
    this.accountId = const Value.absent(),
    this.accountName = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  StocksCompanion.insert({
    this.appStockId = const Value.absent(),
    this.salesAppId = const Value.absent(),
    this.id = const Value.absent(),
    this.productId = const Value.absent(),
    this.productName = const Value.absent(),
    this.productCategory = const Value.absent(),
    this.unitPrice = const Value.absent(),
    this.quantity = const Value.absent(),
    this.accountId = const Value.absent(),
    this.accountName = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  static Insertable<Stock> custom({
    Expression<String>? appStockId,
    Expression<String>? salesAppId,
    Expression<String>? id,
    Expression<String>? productId,
    Expression<String>? productName,
    Expression<String>? productCategory,
    Expression<double>? unitPrice,
    Expression<int>? quantity,
    Expression<String>? accountId,
    Expression<String>? accountName,
    Expression<bool>? synced,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (appStockId != null) 'app_stock_id': appStockId,
      if (salesAppId != null) 'sales_app_id': salesAppId,
      if (id != null) 'id': id,
      if (productId != null) 'product_id': productId,
      if (productName != null) 'product_name': productName,
      if (productCategory != null) 'product_category': productCategory,
      if (unitPrice != null) 'unit_price': unitPrice,
      if (quantity != null) 'quantity': quantity,
      if (accountId != null) 'account_id': accountId,
      if (accountName != null) 'account_name': accountName,
      if (synced != null) 'synced': synced,
      if (rowid != null) 'rowid': rowid,
    });
  }

  StocksCompanion copyWith(
      {Value<String?>? appStockId,
      Value<String?>? salesAppId,
      Value<String?>? id,
      Value<String?>? productId,
      Value<String?>? productName,
      Value<String?>? productCategory,
      Value<double?>? unitPrice,
      Value<int?>? quantity,
      Value<String?>? accountId,
      Value<String?>? accountName,
      Value<bool?>? synced,
      Value<int>? rowid}) {
    return StocksCompanion(
      appStockId: appStockId ?? this.appStockId,
      salesAppId: salesAppId ?? this.salesAppId,
      id: id ?? this.id,
      productId: productId ?? this.productId,
      productName: productName ?? this.productName,
      productCategory: productCategory ?? this.productCategory,
      unitPrice: unitPrice ?? this.unitPrice,
      quantity: quantity ?? this.quantity,
      accountId: accountId ?? this.accountId,
      accountName: accountName ?? this.accountName,
      synced: synced ?? this.synced,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (appStockId.present) {
      map['app_stock_id'] = Variable<String>(appStockId.value);
    }
    if (salesAppId.present) {
      map['sales_app_id'] = Variable<String>(salesAppId.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (productId.present) {
      map['product_id'] = Variable<String>(productId.value);
    }
    if (productName.present) {
      map['product_name'] = Variable<String>(productName.value);
    }
    if (productCategory.present) {
      map['product_category'] = Variable<String>(productCategory.value);
    }
    if (unitPrice.present) {
      map['unit_price'] = Variable<double>(unitPrice.value);
    }
    if (quantity.present) {
      map['quantity'] = Variable<int>(quantity.value);
    }
    if (accountId.present) {
      map['account_id'] = Variable<String>(accountId.value);
    }
    if (accountName.present) {
      map['account_name'] = Variable<String>(accountName.value);
    }
    if (synced.present) {
      map['synced'] = Variable<bool>(synced.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('StocksCompanion(')
          ..write('appStockId: $appStockId, ')
          ..write('salesAppId: $salesAppId, ')
          ..write('id: $id, ')
          ..write('productId: $productId, ')
          ..write('productName: $productName, ')
          ..write('productCategory: $productCategory, ')
          ..write('unitPrice: $unitPrice, ')
          ..write('quantity: $quantity, ')
          ..write('accountId: $accountId, ')
          ..write('accountName: $accountName, ')
          ..write('synced: $synced, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $TicketsTable extends Tickets with TableInfo<$TicketsTable, Ticket> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TicketsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _appTicketIdMeta =
      const VerificationMeta('appTicketId');
  @override
  late final GeneratedColumn<String> appTicketId = GeneratedColumn<String>(
      'app_ticket_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      clientDefault: () => uuid.v6());
  static const VerificationMeta _salesAppIdMeta =
      const VerificationMeta('salesAppId');
  @override
  late final GeneratedColumn<String> salesAppId = GeneratedColumn<String>(
      'sales_app_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _visitIdMeta =
      const VerificationMeta('visitId');
  @override
  late final GeneratedColumn<String> visitId = GeneratedColumn<String>(
      'visit_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _complaintTypeMeta =
      const VerificationMeta('complaintType');
  @override
  late final GeneratedColumn<String> complaintType = GeneratedColumn<String>(
      'complaint_type', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _descriptionMeta =
      const VerificationMeta('description');
  @override
  late final GeneratedColumn<String> description = GeneratedColumn<String>(
      'description', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _subjectMeta =
      const VerificationMeta('subject');
  @override
  late final GeneratedColumn<String> subject = GeneratedColumn<String>(
      'subject', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _accountIdMeta =
      const VerificationMeta('accountId');
  @override
  late final GeneratedColumn<String> accountId = GeneratedColumn<String>(
      'account_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _appAccountIdMeta =
      const VerificationMeta('appAccountId');
  @override
  late final GeneratedColumn<String> appAccountId = GeneratedColumn<String>(
      'app_account_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _accountNameMeta =
      const VerificationMeta('accountName');
  @override
  late final GeneratedColumn<String> accountName = GeneratedColumn<String>(
      'account_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdDateMeta =
      const VerificationMeta('createdDate');
  @override
  late final GeneratedColumn<DateTime> createdDate = GeneratedColumn<DateTime>(
      'created_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _syncedMeta = const VerificationMeta('synced');
  @override
  late final GeneratedColumn<bool> synced = GeneratedColumn<bool>(
      'synced', aliasedName, true,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("synced" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        appTicketId,
        salesAppId,
        visitId,
        id,
        complaintType,
        description,
        status,
        subject,
        accountId,
        appAccountId,
        accountName,
        createdDate,
        synced
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tickets';
  @override
  VerificationContext validateIntegrity(Insertable<Ticket> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('app_ticket_id')) {
      context.handle(
          _appTicketIdMeta,
          appTicketId.isAcceptableOrUnknown(
              data['app_ticket_id']!, _appTicketIdMeta));
    }
    if (data.containsKey('sales_app_id')) {
      context.handle(
          _salesAppIdMeta,
          salesAppId.isAcceptableOrUnknown(
              data['sales_app_id']!, _salesAppIdMeta));
    }
    if (data.containsKey('visit_id')) {
      context.handle(_visitIdMeta,
          visitId.isAcceptableOrUnknown(data['visit_id']!, _visitIdMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('complaint_type')) {
      context.handle(
          _complaintTypeMeta,
          complaintType.isAcceptableOrUnknown(
              data['complaint_type']!, _complaintTypeMeta));
    }
    if (data.containsKey('description')) {
      context.handle(
          _descriptionMeta,
          description.isAcceptableOrUnknown(
              data['description']!, _descriptionMeta));
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('subject')) {
      context.handle(_subjectMeta,
          subject.isAcceptableOrUnknown(data['subject']!, _subjectMeta));
    }
    if (data.containsKey('account_id')) {
      context.handle(_accountIdMeta,
          accountId.isAcceptableOrUnknown(data['account_id']!, _accountIdMeta));
    }
    if (data.containsKey('app_account_id')) {
      context.handle(
          _appAccountIdMeta,
          appAccountId.isAcceptableOrUnknown(
              data['app_account_id']!, _appAccountIdMeta));
    }
    if (data.containsKey('account_name')) {
      context.handle(
          _accountNameMeta,
          accountName.isAcceptableOrUnknown(
              data['account_name']!, _accountNameMeta));
    }
    if (data.containsKey('created_date')) {
      context.handle(
          _createdDateMeta,
          createdDate.isAcceptableOrUnknown(
              data['created_date']!, _createdDateMeta));
    }
    if (data.containsKey('synced')) {
      context.handle(_syncedMeta,
          synced.isAcceptableOrUnknown(data['synced']!, _syncedMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {appTicketId};
  @override
  Ticket map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Ticket(
      appTicketId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_ticket_id']),
      salesAppId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sales_app_id']),
      visitId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}visit_id']),
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id']),
      complaintType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complaint_type']),
      description: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}description']),
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status']),
      subject: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}subject']),
      accountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}account_id']),
      appAccountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_account_id']),
      accountName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}account_name']),
      createdDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_date']),
      synced: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}synced']),
    );
  }

  @override
  $TicketsTable createAlias(String alias) {
    return $TicketsTable(attachedDatabase, alias);
  }
}

class Ticket extends DataClass implements Insertable<Ticket> {
  final String? appTicketId;
  final String? salesAppId;
  final String? visitId;
  final String? id;
  final String? complaintType;
  final String? description;
  final String? status;
  final String? subject;
  final String? accountId;
  final String? appAccountId;
  final String? accountName;
  final DateTime? createdDate;
  final bool? synced;
  const Ticket(
      {this.appTicketId,
      this.salesAppId,
      this.visitId,
      this.id,
      this.complaintType,
      this.description,
      this.status,
      this.subject,
      this.accountId,
      this.appAccountId,
      this.accountName,
      this.createdDate,
      this.synced});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || appTicketId != null) {
      map['app_ticket_id'] = Variable<String>(appTicketId);
    }
    if (!nullToAbsent || salesAppId != null) {
      map['sales_app_id'] = Variable<String>(salesAppId);
    }
    if (!nullToAbsent || visitId != null) {
      map['visit_id'] = Variable<String>(visitId);
    }
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<String>(id);
    }
    if (!nullToAbsent || complaintType != null) {
      map['complaint_type'] = Variable<String>(complaintType);
    }
    if (!nullToAbsent || description != null) {
      map['description'] = Variable<String>(description);
    }
    if (!nullToAbsent || status != null) {
      map['status'] = Variable<String>(status);
    }
    if (!nullToAbsent || subject != null) {
      map['subject'] = Variable<String>(subject);
    }
    if (!nullToAbsent || accountId != null) {
      map['account_id'] = Variable<String>(accountId);
    }
    if (!nullToAbsent || appAccountId != null) {
      map['app_account_id'] = Variable<String>(appAccountId);
    }
    if (!nullToAbsent || accountName != null) {
      map['account_name'] = Variable<String>(accountName);
    }
    if (!nullToAbsent || createdDate != null) {
      map['created_date'] = Variable<DateTime>(createdDate);
    }
    if (!nullToAbsent || synced != null) {
      map['synced'] = Variable<bool>(synced);
    }
    return map;
  }

  TicketsCompanion toCompanion(bool nullToAbsent) {
    return TicketsCompanion(
      appTicketId: appTicketId == null && nullToAbsent
          ? const Value.absent()
          : Value(appTicketId),
      salesAppId: salesAppId == null && nullToAbsent
          ? const Value.absent()
          : Value(salesAppId),
      visitId: visitId == null && nullToAbsent
          ? const Value.absent()
          : Value(visitId),
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      complaintType: complaintType == null && nullToAbsent
          ? const Value.absent()
          : Value(complaintType),
      description: description == null && nullToAbsent
          ? const Value.absent()
          : Value(description),
      status:
          status == null && nullToAbsent ? const Value.absent() : Value(status),
      subject: subject == null && nullToAbsent
          ? const Value.absent()
          : Value(subject),
      accountId: accountId == null && nullToAbsent
          ? const Value.absent()
          : Value(accountId),
      appAccountId: appAccountId == null && nullToAbsent
          ? const Value.absent()
          : Value(appAccountId),
      accountName: accountName == null && nullToAbsent
          ? const Value.absent()
          : Value(accountName),
      createdDate: createdDate == null && nullToAbsent
          ? const Value.absent()
          : Value(createdDate),
      synced:
          synced == null && nullToAbsent ? const Value.absent() : Value(synced),
    );
  }

  factory Ticket.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Ticket(
      appTicketId: serializer.fromJson<String?>(json['appTicketId']),
      salesAppId: serializer.fromJson<String?>(json['salesAppId']),
      visitId: serializer.fromJson<String?>(json['visitId']),
      id: serializer.fromJson<String?>(json['Id']),
      complaintType: serializer.fromJson<String?>(json['complaintType']),
      description: serializer.fromJson<String?>(json['decription']),
      status: serializer.fromJson<String?>(json['status']),
      subject: serializer.fromJson<String?>(json['subject']),
      accountId: serializer.fromJson<String?>(json['accountId']),
      appAccountId: serializer.fromJson<String?>(json['appAccountId']),
      accountName: serializer.fromJson<String?>(json['accountName']),
      createdDate: serializer.fromJson<DateTime?>(json['createdDate']),
      synced: serializer.fromJson<bool?>(json['synced']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'appTicketId': serializer.toJson<String?>(appTicketId),
      'salesAppId': serializer.toJson<String?>(salesAppId),
      'visitId': serializer.toJson<String?>(visitId),
      'Id': serializer.toJson<String?>(id),
      'complaintType': serializer.toJson<String?>(complaintType),
      'decription': serializer.toJson<String?>(description),
      'status': serializer.toJson<String?>(status),
      'subject': serializer.toJson<String?>(subject),
      'accountId': serializer.toJson<String?>(accountId),
      'appAccountId': serializer.toJson<String?>(appAccountId),
      'accountName': serializer.toJson<String?>(accountName),
      'createdDate': serializer.toJson<DateTime?>(createdDate),
      'synced': serializer.toJson<bool?>(synced),
    };
  }

  Ticket copyWith(
          {Value<String?> appTicketId = const Value.absent(),
          Value<String?> salesAppId = const Value.absent(),
          Value<String?> visitId = const Value.absent(),
          Value<String?> id = const Value.absent(),
          Value<String?> complaintType = const Value.absent(),
          Value<String?> description = const Value.absent(),
          Value<String?> status = const Value.absent(),
          Value<String?> subject = const Value.absent(),
          Value<String?> accountId = const Value.absent(),
          Value<String?> appAccountId = const Value.absent(),
          Value<String?> accountName = const Value.absent(),
          Value<DateTime?> createdDate = const Value.absent(),
          Value<bool?> synced = const Value.absent()}) =>
      Ticket(
        appTicketId: appTicketId.present ? appTicketId.value : this.appTicketId,
        salesAppId: salesAppId.present ? salesAppId.value : this.salesAppId,
        visitId: visitId.present ? visitId.value : this.visitId,
        id: id.present ? id.value : this.id,
        complaintType:
            complaintType.present ? complaintType.value : this.complaintType,
        description: description.present ? description.value : this.description,
        status: status.present ? status.value : this.status,
        subject: subject.present ? subject.value : this.subject,
        accountId: accountId.present ? accountId.value : this.accountId,
        appAccountId:
            appAccountId.present ? appAccountId.value : this.appAccountId,
        accountName: accountName.present ? accountName.value : this.accountName,
        createdDate: createdDate.present ? createdDate.value : this.createdDate,
        synced: synced.present ? synced.value : this.synced,
      );
  @override
  String toString() {
    return (StringBuffer('Ticket(')
          ..write('appTicketId: $appTicketId, ')
          ..write('salesAppId: $salesAppId, ')
          ..write('visitId: $visitId, ')
          ..write('id: $id, ')
          ..write('complaintType: $complaintType, ')
          ..write('description: $description, ')
          ..write('status: $status, ')
          ..write('subject: $subject, ')
          ..write('accountId: $accountId, ')
          ..write('appAccountId: $appAccountId, ')
          ..write('accountName: $accountName, ')
          ..write('createdDate: $createdDate, ')
          ..write('synced: $synced')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      appTicketId,
      salesAppId,
      visitId,
      id,
      complaintType,
      description,
      status,
      subject,
      accountId,
      appAccountId,
      accountName,
      createdDate,
      synced);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Ticket &&
          other.appTicketId == this.appTicketId &&
          other.salesAppId == this.salesAppId &&
          other.visitId == this.visitId &&
          other.id == this.id &&
          other.complaintType == this.complaintType &&
          other.description == this.description &&
          other.status == this.status &&
          other.subject == this.subject &&
          other.accountId == this.accountId &&
          other.appAccountId == this.appAccountId &&
          other.accountName == this.accountName &&
          other.createdDate == this.createdDate &&
          other.synced == this.synced);
}

class TicketsCompanion extends UpdateCompanion<Ticket> {
  final Value<String?> appTicketId;
  final Value<String?> salesAppId;
  final Value<String?> visitId;
  final Value<String?> id;
  final Value<String?> complaintType;
  final Value<String?> description;
  final Value<String?> status;
  final Value<String?> subject;
  final Value<String?> accountId;
  final Value<String?> appAccountId;
  final Value<String?> accountName;
  final Value<DateTime?> createdDate;
  final Value<bool?> synced;
  final Value<int> rowid;
  const TicketsCompanion({
    this.appTicketId = const Value.absent(),
    this.salesAppId = const Value.absent(),
    this.visitId = const Value.absent(),
    this.id = const Value.absent(),
    this.complaintType = const Value.absent(),
    this.description = const Value.absent(),
    this.status = const Value.absent(),
    this.subject = const Value.absent(),
    this.accountId = const Value.absent(),
    this.appAccountId = const Value.absent(),
    this.accountName = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  TicketsCompanion.insert({
    this.appTicketId = const Value.absent(),
    this.salesAppId = const Value.absent(),
    this.visitId = const Value.absent(),
    this.id = const Value.absent(),
    this.complaintType = const Value.absent(),
    this.description = const Value.absent(),
    this.status = const Value.absent(),
    this.subject = const Value.absent(),
    this.accountId = const Value.absent(),
    this.appAccountId = const Value.absent(),
    this.accountName = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  static Insertable<Ticket> custom({
    Expression<String>? appTicketId,
    Expression<String>? salesAppId,
    Expression<String>? visitId,
    Expression<String>? id,
    Expression<String>? complaintType,
    Expression<String>? description,
    Expression<String>? status,
    Expression<String>? subject,
    Expression<String>? accountId,
    Expression<String>? appAccountId,
    Expression<String>? accountName,
    Expression<DateTime>? createdDate,
    Expression<bool>? synced,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (appTicketId != null) 'app_ticket_id': appTicketId,
      if (salesAppId != null) 'sales_app_id': salesAppId,
      if (visitId != null) 'visit_id': visitId,
      if (id != null) 'id': id,
      if (complaintType != null) 'complaint_type': complaintType,
      if (description != null) 'description': description,
      if (status != null) 'status': status,
      if (subject != null) 'subject': subject,
      if (accountId != null) 'account_id': accountId,
      if (appAccountId != null) 'app_account_id': appAccountId,
      if (accountName != null) 'account_name': accountName,
      if (createdDate != null) 'created_date': createdDate,
      if (synced != null) 'synced': synced,
      if (rowid != null) 'rowid': rowid,
    });
  }

  TicketsCompanion copyWith(
      {Value<String?>? appTicketId,
      Value<String?>? salesAppId,
      Value<String?>? visitId,
      Value<String?>? id,
      Value<String?>? complaintType,
      Value<String?>? description,
      Value<String?>? status,
      Value<String?>? subject,
      Value<String?>? accountId,
      Value<String?>? appAccountId,
      Value<String?>? accountName,
      Value<DateTime?>? createdDate,
      Value<bool?>? synced,
      Value<int>? rowid}) {
    return TicketsCompanion(
      appTicketId: appTicketId ?? this.appTicketId,
      salesAppId: salesAppId ?? this.salesAppId,
      visitId: visitId ?? this.visitId,
      id: id ?? this.id,
      complaintType: complaintType ?? this.complaintType,
      description: description ?? this.description,
      status: status ?? this.status,
      subject: subject ?? this.subject,
      accountId: accountId ?? this.accountId,
      appAccountId: appAccountId ?? this.appAccountId,
      accountName: accountName ?? this.accountName,
      createdDate: createdDate ?? this.createdDate,
      synced: synced ?? this.synced,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (appTicketId.present) {
      map['app_ticket_id'] = Variable<String>(appTicketId.value);
    }
    if (salesAppId.present) {
      map['sales_app_id'] = Variable<String>(salesAppId.value);
    }
    if (visitId.present) {
      map['visit_id'] = Variable<String>(visitId.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (complaintType.present) {
      map['complaint_type'] = Variable<String>(complaintType.value);
    }
    if (description.present) {
      map['description'] = Variable<String>(description.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (subject.present) {
      map['subject'] = Variable<String>(subject.value);
    }
    if (accountId.present) {
      map['account_id'] = Variable<String>(accountId.value);
    }
    if (appAccountId.present) {
      map['app_account_id'] = Variable<String>(appAccountId.value);
    }
    if (accountName.present) {
      map['account_name'] = Variable<String>(accountName.value);
    }
    if (createdDate.present) {
      map['created_date'] = Variable<DateTime>(createdDate.value);
    }
    if (synced.present) {
      map['synced'] = Variable<bool>(synced.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TicketsCompanion(')
          ..write('appTicketId: $appTicketId, ')
          ..write('salesAppId: $salesAppId, ')
          ..write('visitId: $visitId, ')
          ..write('id: $id, ')
          ..write('complaintType: $complaintType, ')
          ..write('description: $description, ')
          ..write('status: $status, ')
          ..write('subject: $subject, ')
          ..write('accountId: $accountId, ')
          ..write('appAccountId: $appAccountId, ')
          ..write('accountName: $accountName, ')
          ..write('createdDate: $createdDate, ')
          ..write('synced: $synced, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $CompetitiorsTable extends Competitiors
    with TableInfo<$CompetitiorsTable, Competitior> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CompetitiorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, name];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'competitiors';
  @override
  VerificationContext validateIntegrity(Insertable<Competitior> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Competitior map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Competitior(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id']),
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name']),
    );
  }

  @override
  $CompetitiorsTable createAlias(String alias) {
    return $CompetitiorsTable(attachedDatabase, alias);
  }
}

class Competitior extends DataClass implements Insertable<Competitior> {
  final String? id;
  final String? name;
  const Competitior({this.id, this.name});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<String>(id);
    }
    if (!nullToAbsent || name != null) {
      map['name'] = Variable<String>(name);
    }
    return map;
  }

  CompetitiorsCompanion toCompanion(bool nullToAbsent) {
    return CompetitiorsCompanion(
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      name: name == null && nullToAbsent ? const Value.absent() : Value(name),
    );
  }

  factory Competitior.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Competitior(
      id: serializer.fromJson<String?>(json['id']),
      name: serializer.fromJson<String?>(json['name']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String?>(id),
      'name': serializer.toJson<String?>(name),
    };
  }

  Competitior copyWith(
          {Value<String?> id = const Value.absent(),
          Value<String?> name = const Value.absent()}) =>
      Competitior(
        id: id.present ? id.value : this.id,
        name: name.present ? name.value : this.name,
      );
  @override
  String toString() {
    return (StringBuffer('Competitior(')
          ..write('id: $id, ')
          ..write('name: $name')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, name);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Competitior && other.id == this.id && other.name == this.name);
}

class CompetitiorsCompanion extends UpdateCompanion<Competitior> {
  final Value<String?> id;
  final Value<String?> name;
  final Value<int> rowid;
  const CompetitiorsCompanion({
    this.id = const Value.absent(),
    this.name = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  CompetitiorsCompanion.insert({
    this.id = const Value.absent(),
    this.name = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  static Insertable<Competitior> custom({
    Expression<String>? id,
    Expression<String>? name,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (name != null) 'name': name,
      if (rowid != null) 'rowid': rowid,
    });
  }

  CompetitiorsCompanion copyWith(
      {Value<String?>? id, Value<String?>? name, Value<int>? rowid}) {
    return CompetitiorsCompanion(
      id: id ?? this.id,
      name: name ?? this.name,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CompetitiorsCompanion(')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $CompetitionsTable extends Competitions
    with TableInfo<$CompetitionsTable, Competition> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CompetitionsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _appCompetitionIdMeta =
      const VerificationMeta('appCompetitionId');
  @override
  late final GeneratedColumn<String> appCompetitionId = GeneratedColumn<String>(
      'app_competition_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      clientDefault: () => uuid.v6());
  static const VerificationMeta _salesAppIdMeta =
      const VerificationMeta('salesAppId');
  @override
  late final GeneratedColumn<String> salesAppId = GeneratedColumn<String>(
      'sales_app_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultConstraints: GeneratedColumn.constraintIsAlways(
          'REFERENCES visits (sales_app_id)'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _productIdMeta =
      const VerificationMeta('productId');
  @override
  late final GeneratedColumn<String> productId = GeneratedColumn<String>(
      'product_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _productNameMeta =
      const VerificationMeta('productName');
  @override
  late final GeneratedColumn<String> productName = GeneratedColumn<String>(
      'product_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _currentStockMeta =
      const VerificationMeta('currentStock');
  @override
  late final GeneratedColumn<String> currentStock = GeneratedColumn<String>(
      'current_stock', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _rateMeta = const VerificationMeta('rate');
  @override
  late final GeneratedColumn<double> rate = GeneratedColumn<double>(
      'rate', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _accountIdMeta =
      const VerificationMeta('accountId');
  @override
  late final GeneratedColumn<String> accountId = GeneratedColumn<String>(
      'account_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _accountNameMeta =
      const VerificationMeta('accountName');
  @override
  late final GeneratedColumn<String> accountName = GeneratedColumn<String>(
      'account_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _competitorIdMeta =
      const VerificationMeta('competitorId');
  @override
  late final GeneratedColumn<String> competitorId = GeneratedColumn<String>(
      'competitor_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _competitorNameMeta =
      const VerificationMeta('competitorName');
  @override
  late final GeneratedColumn<String> competitorName = GeneratedColumn<String>(
      'competitor_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _syncedMeta = const VerificationMeta('synced');
  @override
  late final GeneratedColumn<bool> synced = GeneratedColumn<bool>(
      'synced', aliasedName, true,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("synced" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        appCompetitionId,
        salesAppId,
        id,
        productId,
        productName,
        currentStock,
        rate,
        accountId,
        accountName,
        competitorId,
        competitorName,
        synced
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'competitions';
  @override
  VerificationContext validateIntegrity(Insertable<Competition> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('app_competition_id')) {
      context.handle(
          _appCompetitionIdMeta,
          appCompetitionId.isAcceptableOrUnknown(
              data['app_competition_id']!, _appCompetitionIdMeta));
    }
    if (data.containsKey('sales_app_id')) {
      context.handle(
          _salesAppIdMeta,
          salesAppId.isAcceptableOrUnknown(
              data['sales_app_id']!, _salesAppIdMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('product_id')) {
      context.handle(_productIdMeta,
          productId.isAcceptableOrUnknown(data['product_id']!, _productIdMeta));
    }
    if (data.containsKey('product_name')) {
      context.handle(
          _productNameMeta,
          productName.isAcceptableOrUnknown(
              data['product_name']!, _productNameMeta));
    }
    if (data.containsKey('current_stock')) {
      context.handle(
          _currentStockMeta,
          currentStock.isAcceptableOrUnknown(
              data['current_stock']!, _currentStockMeta));
    }
    if (data.containsKey('rate')) {
      context.handle(
          _rateMeta, rate.isAcceptableOrUnknown(data['rate']!, _rateMeta));
    }
    if (data.containsKey('account_id')) {
      context.handle(_accountIdMeta,
          accountId.isAcceptableOrUnknown(data['account_id']!, _accountIdMeta));
    }
    if (data.containsKey('account_name')) {
      context.handle(
          _accountNameMeta,
          accountName.isAcceptableOrUnknown(
              data['account_name']!, _accountNameMeta));
    }
    if (data.containsKey('competitor_id')) {
      context.handle(
          _competitorIdMeta,
          competitorId.isAcceptableOrUnknown(
              data['competitor_id']!, _competitorIdMeta));
    }
    if (data.containsKey('competitor_name')) {
      context.handle(
          _competitorNameMeta,
          competitorName.isAcceptableOrUnknown(
              data['competitor_name']!, _competitorNameMeta));
    }
    if (data.containsKey('synced')) {
      context.handle(_syncedMeta,
          synced.isAcceptableOrUnknown(data['synced']!, _syncedMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {appCompetitionId};
  @override
  Competition map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Competition(
      appCompetitionId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}app_competition_id']),
      salesAppId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sales_app_id']),
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id']),
      productId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}product_id']),
      productName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}product_name']),
      currentStock: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}current_stock']),
      rate: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}rate']),
      accountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}account_id']),
      accountName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}account_name']),
      competitorId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}competitor_id']),
      competitorName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}competitor_name']),
      synced: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}synced']),
    );
  }

  @override
  $CompetitionsTable createAlias(String alias) {
    return $CompetitionsTable(attachedDatabase, alias);
  }
}

class Competition extends DataClass implements Insertable<Competition> {
  final String? appCompetitionId;
  final String? salesAppId;
  final String? id;
  final String? productId;
  final String? productName;
  final String? currentStock;
  final double? rate;
  final String? accountId;
  final String? accountName;
  final String? competitorId;
  final String? competitorName;
  final bool? synced;
  const Competition(
      {this.appCompetitionId,
      this.salesAppId,
      this.id,
      this.productId,
      this.productName,
      this.currentStock,
      this.rate,
      this.accountId,
      this.accountName,
      this.competitorId,
      this.competitorName,
      this.synced});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || appCompetitionId != null) {
      map['app_competition_id'] = Variable<String>(appCompetitionId);
    }
    if (!nullToAbsent || salesAppId != null) {
      map['sales_app_id'] = Variable<String>(salesAppId);
    }
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<String>(id);
    }
    if (!nullToAbsent || productId != null) {
      map['product_id'] = Variable<String>(productId);
    }
    if (!nullToAbsent || productName != null) {
      map['product_name'] = Variable<String>(productName);
    }
    if (!nullToAbsent || currentStock != null) {
      map['current_stock'] = Variable<String>(currentStock);
    }
    if (!nullToAbsent || rate != null) {
      map['rate'] = Variable<double>(rate);
    }
    if (!nullToAbsent || accountId != null) {
      map['account_id'] = Variable<String>(accountId);
    }
    if (!nullToAbsent || accountName != null) {
      map['account_name'] = Variable<String>(accountName);
    }
    if (!nullToAbsent || competitorId != null) {
      map['competitor_id'] = Variable<String>(competitorId);
    }
    if (!nullToAbsent || competitorName != null) {
      map['competitor_name'] = Variable<String>(competitorName);
    }
    if (!nullToAbsent || synced != null) {
      map['synced'] = Variable<bool>(synced);
    }
    return map;
  }

  CompetitionsCompanion toCompanion(bool nullToAbsent) {
    return CompetitionsCompanion(
      appCompetitionId: appCompetitionId == null && nullToAbsent
          ? const Value.absent()
          : Value(appCompetitionId),
      salesAppId: salesAppId == null && nullToAbsent
          ? const Value.absent()
          : Value(salesAppId),
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      productId: productId == null && nullToAbsent
          ? const Value.absent()
          : Value(productId),
      productName: productName == null && nullToAbsent
          ? const Value.absent()
          : Value(productName),
      currentStock: currentStock == null && nullToAbsent
          ? const Value.absent()
          : Value(currentStock),
      rate: rate == null && nullToAbsent ? const Value.absent() : Value(rate),
      accountId: accountId == null && nullToAbsent
          ? const Value.absent()
          : Value(accountId),
      accountName: accountName == null && nullToAbsent
          ? const Value.absent()
          : Value(accountName),
      competitorId: competitorId == null && nullToAbsent
          ? const Value.absent()
          : Value(competitorId),
      competitorName: competitorName == null && nullToAbsent
          ? const Value.absent()
          : Value(competitorName),
      synced:
          synced == null && nullToAbsent ? const Value.absent() : Value(synced),
    );
  }

  factory Competition.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Competition(
      appCompetitionId: serializer.fromJson<String?>(json['appCompetitionId']),
      salesAppId: serializer.fromJson<String?>(json['salesAppId']),
      id: serializer.fromJson<String?>(json['Id']),
      productId: serializer.fromJson<String?>(json['productId']),
      productName: serializer.fromJson<String?>(json['productName']),
      currentStock: serializer.fromJson<String?>(json['currentStock']),
      rate: serializer.fromJson<double?>(json['rate']),
      accountId: serializer.fromJson<String?>(json['accountId']),
      accountName: serializer.fromJson<String?>(json['accountName']),
      competitorId: serializer.fromJson<String?>(json['competitorId']),
      competitorName: serializer.fromJson<String?>(json['competitorName']),
      synced: serializer.fromJson<bool?>(json['synced']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'appCompetitionId': serializer.toJson<String?>(appCompetitionId),
      'salesAppId': serializer.toJson<String?>(salesAppId),
      'Id': serializer.toJson<String?>(id),
      'productId': serializer.toJson<String?>(productId),
      'productName': serializer.toJson<String?>(productName),
      'currentStock': serializer.toJson<String?>(currentStock),
      'rate': serializer.toJson<double?>(rate),
      'accountId': serializer.toJson<String?>(accountId),
      'accountName': serializer.toJson<String?>(accountName),
      'competitorId': serializer.toJson<String?>(competitorId),
      'competitorName': serializer.toJson<String?>(competitorName),
      'synced': serializer.toJson<bool?>(synced),
    };
  }

  Competition copyWith(
          {Value<String?> appCompetitionId = const Value.absent(),
          Value<String?> salesAppId = const Value.absent(),
          Value<String?> id = const Value.absent(),
          Value<String?> productId = const Value.absent(),
          Value<String?> productName = const Value.absent(),
          Value<String?> currentStock = const Value.absent(),
          Value<double?> rate = const Value.absent(),
          Value<String?> accountId = const Value.absent(),
          Value<String?> accountName = const Value.absent(),
          Value<String?> competitorId = const Value.absent(),
          Value<String?> competitorName = const Value.absent(),
          Value<bool?> synced = const Value.absent()}) =>
      Competition(
        appCompetitionId: appCompetitionId.present
            ? appCompetitionId.value
            : this.appCompetitionId,
        salesAppId: salesAppId.present ? salesAppId.value : this.salesAppId,
        id: id.present ? id.value : this.id,
        productId: productId.present ? productId.value : this.productId,
        productName: productName.present ? productName.value : this.productName,
        currentStock:
            currentStock.present ? currentStock.value : this.currentStock,
        rate: rate.present ? rate.value : this.rate,
        accountId: accountId.present ? accountId.value : this.accountId,
        accountName: accountName.present ? accountName.value : this.accountName,
        competitorId:
            competitorId.present ? competitorId.value : this.competitorId,
        competitorName:
            competitorName.present ? competitorName.value : this.competitorName,
        synced: synced.present ? synced.value : this.synced,
      );
  @override
  String toString() {
    return (StringBuffer('Competition(')
          ..write('appCompetitionId: $appCompetitionId, ')
          ..write('salesAppId: $salesAppId, ')
          ..write('id: $id, ')
          ..write('productId: $productId, ')
          ..write('productName: $productName, ')
          ..write('currentStock: $currentStock, ')
          ..write('rate: $rate, ')
          ..write('accountId: $accountId, ')
          ..write('accountName: $accountName, ')
          ..write('competitorId: $competitorId, ')
          ..write('competitorName: $competitorName, ')
          ..write('synced: $synced')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      appCompetitionId,
      salesAppId,
      id,
      productId,
      productName,
      currentStock,
      rate,
      accountId,
      accountName,
      competitorId,
      competitorName,
      synced);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Competition &&
          other.appCompetitionId == this.appCompetitionId &&
          other.salesAppId == this.salesAppId &&
          other.id == this.id &&
          other.productId == this.productId &&
          other.productName == this.productName &&
          other.currentStock == this.currentStock &&
          other.rate == this.rate &&
          other.accountId == this.accountId &&
          other.accountName == this.accountName &&
          other.competitorId == this.competitorId &&
          other.competitorName == this.competitorName &&
          other.synced == this.synced);
}

class CompetitionsCompanion extends UpdateCompanion<Competition> {
  final Value<String?> appCompetitionId;
  final Value<String?> salesAppId;
  final Value<String?> id;
  final Value<String?> productId;
  final Value<String?> productName;
  final Value<String?> currentStock;
  final Value<double?> rate;
  final Value<String?> accountId;
  final Value<String?> accountName;
  final Value<String?> competitorId;
  final Value<String?> competitorName;
  final Value<bool?> synced;
  final Value<int> rowid;
  const CompetitionsCompanion({
    this.appCompetitionId = const Value.absent(),
    this.salesAppId = const Value.absent(),
    this.id = const Value.absent(),
    this.productId = const Value.absent(),
    this.productName = const Value.absent(),
    this.currentStock = const Value.absent(),
    this.rate = const Value.absent(),
    this.accountId = const Value.absent(),
    this.accountName = const Value.absent(),
    this.competitorId = const Value.absent(),
    this.competitorName = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  CompetitionsCompanion.insert({
    this.appCompetitionId = const Value.absent(),
    this.salesAppId = const Value.absent(),
    this.id = const Value.absent(),
    this.productId = const Value.absent(),
    this.productName = const Value.absent(),
    this.currentStock = const Value.absent(),
    this.rate = const Value.absent(),
    this.accountId = const Value.absent(),
    this.accountName = const Value.absent(),
    this.competitorId = const Value.absent(),
    this.competitorName = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  static Insertable<Competition> custom({
    Expression<String>? appCompetitionId,
    Expression<String>? salesAppId,
    Expression<String>? id,
    Expression<String>? productId,
    Expression<String>? productName,
    Expression<String>? currentStock,
    Expression<double>? rate,
    Expression<String>? accountId,
    Expression<String>? accountName,
    Expression<String>? competitorId,
    Expression<String>? competitorName,
    Expression<bool>? synced,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (appCompetitionId != null) 'app_competition_id': appCompetitionId,
      if (salesAppId != null) 'sales_app_id': salesAppId,
      if (id != null) 'id': id,
      if (productId != null) 'product_id': productId,
      if (productName != null) 'product_name': productName,
      if (currentStock != null) 'current_stock': currentStock,
      if (rate != null) 'rate': rate,
      if (accountId != null) 'account_id': accountId,
      if (accountName != null) 'account_name': accountName,
      if (competitorId != null) 'competitor_id': competitorId,
      if (competitorName != null) 'competitor_name': competitorName,
      if (synced != null) 'synced': synced,
      if (rowid != null) 'rowid': rowid,
    });
  }

  CompetitionsCompanion copyWith(
      {Value<String?>? appCompetitionId,
      Value<String?>? salesAppId,
      Value<String?>? id,
      Value<String?>? productId,
      Value<String?>? productName,
      Value<String?>? currentStock,
      Value<double?>? rate,
      Value<String?>? accountId,
      Value<String?>? accountName,
      Value<String?>? competitorId,
      Value<String?>? competitorName,
      Value<bool?>? synced,
      Value<int>? rowid}) {
    return CompetitionsCompanion(
      appCompetitionId: appCompetitionId ?? this.appCompetitionId,
      salesAppId: salesAppId ?? this.salesAppId,
      id: id ?? this.id,
      productId: productId ?? this.productId,
      productName: productName ?? this.productName,
      currentStock: currentStock ?? this.currentStock,
      rate: rate ?? this.rate,
      accountId: accountId ?? this.accountId,
      accountName: accountName ?? this.accountName,
      competitorId: competitorId ?? this.competitorId,
      competitorName: competitorName ?? this.competitorName,
      synced: synced ?? this.synced,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (appCompetitionId.present) {
      map['app_competition_id'] = Variable<String>(appCompetitionId.value);
    }
    if (salesAppId.present) {
      map['sales_app_id'] = Variable<String>(salesAppId.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (productId.present) {
      map['product_id'] = Variable<String>(productId.value);
    }
    if (productName.present) {
      map['product_name'] = Variable<String>(productName.value);
    }
    if (currentStock.present) {
      map['current_stock'] = Variable<String>(currentStock.value);
    }
    if (rate.present) {
      map['rate'] = Variable<double>(rate.value);
    }
    if (accountId.present) {
      map['account_id'] = Variable<String>(accountId.value);
    }
    if (accountName.present) {
      map['account_name'] = Variable<String>(accountName.value);
    }
    if (competitorId.present) {
      map['competitor_id'] = Variable<String>(competitorId.value);
    }
    if (competitorName.present) {
      map['competitor_name'] = Variable<String>(competitorName.value);
    }
    if (synced.present) {
      map['synced'] = Variable<bool>(synced.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CompetitionsCompanion(')
          ..write('appCompetitionId: $appCompetitionId, ')
          ..write('salesAppId: $salesAppId, ')
          ..write('id: $id, ')
          ..write('productId: $productId, ')
          ..write('productName: $productName, ')
          ..write('currentStock: $currentStock, ')
          ..write('rate: $rate, ')
          ..write('accountId: $accountId, ')
          ..write('accountName: $accountName, ')
          ..write('competitorId: $competitorId, ')
          ..write('competitorName: $competitorName, ')
          ..write('synced: $synced, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $AccountFilesTable extends AccountFiles
    with TableInfo<$AccountFilesTable, AccountFile> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AccountFilesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      clientDefault: () => uuid.v6());
  static const VerificationMeta _appAccountIdMeta =
      const VerificationMeta('appAccountId');
  @override
  late final GeneratedColumn<String> appAccountId = GeneratedColumn<String>(
      'app_account_id', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: true,
      defaultConstraints: GeneratedColumn.constraintIsAlways(
          'REFERENCES accounts (app_account_id)'));
  static const VerificationMeta _fileMeta = const VerificationMeta('file');
  @override
  late final GeneratedColumn<Uint8List> file = GeneratedColumn<Uint8List>(
      'file', aliasedName, false,
      type: DriftSqlType.blob, requiredDuringInsert: true);
  static const VerificationMeta _fileNameMeta =
      const VerificationMeta('fileName');
  @override
  late final GeneratedColumn<String> fileName = GeneratedColumn<String>(
      'file_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _syncedMeta = const VerificationMeta('synced');
  @override
  late final GeneratedColumn<bool> synced = GeneratedColumn<bool>(
      'synced', aliasedName, true,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("synced" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns =>
      [id, appAccountId, file, fileName, synced];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'account_files';
  @override
  VerificationContext validateIntegrity(Insertable<AccountFile> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('app_account_id')) {
      context.handle(
          _appAccountIdMeta,
          appAccountId.isAcceptableOrUnknown(
              data['app_account_id']!, _appAccountIdMeta));
    } else if (isInserting) {
      context.missing(_appAccountIdMeta);
    }
    if (data.containsKey('file')) {
      context.handle(
          _fileMeta, file.isAcceptableOrUnknown(data['file']!, _fileMeta));
    } else if (isInserting) {
      context.missing(_fileMeta);
    }
    if (data.containsKey('file_name')) {
      context.handle(_fileNameMeta,
          fileName.isAcceptableOrUnknown(data['file_name']!, _fileNameMeta));
    }
    if (data.containsKey('synced')) {
      context.handle(_syncedMeta,
          synced.isAcceptableOrUnknown(data['synced']!, _syncedMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  AccountFile map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return AccountFile(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id']),
      appAccountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_account_id'])!,
      file: attachedDatabase.typeMapping
          .read(DriftSqlType.blob, data['${effectivePrefix}file'])!,
      fileName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}file_name']),
      synced: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}synced']),
    );
  }

  @override
  $AccountFilesTable createAlias(String alias) {
    return $AccountFilesTable(attachedDatabase, alias);
  }
}

class AccountFile extends DataClass implements Insertable<AccountFile> {
  final String? id;
  final String appAccountId;
  final Uint8List file;
  final String? fileName;
  final bool? synced;
  const AccountFile(
      {this.id,
      required this.appAccountId,
      required this.file,
      this.fileName,
      this.synced});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<String>(id);
    }
    map['app_account_id'] = Variable<String>(appAccountId);
    map['file'] = Variable<Uint8List>(file);
    if (!nullToAbsent || fileName != null) {
      map['file_name'] = Variable<String>(fileName);
    }
    if (!nullToAbsent || synced != null) {
      map['synced'] = Variable<bool>(synced);
    }
    return map;
  }

  AccountFilesCompanion toCompanion(bool nullToAbsent) {
    return AccountFilesCompanion(
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      appAccountId: Value(appAccountId),
      file: Value(file),
      fileName: fileName == null && nullToAbsent
          ? const Value.absent()
          : Value(fileName),
      synced:
          synced == null && nullToAbsent ? const Value.absent() : Value(synced),
    );
  }

  factory AccountFile.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return AccountFile(
      id: serializer.fromJson<String?>(json['id']),
      appAccountId: serializer.fromJson<String>(json['appAccountId']),
      file: serializer.fromJson<Uint8List>(json['file']),
      fileName: serializer.fromJson<String?>(json['fileName']),
      synced: serializer.fromJson<bool?>(json['synced']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String?>(id),
      'appAccountId': serializer.toJson<String>(appAccountId),
      'file': serializer.toJson<Uint8List>(file),
      'fileName': serializer.toJson<String?>(fileName),
      'synced': serializer.toJson<bool?>(synced),
    };
  }

  AccountFile copyWith(
          {Value<String?> id = const Value.absent(),
          String? appAccountId,
          Uint8List? file,
          Value<String?> fileName = const Value.absent(),
          Value<bool?> synced = const Value.absent()}) =>
      AccountFile(
        id: id.present ? id.value : this.id,
        appAccountId: appAccountId ?? this.appAccountId,
        file: file ?? this.file,
        fileName: fileName.present ? fileName.value : this.fileName,
        synced: synced.present ? synced.value : this.synced,
      );
  @override
  String toString() {
    return (StringBuffer('AccountFile(')
          ..write('id: $id, ')
          ..write('appAccountId: $appAccountId, ')
          ..write('file: $file, ')
          ..write('fileName: $fileName, ')
          ..write('synced: $synced')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, appAccountId, $driftBlobEquality.hash(file), fileName, synced);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is AccountFile &&
          other.id == this.id &&
          other.appAccountId == this.appAccountId &&
          $driftBlobEquality.equals(other.file, this.file) &&
          other.fileName == this.fileName &&
          other.synced == this.synced);
}

class AccountFilesCompanion extends UpdateCompanion<AccountFile> {
  final Value<String?> id;
  final Value<String> appAccountId;
  final Value<Uint8List> file;
  final Value<String?> fileName;
  final Value<bool?> synced;
  final Value<int> rowid;
  const AccountFilesCompanion({
    this.id = const Value.absent(),
    this.appAccountId = const Value.absent(),
    this.file = const Value.absent(),
    this.fileName = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  AccountFilesCompanion.insert({
    this.id = const Value.absent(),
    required String appAccountId,
    required Uint8List file,
    this.fileName = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : appAccountId = Value(appAccountId),
        file = Value(file);
  static Insertable<AccountFile> custom({
    Expression<String>? id,
    Expression<String>? appAccountId,
    Expression<Uint8List>? file,
    Expression<String>? fileName,
    Expression<bool>? synced,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (appAccountId != null) 'app_account_id': appAccountId,
      if (file != null) 'file': file,
      if (fileName != null) 'file_name': fileName,
      if (synced != null) 'synced': synced,
      if (rowid != null) 'rowid': rowid,
    });
  }

  AccountFilesCompanion copyWith(
      {Value<String?>? id,
      Value<String>? appAccountId,
      Value<Uint8List>? file,
      Value<String?>? fileName,
      Value<bool?>? synced,
      Value<int>? rowid}) {
    return AccountFilesCompanion(
      id: id ?? this.id,
      appAccountId: appAccountId ?? this.appAccountId,
      file: file ?? this.file,
      fileName: fileName ?? this.fileName,
      synced: synced ?? this.synced,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (appAccountId.present) {
      map['app_account_id'] = Variable<String>(appAccountId.value);
    }
    if (file.present) {
      map['file'] = Variable<Uint8List>(file.value);
    }
    if (fileName.present) {
      map['file_name'] = Variable<String>(fileName.value);
    }
    if (synced.present) {
      map['synced'] = Variable<bool>(synced.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AccountFilesCompanion(')
          ..write('id: $id, ')
          ..write('appAccountId: $appAccountId, ')
          ..write('file: $file, ')
          ..write('fileName: $fileName, ')
          ..write('synced: $synced, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $PaymentFollowUpsTable extends PaymentFollowUps
    with TableInfo<$PaymentFollowUpsTable, PaymentFollowUp> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PaymentFollowUpsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _appPaymentFollowUpIdMeta =
      const VerificationMeta('appPaymentFollowUpId');
  @override
  late final GeneratedColumn<String> appPaymentFollowUpId =
      GeneratedColumn<String>('app_payment_follow_up_id', aliasedName, true,
          type: DriftSqlType.string,
          requiredDuringInsert: false,
          clientDefault: () => uuid.v6());
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _expectedPaymentDateMeta =
      const VerificationMeta('expectedPaymentDate');
  @override
  late final GeneratedColumn<DateTime> expectedPaymentDate =
      GeneratedColumn<DateTime>('expected_payment_date', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _expectedAmountMeta =
      const VerificationMeta('expectedAmount');
  @override
  late final GeneratedColumn<String> expectedAmount = GeneratedColumn<String>(
      'expected_amount', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _commentMeta =
      const VerificationMeta('comment');
  @override
  late final GeneratedColumn<String> comment = GeneratedColumn<String>(
      'comment', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _appAccountIdMeta =
      const VerificationMeta('appAccountId');
  @override
  late final GeneratedColumn<String> appAccountId = GeneratedColumn<String>(
      'app_account_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _accountIdMeta =
      const VerificationMeta('accountId');
  @override
  late final GeneratedColumn<String> accountId = GeneratedColumn<String>(
      'account_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _accountNameMeta =
      const VerificationMeta('accountName');
  @override
  late final GeneratedColumn<String> accountName = GeneratedColumn<String>(
      'account_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _visitIdMeta =
      const VerificationMeta('visitId');
  @override
  late final GeneratedColumn<String> visitId = GeneratedColumn<String>(
      'visit_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _appVisitIdMeta =
      const VerificationMeta('appVisitId');
  @override
  late final GeneratedColumn<String> appVisitId = GeneratedColumn<String>(
      'app_visit_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _syncedMeta = const VerificationMeta('synced');
  @override
  late final GeneratedColumn<bool> synced = GeneratedColumn<bool>(
      'synced', aliasedName, true,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("synced" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        appPaymentFollowUpId,
        id,
        name,
        expectedPaymentDate,
        expectedAmount,
        comment,
        appAccountId,
        accountId,
        accountName,
        visitId,
        appVisitId,
        synced
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'payment_follow_ups';
  @override
  VerificationContext validateIntegrity(Insertable<PaymentFollowUp> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('app_payment_follow_up_id')) {
      context.handle(
          _appPaymentFollowUpIdMeta,
          appPaymentFollowUpId.isAcceptableOrUnknown(
              data['app_payment_follow_up_id']!, _appPaymentFollowUpIdMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    }
    if (data.containsKey('expected_payment_date')) {
      context.handle(
          _expectedPaymentDateMeta,
          expectedPaymentDate.isAcceptableOrUnknown(
              data['expected_payment_date']!, _expectedPaymentDateMeta));
    }
    if (data.containsKey('expected_amount')) {
      context.handle(
          _expectedAmountMeta,
          expectedAmount.isAcceptableOrUnknown(
              data['expected_amount']!, _expectedAmountMeta));
    }
    if (data.containsKey('comment')) {
      context.handle(_commentMeta,
          comment.isAcceptableOrUnknown(data['comment']!, _commentMeta));
    }
    if (data.containsKey('app_account_id')) {
      context.handle(
          _appAccountIdMeta,
          appAccountId.isAcceptableOrUnknown(
              data['app_account_id']!, _appAccountIdMeta));
    }
    if (data.containsKey('account_id')) {
      context.handle(_accountIdMeta,
          accountId.isAcceptableOrUnknown(data['account_id']!, _accountIdMeta));
    }
    if (data.containsKey('account_name')) {
      context.handle(
          _accountNameMeta,
          accountName.isAcceptableOrUnknown(
              data['account_name']!, _accountNameMeta));
    }
    if (data.containsKey('visit_id')) {
      context.handle(_visitIdMeta,
          visitId.isAcceptableOrUnknown(data['visit_id']!, _visitIdMeta));
    }
    if (data.containsKey('app_visit_id')) {
      context.handle(
          _appVisitIdMeta,
          appVisitId.isAcceptableOrUnknown(
              data['app_visit_id']!, _appVisitIdMeta));
    }
    if (data.containsKey('synced')) {
      context.handle(_syncedMeta,
          synced.isAcceptableOrUnknown(data['synced']!, _syncedMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {appPaymentFollowUpId};
  @override
  PaymentFollowUp map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PaymentFollowUp(
      appPaymentFollowUpId: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}app_payment_follow_up_id']),
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id']),
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name']),
      expectedPaymentDate: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}expected_payment_date']),
      expectedAmount: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}expected_amount']),
      comment: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}comment']),
      appAccountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_account_id']),
      accountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}account_id']),
      accountName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}account_name']),
      visitId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}visit_id']),
      appVisitId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_visit_id']),
      synced: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}synced']),
    );
  }

  @override
  $PaymentFollowUpsTable createAlias(String alias) {
    return $PaymentFollowUpsTable(attachedDatabase, alias);
  }
}

class PaymentFollowUp extends DataClass implements Insertable<PaymentFollowUp> {
  final String? appPaymentFollowUpId;
  final String? id;
  final String? name;
  final DateTime? expectedPaymentDate;
  final String? expectedAmount;
  final String? comment;
  final String? appAccountId;
  final String? accountId;
  final String? accountName;
  final String? visitId;
  final String? appVisitId;
  final bool? synced;
  const PaymentFollowUp(
      {this.appPaymentFollowUpId,
      this.id,
      this.name,
      this.expectedPaymentDate,
      this.expectedAmount,
      this.comment,
      this.appAccountId,
      this.accountId,
      this.accountName,
      this.visitId,
      this.appVisitId,
      this.synced});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || appPaymentFollowUpId != null) {
      map['app_payment_follow_up_id'] = Variable<String>(appPaymentFollowUpId);
    }
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<String>(id);
    }
    if (!nullToAbsent || name != null) {
      map['name'] = Variable<String>(name);
    }
    if (!nullToAbsent || expectedPaymentDate != null) {
      map['expected_payment_date'] = Variable<DateTime>(expectedPaymentDate);
    }
    if (!nullToAbsent || expectedAmount != null) {
      map['expected_amount'] = Variable<String>(expectedAmount);
    }
    if (!nullToAbsent || comment != null) {
      map['comment'] = Variable<String>(comment);
    }
    if (!nullToAbsent || appAccountId != null) {
      map['app_account_id'] = Variable<String>(appAccountId);
    }
    if (!nullToAbsent || accountId != null) {
      map['account_id'] = Variable<String>(accountId);
    }
    if (!nullToAbsent || accountName != null) {
      map['account_name'] = Variable<String>(accountName);
    }
    if (!nullToAbsent || visitId != null) {
      map['visit_id'] = Variable<String>(visitId);
    }
    if (!nullToAbsent || appVisitId != null) {
      map['app_visit_id'] = Variable<String>(appVisitId);
    }
    if (!nullToAbsent || synced != null) {
      map['synced'] = Variable<bool>(synced);
    }
    return map;
  }

  PaymentFollowUpsCompanion toCompanion(bool nullToAbsent) {
    return PaymentFollowUpsCompanion(
      appPaymentFollowUpId: appPaymentFollowUpId == null && nullToAbsent
          ? const Value.absent()
          : Value(appPaymentFollowUpId),
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      name: name == null && nullToAbsent ? const Value.absent() : Value(name),
      expectedPaymentDate: expectedPaymentDate == null && nullToAbsent
          ? const Value.absent()
          : Value(expectedPaymentDate),
      expectedAmount: expectedAmount == null && nullToAbsent
          ? const Value.absent()
          : Value(expectedAmount),
      comment: comment == null && nullToAbsent
          ? const Value.absent()
          : Value(comment),
      appAccountId: appAccountId == null && nullToAbsent
          ? const Value.absent()
          : Value(appAccountId),
      accountId: accountId == null && nullToAbsent
          ? const Value.absent()
          : Value(accountId),
      accountName: accountName == null && nullToAbsent
          ? const Value.absent()
          : Value(accountName),
      visitId: visitId == null && nullToAbsent
          ? const Value.absent()
          : Value(visitId),
      appVisitId: appVisitId == null && nullToAbsent
          ? const Value.absent()
          : Value(appVisitId),
      synced:
          synced == null && nullToAbsent ? const Value.absent() : Value(synced),
    );
  }

  factory PaymentFollowUp.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PaymentFollowUp(
      appPaymentFollowUpId:
          serializer.fromJson<String?>(json['appPaymentFllowUpId']),
      id: serializer.fromJson<String?>(json['Id']),
      name: serializer.fromJson<String?>(json['name']),
      expectedPaymentDate:
          serializer.fromJson<DateTime?>(json['expectedPaymentdate']),
      expectedAmount: serializer.fromJson<String?>(json['expectedAmount']),
      comment: serializer.fromJson<String?>(json['comment']),
      appAccountId: serializer.fromJson<String?>(json['appAccountId']),
      accountId: serializer.fromJson<String?>(json['accountId']),
      accountName: serializer.fromJson<String?>(json['accountName']),
      visitId: serializer.fromJson<String?>(json['visitId']),
      appVisitId: serializer.fromJson<String?>(json['appVisitId']),
      synced: serializer.fromJson<bool?>(json['synced']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'appPaymentFllowUpId': serializer.toJson<String?>(appPaymentFollowUpId),
      'Id': serializer.toJson<String?>(id),
      'name': serializer.toJson<String?>(name),
      'expectedPaymentdate': serializer.toJson<DateTime?>(expectedPaymentDate),
      'expectedAmount': serializer.toJson<String?>(expectedAmount),
      'comment': serializer.toJson<String?>(comment),
      'appAccountId': serializer.toJson<String?>(appAccountId),
      'accountId': serializer.toJson<String?>(accountId),
      'accountName': serializer.toJson<String?>(accountName),
      'visitId': serializer.toJson<String?>(visitId),
      'appVisitId': serializer.toJson<String?>(appVisitId),
      'synced': serializer.toJson<bool?>(synced),
    };
  }

  PaymentFollowUp copyWith(
          {Value<String?> appPaymentFollowUpId = const Value.absent(),
          Value<String?> id = const Value.absent(),
          Value<String?> name = const Value.absent(),
          Value<DateTime?> expectedPaymentDate = const Value.absent(),
          Value<String?> expectedAmount = const Value.absent(),
          Value<String?> comment = const Value.absent(),
          Value<String?> appAccountId = const Value.absent(),
          Value<String?> accountId = const Value.absent(),
          Value<String?> accountName = const Value.absent(),
          Value<String?> visitId = const Value.absent(),
          Value<String?> appVisitId = const Value.absent(),
          Value<bool?> synced = const Value.absent()}) =>
      PaymentFollowUp(
        appPaymentFollowUpId: appPaymentFollowUpId.present
            ? appPaymentFollowUpId.value
            : this.appPaymentFollowUpId,
        id: id.present ? id.value : this.id,
        name: name.present ? name.value : this.name,
        expectedPaymentDate: expectedPaymentDate.present
            ? expectedPaymentDate.value
            : this.expectedPaymentDate,
        expectedAmount:
            expectedAmount.present ? expectedAmount.value : this.expectedAmount,
        comment: comment.present ? comment.value : this.comment,
        appAccountId:
            appAccountId.present ? appAccountId.value : this.appAccountId,
        accountId: accountId.present ? accountId.value : this.accountId,
        accountName: accountName.present ? accountName.value : this.accountName,
        visitId: visitId.present ? visitId.value : this.visitId,
        appVisitId: appVisitId.present ? appVisitId.value : this.appVisitId,
        synced: synced.present ? synced.value : this.synced,
      );
  @override
  String toString() {
    return (StringBuffer('PaymentFollowUp(')
          ..write('appPaymentFollowUpId: $appPaymentFollowUpId, ')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('expectedPaymentDate: $expectedPaymentDate, ')
          ..write('expectedAmount: $expectedAmount, ')
          ..write('comment: $comment, ')
          ..write('appAccountId: $appAccountId, ')
          ..write('accountId: $accountId, ')
          ..write('accountName: $accountName, ')
          ..write('visitId: $visitId, ')
          ..write('appVisitId: $appVisitId, ')
          ..write('synced: $synced')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      appPaymentFollowUpId,
      id,
      name,
      expectedPaymentDate,
      expectedAmount,
      comment,
      appAccountId,
      accountId,
      accountName,
      visitId,
      appVisitId,
      synced);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PaymentFollowUp &&
          other.appPaymentFollowUpId == this.appPaymentFollowUpId &&
          other.id == this.id &&
          other.name == this.name &&
          other.expectedPaymentDate == this.expectedPaymentDate &&
          other.expectedAmount == this.expectedAmount &&
          other.comment == this.comment &&
          other.appAccountId == this.appAccountId &&
          other.accountId == this.accountId &&
          other.accountName == this.accountName &&
          other.visitId == this.visitId &&
          other.appVisitId == this.appVisitId &&
          other.synced == this.synced);
}

class PaymentFollowUpsCompanion extends UpdateCompanion<PaymentFollowUp> {
  final Value<String?> appPaymentFollowUpId;
  final Value<String?> id;
  final Value<String?> name;
  final Value<DateTime?> expectedPaymentDate;
  final Value<String?> expectedAmount;
  final Value<String?> comment;
  final Value<String?> appAccountId;
  final Value<String?> accountId;
  final Value<String?> accountName;
  final Value<String?> visitId;
  final Value<String?> appVisitId;
  final Value<bool?> synced;
  final Value<int> rowid;
  const PaymentFollowUpsCompanion({
    this.appPaymentFollowUpId = const Value.absent(),
    this.id = const Value.absent(),
    this.name = const Value.absent(),
    this.expectedPaymentDate = const Value.absent(),
    this.expectedAmount = const Value.absent(),
    this.comment = const Value.absent(),
    this.appAccountId = const Value.absent(),
    this.accountId = const Value.absent(),
    this.accountName = const Value.absent(),
    this.visitId = const Value.absent(),
    this.appVisitId = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  PaymentFollowUpsCompanion.insert({
    this.appPaymentFollowUpId = const Value.absent(),
    this.id = const Value.absent(),
    this.name = const Value.absent(),
    this.expectedPaymentDate = const Value.absent(),
    this.expectedAmount = const Value.absent(),
    this.comment = const Value.absent(),
    this.appAccountId = const Value.absent(),
    this.accountId = const Value.absent(),
    this.accountName = const Value.absent(),
    this.visitId = const Value.absent(),
    this.appVisitId = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  static Insertable<PaymentFollowUp> custom({
    Expression<String>? appPaymentFollowUpId,
    Expression<String>? id,
    Expression<String>? name,
    Expression<DateTime>? expectedPaymentDate,
    Expression<String>? expectedAmount,
    Expression<String>? comment,
    Expression<String>? appAccountId,
    Expression<String>? accountId,
    Expression<String>? accountName,
    Expression<String>? visitId,
    Expression<String>? appVisitId,
    Expression<bool>? synced,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (appPaymentFollowUpId != null)
        'app_payment_follow_up_id': appPaymentFollowUpId,
      if (id != null) 'id': id,
      if (name != null) 'name': name,
      if (expectedPaymentDate != null)
        'expected_payment_date': expectedPaymentDate,
      if (expectedAmount != null) 'expected_amount': expectedAmount,
      if (comment != null) 'comment': comment,
      if (appAccountId != null) 'app_account_id': appAccountId,
      if (accountId != null) 'account_id': accountId,
      if (accountName != null) 'account_name': accountName,
      if (visitId != null) 'visit_id': visitId,
      if (appVisitId != null) 'app_visit_id': appVisitId,
      if (synced != null) 'synced': synced,
      if (rowid != null) 'rowid': rowid,
    });
  }

  PaymentFollowUpsCompanion copyWith(
      {Value<String?>? appPaymentFollowUpId,
      Value<String?>? id,
      Value<String?>? name,
      Value<DateTime?>? expectedPaymentDate,
      Value<String?>? expectedAmount,
      Value<String?>? comment,
      Value<String?>? appAccountId,
      Value<String?>? accountId,
      Value<String?>? accountName,
      Value<String?>? visitId,
      Value<String?>? appVisitId,
      Value<bool?>? synced,
      Value<int>? rowid}) {
    return PaymentFollowUpsCompanion(
      appPaymentFollowUpId: appPaymentFollowUpId ?? this.appPaymentFollowUpId,
      id: id ?? this.id,
      name: name ?? this.name,
      expectedPaymentDate: expectedPaymentDate ?? this.expectedPaymentDate,
      expectedAmount: expectedAmount ?? this.expectedAmount,
      comment: comment ?? this.comment,
      appAccountId: appAccountId ?? this.appAccountId,
      accountId: accountId ?? this.accountId,
      accountName: accountName ?? this.accountName,
      visitId: visitId ?? this.visitId,
      appVisitId: appVisitId ?? this.appVisitId,
      synced: synced ?? this.synced,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (appPaymentFollowUpId.present) {
      map['app_payment_follow_up_id'] =
          Variable<String>(appPaymentFollowUpId.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (expectedPaymentDate.present) {
      map['expected_payment_date'] =
          Variable<DateTime>(expectedPaymentDate.value);
    }
    if (expectedAmount.present) {
      map['expected_amount'] = Variable<String>(expectedAmount.value);
    }
    if (comment.present) {
      map['comment'] = Variable<String>(comment.value);
    }
    if (appAccountId.present) {
      map['app_account_id'] = Variable<String>(appAccountId.value);
    }
    if (accountId.present) {
      map['account_id'] = Variable<String>(accountId.value);
    }
    if (accountName.present) {
      map['account_name'] = Variable<String>(accountName.value);
    }
    if (visitId.present) {
      map['visit_id'] = Variable<String>(visitId.value);
    }
    if (appVisitId.present) {
      map['app_visit_id'] = Variable<String>(appVisitId.value);
    }
    if (synced.present) {
      map['synced'] = Variable<bool>(synced.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PaymentFollowUpsCompanion(')
          ..write('appPaymentFollowUpId: $appPaymentFollowUpId, ')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('expectedPaymentDate: $expectedPaymentDate, ')
          ..write('expectedAmount: $expectedAmount, ')
          ..write('comment: $comment, ')
          ..write('appAccountId: $appAccountId, ')
          ..write('accountId: $accountId, ')
          ..write('accountName: $accountName, ')
          ..write('visitId: $visitId, ')
          ..write('appVisitId: $appVisitId, ')
          ..write('synced: $synced, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $PaymentReceiptsTable extends PaymentReceipts
    with TableInfo<$PaymentReceiptsTable, PaymentReceipt> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PaymentReceiptsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _remarkMeta = const VerificationMeta('remark');
  @override
  late final GeneratedColumn<String> remark = GeneratedColumn<String>(
      'remark', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _paymentTypeMeta =
      const VerificationMeta('paymentType');
  @override
  late final GeneratedColumn<String> paymentType = GeneratedColumn<String>(
      'payment_type', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _paymentDateMeta =
      const VerificationMeta('paymentDate');
  @override
  late final GeneratedColumn<DateTime> paymentDate = GeneratedColumn<DateTime>(
      'payment_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _invoiceNameMeta =
      const VerificationMeta('invoiceName');
  @override
  late final GeneratedColumn<String> invoiceName = GeneratedColumn<String>(
      'invoice_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _checkNoMeta =
      const VerificationMeta('checkNo');
  @override
  late final GeneratedColumn<String> checkNo = GeneratedColumn<String>(
      'check_no', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _checkDateMeta =
      const VerificationMeta('checkDate');
  @override
  late final GeneratedColumn<DateTime> checkDate = GeneratedColumn<DateTime>(
      'check_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _appInvoiceIdMeta =
      const VerificationMeta('appInvoiceId');
  @override
  late final GeneratedColumn<String> appInvoiceId = GeneratedColumn<String>(
      'app_invoice_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _appAccountIdMeta =
      const VerificationMeta('appAccountId');
  @override
  late final GeneratedColumn<String> appAccountId = GeneratedColumn<String>(
      'app_account_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _amountMeta = const VerificationMeta('amount');
  @override
  late final GeneratedColumn<double> amount = GeneratedColumn<double>(
      'amount', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _accountNameMeta =
      const VerificationMeta('accountName');
  @override
  late final GeneratedColumn<String> accountName = GeneratedColumn<String>(
      'account_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _accountIdMeta =
      const VerificationMeta('accountId');
  @override
  late final GeneratedColumn<String> accountId = GeneratedColumn<String>(
      'account_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdDateMeta =
      const VerificationMeta('createdDate');
  @override
  late final GeneratedColumn<DateTime> createdDate = GeneratedColumn<DateTime>(
      'created_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        status,
        remark,
        paymentType,
        paymentDate,
        name,
        invoiceName,
        checkNo,
        checkDate,
        appInvoiceId,
        appAccountId,
        amount,
        accountName,
        accountId,
        createdDate
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'payment_receipts';
  @override
  VerificationContext validateIntegrity(Insertable<PaymentReceipt> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('remark')) {
      context.handle(_remarkMeta,
          remark.isAcceptableOrUnknown(data['remark']!, _remarkMeta));
    }
    if (data.containsKey('payment_type')) {
      context.handle(
          _paymentTypeMeta,
          paymentType.isAcceptableOrUnknown(
              data['payment_type']!, _paymentTypeMeta));
    }
    if (data.containsKey('payment_date')) {
      context.handle(
          _paymentDateMeta,
          paymentDate.isAcceptableOrUnknown(
              data['payment_date']!, _paymentDateMeta));
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    }
    if (data.containsKey('invoice_name')) {
      context.handle(
          _invoiceNameMeta,
          invoiceName.isAcceptableOrUnknown(
              data['invoice_name']!, _invoiceNameMeta));
    }
    if (data.containsKey('check_no')) {
      context.handle(_checkNoMeta,
          checkNo.isAcceptableOrUnknown(data['check_no']!, _checkNoMeta));
    }
    if (data.containsKey('check_date')) {
      context.handle(_checkDateMeta,
          checkDate.isAcceptableOrUnknown(data['check_date']!, _checkDateMeta));
    }
    if (data.containsKey('app_invoice_id')) {
      context.handle(
          _appInvoiceIdMeta,
          appInvoiceId.isAcceptableOrUnknown(
              data['app_invoice_id']!, _appInvoiceIdMeta));
    }
    if (data.containsKey('app_account_id')) {
      context.handle(
          _appAccountIdMeta,
          appAccountId.isAcceptableOrUnknown(
              data['app_account_id']!, _appAccountIdMeta));
    }
    if (data.containsKey('amount')) {
      context.handle(_amountMeta,
          amount.isAcceptableOrUnknown(data['amount']!, _amountMeta));
    }
    if (data.containsKey('account_name')) {
      context.handle(
          _accountNameMeta,
          accountName.isAcceptableOrUnknown(
              data['account_name']!, _accountNameMeta));
    }
    if (data.containsKey('account_id')) {
      context.handle(_accountIdMeta,
          accountId.isAcceptableOrUnknown(data['account_id']!, _accountIdMeta));
    }
    if (data.containsKey('created_date')) {
      context.handle(
          _createdDateMeta,
          createdDate.isAcceptableOrUnknown(
              data['created_date']!, _createdDateMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PaymentReceipt map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PaymentReceipt(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id']),
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status']),
      remark: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}remark']),
      paymentType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}payment_type']),
      paymentDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}payment_date']),
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name']),
      invoiceName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}invoice_name']),
      checkNo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}check_no']),
      checkDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}check_date']),
      appInvoiceId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_invoice_id']),
      appAccountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_account_id']),
      amount: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}amount']),
      accountName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}account_name']),
      accountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}account_id']),
      createdDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_date']),
    );
  }

  @override
  $PaymentReceiptsTable createAlias(String alias) {
    return $PaymentReceiptsTable(attachedDatabase, alias);
  }
}

class PaymentReceipt extends DataClass implements Insertable<PaymentReceipt> {
  final String? id;
  final String? status;
  final String? remark;
  final String? paymentType;
  final DateTime? paymentDate;
  final String? name;
  final String? invoiceName;
  final String? checkNo;
  final DateTime? checkDate;
  final String? appInvoiceId;
  final String? appAccountId;
  final double? amount;
  final String? accountName;
  final String? accountId;
  final DateTime? createdDate;
  const PaymentReceipt(
      {this.id,
      this.status,
      this.remark,
      this.paymentType,
      this.paymentDate,
      this.name,
      this.invoiceName,
      this.checkNo,
      this.checkDate,
      this.appInvoiceId,
      this.appAccountId,
      this.amount,
      this.accountName,
      this.accountId,
      this.createdDate});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<String>(id);
    }
    if (!nullToAbsent || status != null) {
      map['status'] = Variable<String>(status);
    }
    if (!nullToAbsent || remark != null) {
      map['remark'] = Variable<String>(remark);
    }
    if (!nullToAbsent || paymentType != null) {
      map['payment_type'] = Variable<String>(paymentType);
    }
    if (!nullToAbsent || paymentDate != null) {
      map['payment_date'] = Variable<DateTime>(paymentDate);
    }
    if (!nullToAbsent || name != null) {
      map['name'] = Variable<String>(name);
    }
    if (!nullToAbsent || invoiceName != null) {
      map['invoice_name'] = Variable<String>(invoiceName);
    }
    if (!nullToAbsent || checkNo != null) {
      map['check_no'] = Variable<String>(checkNo);
    }
    if (!nullToAbsent || checkDate != null) {
      map['check_date'] = Variable<DateTime>(checkDate);
    }
    if (!nullToAbsent || appInvoiceId != null) {
      map['app_invoice_id'] = Variable<String>(appInvoiceId);
    }
    if (!nullToAbsent || appAccountId != null) {
      map['app_account_id'] = Variable<String>(appAccountId);
    }
    if (!nullToAbsent || amount != null) {
      map['amount'] = Variable<double>(amount);
    }
    if (!nullToAbsent || accountName != null) {
      map['account_name'] = Variable<String>(accountName);
    }
    if (!nullToAbsent || accountId != null) {
      map['account_id'] = Variable<String>(accountId);
    }
    if (!nullToAbsent || createdDate != null) {
      map['created_date'] = Variable<DateTime>(createdDate);
    }
    return map;
  }

  PaymentReceiptsCompanion toCompanion(bool nullToAbsent) {
    return PaymentReceiptsCompanion(
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      status:
          status == null && nullToAbsent ? const Value.absent() : Value(status),
      remark:
          remark == null && nullToAbsent ? const Value.absent() : Value(remark),
      paymentType: paymentType == null && nullToAbsent
          ? const Value.absent()
          : Value(paymentType),
      paymentDate: paymentDate == null && nullToAbsent
          ? const Value.absent()
          : Value(paymentDate),
      name: name == null && nullToAbsent ? const Value.absent() : Value(name),
      invoiceName: invoiceName == null && nullToAbsent
          ? const Value.absent()
          : Value(invoiceName),
      checkNo: checkNo == null && nullToAbsent
          ? const Value.absent()
          : Value(checkNo),
      checkDate: checkDate == null && nullToAbsent
          ? const Value.absent()
          : Value(checkDate),
      appInvoiceId: appInvoiceId == null && nullToAbsent
          ? const Value.absent()
          : Value(appInvoiceId),
      appAccountId: appAccountId == null && nullToAbsent
          ? const Value.absent()
          : Value(appAccountId),
      amount:
          amount == null && nullToAbsent ? const Value.absent() : Value(amount),
      accountName: accountName == null && nullToAbsent
          ? const Value.absent()
          : Value(accountName),
      accountId: accountId == null && nullToAbsent
          ? const Value.absent()
          : Value(accountId),
      createdDate: createdDate == null && nullToAbsent
          ? const Value.absent()
          : Value(createdDate),
    );
  }

  factory PaymentReceipt.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PaymentReceipt(
      id: serializer.fromJson<String?>(json['Id']),
      status: serializer.fromJson<String?>(json['status']),
      remark: serializer.fromJson<String?>(json['remark']),
      paymentType: serializer.fromJson<String?>(json['paymentType']),
      paymentDate: serializer.fromJson<DateTime?>(json['paymentDate']),
      name: serializer.fromJson<String?>(json['name']),
      invoiceName: serializer.fromJson<String?>(json['invoiceName']),
      checkNo: serializer.fromJson<String?>(json['checkNo']),
      checkDate: serializer.fromJson<DateTime?>(json['checkDate']),
      appInvoiceId: serializer.fromJson<String?>(json['appInvoiceid']),
      appAccountId: serializer.fromJson<String?>(json['appAccountId']),
      amount: serializer.fromJson<double?>(json['amount']),
      accountName: serializer.fromJson<String?>(json['accountName']),
      accountId: serializer.fromJson<String?>(json['accountId']),
      createdDate: serializer.fromJson<DateTime?>(json['createdDate']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'Id': serializer.toJson<String?>(id),
      'status': serializer.toJson<String?>(status),
      'remark': serializer.toJson<String?>(remark),
      'paymentType': serializer.toJson<String?>(paymentType),
      'paymentDate': serializer.toJson<DateTime?>(paymentDate),
      'name': serializer.toJson<String?>(name),
      'invoiceName': serializer.toJson<String?>(invoiceName),
      'checkNo': serializer.toJson<String?>(checkNo),
      'checkDate': serializer.toJson<DateTime?>(checkDate),
      'appInvoiceid': serializer.toJson<String?>(appInvoiceId),
      'appAccountId': serializer.toJson<String?>(appAccountId),
      'amount': serializer.toJson<double?>(amount),
      'accountName': serializer.toJson<String?>(accountName),
      'accountId': serializer.toJson<String?>(accountId),
      'createdDate': serializer.toJson<DateTime?>(createdDate),
    };
  }

  PaymentReceipt copyWith(
          {Value<String?> id = const Value.absent(),
          Value<String?> status = const Value.absent(),
          Value<String?> remark = const Value.absent(),
          Value<String?> paymentType = const Value.absent(),
          Value<DateTime?> paymentDate = const Value.absent(),
          Value<String?> name = const Value.absent(),
          Value<String?> invoiceName = const Value.absent(),
          Value<String?> checkNo = const Value.absent(),
          Value<DateTime?> checkDate = const Value.absent(),
          Value<String?> appInvoiceId = const Value.absent(),
          Value<String?> appAccountId = const Value.absent(),
          Value<double?> amount = const Value.absent(),
          Value<String?> accountName = const Value.absent(),
          Value<String?> accountId = const Value.absent(),
          Value<DateTime?> createdDate = const Value.absent()}) =>
      PaymentReceipt(
        id: id.present ? id.value : this.id,
        status: status.present ? status.value : this.status,
        remark: remark.present ? remark.value : this.remark,
        paymentType: paymentType.present ? paymentType.value : this.paymentType,
        paymentDate: paymentDate.present ? paymentDate.value : this.paymentDate,
        name: name.present ? name.value : this.name,
        invoiceName: invoiceName.present ? invoiceName.value : this.invoiceName,
        checkNo: checkNo.present ? checkNo.value : this.checkNo,
        checkDate: checkDate.present ? checkDate.value : this.checkDate,
        appInvoiceId:
            appInvoiceId.present ? appInvoiceId.value : this.appInvoiceId,
        appAccountId:
            appAccountId.present ? appAccountId.value : this.appAccountId,
        amount: amount.present ? amount.value : this.amount,
        accountName: accountName.present ? accountName.value : this.accountName,
        accountId: accountId.present ? accountId.value : this.accountId,
        createdDate: createdDate.present ? createdDate.value : this.createdDate,
      );
  @override
  String toString() {
    return (StringBuffer('PaymentReceipt(')
          ..write('id: $id, ')
          ..write('status: $status, ')
          ..write('remark: $remark, ')
          ..write('paymentType: $paymentType, ')
          ..write('paymentDate: $paymentDate, ')
          ..write('name: $name, ')
          ..write('invoiceName: $invoiceName, ')
          ..write('checkNo: $checkNo, ')
          ..write('checkDate: $checkDate, ')
          ..write('appInvoiceId: $appInvoiceId, ')
          ..write('appAccountId: $appAccountId, ')
          ..write('amount: $amount, ')
          ..write('accountName: $accountName, ')
          ..write('accountId: $accountId, ')
          ..write('createdDate: $createdDate')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      status,
      remark,
      paymentType,
      paymentDate,
      name,
      invoiceName,
      checkNo,
      checkDate,
      appInvoiceId,
      appAccountId,
      amount,
      accountName,
      accountId,
      createdDate);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PaymentReceipt &&
          other.id == this.id &&
          other.status == this.status &&
          other.remark == this.remark &&
          other.paymentType == this.paymentType &&
          other.paymentDate == this.paymentDate &&
          other.name == this.name &&
          other.invoiceName == this.invoiceName &&
          other.checkNo == this.checkNo &&
          other.checkDate == this.checkDate &&
          other.appInvoiceId == this.appInvoiceId &&
          other.appAccountId == this.appAccountId &&
          other.amount == this.amount &&
          other.accountName == this.accountName &&
          other.accountId == this.accountId &&
          other.createdDate == this.createdDate);
}

class PaymentReceiptsCompanion extends UpdateCompanion<PaymentReceipt> {
  final Value<String?> id;
  final Value<String?> status;
  final Value<String?> remark;
  final Value<String?> paymentType;
  final Value<DateTime?> paymentDate;
  final Value<String?> name;
  final Value<String?> invoiceName;
  final Value<String?> checkNo;
  final Value<DateTime?> checkDate;
  final Value<String?> appInvoiceId;
  final Value<String?> appAccountId;
  final Value<double?> amount;
  final Value<String?> accountName;
  final Value<String?> accountId;
  final Value<DateTime?> createdDate;
  final Value<int> rowid;
  const PaymentReceiptsCompanion({
    this.id = const Value.absent(),
    this.status = const Value.absent(),
    this.remark = const Value.absent(),
    this.paymentType = const Value.absent(),
    this.paymentDate = const Value.absent(),
    this.name = const Value.absent(),
    this.invoiceName = const Value.absent(),
    this.checkNo = const Value.absent(),
    this.checkDate = const Value.absent(),
    this.appInvoiceId = const Value.absent(),
    this.appAccountId = const Value.absent(),
    this.amount = const Value.absent(),
    this.accountName = const Value.absent(),
    this.accountId = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  PaymentReceiptsCompanion.insert({
    this.id = const Value.absent(),
    this.status = const Value.absent(),
    this.remark = const Value.absent(),
    this.paymentType = const Value.absent(),
    this.paymentDate = const Value.absent(),
    this.name = const Value.absent(),
    this.invoiceName = const Value.absent(),
    this.checkNo = const Value.absent(),
    this.checkDate = const Value.absent(),
    this.appInvoiceId = const Value.absent(),
    this.appAccountId = const Value.absent(),
    this.amount = const Value.absent(),
    this.accountName = const Value.absent(),
    this.accountId = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  static Insertable<PaymentReceipt> custom({
    Expression<String>? id,
    Expression<String>? status,
    Expression<String>? remark,
    Expression<String>? paymentType,
    Expression<DateTime>? paymentDate,
    Expression<String>? name,
    Expression<String>? invoiceName,
    Expression<String>? checkNo,
    Expression<DateTime>? checkDate,
    Expression<String>? appInvoiceId,
    Expression<String>? appAccountId,
    Expression<double>? amount,
    Expression<String>? accountName,
    Expression<String>? accountId,
    Expression<DateTime>? createdDate,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (status != null) 'status': status,
      if (remark != null) 'remark': remark,
      if (paymentType != null) 'payment_type': paymentType,
      if (paymentDate != null) 'payment_date': paymentDate,
      if (name != null) 'name': name,
      if (invoiceName != null) 'invoice_name': invoiceName,
      if (checkNo != null) 'check_no': checkNo,
      if (checkDate != null) 'check_date': checkDate,
      if (appInvoiceId != null) 'app_invoice_id': appInvoiceId,
      if (appAccountId != null) 'app_account_id': appAccountId,
      if (amount != null) 'amount': amount,
      if (accountName != null) 'account_name': accountName,
      if (accountId != null) 'account_id': accountId,
      if (createdDate != null) 'created_date': createdDate,
      if (rowid != null) 'rowid': rowid,
    });
  }

  PaymentReceiptsCompanion copyWith(
      {Value<String?>? id,
      Value<String?>? status,
      Value<String?>? remark,
      Value<String?>? paymentType,
      Value<DateTime?>? paymentDate,
      Value<String?>? name,
      Value<String?>? invoiceName,
      Value<String?>? checkNo,
      Value<DateTime?>? checkDate,
      Value<String?>? appInvoiceId,
      Value<String?>? appAccountId,
      Value<double?>? amount,
      Value<String?>? accountName,
      Value<String?>? accountId,
      Value<DateTime?>? createdDate,
      Value<int>? rowid}) {
    return PaymentReceiptsCompanion(
      id: id ?? this.id,
      status: status ?? this.status,
      remark: remark ?? this.remark,
      paymentType: paymentType ?? this.paymentType,
      paymentDate: paymentDate ?? this.paymentDate,
      name: name ?? this.name,
      invoiceName: invoiceName ?? this.invoiceName,
      checkNo: checkNo ?? this.checkNo,
      checkDate: checkDate ?? this.checkDate,
      appInvoiceId: appInvoiceId ?? this.appInvoiceId,
      appAccountId: appAccountId ?? this.appAccountId,
      amount: amount ?? this.amount,
      accountName: accountName ?? this.accountName,
      accountId: accountId ?? this.accountId,
      createdDate: createdDate ?? this.createdDate,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (remark.present) {
      map['remark'] = Variable<String>(remark.value);
    }
    if (paymentType.present) {
      map['payment_type'] = Variable<String>(paymentType.value);
    }
    if (paymentDate.present) {
      map['payment_date'] = Variable<DateTime>(paymentDate.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (invoiceName.present) {
      map['invoice_name'] = Variable<String>(invoiceName.value);
    }
    if (checkNo.present) {
      map['check_no'] = Variable<String>(checkNo.value);
    }
    if (checkDate.present) {
      map['check_date'] = Variable<DateTime>(checkDate.value);
    }
    if (appInvoiceId.present) {
      map['app_invoice_id'] = Variable<String>(appInvoiceId.value);
    }
    if (appAccountId.present) {
      map['app_account_id'] = Variable<String>(appAccountId.value);
    }
    if (amount.present) {
      map['amount'] = Variable<double>(amount.value);
    }
    if (accountName.present) {
      map['account_name'] = Variable<String>(accountName.value);
    }
    if (accountId.present) {
      map['account_id'] = Variable<String>(accountId.value);
    }
    if (createdDate.present) {
      map['created_date'] = Variable<DateTime>(createdDate.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PaymentReceiptsCompanion(')
          ..write('id: $id, ')
          ..write('status: $status, ')
          ..write('remark: $remark, ')
          ..write('paymentType: $paymentType, ')
          ..write('paymentDate: $paymentDate, ')
          ..write('name: $name, ')
          ..write('invoiceName: $invoiceName, ')
          ..write('checkNo: $checkNo, ')
          ..write('checkDate: $checkDate, ')
          ..write('appInvoiceId: $appInvoiceId, ')
          ..write('appAccountId: $appAccountId, ')
          ..write('amount: $amount, ')
          ..write('accountName: $accountName, ')
          ..write('accountId: $accountId, ')
          ..write('createdDate: $createdDate, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $InvoicesTable extends Invoices with TableInfo<$InvoicesTable, Invoice> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $InvoicesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _appInvoiceIdMeta =
      const VerificationMeta('appInvoiceId');
  @override
  late final GeneratedColumn<String> appInvoiceId = GeneratedColumn<String>(
      'app_invoice_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      clientDefault: () => uuid.v6());
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _totalQuantityMeta =
      const VerificationMeta('totalQuantity');
  @override
  late final GeneratedColumn<int> totalQuantity = GeneratedColumn<int>(
      'total_quantity', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _totalAmountMeta =
      const VerificationMeta('totalAmount');
  @override
  late final GeneratedColumn<double> totalAmount = GeneratedColumn<double>(
      'total_amount', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _grandTotalMeta =
      const VerificationMeta('grandTotal');
  @override
  late final GeneratedColumn<double> grandTotal = GeneratedColumn<double>(
      'grand_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _balanceMeta =
      const VerificationMeta('balance');
  @override
  late final GeneratedColumn<double> balance = GeneratedColumn<double>(
      'balance', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _invoiceDateMeta =
      const VerificationMeta('invoiceDate');
  @override
  late final GeneratedColumn<DateTime> invoiceDate = GeneratedColumn<DateTime>(
      'invoice_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dueDateMeta =
      const VerificationMeta('dueDate');
  @override
  late final GeneratedColumn<DateTime> dueDate = GeneratedColumn<DateTime>(
      'due_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _accountNameMeta =
      const VerificationMeta('accountName');
  @override
  late final GeneratedColumn<String> accountName = GeneratedColumn<String>(
      'account_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _accountIdMeta =
      const VerificationMeta('accountId');
  @override
  late final GeneratedColumn<String> accountId = GeneratedColumn<String>(
      'account_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdDateMeta =
      const VerificationMeta('createdDate');
  @override
  late final GeneratedColumn<DateTime> createdDate = GeneratedColumn<DateTime>(
      'created_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        appInvoiceId,
        name,
        status,
        totalQuantity,
        totalAmount,
        grandTotal,
        balance,
        invoiceDate,
        dueDate,
        accountName,
        accountId,
        createdDate
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'invoices';
  @override
  VerificationContext validateIntegrity(Insertable<Invoice> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('app_invoice_id')) {
      context.handle(
          _appInvoiceIdMeta,
          appInvoiceId.isAcceptableOrUnknown(
              data['app_invoice_id']!, _appInvoiceIdMeta));
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('total_quantity')) {
      context.handle(
          _totalQuantityMeta,
          totalQuantity.isAcceptableOrUnknown(
              data['total_quantity']!, _totalQuantityMeta));
    }
    if (data.containsKey('total_amount')) {
      context.handle(
          _totalAmountMeta,
          totalAmount.isAcceptableOrUnknown(
              data['total_amount']!, _totalAmountMeta));
    }
    if (data.containsKey('grand_total')) {
      context.handle(
          _grandTotalMeta,
          grandTotal.isAcceptableOrUnknown(
              data['grand_total']!, _grandTotalMeta));
    }
    if (data.containsKey('balance')) {
      context.handle(_balanceMeta,
          balance.isAcceptableOrUnknown(data['balance']!, _balanceMeta));
    }
    if (data.containsKey('invoice_date')) {
      context.handle(
          _invoiceDateMeta,
          invoiceDate.isAcceptableOrUnknown(
              data['invoice_date']!, _invoiceDateMeta));
    }
    if (data.containsKey('due_date')) {
      context.handle(_dueDateMeta,
          dueDate.isAcceptableOrUnknown(data['due_date']!, _dueDateMeta));
    }
    if (data.containsKey('account_name')) {
      context.handle(
          _accountNameMeta,
          accountName.isAcceptableOrUnknown(
              data['account_name']!, _accountNameMeta));
    }
    if (data.containsKey('account_id')) {
      context.handle(_accountIdMeta,
          accountId.isAcceptableOrUnknown(data['account_id']!, _accountIdMeta));
    }
    if (data.containsKey('created_date')) {
      context.handle(
          _createdDateMeta,
          createdDate.isAcceptableOrUnknown(
              data['created_date']!, _createdDateMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {appInvoiceId};
  @override
  Invoice map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Invoice(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id']),
      appInvoiceId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_invoice_id']),
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name']),
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status']),
      totalQuantity: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}total_quantity']),
      totalAmount: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}total_amount']),
      grandTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}grand_total']),
      balance: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}balance']),
      invoiceDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}invoice_date']),
      dueDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}due_date']),
      accountName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}account_name']),
      accountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}account_id']),
      createdDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_date']),
    );
  }

  @override
  $InvoicesTable createAlias(String alias) {
    return $InvoicesTable(attachedDatabase, alias);
  }
}

class Invoice extends DataClass implements Insertable<Invoice> {
  final String? id;
  final String? appInvoiceId;
  final String? name;
  final String? status;
  final int? totalQuantity;
  final double? totalAmount;
  final double? grandTotal;
  final double? balance;
  final DateTime? invoiceDate;
  final DateTime? dueDate;
  final String? accountName;
  final String? accountId;
  final DateTime? createdDate;
  const Invoice(
      {this.id,
      this.appInvoiceId,
      this.name,
      this.status,
      this.totalQuantity,
      this.totalAmount,
      this.grandTotal,
      this.balance,
      this.invoiceDate,
      this.dueDate,
      this.accountName,
      this.accountId,
      this.createdDate});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<String>(id);
    }
    if (!nullToAbsent || appInvoiceId != null) {
      map['app_invoice_id'] = Variable<String>(appInvoiceId);
    }
    if (!nullToAbsent || name != null) {
      map['name'] = Variable<String>(name);
    }
    if (!nullToAbsent || status != null) {
      map['status'] = Variable<String>(status);
    }
    if (!nullToAbsent || totalQuantity != null) {
      map['total_quantity'] = Variable<int>(totalQuantity);
    }
    if (!nullToAbsent || totalAmount != null) {
      map['total_amount'] = Variable<double>(totalAmount);
    }
    if (!nullToAbsent || grandTotal != null) {
      map['grand_total'] = Variable<double>(grandTotal);
    }
    if (!nullToAbsent || balance != null) {
      map['balance'] = Variable<double>(balance);
    }
    if (!nullToAbsent || invoiceDate != null) {
      map['invoice_date'] = Variable<DateTime>(invoiceDate);
    }
    if (!nullToAbsent || dueDate != null) {
      map['due_date'] = Variable<DateTime>(dueDate);
    }
    if (!nullToAbsent || accountName != null) {
      map['account_name'] = Variable<String>(accountName);
    }
    if (!nullToAbsent || accountId != null) {
      map['account_id'] = Variable<String>(accountId);
    }
    if (!nullToAbsent || createdDate != null) {
      map['created_date'] = Variable<DateTime>(createdDate);
    }
    return map;
  }

  InvoicesCompanion toCompanion(bool nullToAbsent) {
    return InvoicesCompanion(
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      appInvoiceId: appInvoiceId == null && nullToAbsent
          ? const Value.absent()
          : Value(appInvoiceId),
      name: name == null && nullToAbsent ? const Value.absent() : Value(name),
      status:
          status == null && nullToAbsent ? const Value.absent() : Value(status),
      totalQuantity: totalQuantity == null && nullToAbsent
          ? const Value.absent()
          : Value(totalQuantity),
      totalAmount: totalAmount == null && nullToAbsent
          ? const Value.absent()
          : Value(totalAmount),
      grandTotal: grandTotal == null && nullToAbsent
          ? const Value.absent()
          : Value(grandTotal),
      balance: balance == null && nullToAbsent
          ? const Value.absent()
          : Value(balance),
      invoiceDate: invoiceDate == null && nullToAbsent
          ? const Value.absent()
          : Value(invoiceDate),
      dueDate: dueDate == null && nullToAbsent
          ? const Value.absent()
          : Value(dueDate),
      accountName: accountName == null && nullToAbsent
          ? const Value.absent()
          : Value(accountName),
      accountId: accountId == null && nullToAbsent
          ? const Value.absent()
          : Value(accountId),
      createdDate: createdDate == null && nullToAbsent
          ? const Value.absent()
          : Value(createdDate),
    );
  }

  factory Invoice.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Invoice(
      id: serializer.fromJson<String?>(json['id']),
      appInvoiceId: serializer.fromJson<String?>(json['appInvoiceId']),
      name: serializer.fromJson<String?>(json['Name']),
      status: serializer.fromJson<String?>(json['status']),
      totalQuantity: serializer.fromJson<int?>(json['totalQuantity']),
      totalAmount: serializer.fromJson<double?>(json['totalAmount']),
      grandTotal: serializer.fromJson<double?>(json['grandTotal']),
      balance: serializer.fromJson<double?>(json['balance']),
      invoiceDate: serializer.fromJson<DateTime?>(json['invoiceDate']),
      dueDate: serializer.fromJson<DateTime?>(json['dueDate']),
      accountName: serializer.fromJson<String?>(json['accountName']),
      accountId: serializer.fromJson<String?>(json['accountId']),
      createdDate: serializer.fromJson<DateTime?>(json['createdDate']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String?>(id),
      'appInvoiceId': serializer.toJson<String?>(appInvoiceId),
      'Name': serializer.toJson<String?>(name),
      'status': serializer.toJson<String?>(status),
      'totalQuantity': serializer.toJson<int?>(totalQuantity),
      'totalAmount': serializer.toJson<double?>(totalAmount),
      'grandTotal': serializer.toJson<double?>(grandTotal),
      'balance': serializer.toJson<double?>(balance),
      'invoiceDate': serializer.toJson<DateTime?>(invoiceDate),
      'dueDate': serializer.toJson<DateTime?>(dueDate),
      'accountName': serializer.toJson<String?>(accountName),
      'accountId': serializer.toJson<String?>(accountId),
      'createdDate': serializer.toJson<DateTime?>(createdDate),
    };
  }

  Invoice copyWith(
          {Value<String?> id = const Value.absent(),
          Value<String?> appInvoiceId = const Value.absent(),
          Value<String?> name = const Value.absent(),
          Value<String?> status = const Value.absent(),
          Value<int?> totalQuantity = const Value.absent(),
          Value<double?> totalAmount = const Value.absent(),
          Value<double?> grandTotal = const Value.absent(),
          Value<double?> balance = const Value.absent(),
          Value<DateTime?> invoiceDate = const Value.absent(),
          Value<DateTime?> dueDate = const Value.absent(),
          Value<String?> accountName = const Value.absent(),
          Value<String?> accountId = const Value.absent(),
          Value<DateTime?> createdDate = const Value.absent()}) =>
      Invoice(
        id: id.present ? id.value : this.id,
        appInvoiceId:
            appInvoiceId.present ? appInvoiceId.value : this.appInvoiceId,
        name: name.present ? name.value : this.name,
        status: status.present ? status.value : this.status,
        totalQuantity:
            totalQuantity.present ? totalQuantity.value : this.totalQuantity,
        totalAmount: totalAmount.present ? totalAmount.value : this.totalAmount,
        grandTotal: grandTotal.present ? grandTotal.value : this.grandTotal,
        balance: balance.present ? balance.value : this.balance,
        invoiceDate: invoiceDate.present ? invoiceDate.value : this.invoiceDate,
        dueDate: dueDate.present ? dueDate.value : this.dueDate,
        accountName: accountName.present ? accountName.value : this.accountName,
        accountId: accountId.present ? accountId.value : this.accountId,
        createdDate: createdDate.present ? createdDate.value : this.createdDate,
      );
  @override
  String toString() {
    return (StringBuffer('Invoice(')
          ..write('id: $id, ')
          ..write('appInvoiceId: $appInvoiceId, ')
          ..write('name: $name, ')
          ..write('status: $status, ')
          ..write('totalQuantity: $totalQuantity, ')
          ..write('totalAmount: $totalAmount, ')
          ..write('grandTotal: $grandTotal, ')
          ..write('balance: $balance, ')
          ..write('invoiceDate: $invoiceDate, ')
          ..write('dueDate: $dueDate, ')
          ..write('accountName: $accountName, ')
          ..write('accountId: $accountId, ')
          ..write('createdDate: $createdDate')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      appInvoiceId,
      name,
      status,
      totalQuantity,
      totalAmount,
      grandTotal,
      balance,
      invoiceDate,
      dueDate,
      accountName,
      accountId,
      createdDate);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Invoice &&
          other.id == this.id &&
          other.appInvoiceId == this.appInvoiceId &&
          other.name == this.name &&
          other.status == this.status &&
          other.totalQuantity == this.totalQuantity &&
          other.totalAmount == this.totalAmount &&
          other.grandTotal == this.grandTotal &&
          other.balance == this.balance &&
          other.invoiceDate == this.invoiceDate &&
          other.dueDate == this.dueDate &&
          other.accountName == this.accountName &&
          other.accountId == this.accountId &&
          other.createdDate == this.createdDate);
}

class InvoicesCompanion extends UpdateCompanion<Invoice> {
  final Value<String?> id;
  final Value<String?> appInvoiceId;
  final Value<String?> name;
  final Value<String?> status;
  final Value<int?> totalQuantity;
  final Value<double?> totalAmount;
  final Value<double?> grandTotal;
  final Value<double?> balance;
  final Value<DateTime?> invoiceDate;
  final Value<DateTime?> dueDate;
  final Value<String?> accountName;
  final Value<String?> accountId;
  final Value<DateTime?> createdDate;
  final Value<int> rowid;
  const InvoicesCompanion({
    this.id = const Value.absent(),
    this.appInvoiceId = const Value.absent(),
    this.name = const Value.absent(),
    this.status = const Value.absent(),
    this.totalQuantity = const Value.absent(),
    this.totalAmount = const Value.absent(),
    this.grandTotal = const Value.absent(),
    this.balance = const Value.absent(),
    this.invoiceDate = const Value.absent(),
    this.dueDate = const Value.absent(),
    this.accountName = const Value.absent(),
    this.accountId = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  InvoicesCompanion.insert({
    this.id = const Value.absent(),
    this.appInvoiceId = const Value.absent(),
    this.name = const Value.absent(),
    this.status = const Value.absent(),
    this.totalQuantity = const Value.absent(),
    this.totalAmount = const Value.absent(),
    this.grandTotal = const Value.absent(),
    this.balance = const Value.absent(),
    this.invoiceDate = const Value.absent(),
    this.dueDate = const Value.absent(),
    this.accountName = const Value.absent(),
    this.accountId = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  static Insertable<Invoice> custom({
    Expression<String>? id,
    Expression<String>? appInvoiceId,
    Expression<String>? name,
    Expression<String>? status,
    Expression<int>? totalQuantity,
    Expression<double>? totalAmount,
    Expression<double>? grandTotal,
    Expression<double>? balance,
    Expression<DateTime>? invoiceDate,
    Expression<DateTime>? dueDate,
    Expression<String>? accountName,
    Expression<String>? accountId,
    Expression<DateTime>? createdDate,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (appInvoiceId != null) 'app_invoice_id': appInvoiceId,
      if (name != null) 'name': name,
      if (status != null) 'status': status,
      if (totalQuantity != null) 'total_quantity': totalQuantity,
      if (totalAmount != null) 'total_amount': totalAmount,
      if (grandTotal != null) 'grand_total': grandTotal,
      if (balance != null) 'balance': balance,
      if (invoiceDate != null) 'invoice_date': invoiceDate,
      if (dueDate != null) 'due_date': dueDate,
      if (accountName != null) 'account_name': accountName,
      if (accountId != null) 'account_id': accountId,
      if (createdDate != null) 'created_date': createdDate,
      if (rowid != null) 'rowid': rowid,
    });
  }

  InvoicesCompanion copyWith(
      {Value<String?>? id,
      Value<String?>? appInvoiceId,
      Value<String?>? name,
      Value<String?>? status,
      Value<int?>? totalQuantity,
      Value<double?>? totalAmount,
      Value<double?>? grandTotal,
      Value<double?>? balance,
      Value<DateTime?>? invoiceDate,
      Value<DateTime?>? dueDate,
      Value<String?>? accountName,
      Value<String?>? accountId,
      Value<DateTime?>? createdDate,
      Value<int>? rowid}) {
    return InvoicesCompanion(
      id: id ?? this.id,
      appInvoiceId: appInvoiceId ?? this.appInvoiceId,
      name: name ?? this.name,
      status: status ?? this.status,
      totalQuantity: totalQuantity ?? this.totalQuantity,
      totalAmount: totalAmount ?? this.totalAmount,
      grandTotal: grandTotal ?? this.grandTotal,
      balance: balance ?? this.balance,
      invoiceDate: invoiceDate ?? this.invoiceDate,
      dueDate: dueDate ?? this.dueDate,
      accountName: accountName ?? this.accountName,
      accountId: accountId ?? this.accountId,
      createdDate: createdDate ?? this.createdDate,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (appInvoiceId.present) {
      map['app_invoice_id'] = Variable<String>(appInvoiceId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (totalQuantity.present) {
      map['total_quantity'] = Variable<int>(totalQuantity.value);
    }
    if (totalAmount.present) {
      map['total_amount'] = Variable<double>(totalAmount.value);
    }
    if (grandTotal.present) {
      map['grand_total'] = Variable<double>(grandTotal.value);
    }
    if (balance.present) {
      map['balance'] = Variable<double>(balance.value);
    }
    if (invoiceDate.present) {
      map['invoice_date'] = Variable<DateTime>(invoiceDate.value);
    }
    if (dueDate.present) {
      map['due_date'] = Variable<DateTime>(dueDate.value);
    }
    if (accountName.present) {
      map['account_name'] = Variable<String>(accountName.value);
    }
    if (accountId.present) {
      map['account_id'] = Variable<String>(accountId.value);
    }
    if (createdDate.present) {
      map['created_date'] = Variable<DateTime>(createdDate.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('InvoicesCompanion(')
          ..write('id: $id, ')
          ..write('appInvoiceId: $appInvoiceId, ')
          ..write('name: $name, ')
          ..write('status: $status, ')
          ..write('totalQuantity: $totalQuantity, ')
          ..write('totalAmount: $totalAmount, ')
          ..write('grandTotal: $grandTotal, ')
          ..write('balance: $balance, ')
          ..write('invoiceDate: $invoiceDate, ')
          ..write('dueDate: $dueDate, ')
          ..write('accountName: $accountName, ')
          ..write('accountId: $accountId, ')
          ..write('createdDate: $createdDate, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $InvoiceItemsTable extends InvoiceItems
    with TableInfo<$InvoiceItemsTable, InvoiceItem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $InvoiceItemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _appInvoiceIdMeta =
      const VerificationMeta('appInvoiceId');
  @override
  late final GeneratedColumn<String> appInvoiceId = GeneratedColumn<String>(
      'app_invoice_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _productIdMeta =
      const VerificationMeta('productId');
  @override
  late final GeneratedColumn<String> productId = GeneratedColumn<String>(
      'product_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _productNameMeta =
      const VerificationMeta('productName');
  @override
  late final GeneratedColumn<String> productName = GeneratedColumn<String>(
      'product_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _quantityMeta =
      const VerificationMeta('quantity');
  @override
  late final GeneratedColumn<int> quantity = GeneratedColumn<int>(
      'quantity', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _unitPriceMeta =
      const VerificationMeta('unitPrice');
  @override
  late final GeneratedColumn<double> unitPrice = GeneratedColumn<double>(
      'unit_price', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxPercentMeta =
      const VerificationMeta('taxPercent');
  @override
  late final GeneratedColumn<double> taxPercent = GeneratedColumn<double>(
      'tax_percent', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxAmountMeta =
      const VerificationMeta('taxAmount');
  @override
  late final GeneratedColumn<double> taxAmount = GeneratedColumn<double>(
      'tax_amount', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _totalAmountMeta =
      const VerificationMeta('totalAmount');
  @override
  late final GeneratedColumn<double> totalAmount = GeneratedColumn<double>(
      'total_amount', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _totalTaxMeta =
      const VerificationMeta('totalTax');
  @override
  late final GeneratedColumn<double> totalTax = GeneratedColumn<double>(
      'total_tax', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _grandTotalMeta =
      const VerificationMeta('grandTotal');
  @override
  late final GeneratedColumn<double> grandTotal = GeneratedColumn<double>(
      'grand_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        appInvoiceId,
        productId,
        productName,
        quantity,
        unitPrice,
        taxPercent,
        taxAmount,
        totalAmount,
        totalTax,
        grandTotal
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'invoice_items';
  @override
  VerificationContext validateIntegrity(Insertable<InvoiceItem> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('app_invoice_id')) {
      context.handle(
          _appInvoiceIdMeta,
          appInvoiceId.isAcceptableOrUnknown(
              data['app_invoice_id']!, _appInvoiceIdMeta));
    }
    if (data.containsKey('product_id')) {
      context.handle(_productIdMeta,
          productId.isAcceptableOrUnknown(data['product_id']!, _productIdMeta));
    }
    if (data.containsKey('product_name')) {
      context.handle(
          _productNameMeta,
          productName.isAcceptableOrUnknown(
              data['product_name']!, _productNameMeta));
    }
    if (data.containsKey('quantity')) {
      context.handle(_quantityMeta,
          quantity.isAcceptableOrUnknown(data['quantity']!, _quantityMeta));
    }
    if (data.containsKey('unit_price')) {
      context.handle(_unitPriceMeta,
          unitPrice.isAcceptableOrUnknown(data['unit_price']!, _unitPriceMeta));
    }
    if (data.containsKey('tax_percent')) {
      context.handle(
          _taxPercentMeta,
          taxPercent.isAcceptableOrUnknown(
              data['tax_percent']!, _taxPercentMeta));
    }
    if (data.containsKey('tax_amount')) {
      context.handle(_taxAmountMeta,
          taxAmount.isAcceptableOrUnknown(data['tax_amount']!, _taxAmountMeta));
    }
    if (data.containsKey('total_amount')) {
      context.handle(
          _totalAmountMeta,
          totalAmount.isAcceptableOrUnknown(
              data['total_amount']!, _totalAmountMeta));
    }
    if (data.containsKey('total_tax')) {
      context.handle(_totalTaxMeta,
          totalTax.isAcceptableOrUnknown(data['total_tax']!, _totalTaxMeta));
    }
    if (data.containsKey('grand_total')) {
      context.handle(
          _grandTotalMeta,
          grandTotal.isAcceptableOrUnknown(
              data['grand_total']!, _grandTotalMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  InvoiceItem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return InvoiceItem(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      appInvoiceId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_invoice_id']),
      productId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}product_id']),
      productName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}product_name']),
      quantity: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}quantity']),
      unitPrice: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}unit_price']),
      taxPercent: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}tax_percent']),
      taxAmount: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}tax_amount']),
      totalAmount: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}total_amount']),
      totalTax: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}total_tax']),
      grandTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}grand_total']),
    );
  }

  @override
  $InvoiceItemsTable createAlias(String alias) {
    return $InvoiceItemsTable(attachedDatabase, alias);
  }
}

class InvoiceItem extends DataClass implements Insertable<InvoiceItem> {
  final int? id;
  final String? appInvoiceId;
  final String? productId;
  final String? productName;
  final int? quantity;
  final double? unitPrice;
  final double? taxPercent;
  final double? taxAmount;
  final double? totalAmount;
  final double? totalTax;
  final double? grandTotal;
  const InvoiceItem(
      {this.id,
      this.appInvoiceId,
      this.productId,
      this.productName,
      this.quantity,
      this.unitPrice,
      this.taxPercent,
      this.taxAmount,
      this.totalAmount,
      this.totalTax,
      this.grandTotal});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || appInvoiceId != null) {
      map['app_invoice_id'] = Variable<String>(appInvoiceId);
    }
    if (!nullToAbsent || productId != null) {
      map['product_id'] = Variable<String>(productId);
    }
    if (!nullToAbsent || productName != null) {
      map['product_name'] = Variable<String>(productName);
    }
    if (!nullToAbsent || quantity != null) {
      map['quantity'] = Variable<int>(quantity);
    }
    if (!nullToAbsent || unitPrice != null) {
      map['unit_price'] = Variable<double>(unitPrice);
    }
    if (!nullToAbsent || taxPercent != null) {
      map['tax_percent'] = Variable<double>(taxPercent);
    }
    if (!nullToAbsent || taxAmount != null) {
      map['tax_amount'] = Variable<double>(taxAmount);
    }
    if (!nullToAbsent || totalAmount != null) {
      map['total_amount'] = Variable<double>(totalAmount);
    }
    if (!nullToAbsent || totalTax != null) {
      map['total_tax'] = Variable<double>(totalTax);
    }
    if (!nullToAbsent || grandTotal != null) {
      map['grand_total'] = Variable<double>(grandTotal);
    }
    return map;
  }

  InvoiceItemsCompanion toCompanion(bool nullToAbsent) {
    return InvoiceItemsCompanion(
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      appInvoiceId: appInvoiceId == null && nullToAbsent
          ? const Value.absent()
          : Value(appInvoiceId),
      productId: productId == null && nullToAbsent
          ? const Value.absent()
          : Value(productId),
      productName: productName == null && nullToAbsent
          ? const Value.absent()
          : Value(productName),
      quantity: quantity == null && nullToAbsent
          ? const Value.absent()
          : Value(quantity),
      unitPrice: unitPrice == null && nullToAbsent
          ? const Value.absent()
          : Value(unitPrice),
      taxPercent: taxPercent == null && nullToAbsent
          ? const Value.absent()
          : Value(taxPercent),
      taxAmount: taxAmount == null && nullToAbsent
          ? const Value.absent()
          : Value(taxAmount),
      totalAmount: totalAmount == null && nullToAbsent
          ? const Value.absent()
          : Value(totalAmount),
      totalTax: totalTax == null && nullToAbsent
          ? const Value.absent()
          : Value(totalTax),
      grandTotal: grandTotal == null && nullToAbsent
          ? const Value.absent()
          : Value(grandTotal),
    );
  }

  factory InvoiceItem.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return InvoiceItem(
      id: serializer.fromJson<int?>(json['id']),
      appInvoiceId: serializer.fromJson<String?>(json['appInvoiceId']),
      productId: serializer.fromJson<String?>(json['productId']),
      productName: serializer.fromJson<String?>(json['productName']),
      quantity: serializer.fromJson<int?>(json['quantity']),
      unitPrice: serializer.fromJson<double?>(json['unitPrice']),
      taxPercent: serializer.fromJson<double?>(json['taxPercent']),
      taxAmount: serializer.fromJson<double?>(json['taxAmount']),
      totalAmount: serializer.fromJson<double?>(json['totalAmount']),
      totalTax: serializer.fromJson<double?>(json['totalTax']),
      grandTotal: serializer.fromJson<double?>(json['grandTotal']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'appInvoiceId': serializer.toJson<String?>(appInvoiceId),
      'productId': serializer.toJson<String?>(productId),
      'productName': serializer.toJson<String?>(productName),
      'quantity': serializer.toJson<int?>(quantity),
      'unitPrice': serializer.toJson<double?>(unitPrice),
      'taxPercent': serializer.toJson<double?>(taxPercent),
      'taxAmount': serializer.toJson<double?>(taxAmount),
      'totalAmount': serializer.toJson<double?>(totalAmount),
      'totalTax': serializer.toJson<double?>(totalTax),
      'grandTotal': serializer.toJson<double?>(grandTotal),
    };
  }

  InvoiceItem copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> appInvoiceId = const Value.absent(),
          Value<String?> productId = const Value.absent(),
          Value<String?> productName = const Value.absent(),
          Value<int?> quantity = const Value.absent(),
          Value<double?> unitPrice = const Value.absent(),
          Value<double?> taxPercent = const Value.absent(),
          Value<double?> taxAmount = const Value.absent(),
          Value<double?> totalAmount = const Value.absent(),
          Value<double?> totalTax = const Value.absent(),
          Value<double?> grandTotal = const Value.absent()}) =>
      InvoiceItem(
        id: id.present ? id.value : this.id,
        appInvoiceId:
            appInvoiceId.present ? appInvoiceId.value : this.appInvoiceId,
        productId: productId.present ? productId.value : this.productId,
        productName: productName.present ? productName.value : this.productName,
        quantity: quantity.present ? quantity.value : this.quantity,
        unitPrice: unitPrice.present ? unitPrice.value : this.unitPrice,
        taxPercent: taxPercent.present ? taxPercent.value : this.taxPercent,
        taxAmount: taxAmount.present ? taxAmount.value : this.taxAmount,
        totalAmount: totalAmount.present ? totalAmount.value : this.totalAmount,
        totalTax: totalTax.present ? totalTax.value : this.totalTax,
        grandTotal: grandTotal.present ? grandTotal.value : this.grandTotal,
      );
  @override
  String toString() {
    return (StringBuffer('InvoiceItem(')
          ..write('id: $id, ')
          ..write('appInvoiceId: $appInvoiceId, ')
          ..write('productId: $productId, ')
          ..write('productName: $productName, ')
          ..write('quantity: $quantity, ')
          ..write('unitPrice: $unitPrice, ')
          ..write('taxPercent: $taxPercent, ')
          ..write('taxAmount: $taxAmount, ')
          ..write('totalAmount: $totalAmount, ')
          ..write('totalTax: $totalTax, ')
          ..write('grandTotal: $grandTotal')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      appInvoiceId,
      productId,
      productName,
      quantity,
      unitPrice,
      taxPercent,
      taxAmount,
      totalAmount,
      totalTax,
      grandTotal);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is InvoiceItem &&
          other.id == this.id &&
          other.appInvoiceId == this.appInvoiceId &&
          other.productId == this.productId &&
          other.productName == this.productName &&
          other.quantity == this.quantity &&
          other.unitPrice == this.unitPrice &&
          other.taxPercent == this.taxPercent &&
          other.taxAmount == this.taxAmount &&
          other.totalAmount == this.totalAmount &&
          other.totalTax == this.totalTax &&
          other.grandTotal == this.grandTotal);
}

class InvoiceItemsCompanion extends UpdateCompanion<InvoiceItem> {
  final Value<int?> id;
  final Value<String?> appInvoiceId;
  final Value<String?> productId;
  final Value<String?> productName;
  final Value<int?> quantity;
  final Value<double?> unitPrice;
  final Value<double?> taxPercent;
  final Value<double?> taxAmount;
  final Value<double?> totalAmount;
  final Value<double?> totalTax;
  final Value<double?> grandTotal;
  const InvoiceItemsCompanion({
    this.id = const Value.absent(),
    this.appInvoiceId = const Value.absent(),
    this.productId = const Value.absent(),
    this.productName = const Value.absent(),
    this.quantity = const Value.absent(),
    this.unitPrice = const Value.absent(),
    this.taxPercent = const Value.absent(),
    this.taxAmount = const Value.absent(),
    this.totalAmount = const Value.absent(),
    this.totalTax = const Value.absent(),
    this.grandTotal = const Value.absent(),
  });
  InvoiceItemsCompanion.insert({
    this.id = const Value.absent(),
    this.appInvoiceId = const Value.absent(),
    this.productId = const Value.absent(),
    this.productName = const Value.absent(),
    this.quantity = const Value.absent(),
    this.unitPrice = const Value.absent(),
    this.taxPercent = const Value.absent(),
    this.taxAmount = const Value.absent(),
    this.totalAmount = const Value.absent(),
    this.totalTax = const Value.absent(),
    this.grandTotal = const Value.absent(),
  });
  static Insertable<InvoiceItem> custom({
    Expression<int>? id,
    Expression<String>? appInvoiceId,
    Expression<String>? productId,
    Expression<String>? productName,
    Expression<int>? quantity,
    Expression<double>? unitPrice,
    Expression<double>? taxPercent,
    Expression<double>? taxAmount,
    Expression<double>? totalAmount,
    Expression<double>? totalTax,
    Expression<double>? grandTotal,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (appInvoiceId != null) 'app_invoice_id': appInvoiceId,
      if (productId != null) 'product_id': productId,
      if (productName != null) 'product_name': productName,
      if (quantity != null) 'quantity': quantity,
      if (unitPrice != null) 'unit_price': unitPrice,
      if (taxPercent != null) 'tax_percent': taxPercent,
      if (taxAmount != null) 'tax_amount': taxAmount,
      if (totalAmount != null) 'total_amount': totalAmount,
      if (totalTax != null) 'total_tax': totalTax,
      if (grandTotal != null) 'grand_total': grandTotal,
    });
  }

  InvoiceItemsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? appInvoiceId,
      Value<String?>? productId,
      Value<String?>? productName,
      Value<int?>? quantity,
      Value<double?>? unitPrice,
      Value<double?>? taxPercent,
      Value<double?>? taxAmount,
      Value<double?>? totalAmount,
      Value<double?>? totalTax,
      Value<double?>? grandTotal}) {
    return InvoiceItemsCompanion(
      id: id ?? this.id,
      appInvoiceId: appInvoiceId ?? this.appInvoiceId,
      productId: productId ?? this.productId,
      productName: productName ?? this.productName,
      quantity: quantity ?? this.quantity,
      unitPrice: unitPrice ?? this.unitPrice,
      taxPercent: taxPercent ?? this.taxPercent,
      taxAmount: taxAmount ?? this.taxAmount,
      totalAmount: totalAmount ?? this.totalAmount,
      totalTax: totalTax ?? this.totalTax,
      grandTotal: grandTotal ?? this.grandTotal,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (appInvoiceId.present) {
      map['app_invoice_id'] = Variable<String>(appInvoiceId.value);
    }
    if (productId.present) {
      map['product_id'] = Variable<String>(productId.value);
    }
    if (productName.present) {
      map['product_name'] = Variable<String>(productName.value);
    }
    if (quantity.present) {
      map['quantity'] = Variable<int>(quantity.value);
    }
    if (unitPrice.present) {
      map['unit_price'] = Variable<double>(unitPrice.value);
    }
    if (taxPercent.present) {
      map['tax_percent'] = Variable<double>(taxPercent.value);
    }
    if (taxAmount.present) {
      map['tax_amount'] = Variable<double>(taxAmount.value);
    }
    if (totalAmount.present) {
      map['total_amount'] = Variable<double>(totalAmount.value);
    }
    if (totalTax.present) {
      map['total_tax'] = Variable<double>(totalTax.value);
    }
    if (grandTotal.present) {
      map['grand_total'] = Variable<double>(grandTotal.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('InvoiceItemsCompanion(')
          ..write('id: $id, ')
          ..write('appInvoiceId: $appInvoiceId, ')
          ..write('productId: $productId, ')
          ..write('productName: $productName, ')
          ..write('quantity: $quantity, ')
          ..write('unitPrice: $unitPrice, ')
          ..write('taxPercent: $taxPercent, ')
          ..write('taxAmount: $taxAmount, ')
          ..write('totalAmount: $totalAmount, ')
          ..write('totalTax: $totalTax, ')
          ..write('grandTotal: $grandTotal')
          ..write(')'))
        .toString();
  }
}

class $LeavesTable extends Leaves with TableInfo<$LeavesTable, Leave> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $LeavesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _appLeaveIdMeta =
      const VerificationMeta('appLeaveId');
  @override
  late final GeneratedColumn<String> appLeaveId = GeneratedColumn<String>(
      'app_leave_id', aliasedName, true,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      clientDefault: () => uuid.v6());
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _startDateMeta =
      const VerificationMeta('startDate');
  @override
  late final GeneratedColumn<DateTime> startDate = GeneratedColumn<DateTime>(
      'start_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _endDateMeta =
      const VerificationMeta('endDate');
  @override
  late final GeneratedColumn<DateTime> endDate = GeneratedColumn<DateTime>(
      'end_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _commentsMeta =
      const VerificationMeta('comments');
  @override
  late final GeneratedColumn<String> comments = GeneratedColumn<String>(
      'comments', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _reasonMeta = const VerificationMeta('reason');
  @override
  late final GeneratedColumn<String> reason = GeneratedColumn<String>(
      'reason', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _leaveTypeMeta =
      const VerificationMeta('leaveType');
  @override
  late final GeneratedColumn<String> leaveType = GeneratedColumn<String>(
      'leave_type', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _leaveStatusMeta =
      const VerificationMeta('leaveStatus');
  @override
  late final GeneratedColumn<String> leaveStatus = GeneratedColumn<String>(
      'leave_status', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _lastModifiedDateMeta =
      const VerificationMeta('lastModifiedDate');
  @override
  late final GeneratedColumn<DateTime> lastModifiedDate =
      GeneratedColumn<DateTime>('last_modified_date', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _firstSecondMeta =
      const VerificationMeta('firstSecond');
  @override
  late final GeneratedColumn<String> firstSecond = GeneratedColumn<String>(
      'first_second', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _durationMeta =
      const VerificationMeta('duration');
  @override
  late final GeneratedColumn<String> duration = GeneratedColumn<String>(
      'duration', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _executiveNameMeta =
      const VerificationMeta('executiveName');
  @override
  late final GeneratedColumn<String> executiveName = GeneratedColumn<String>(
      'executive_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _executiveIdMeta =
      const VerificationMeta('executiveId');
  @override
  late final GeneratedColumn<String> executiveId = GeneratedColumn<String>(
      'executive_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdDateMeta =
      const VerificationMeta('createdDate');
  @override
  late final GeneratedColumn<DateTime> createdDate = GeneratedColumn<DateTime>(
      'created_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _syncedMeta = const VerificationMeta('synced');
  @override
  late final GeneratedColumn<bool> synced = GeneratedColumn<bool>(
      'synced', aliasedName, true,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("synced" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        id,
        appLeaveId,
        name,
        startDate,
        endDate,
        comments,
        reason,
        leaveType,
        leaveStatus,
        lastModifiedDate,
        firstSecond,
        duration,
        executiveName,
        executiveId,
        createdDate,
        synced
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'leaves';
  @override
  VerificationContext validateIntegrity(Insertable<Leave> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('app_leave_id')) {
      context.handle(
          _appLeaveIdMeta,
          appLeaveId.isAcceptableOrUnknown(
              data['app_leave_id']!, _appLeaveIdMeta));
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    }
    if (data.containsKey('start_date')) {
      context.handle(_startDateMeta,
          startDate.isAcceptableOrUnknown(data['start_date']!, _startDateMeta));
    }
    if (data.containsKey('end_date')) {
      context.handle(_endDateMeta,
          endDate.isAcceptableOrUnknown(data['end_date']!, _endDateMeta));
    }
    if (data.containsKey('comments')) {
      context.handle(_commentsMeta,
          comments.isAcceptableOrUnknown(data['comments']!, _commentsMeta));
    }
    if (data.containsKey('reason')) {
      context.handle(_reasonMeta,
          reason.isAcceptableOrUnknown(data['reason']!, _reasonMeta));
    }
    if (data.containsKey('leave_type')) {
      context.handle(_leaveTypeMeta,
          leaveType.isAcceptableOrUnknown(data['leave_type']!, _leaveTypeMeta));
    }
    if (data.containsKey('leave_status')) {
      context.handle(
          _leaveStatusMeta,
          leaveStatus.isAcceptableOrUnknown(
              data['leave_status']!, _leaveStatusMeta));
    }
    if (data.containsKey('last_modified_date')) {
      context.handle(
          _lastModifiedDateMeta,
          lastModifiedDate.isAcceptableOrUnknown(
              data['last_modified_date']!, _lastModifiedDateMeta));
    }
    if (data.containsKey('first_second')) {
      context.handle(
          _firstSecondMeta,
          firstSecond.isAcceptableOrUnknown(
              data['first_second']!, _firstSecondMeta));
    }
    if (data.containsKey('duration')) {
      context.handle(_durationMeta,
          duration.isAcceptableOrUnknown(data['duration']!, _durationMeta));
    }
    if (data.containsKey('executive_name')) {
      context.handle(
          _executiveNameMeta,
          executiveName.isAcceptableOrUnknown(
              data['executive_name']!, _executiveNameMeta));
    }
    if (data.containsKey('executive_id')) {
      context.handle(
          _executiveIdMeta,
          executiveId.isAcceptableOrUnknown(
              data['executive_id']!, _executiveIdMeta));
    }
    if (data.containsKey('created_date')) {
      context.handle(
          _createdDateMeta,
          createdDate.isAcceptableOrUnknown(
              data['created_date']!, _createdDateMeta));
    }
    if (data.containsKey('synced')) {
      context.handle(_syncedMeta,
          synced.isAcceptableOrUnknown(data['synced']!, _syncedMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {appLeaveId};
  @override
  Leave map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Leave(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id']),
      appLeaveId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_leave_id']),
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name']),
      startDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}start_date']),
      endDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}end_date']),
      comments: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}comments']),
      reason: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}reason']),
      leaveType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}leave_type']),
      leaveStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}leave_status']),
      lastModifiedDate: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}last_modified_date']),
      firstSecond: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}first_second']),
      duration: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}duration']),
      executiveName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}executive_name']),
      executiveId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}executive_id']),
      createdDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_date']),
      synced: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}synced']),
    );
  }

  @override
  $LeavesTable createAlias(String alias) {
    return $LeavesTable(attachedDatabase, alias);
  }
}

class Leave extends DataClass implements Insertable<Leave> {
  final String? id;
  final String? appLeaveId;
  final String? name;
  final DateTime? startDate;
  final DateTime? endDate;
  final String? comments;
  final String? reason;
  final String? leaveType;
  final String? leaveStatus;
  final DateTime? lastModifiedDate;
  final String? firstSecond;
  final String? duration;
  final String? executiveName;
  final String? executiveId;
  final DateTime? createdDate;
  final bool? synced;
  const Leave(
      {this.id,
      this.appLeaveId,
      this.name,
      this.startDate,
      this.endDate,
      this.comments,
      this.reason,
      this.leaveType,
      this.leaveStatus,
      this.lastModifiedDate,
      this.firstSecond,
      this.duration,
      this.executiveName,
      this.executiveId,
      this.createdDate,
      this.synced});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<String>(id);
    }
    if (!nullToAbsent || appLeaveId != null) {
      map['app_leave_id'] = Variable<String>(appLeaveId);
    }
    if (!nullToAbsent || name != null) {
      map['name'] = Variable<String>(name);
    }
    if (!nullToAbsent || startDate != null) {
      map['start_date'] = Variable<DateTime>(startDate);
    }
    if (!nullToAbsent || endDate != null) {
      map['end_date'] = Variable<DateTime>(endDate);
    }
    if (!nullToAbsent || comments != null) {
      map['comments'] = Variable<String>(comments);
    }
    if (!nullToAbsent || reason != null) {
      map['reason'] = Variable<String>(reason);
    }
    if (!nullToAbsent || leaveType != null) {
      map['leave_type'] = Variable<String>(leaveType);
    }
    if (!nullToAbsent || leaveStatus != null) {
      map['leave_status'] = Variable<String>(leaveStatus);
    }
    if (!nullToAbsent || lastModifiedDate != null) {
      map['last_modified_date'] = Variable<DateTime>(lastModifiedDate);
    }
    if (!nullToAbsent || firstSecond != null) {
      map['first_second'] = Variable<String>(firstSecond);
    }
    if (!nullToAbsent || duration != null) {
      map['duration'] = Variable<String>(duration);
    }
    if (!nullToAbsent || executiveName != null) {
      map['executive_name'] = Variable<String>(executiveName);
    }
    if (!nullToAbsent || executiveId != null) {
      map['executive_id'] = Variable<String>(executiveId);
    }
    if (!nullToAbsent || createdDate != null) {
      map['created_date'] = Variable<DateTime>(createdDate);
    }
    if (!nullToAbsent || synced != null) {
      map['synced'] = Variable<bool>(synced);
    }
    return map;
  }

  LeavesCompanion toCompanion(bool nullToAbsent) {
    return LeavesCompanion(
      id: id == null && nullToAbsent ? const Value.absent() : Value(id),
      appLeaveId: appLeaveId == null && nullToAbsent
          ? const Value.absent()
          : Value(appLeaveId),
      name: name == null && nullToAbsent ? const Value.absent() : Value(name),
      startDate: startDate == null && nullToAbsent
          ? const Value.absent()
          : Value(startDate),
      endDate: endDate == null && nullToAbsent
          ? const Value.absent()
          : Value(endDate),
      comments: comments == null && nullToAbsent
          ? const Value.absent()
          : Value(comments),
      reason:
          reason == null && nullToAbsent ? const Value.absent() : Value(reason),
      leaveType: leaveType == null && nullToAbsent
          ? const Value.absent()
          : Value(leaveType),
      leaveStatus: leaveStatus == null && nullToAbsent
          ? const Value.absent()
          : Value(leaveStatus),
      lastModifiedDate: lastModifiedDate == null && nullToAbsent
          ? const Value.absent()
          : Value(lastModifiedDate),
      firstSecond: firstSecond == null && nullToAbsent
          ? const Value.absent()
          : Value(firstSecond),
      duration: duration == null && nullToAbsent
          ? const Value.absent()
          : Value(duration),
      executiveName: executiveName == null && nullToAbsent
          ? const Value.absent()
          : Value(executiveName),
      executiveId: executiveId == null && nullToAbsent
          ? const Value.absent()
          : Value(executiveId),
      createdDate: createdDate == null && nullToAbsent
          ? const Value.absent()
          : Value(createdDate),
      synced:
          synced == null && nullToAbsent ? const Value.absent() : Value(synced),
    );
  }

  factory Leave.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Leave(
      id: serializer.fromJson<String?>(json['id']),
      appLeaveId: serializer.fromJson<String?>(json['appLeaveId']),
      name: serializer.fromJson<String?>(json['name']),
      startDate: serializer.fromJson<DateTime?>(json['startDate']),
      endDate: serializer.fromJson<DateTime?>(json['endDate']),
      comments: serializer.fromJson<String?>(json['comments']),
      reason: serializer.fromJson<String?>(json['reason']),
      leaveType: serializer.fromJson<String?>(json['leaveType']),
      leaveStatus: serializer.fromJson<String?>(json['leaveStatus']),
      lastModifiedDate:
          serializer.fromJson<DateTime?>(json['lastModifiedDate']),
      firstSecond: serializer.fromJson<String?>(json['firstSecond']),
      duration: serializer.fromJson<String?>(json['duration']),
      executiveName: serializer.fromJson<String?>(json['executiveName']),
      executiveId: serializer.fromJson<String?>(json['executiveId']),
      createdDate: serializer.fromJson<DateTime?>(json['createdDate']),
      synced: serializer.fromJson<bool?>(json['synced']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String?>(id),
      'appLeaveId': serializer.toJson<String?>(appLeaveId),
      'name': serializer.toJson<String?>(name),
      'startDate': serializer.toJson<DateTime?>(startDate),
      'endDate': serializer.toJson<DateTime?>(endDate),
      'comments': serializer.toJson<String?>(comments),
      'reason': serializer.toJson<String?>(reason),
      'leaveType': serializer.toJson<String?>(leaveType),
      'leaveStatus': serializer.toJson<String?>(leaveStatus),
      'lastModifiedDate': serializer.toJson<DateTime?>(lastModifiedDate),
      'firstSecond': serializer.toJson<String?>(firstSecond),
      'duration': serializer.toJson<String?>(duration),
      'executiveName': serializer.toJson<String?>(executiveName),
      'executiveId': serializer.toJson<String?>(executiveId),
      'createdDate': serializer.toJson<DateTime?>(createdDate),
      'synced': serializer.toJson<bool?>(synced),
    };
  }

  Leave copyWith(
          {Value<String?> id = const Value.absent(),
          Value<String?> appLeaveId = const Value.absent(),
          Value<String?> name = const Value.absent(),
          Value<DateTime?> startDate = const Value.absent(),
          Value<DateTime?> endDate = const Value.absent(),
          Value<String?> comments = const Value.absent(),
          Value<String?> reason = const Value.absent(),
          Value<String?> leaveType = const Value.absent(),
          Value<String?> leaveStatus = const Value.absent(),
          Value<DateTime?> lastModifiedDate = const Value.absent(),
          Value<String?> firstSecond = const Value.absent(),
          Value<String?> duration = const Value.absent(),
          Value<String?> executiveName = const Value.absent(),
          Value<String?> executiveId = const Value.absent(),
          Value<DateTime?> createdDate = const Value.absent(),
          Value<bool?> synced = const Value.absent()}) =>
      Leave(
        id: id.present ? id.value : this.id,
        appLeaveId: appLeaveId.present ? appLeaveId.value : this.appLeaveId,
        name: name.present ? name.value : this.name,
        startDate: startDate.present ? startDate.value : this.startDate,
        endDate: endDate.present ? endDate.value : this.endDate,
        comments: comments.present ? comments.value : this.comments,
        reason: reason.present ? reason.value : this.reason,
        leaveType: leaveType.present ? leaveType.value : this.leaveType,
        leaveStatus: leaveStatus.present ? leaveStatus.value : this.leaveStatus,
        lastModifiedDate: lastModifiedDate.present
            ? lastModifiedDate.value
            : this.lastModifiedDate,
        firstSecond: firstSecond.present ? firstSecond.value : this.firstSecond,
        duration: duration.present ? duration.value : this.duration,
        executiveName:
            executiveName.present ? executiveName.value : this.executiveName,
        executiveId: executiveId.present ? executiveId.value : this.executiveId,
        createdDate: createdDate.present ? createdDate.value : this.createdDate,
        synced: synced.present ? synced.value : this.synced,
      );
  @override
  String toString() {
    return (StringBuffer('Leave(')
          ..write('id: $id, ')
          ..write('appLeaveId: $appLeaveId, ')
          ..write('name: $name, ')
          ..write('startDate: $startDate, ')
          ..write('endDate: $endDate, ')
          ..write('comments: $comments, ')
          ..write('reason: $reason, ')
          ..write('leaveType: $leaveType, ')
          ..write('leaveStatus: $leaveStatus, ')
          ..write('lastModifiedDate: $lastModifiedDate, ')
          ..write('firstSecond: $firstSecond, ')
          ..write('duration: $duration, ')
          ..write('executiveName: $executiveName, ')
          ..write('executiveId: $executiveId, ')
          ..write('createdDate: $createdDate, ')
          ..write('synced: $synced')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      appLeaveId,
      name,
      startDate,
      endDate,
      comments,
      reason,
      leaveType,
      leaveStatus,
      lastModifiedDate,
      firstSecond,
      duration,
      executiveName,
      executiveId,
      createdDate,
      synced);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Leave &&
          other.id == this.id &&
          other.appLeaveId == this.appLeaveId &&
          other.name == this.name &&
          other.startDate == this.startDate &&
          other.endDate == this.endDate &&
          other.comments == this.comments &&
          other.reason == this.reason &&
          other.leaveType == this.leaveType &&
          other.leaveStatus == this.leaveStatus &&
          other.lastModifiedDate == this.lastModifiedDate &&
          other.firstSecond == this.firstSecond &&
          other.duration == this.duration &&
          other.executiveName == this.executiveName &&
          other.executiveId == this.executiveId &&
          other.createdDate == this.createdDate &&
          other.synced == this.synced);
}

class LeavesCompanion extends UpdateCompanion<Leave> {
  final Value<String?> id;
  final Value<String?> appLeaveId;
  final Value<String?> name;
  final Value<DateTime?> startDate;
  final Value<DateTime?> endDate;
  final Value<String?> comments;
  final Value<String?> reason;
  final Value<String?> leaveType;
  final Value<String?> leaveStatus;
  final Value<DateTime?> lastModifiedDate;
  final Value<String?> firstSecond;
  final Value<String?> duration;
  final Value<String?> executiveName;
  final Value<String?> executiveId;
  final Value<DateTime?> createdDate;
  final Value<bool?> synced;
  final Value<int> rowid;
  const LeavesCompanion({
    this.id = const Value.absent(),
    this.appLeaveId = const Value.absent(),
    this.name = const Value.absent(),
    this.startDate = const Value.absent(),
    this.endDate = const Value.absent(),
    this.comments = const Value.absent(),
    this.reason = const Value.absent(),
    this.leaveType = const Value.absent(),
    this.leaveStatus = const Value.absent(),
    this.lastModifiedDate = const Value.absent(),
    this.firstSecond = const Value.absent(),
    this.duration = const Value.absent(),
    this.executiveName = const Value.absent(),
    this.executiveId = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  LeavesCompanion.insert({
    this.id = const Value.absent(),
    this.appLeaveId = const Value.absent(),
    this.name = const Value.absent(),
    this.startDate = const Value.absent(),
    this.endDate = const Value.absent(),
    this.comments = const Value.absent(),
    this.reason = const Value.absent(),
    this.leaveType = const Value.absent(),
    this.leaveStatus = const Value.absent(),
    this.lastModifiedDate = const Value.absent(),
    this.firstSecond = const Value.absent(),
    this.duration = const Value.absent(),
    this.executiveName = const Value.absent(),
    this.executiveId = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.synced = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  static Insertable<Leave> custom({
    Expression<String>? id,
    Expression<String>? appLeaveId,
    Expression<String>? name,
    Expression<DateTime>? startDate,
    Expression<DateTime>? endDate,
    Expression<String>? comments,
    Expression<String>? reason,
    Expression<String>? leaveType,
    Expression<String>? leaveStatus,
    Expression<DateTime>? lastModifiedDate,
    Expression<String>? firstSecond,
    Expression<String>? duration,
    Expression<String>? executiveName,
    Expression<String>? executiveId,
    Expression<DateTime>? createdDate,
    Expression<bool>? synced,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (appLeaveId != null) 'app_leave_id': appLeaveId,
      if (name != null) 'name': name,
      if (startDate != null) 'start_date': startDate,
      if (endDate != null) 'end_date': endDate,
      if (comments != null) 'comments': comments,
      if (reason != null) 'reason': reason,
      if (leaveType != null) 'leave_type': leaveType,
      if (leaveStatus != null) 'leave_status': leaveStatus,
      if (lastModifiedDate != null) 'last_modified_date': lastModifiedDate,
      if (firstSecond != null) 'first_second': firstSecond,
      if (duration != null) 'duration': duration,
      if (executiveName != null) 'executive_name': executiveName,
      if (executiveId != null) 'executive_id': executiveId,
      if (createdDate != null) 'created_date': createdDate,
      if (synced != null) 'synced': synced,
      if (rowid != null) 'rowid': rowid,
    });
  }

  LeavesCompanion copyWith(
      {Value<String?>? id,
      Value<String?>? appLeaveId,
      Value<String?>? name,
      Value<DateTime?>? startDate,
      Value<DateTime?>? endDate,
      Value<String?>? comments,
      Value<String?>? reason,
      Value<String?>? leaveType,
      Value<String?>? leaveStatus,
      Value<DateTime?>? lastModifiedDate,
      Value<String?>? firstSecond,
      Value<String?>? duration,
      Value<String?>? executiveName,
      Value<String?>? executiveId,
      Value<DateTime?>? createdDate,
      Value<bool?>? synced,
      Value<int>? rowid}) {
    return LeavesCompanion(
      id: id ?? this.id,
      appLeaveId: appLeaveId ?? this.appLeaveId,
      name: name ?? this.name,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      comments: comments ?? this.comments,
      reason: reason ?? this.reason,
      leaveType: leaveType ?? this.leaveType,
      leaveStatus: leaveStatus ?? this.leaveStatus,
      lastModifiedDate: lastModifiedDate ?? this.lastModifiedDate,
      firstSecond: firstSecond ?? this.firstSecond,
      duration: duration ?? this.duration,
      executiveName: executiveName ?? this.executiveName,
      executiveId: executiveId ?? this.executiveId,
      createdDate: createdDate ?? this.createdDate,
      synced: synced ?? this.synced,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (appLeaveId.present) {
      map['app_leave_id'] = Variable<String>(appLeaveId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (startDate.present) {
      map['start_date'] = Variable<DateTime>(startDate.value);
    }
    if (endDate.present) {
      map['end_date'] = Variable<DateTime>(endDate.value);
    }
    if (comments.present) {
      map['comments'] = Variable<String>(comments.value);
    }
    if (reason.present) {
      map['reason'] = Variable<String>(reason.value);
    }
    if (leaveType.present) {
      map['leave_type'] = Variable<String>(leaveType.value);
    }
    if (leaveStatus.present) {
      map['leave_status'] = Variable<String>(leaveStatus.value);
    }
    if (lastModifiedDate.present) {
      map['last_modified_date'] = Variable<DateTime>(lastModifiedDate.value);
    }
    if (firstSecond.present) {
      map['first_second'] = Variable<String>(firstSecond.value);
    }
    if (duration.present) {
      map['duration'] = Variable<String>(duration.value);
    }
    if (executiveName.present) {
      map['executive_name'] = Variable<String>(executiveName.value);
    }
    if (executiveId.present) {
      map['executive_id'] = Variable<String>(executiveId.value);
    }
    if (createdDate.present) {
      map['created_date'] = Variable<DateTime>(createdDate.value);
    }
    if (synced.present) {
      map['synced'] = Variable<bool>(synced.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('LeavesCompanion(')
          ..write('id: $id, ')
          ..write('appLeaveId: $appLeaveId, ')
          ..write('name: $name, ')
          ..write('startDate: $startDate, ')
          ..write('endDate: $endDate, ')
          ..write('comments: $comments, ')
          ..write('reason: $reason, ')
          ..write('leaveType: $leaveType, ')
          ..write('leaveStatus: $leaveStatus, ')
          ..write('lastModifiedDate: $lastModifiedDate, ')
          ..write('firstSecond: $firstSecond, ')
          ..write('duration: $duration, ')
          ..write('executiveName: $executiveName, ')
          ..write('executiveId: $executiveId, ')
          ..write('createdDate: $createdDate, ')
          ..write('synced: $synced, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

abstract class _$DatabaseService extends GeneratedDatabase {
  _$DatabaseService(QueryExecutor e) : super(e);
  _$DatabaseServiceManager get managers => _$DatabaseServiceManager(this);
  late final $AccountsTable accounts = $AccountsTable(this);
  late final $ProductsTable products = $ProductsTable(this);
  late final $VisitPlansTable visitPlans = $VisitPlansTable(this);
  late final $VisitsTable visits = $VisitsTable(this);
  late final $DayLogsTable dayLogs = $DayLogsTable(this);
  late final $CartItemsTable cartItems = $CartItemsTable(this);
  late final $OrdersTable orders = $OrdersTable(this);
  late final $OrderItemsTable orderItems = $OrderItemsTable(this);
  late final $VisitFilesTable visitFiles = $VisitFilesTable(this);
  late final $AccountRoutesTable accountRoutes = $AccountRoutesTable(this);
  late final $ExpensesTable expenses = $ExpensesTable(this);
  late final $ExpenseItemsTable expenseItems = $ExpenseItemsTable(this);
  late final $ExpenseItemFilesTable expenseItemFiles =
      $ExpenseItemFilesTable(this);
  late final $StocksTable stocks = $StocksTable(this);
  late final $TicketsTable tickets = $TicketsTable(this);
  late final $CompetitiorsTable competitiors = $CompetitiorsTable(this);
  late final $CompetitionsTable competitions = $CompetitionsTable(this);
  late final $AccountFilesTable accountFiles = $AccountFilesTable(this);
  late final $PaymentFollowUpsTable paymentFollowUps =
      $PaymentFollowUpsTable(this);
  late final $PaymentReceiptsTable paymentReceipts =
      $PaymentReceiptsTable(this);
  late final $InvoicesTable invoices = $InvoicesTable(this);
  late final $InvoiceItemsTable invoiceItems = $InvoiceItemsTable(this);
  late final $LeavesTable leaves = $LeavesTable(this);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        accounts,
        products,
        visitPlans,
        visits,
        dayLogs,
        cartItems,
        orders,
        orderItems,
        visitFiles,
        accountRoutes,
        expenses,
        expenseItems,
        expenseItemFiles,
        stocks,
        tickets,
        competitiors,
        competitions,
        accountFiles,
        paymentFollowUps,
        paymentReceipts,
        invoices,
        invoiceItems,
        leaves
      ];
  @override
  DriftDatabaseOptions get options =>
      const DriftDatabaseOptions(storeDateTimeAsText: true);
}

typedef $$AccountsTableInsertCompanionBuilder = AccountsCompanion Function({
  Value<String?> appAccountId,
  Value<String?> id,
  Value<String?> name,
  Value<String?> accountOwnerId,
  Value<String?> accountOwnerName,
  Value<String?> contactPersonName,
  Value<String?> email,
  Value<String?> mobile,
  Value<String?> alternateMobile,
  Value<String?> gstNo,
  Value<String?> description,
  Value<String?> liquidation,
  Value<String?> paymentType,
  Value<String?> accountClassification,
  Value<String?> grade,
  Value<String?> routesId,
  Value<String?> routesName,
  Value<String?> longitude,
  Value<String?> latitude,
  Value<String?> parentAccountId,
  Value<String?> parentAccountName,
  Value<String?> outstanding,
  Value<String?> avgCreditDays,
  Value<String?> openingBalance,
  Value<String?> streetName,
  Value<String?> panchayat,
  Value<String?> city,
  Value<String?> state,
  Value<String?> district,
  Value<String?> pincode,
  Value<String?> approvalStatus,
  Value<DateTime?> lastModifiedDate,
  Value<String?> lastModifiedBy,
  Value<DateTime?> createdDate,
  Value<String?> createdBy,
  Value<bool?> synced,
  Value<int> rowid,
});
typedef $$AccountsTableUpdateCompanionBuilder = AccountsCompanion Function({
  Value<String?> appAccountId,
  Value<String?> id,
  Value<String?> name,
  Value<String?> accountOwnerId,
  Value<String?> accountOwnerName,
  Value<String?> contactPersonName,
  Value<String?> email,
  Value<String?> mobile,
  Value<String?> alternateMobile,
  Value<String?> gstNo,
  Value<String?> description,
  Value<String?> liquidation,
  Value<String?> paymentType,
  Value<String?> accountClassification,
  Value<String?> grade,
  Value<String?> routesId,
  Value<String?> routesName,
  Value<String?> longitude,
  Value<String?> latitude,
  Value<String?> parentAccountId,
  Value<String?> parentAccountName,
  Value<String?> outstanding,
  Value<String?> avgCreditDays,
  Value<String?> openingBalance,
  Value<String?> streetName,
  Value<String?> panchayat,
  Value<String?> city,
  Value<String?> state,
  Value<String?> district,
  Value<String?> pincode,
  Value<String?> approvalStatus,
  Value<DateTime?> lastModifiedDate,
  Value<String?> lastModifiedBy,
  Value<DateTime?> createdDate,
  Value<String?> createdBy,
  Value<bool?> synced,
  Value<int> rowid,
});

class $$AccountsTableTableManager extends RootTableManager<
    _$DatabaseService,
    $AccountsTable,
    Account,
    $$AccountsTableFilterComposer,
    $$AccountsTableOrderingComposer,
    $$AccountsTableProcessedTableManager,
    $$AccountsTableInsertCompanionBuilder,
    $$AccountsTableUpdateCompanionBuilder> {
  $$AccountsTableTableManager(_$DatabaseService db, $AccountsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$AccountsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$AccountsTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$AccountsTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> appAccountId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<String?> accountOwnerId = const Value.absent(),
            Value<String?> accountOwnerName = const Value.absent(),
            Value<String?> contactPersonName = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> mobile = const Value.absent(),
            Value<String?> alternateMobile = const Value.absent(),
            Value<String?> gstNo = const Value.absent(),
            Value<String?> description = const Value.absent(),
            Value<String?> liquidation = const Value.absent(),
            Value<String?> paymentType = const Value.absent(),
            Value<String?> accountClassification = const Value.absent(),
            Value<String?> grade = const Value.absent(),
            Value<String?> routesId = const Value.absent(),
            Value<String?> routesName = const Value.absent(),
            Value<String?> longitude = const Value.absent(),
            Value<String?> latitude = const Value.absent(),
            Value<String?> parentAccountId = const Value.absent(),
            Value<String?> parentAccountName = const Value.absent(),
            Value<String?> outstanding = const Value.absent(),
            Value<String?> avgCreditDays = const Value.absent(),
            Value<String?> openingBalance = const Value.absent(),
            Value<String?> streetName = const Value.absent(),
            Value<String?> panchayat = const Value.absent(),
            Value<String?> city = const Value.absent(),
            Value<String?> state = const Value.absent(),
            Value<String?> district = const Value.absent(),
            Value<String?> pincode = const Value.absent(),
            Value<String?> approvalStatus = const Value.absent(),
            Value<DateTime?> lastModifiedDate = const Value.absent(),
            Value<String?> lastModifiedBy = const Value.absent(),
            Value<DateTime?> createdDate = const Value.absent(),
            Value<String?> createdBy = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              AccountsCompanion(
            appAccountId: appAccountId,
            id: id,
            name: name,
            accountOwnerId: accountOwnerId,
            accountOwnerName: accountOwnerName,
            contactPersonName: contactPersonName,
            email: email,
            mobile: mobile,
            alternateMobile: alternateMobile,
            gstNo: gstNo,
            description: description,
            liquidation: liquidation,
            paymentType: paymentType,
            accountClassification: accountClassification,
            grade: grade,
            routesId: routesId,
            routesName: routesName,
            longitude: longitude,
            latitude: latitude,
            parentAccountId: parentAccountId,
            parentAccountName: parentAccountName,
            outstanding: outstanding,
            avgCreditDays: avgCreditDays,
            openingBalance: openingBalance,
            streetName: streetName,
            panchayat: panchayat,
            city: city,
            state: state,
            district: district,
            pincode: pincode,
            approvalStatus: approvalStatus,
            lastModifiedDate: lastModifiedDate,
            lastModifiedBy: lastModifiedBy,
            createdDate: createdDate,
            createdBy: createdBy,
            synced: synced,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> appAccountId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<String?> accountOwnerId = const Value.absent(),
            Value<String?> accountOwnerName = const Value.absent(),
            Value<String?> contactPersonName = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> mobile = const Value.absent(),
            Value<String?> alternateMobile = const Value.absent(),
            Value<String?> gstNo = const Value.absent(),
            Value<String?> description = const Value.absent(),
            Value<String?> liquidation = const Value.absent(),
            Value<String?> paymentType = const Value.absent(),
            Value<String?> accountClassification = const Value.absent(),
            Value<String?> grade = const Value.absent(),
            Value<String?> routesId = const Value.absent(),
            Value<String?> routesName = const Value.absent(),
            Value<String?> longitude = const Value.absent(),
            Value<String?> latitude = const Value.absent(),
            Value<String?> parentAccountId = const Value.absent(),
            Value<String?> parentAccountName = const Value.absent(),
            Value<String?> outstanding = const Value.absent(),
            Value<String?> avgCreditDays = const Value.absent(),
            Value<String?> openingBalance = const Value.absent(),
            Value<String?> streetName = const Value.absent(),
            Value<String?> panchayat = const Value.absent(),
            Value<String?> city = const Value.absent(),
            Value<String?> state = const Value.absent(),
            Value<String?> district = const Value.absent(),
            Value<String?> pincode = const Value.absent(),
            Value<String?> approvalStatus = const Value.absent(),
            Value<DateTime?> lastModifiedDate = const Value.absent(),
            Value<String?> lastModifiedBy = const Value.absent(),
            Value<DateTime?> createdDate = const Value.absent(),
            Value<String?> createdBy = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              AccountsCompanion.insert(
            appAccountId: appAccountId,
            id: id,
            name: name,
            accountOwnerId: accountOwnerId,
            accountOwnerName: accountOwnerName,
            contactPersonName: contactPersonName,
            email: email,
            mobile: mobile,
            alternateMobile: alternateMobile,
            gstNo: gstNo,
            description: description,
            liquidation: liquidation,
            paymentType: paymentType,
            accountClassification: accountClassification,
            grade: grade,
            routesId: routesId,
            routesName: routesName,
            longitude: longitude,
            latitude: latitude,
            parentAccountId: parentAccountId,
            parentAccountName: parentAccountName,
            outstanding: outstanding,
            avgCreditDays: avgCreditDays,
            openingBalance: openingBalance,
            streetName: streetName,
            panchayat: panchayat,
            city: city,
            state: state,
            district: district,
            pincode: pincode,
            approvalStatus: approvalStatus,
            lastModifiedDate: lastModifiedDate,
            lastModifiedBy: lastModifiedBy,
            createdDate: createdDate,
            createdBy: createdBy,
            synced: synced,
            rowid: rowid,
          ),
        ));
}

class $$AccountsTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $AccountsTable,
    Account,
    $$AccountsTableFilterComposer,
    $$AccountsTableOrderingComposer,
    $$AccountsTableProcessedTableManager,
    $$AccountsTableInsertCompanionBuilder,
    $$AccountsTableUpdateCompanionBuilder> {
  $$AccountsTableProcessedTableManager(super.$state);
}

class $$AccountsTableFilterComposer
    extends FilterComposer<_$DatabaseService, $AccountsTable> {
  $$AccountsTableFilterComposer(super.$state);
  ColumnFilters<String> get appAccountId => $state.composableBuilder(
      column: $state.table.appAccountId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountOwnerId => $state.composableBuilder(
      column: $state.table.accountOwnerId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountOwnerName => $state.composableBuilder(
      column: $state.table.accountOwnerName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contactPersonName => $state.composableBuilder(
      column: $state.table.contactPersonName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get mobile => $state.composableBuilder(
      column: $state.table.mobile,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get alternateMobile => $state.composableBuilder(
      column: $state.table.alternateMobile,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get gstNo => $state.composableBuilder(
      column: $state.table.gstNo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get description => $state.composableBuilder(
      column: $state.table.description,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get liquidation => $state.composableBuilder(
      column: $state.table.liquidation,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get paymentType => $state.composableBuilder(
      column: $state.table.paymentType,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountClassification => $state.composableBuilder(
      column: $state.table.accountClassification,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get grade => $state.composableBuilder(
      column: $state.table.grade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get routesId => $state.composableBuilder(
      column: $state.table.routesId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get routesName => $state.composableBuilder(
      column: $state.table.routesName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get longitude => $state.composableBuilder(
      column: $state.table.longitude,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get latitude => $state.composableBuilder(
      column: $state.table.latitude,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get parentAccountId => $state.composableBuilder(
      column: $state.table.parentAccountId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get parentAccountName => $state.composableBuilder(
      column: $state.table.parentAccountName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get outstanding => $state.composableBuilder(
      column: $state.table.outstanding,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get avgCreditDays => $state.composableBuilder(
      column: $state.table.avgCreditDays,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get openingBalance => $state.composableBuilder(
      column: $state.table.openingBalance,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get streetName => $state.composableBuilder(
      column: $state.table.streetName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get panchayat => $state.composableBuilder(
      column: $state.table.panchayat,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get city => $state.composableBuilder(
      column: $state.table.city,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get state => $state.composableBuilder(
      column: $state.table.state,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get district => $state.composableBuilder(
      column: $state.table.district,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pincode => $state.composableBuilder(
      column: $state.table.pincode,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get approvalStatus => $state.composableBuilder(
      column: $state.table.approvalStatus,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get lastModifiedDate => $state.composableBuilder(
      column: $state.table.lastModifiedDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get lastModifiedBy => $state.composableBuilder(
      column: $state.table.lastModifiedBy,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get createdDate => $state.composableBuilder(
      column: $state.table.createdDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get createdBy => $state.composableBuilder(
      column: $state.table.createdBy,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ComposableFilter accountFilesRefs(
      ComposableFilter Function($$AccountFilesTableFilterComposer f) f) {
    final $$AccountFilesTableFilterComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.appAccountId,
        referencedTable: $state.db.accountFiles,
        getReferencedColumn: (t) => t.appAccountId,
        builder: (joinBuilder, parentComposers) =>
            $$AccountFilesTableFilterComposer(ComposerState($state.db,
                $state.db.accountFiles, joinBuilder, parentComposers)));
    return f(composer);
  }
}

class $$AccountsTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $AccountsTable> {
  $$AccountsTableOrderingComposer(super.$state);
  ColumnOrderings<String> get appAccountId => $state.composableBuilder(
      column: $state.table.appAccountId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountOwnerId => $state.composableBuilder(
      column: $state.table.accountOwnerId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountOwnerName => $state.composableBuilder(
      column: $state.table.accountOwnerName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contactPersonName => $state.composableBuilder(
      column: $state.table.contactPersonName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get mobile => $state.composableBuilder(
      column: $state.table.mobile,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get alternateMobile => $state.composableBuilder(
      column: $state.table.alternateMobile,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get gstNo => $state.composableBuilder(
      column: $state.table.gstNo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get description => $state.composableBuilder(
      column: $state.table.description,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get liquidation => $state.composableBuilder(
      column: $state.table.liquidation,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get paymentType => $state.composableBuilder(
      column: $state.table.paymentType,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountClassification => $state.composableBuilder(
      column: $state.table.accountClassification,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get grade => $state.composableBuilder(
      column: $state.table.grade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get routesId => $state.composableBuilder(
      column: $state.table.routesId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get routesName => $state.composableBuilder(
      column: $state.table.routesName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get longitude => $state.composableBuilder(
      column: $state.table.longitude,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get latitude => $state.composableBuilder(
      column: $state.table.latitude,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get parentAccountId => $state.composableBuilder(
      column: $state.table.parentAccountId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get parentAccountName => $state.composableBuilder(
      column: $state.table.parentAccountName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get outstanding => $state.composableBuilder(
      column: $state.table.outstanding,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get avgCreditDays => $state.composableBuilder(
      column: $state.table.avgCreditDays,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get openingBalance => $state.composableBuilder(
      column: $state.table.openingBalance,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get streetName => $state.composableBuilder(
      column: $state.table.streetName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get panchayat => $state.composableBuilder(
      column: $state.table.panchayat,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get city => $state.composableBuilder(
      column: $state.table.city,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get state => $state.composableBuilder(
      column: $state.table.state,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get district => $state.composableBuilder(
      column: $state.table.district,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pincode => $state.composableBuilder(
      column: $state.table.pincode,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get approvalStatus => $state.composableBuilder(
      column: $state.table.approvalStatus,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get lastModifiedDate => $state.composableBuilder(
      column: $state.table.lastModifiedDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get lastModifiedBy => $state.composableBuilder(
      column: $state.table.lastModifiedBy,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get createdDate => $state.composableBuilder(
      column: $state.table.createdDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get createdBy => $state.composableBuilder(
      column: $state.table.createdBy,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ProductsTableInsertCompanionBuilder = ProductsCompanion Function({
  required String id,
  required String name,
  Value<String?> category,
  required double unitPrice,
  required double taxPercent,
  Value<int> rowid,
});
typedef $$ProductsTableUpdateCompanionBuilder = ProductsCompanion Function({
  Value<String> id,
  Value<String> name,
  Value<String?> category,
  Value<double> unitPrice,
  Value<double> taxPercent,
  Value<int> rowid,
});

class $$ProductsTableTableManager extends RootTableManager<
    _$DatabaseService,
    $ProductsTable,
    Product,
    $$ProductsTableFilterComposer,
    $$ProductsTableOrderingComposer,
    $$ProductsTableProcessedTableManager,
    $$ProductsTableInsertCompanionBuilder,
    $$ProductsTableUpdateCompanionBuilder> {
  $$ProductsTableTableManager(_$DatabaseService db, $ProductsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ProductsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$ProductsTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$ProductsTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String> id = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<String?> category = const Value.absent(),
            Value<double> unitPrice = const Value.absent(),
            Value<double> taxPercent = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ProductsCompanion(
            id: id,
            name: name,
            category: category,
            unitPrice: unitPrice,
            taxPercent: taxPercent,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            required String id,
            required String name,
            Value<String?> category = const Value.absent(),
            required double unitPrice,
            required double taxPercent,
            Value<int> rowid = const Value.absent(),
          }) =>
              ProductsCompanion.insert(
            id: id,
            name: name,
            category: category,
            unitPrice: unitPrice,
            taxPercent: taxPercent,
            rowid: rowid,
          ),
        ));
}

class $$ProductsTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $ProductsTable,
    Product,
    $$ProductsTableFilterComposer,
    $$ProductsTableOrderingComposer,
    $$ProductsTableProcessedTableManager,
    $$ProductsTableInsertCompanionBuilder,
    $$ProductsTableUpdateCompanionBuilder> {
  $$ProductsTableProcessedTableManager(super.$state);
}

class $$ProductsTableFilterComposer
    extends FilterComposer<_$DatabaseService, $ProductsTable> {
  $$ProductsTableFilterComposer(super.$state);
  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get category => $state.composableBuilder(
      column: $state.table.category,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get unitPrice => $state.composableBuilder(
      column: $state.table.unitPrice,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxPercent => $state.composableBuilder(
      column: $state.table.taxPercent,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ProductsTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $ProductsTable> {
  $$ProductsTableOrderingComposer(super.$state);
  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get category => $state.composableBuilder(
      column: $state.table.category,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get unitPrice => $state.composableBuilder(
      column: $state.table.unitPrice,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxPercent => $state.composableBuilder(
      column: $state.table.taxPercent,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$VisitPlansTableInsertCompanionBuilder = VisitPlansCompanion Function({
  Value<String?> appVisitPlanId,
  Value<String?> id,
  Value<String?> name,
  Value<int?> month,
  Value<int?> year,
  Value<String?> frequency,
  Value<DateTime?> startDate,
  Value<DateTime?> endDate,
  Value<String?> executiveId,
  Value<String?> executiveName,
  Value<DateTime?> createdDate,
  Value<bool?> synced,
  Value<int> rowid,
});
typedef $$VisitPlansTableUpdateCompanionBuilder = VisitPlansCompanion Function({
  Value<String?> appVisitPlanId,
  Value<String?> id,
  Value<String?> name,
  Value<int?> month,
  Value<int?> year,
  Value<String?> frequency,
  Value<DateTime?> startDate,
  Value<DateTime?> endDate,
  Value<String?> executiveId,
  Value<String?> executiveName,
  Value<DateTime?> createdDate,
  Value<bool?> synced,
  Value<int> rowid,
});

class $$VisitPlansTableTableManager extends RootTableManager<
    _$DatabaseService,
    $VisitPlansTable,
    VisitPlan,
    $$VisitPlansTableFilterComposer,
    $$VisitPlansTableOrderingComposer,
    $$VisitPlansTableProcessedTableManager,
    $$VisitPlansTableInsertCompanionBuilder,
    $$VisitPlansTableUpdateCompanionBuilder> {
  $$VisitPlansTableTableManager(_$DatabaseService db, $VisitPlansTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$VisitPlansTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$VisitPlansTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$VisitPlansTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> appVisitPlanId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<int?> month = const Value.absent(),
            Value<int?> year = const Value.absent(),
            Value<String?> frequency = const Value.absent(),
            Value<DateTime?> startDate = const Value.absent(),
            Value<DateTime?> endDate = const Value.absent(),
            Value<String?> executiveId = const Value.absent(),
            Value<String?> executiveName = const Value.absent(),
            Value<DateTime?> createdDate = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              VisitPlansCompanion(
            appVisitPlanId: appVisitPlanId,
            id: id,
            name: name,
            month: month,
            year: year,
            frequency: frequency,
            startDate: startDate,
            endDate: endDate,
            executiveId: executiveId,
            executiveName: executiveName,
            createdDate: createdDate,
            synced: synced,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> appVisitPlanId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<int?> month = const Value.absent(),
            Value<int?> year = const Value.absent(),
            Value<String?> frequency = const Value.absent(),
            Value<DateTime?> startDate = const Value.absent(),
            Value<DateTime?> endDate = const Value.absent(),
            Value<String?> executiveId = const Value.absent(),
            Value<String?> executiveName = const Value.absent(),
            Value<DateTime?> createdDate = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              VisitPlansCompanion.insert(
            appVisitPlanId: appVisitPlanId,
            id: id,
            name: name,
            month: month,
            year: year,
            frequency: frequency,
            startDate: startDate,
            endDate: endDate,
            executiveId: executiveId,
            executiveName: executiveName,
            createdDate: createdDate,
            synced: synced,
            rowid: rowid,
          ),
        ));
}

class $$VisitPlansTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $VisitPlansTable,
    VisitPlan,
    $$VisitPlansTableFilterComposer,
    $$VisitPlansTableOrderingComposer,
    $$VisitPlansTableProcessedTableManager,
    $$VisitPlansTableInsertCompanionBuilder,
    $$VisitPlansTableUpdateCompanionBuilder> {
  $$VisitPlansTableProcessedTableManager(super.$state);
}

class $$VisitPlansTableFilterComposer
    extends FilterComposer<_$DatabaseService, $VisitPlansTable> {
  $$VisitPlansTableFilterComposer(super.$state);
  ColumnFilters<String> get appVisitPlanId => $state.composableBuilder(
      column: $state.table.appVisitPlanId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get month => $state.composableBuilder(
      column: $state.table.month,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get year => $state.composableBuilder(
      column: $state.table.year,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get frequency => $state.composableBuilder(
      column: $state.table.frequency,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get startDate => $state.composableBuilder(
      column: $state.table.startDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get endDate => $state.composableBuilder(
      column: $state.table.endDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get executiveId => $state.composableBuilder(
      column: $state.table.executiveId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get executiveName => $state.composableBuilder(
      column: $state.table.executiveName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get createdDate => $state.composableBuilder(
      column: $state.table.createdDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ComposableFilter visitsRefs(
      ComposableFilter Function($$VisitsTableFilterComposer f) f) {
    final $$VisitsTableFilterComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $state.db.visits,
        getReferencedColumn: (t) => t.visitPlanId,
        builder: (joinBuilder, parentComposers) => $$VisitsTableFilterComposer(
            ComposerState(
                $state.db, $state.db.visits, joinBuilder, parentComposers)));
    return f(composer);
  }
}

class $$VisitPlansTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $VisitPlansTable> {
  $$VisitPlansTableOrderingComposer(super.$state);
  ColumnOrderings<String> get appVisitPlanId => $state.composableBuilder(
      column: $state.table.appVisitPlanId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get month => $state.composableBuilder(
      column: $state.table.month,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get year => $state.composableBuilder(
      column: $state.table.year,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get frequency => $state.composableBuilder(
      column: $state.table.frequency,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get startDate => $state.composableBuilder(
      column: $state.table.startDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get endDate => $state.composableBuilder(
      column: $state.table.endDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get executiveId => $state.composableBuilder(
      column: $state.table.executiveId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get executiveName => $state.composableBuilder(
      column: $state.table.executiveName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get createdDate => $state.composableBuilder(
      column: $state.table.createdDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$VisitsTableInsertCompanionBuilder = VisitsCompanion Function({
  Value<String?> salesAppId,
  Value<String?> id,
  Value<String?> accountId,
  Value<String?> appAccountId,
  Value<String?> accountName,
  Value<String?> status,
  required DateTime plannedStartTime,
  Value<DateTime?> plannedEndTime,
  Value<DateTime?> actualStartTime,
  Value<DateTime?> actualEndTime,
  Value<String?> comments,
  Value<String?> missedReason,
  Value<String?> lastVisitComment,
  Value<DateTime?> lastVisitDate,
  Value<LatLng?> geoLocation,
  Value<LatLng?> checkoutLocation,
  Value<double?> outstanding,
  Value<String?> typeofVisit,
  Value<String?> appVisitPlanId,
  Value<String?> visitPlanId,
  Value<bool?> synced,
  Value<int> rowid,
});
typedef $$VisitsTableUpdateCompanionBuilder = VisitsCompanion Function({
  Value<String?> salesAppId,
  Value<String?> id,
  Value<String?> accountId,
  Value<String?> appAccountId,
  Value<String?> accountName,
  Value<String?> status,
  Value<DateTime> plannedStartTime,
  Value<DateTime?> plannedEndTime,
  Value<DateTime?> actualStartTime,
  Value<DateTime?> actualEndTime,
  Value<String?> comments,
  Value<String?> missedReason,
  Value<String?> lastVisitComment,
  Value<DateTime?> lastVisitDate,
  Value<LatLng?> geoLocation,
  Value<LatLng?> checkoutLocation,
  Value<double?> outstanding,
  Value<String?> typeofVisit,
  Value<String?> appVisitPlanId,
  Value<String?> visitPlanId,
  Value<bool?> synced,
  Value<int> rowid,
});

class $$VisitsTableTableManager extends RootTableManager<
    _$DatabaseService,
    $VisitsTable,
    Visit,
    $$VisitsTableFilterComposer,
    $$VisitsTableOrderingComposer,
    $$VisitsTableProcessedTableManager,
    $$VisitsTableInsertCompanionBuilder,
    $$VisitsTableUpdateCompanionBuilder> {
  $$VisitsTableTableManager(_$DatabaseService db, $VisitsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$VisitsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$VisitsTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) => $$VisitsTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> salesAppId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<String?> accountId = const Value.absent(),
            Value<String?> appAccountId = const Value.absent(),
            Value<String?> accountName = const Value.absent(),
            Value<String?> status = const Value.absent(),
            Value<DateTime> plannedStartTime = const Value.absent(),
            Value<DateTime?> plannedEndTime = const Value.absent(),
            Value<DateTime?> actualStartTime = const Value.absent(),
            Value<DateTime?> actualEndTime = const Value.absent(),
            Value<String?> comments = const Value.absent(),
            Value<String?> missedReason = const Value.absent(),
            Value<String?> lastVisitComment = const Value.absent(),
            Value<DateTime?> lastVisitDate = const Value.absent(),
            Value<LatLng?> geoLocation = const Value.absent(),
            Value<LatLng?> checkoutLocation = const Value.absent(),
            Value<double?> outstanding = const Value.absent(),
            Value<String?> typeofVisit = const Value.absent(),
            Value<String?> appVisitPlanId = const Value.absent(),
            Value<String?> visitPlanId = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              VisitsCompanion(
            salesAppId: salesAppId,
            id: id,
            accountId: accountId,
            appAccountId: appAccountId,
            accountName: accountName,
            status: status,
            plannedStartTime: plannedStartTime,
            plannedEndTime: plannedEndTime,
            actualStartTime: actualStartTime,
            actualEndTime: actualEndTime,
            comments: comments,
            missedReason: missedReason,
            lastVisitComment: lastVisitComment,
            lastVisitDate: lastVisitDate,
            geoLocation: geoLocation,
            checkoutLocation: checkoutLocation,
            outstanding: outstanding,
            typeofVisit: typeofVisit,
            appVisitPlanId: appVisitPlanId,
            visitPlanId: visitPlanId,
            synced: synced,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> salesAppId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<String?> accountId = const Value.absent(),
            Value<String?> appAccountId = const Value.absent(),
            Value<String?> accountName = const Value.absent(),
            Value<String?> status = const Value.absent(),
            required DateTime plannedStartTime,
            Value<DateTime?> plannedEndTime = const Value.absent(),
            Value<DateTime?> actualStartTime = const Value.absent(),
            Value<DateTime?> actualEndTime = const Value.absent(),
            Value<String?> comments = const Value.absent(),
            Value<String?> missedReason = const Value.absent(),
            Value<String?> lastVisitComment = const Value.absent(),
            Value<DateTime?> lastVisitDate = const Value.absent(),
            Value<LatLng?> geoLocation = const Value.absent(),
            Value<LatLng?> checkoutLocation = const Value.absent(),
            Value<double?> outstanding = const Value.absent(),
            Value<String?> typeofVisit = const Value.absent(),
            Value<String?> appVisitPlanId = const Value.absent(),
            Value<String?> visitPlanId = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              VisitsCompanion.insert(
            salesAppId: salesAppId,
            id: id,
            accountId: accountId,
            appAccountId: appAccountId,
            accountName: accountName,
            status: status,
            plannedStartTime: plannedStartTime,
            plannedEndTime: plannedEndTime,
            actualStartTime: actualStartTime,
            actualEndTime: actualEndTime,
            comments: comments,
            missedReason: missedReason,
            lastVisitComment: lastVisitComment,
            lastVisitDate: lastVisitDate,
            geoLocation: geoLocation,
            checkoutLocation: checkoutLocation,
            outstanding: outstanding,
            typeofVisit: typeofVisit,
            appVisitPlanId: appVisitPlanId,
            visitPlanId: visitPlanId,
            synced: synced,
            rowid: rowid,
          ),
        ));
}

class $$VisitsTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $VisitsTable,
    Visit,
    $$VisitsTableFilterComposer,
    $$VisitsTableOrderingComposer,
    $$VisitsTableProcessedTableManager,
    $$VisitsTableInsertCompanionBuilder,
    $$VisitsTableUpdateCompanionBuilder> {
  $$VisitsTableProcessedTableManager(super.$state);
}

class $$VisitsTableFilterComposer
    extends FilterComposer<_$DatabaseService, $VisitsTable> {
  $$VisitsTableFilterComposer(super.$state);
  ColumnFilters<String> get salesAppId => $state.composableBuilder(
      column: $state.table.salesAppId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountName => $state.composableBuilder(
      column: $state.table.accountName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get status => $state.composableBuilder(
      column: $state.table.status,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get plannedStartTime => $state.composableBuilder(
      column: $state.table.plannedStartTime,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get plannedEndTime => $state.composableBuilder(
      column: $state.table.plannedEndTime,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get actualStartTime => $state.composableBuilder(
      column: $state.table.actualStartTime,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get actualEndTime => $state.composableBuilder(
      column: $state.table.actualEndTime,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get comments => $state.composableBuilder(
      column: $state.table.comments,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get missedReason => $state.composableBuilder(
      column: $state.table.missedReason,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get lastVisitComment => $state.composableBuilder(
      column: $state.table.lastVisitComment,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get lastVisitDate => $state.composableBuilder(
      column: $state.table.lastVisitDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnWithTypeConverterFilters<LatLng?, LatLng, String> get geoLocation =>
      $state.composableBuilder(
          column: $state.table.geoLocation,
          builder: (column, joinBuilders) => ColumnWithTypeConverterFilters(
              column,
              joinBuilders: joinBuilders));

  ColumnWithTypeConverterFilters<LatLng?, LatLng, String>
      get checkoutLocation => $state.composableBuilder(
          column: $state.table.checkoutLocation,
          builder: (column, joinBuilders) => ColumnWithTypeConverterFilters(
              column,
              joinBuilders: joinBuilders));

  ColumnFilters<double> get outstanding => $state.composableBuilder(
      column: $state.table.outstanding,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get typeofVisit => $state.composableBuilder(
      column: $state.table.typeofVisit,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get appVisitPlanId => $state.composableBuilder(
      column: $state.table.appVisitPlanId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  $$AccountsTableFilterComposer get accountId {
    final $$AccountsTableFilterComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.accountId,
        referencedTable: $state.db.accounts,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder, parentComposers) =>
            $$AccountsTableFilterComposer(ComposerState(
                $state.db, $state.db.accounts, joinBuilder, parentComposers)));
    return composer;
  }

  $$AccountsTableFilterComposer get appAccountId {
    final $$AccountsTableFilterComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.appAccountId,
        referencedTable: $state.db.accounts,
        getReferencedColumn: (t) => t.appAccountId,
        builder: (joinBuilder, parentComposers) =>
            $$AccountsTableFilterComposer(ComposerState(
                $state.db, $state.db.accounts, joinBuilder, parentComposers)));
    return composer;
  }

  $$VisitPlansTableFilterComposer get visitPlanId {
    final $$VisitPlansTableFilterComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.visitPlanId,
        referencedTable: $state.db.visitPlans,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder, parentComposers) =>
            $$VisitPlansTableFilterComposer(ComposerState($state.db,
                $state.db.visitPlans, joinBuilder, parentComposers)));
    return composer;
  }

  ComposableFilter visitFilesRefs(
      ComposableFilter Function($$VisitFilesTableFilterComposer f) f) {
    final $$VisitFilesTableFilterComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.salesAppId,
        referencedTable: $state.db.visitFiles,
        getReferencedColumn: (t) => t.salesAppId,
        builder: (joinBuilder, parentComposers) =>
            $$VisitFilesTableFilterComposer(ComposerState($state.db,
                $state.db.visitFiles, joinBuilder, parentComposers)));
    return f(composer);
  }

  ComposableFilter stocksRefs(
      ComposableFilter Function($$StocksTableFilterComposer f) f) {
    final $$StocksTableFilterComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.salesAppId,
        referencedTable: $state.db.stocks,
        getReferencedColumn: (t) => t.salesAppId,
        builder: (joinBuilder, parentComposers) => $$StocksTableFilterComposer(
            ComposerState(
                $state.db, $state.db.stocks, joinBuilder, parentComposers)));
    return f(composer);
  }

  ComposableFilter competitionsRefs(
      ComposableFilter Function($$CompetitionsTableFilterComposer f) f) {
    final $$CompetitionsTableFilterComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.salesAppId,
        referencedTable: $state.db.competitions,
        getReferencedColumn: (t) => t.salesAppId,
        builder: (joinBuilder, parentComposers) =>
            $$CompetitionsTableFilterComposer(ComposerState($state.db,
                $state.db.competitions, joinBuilder, parentComposers)));
    return f(composer);
  }
}

class $$VisitsTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $VisitsTable> {
  $$VisitsTableOrderingComposer(super.$state);
  ColumnOrderings<String> get salesAppId => $state.composableBuilder(
      column: $state.table.salesAppId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountName => $state.composableBuilder(
      column: $state.table.accountName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get status => $state.composableBuilder(
      column: $state.table.status,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get plannedStartTime => $state.composableBuilder(
      column: $state.table.plannedStartTime,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get plannedEndTime => $state.composableBuilder(
      column: $state.table.plannedEndTime,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get actualStartTime => $state.composableBuilder(
      column: $state.table.actualStartTime,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get actualEndTime => $state.composableBuilder(
      column: $state.table.actualEndTime,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get comments => $state.composableBuilder(
      column: $state.table.comments,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get missedReason => $state.composableBuilder(
      column: $state.table.missedReason,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get lastVisitComment => $state.composableBuilder(
      column: $state.table.lastVisitComment,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get lastVisitDate => $state.composableBuilder(
      column: $state.table.lastVisitDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get geoLocation => $state.composableBuilder(
      column: $state.table.geoLocation,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get checkoutLocation => $state.composableBuilder(
      column: $state.table.checkoutLocation,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get outstanding => $state.composableBuilder(
      column: $state.table.outstanding,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get typeofVisit => $state.composableBuilder(
      column: $state.table.typeofVisit,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get appVisitPlanId => $state.composableBuilder(
      column: $state.table.appVisitPlanId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  $$AccountsTableOrderingComposer get accountId {
    final $$AccountsTableOrderingComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.accountId,
        referencedTable: $state.db.accounts,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder, parentComposers) =>
            $$AccountsTableOrderingComposer(ComposerState(
                $state.db, $state.db.accounts, joinBuilder, parentComposers)));
    return composer;
  }

  $$AccountsTableOrderingComposer get appAccountId {
    final $$AccountsTableOrderingComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.appAccountId,
        referencedTable: $state.db.accounts,
        getReferencedColumn: (t) => t.appAccountId,
        builder: (joinBuilder, parentComposers) =>
            $$AccountsTableOrderingComposer(ComposerState(
                $state.db, $state.db.accounts, joinBuilder, parentComposers)));
    return composer;
  }

  $$VisitPlansTableOrderingComposer get visitPlanId {
    final $$VisitPlansTableOrderingComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.visitPlanId,
        referencedTable: $state.db.visitPlans,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder, parentComposers) =>
            $$VisitPlansTableOrderingComposer(ComposerState($state.db,
                $state.db.visitPlans, joinBuilder, parentComposers)));
    return composer;
  }
}

typedef $$DayLogsTableInsertCompanionBuilder = DayLogsCompanion Function({
  required String day,
  required DateTime dayStartTime,
  Value<DateTime?> dayEndTime,
  required LatLng startLocation,
  Value<LatLng?> endLocation,
  Value<bool?> synced,
  Value<int> rowid,
});
typedef $$DayLogsTableUpdateCompanionBuilder = DayLogsCompanion Function({
  Value<String> day,
  Value<DateTime> dayStartTime,
  Value<DateTime?> dayEndTime,
  Value<LatLng> startLocation,
  Value<LatLng?> endLocation,
  Value<bool?> synced,
  Value<int> rowid,
});

class $$DayLogsTableTableManager extends RootTableManager<
    _$DatabaseService,
    $DayLogsTable,
    DayLog,
    $$DayLogsTableFilterComposer,
    $$DayLogsTableOrderingComposer,
    $$DayLogsTableProcessedTableManager,
    $$DayLogsTableInsertCompanionBuilder,
    $$DayLogsTableUpdateCompanionBuilder> {
  $$DayLogsTableTableManager(_$DatabaseService db, $DayLogsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$DayLogsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$DayLogsTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) => $$DayLogsTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String> day = const Value.absent(),
            Value<DateTime> dayStartTime = const Value.absent(),
            Value<DateTime?> dayEndTime = const Value.absent(),
            Value<LatLng> startLocation = const Value.absent(),
            Value<LatLng?> endLocation = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              DayLogsCompanion(
            day: day,
            dayStartTime: dayStartTime,
            dayEndTime: dayEndTime,
            startLocation: startLocation,
            endLocation: endLocation,
            synced: synced,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            required String day,
            required DateTime dayStartTime,
            Value<DateTime?> dayEndTime = const Value.absent(),
            required LatLng startLocation,
            Value<LatLng?> endLocation = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              DayLogsCompanion.insert(
            day: day,
            dayStartTime: dayStartTime,
            dayEndTime: dayEndTime,
            startLocation: startLocation,
            endLocation: endLocation,
            synced: synced,
            rowid: rowid,
          ),
        ));
}

class $$DayLogsTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $DayLogsTable,
    DayLog,
    $$DayLogsTableFilterComposer,
    $$DayLogsTableOrderingComposer,
    $$DayLogsTableProcessedTableManager,
    $$DayLogsTableInsertCompanionBuilder,
    $$DayLogsTableUpdateCompanionBuilder> {
  $$DayLogsTableProcessedTableManager(super.$state);
}

class $$DayLogsTableFilterComposer
    extends FilterComposer<_$DatabaseService, $DayLogsTable> {
  $$DayLogsTableFilterComposer(super.$state);
  ColumnFilters<String> get day => $state.composableBuilder(
      column: $state.table.day,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dayStartTime => $state.composableBuilder(
      column: $state.table.dayStartTime,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dayEndTime => $state.composableBuilder(
      column: $state.table.dayEndTime,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnWithTypeConverterFilters<LatLng, LatLng, String> get startLocation =>
      $state.composableBuilder(
          column: $state.table.startLocation,
          builder: (column, joinBuilders) => ColumnWithTypeConverterFilters(
              column,
              joinBuilders: joinBuilders));

  ColumnWithTypeConverterFilters<LatLng?, LatLng, String> get endLocation =>
      $state.composableBuilder(
          column: $state.table.endLocation,
          builder: (column, joinBuilders) => ColumnWithTypeConverterFilters(
              column,
              joinBuilders: joinBuilders));

  ColumnFilters<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$DayLogsTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $DayLogsTable> {
  $$DayLogsTableOrderingComposer(super.$state);
  ColumnOrderings<String> get day => $state.composableBuilder(
      column: $state.table.day,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dayStartTime => $state.composableBuilder(
      column: $state.table.dayStartTime,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dayEndTime => $state.composableBuilder(
      column: $state.table.dayEndTime,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get startLocation => $state.composableBuilder(
      column: $state.table.startLocation,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get endLocation => $state.composableBuilder(
      column: $state.table.endLocation,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$CartItemsTableInsertCompanionBuilder = CartItemsCompanion Function({
  Value<int?> id,
  required String productId,
  required String productName,
  required int quantity,
  required double unitPrice,
  required double taxPercent,
  required double taxAmount,
  required double totalAmount,
  required double totalTax,
  required double grandTotal,
});
typedef $$CartItemsTableUpdateCompanionBuilder = CartItemsCompanion Function({
  Value<int?> id,
  Value<String> productId,
  Value<String> productName,
  Value<int> quantity,
  Value<double> unitPrice,
  Value<double> taxPercent,
  Value<double> taxAmount,
  Value<double> totalAmount,
  Value<double> totalTax,
  Value<double> grandTotal,
});

class $$CartItemsTableTableManager extends RootTableManager<
    _$DatabaseService,
    $CartItemsTable,
    CartItem,
    $$CartItemsTableFilterComposer,
    $$CartItemsTableOrderingComposer,
    $$CartItemsTableProcessedTableManager,
    $$CartItemsTableInsertCompanionBuilder,
    $$CartItemsTableUpdateCompanionBuilder> {
  $$CartItemsTableTableManager(_$DatabaseService db, $CartItemsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$CartItemsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$CartItemsTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$CartItemsTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<String> productId = const Value.absent(),
            Value<String> productName = const Value.absent(),
            Value<int> quantity = const Value.absent(),
            Value<double> unitPrice = const Value.absent(),
            Value<double> taxPercent = const Value.absent(),
            Value<double> taxAmount = const Value.absent(),
            Value<double> totalAmount = const Value.absent(),
            Value<double> totalTax = const Value.absent(),
            Value<double> grandTotal = const Value.absent(),
          }) =>
              CartItemsCompanion(
            id: id,
            productId: productId,
            productName: productName,
            quantity: quantity,
            unitPrice: unitPrice,
            taxPercent: taxPercent,
            taxAmount: taxAmount,
            totalAmount: totalAmount,
            totalTax: totalTax,
            grandTotal: grandTotal,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            required String productId,
            required String productName,
            required int quantity,
            required double unitPrice,
            required double taxPercent,
            required double taxAmount,
            required double totalAmount,
            required double totalTax,
            required double grandTotal,
          }) =>
              CartItemsCompanion.insert(
            id: id,
            productId: productId,
            productName: productName,
            quantity: quantity,
            unitPrice: unitPrice,
            taxPercent: taxPercent,
            taxAmount: taxAmount,
            totalAmount: totalAmount,
            totalTax: totalTax,
            grandTotal: grandTotal,
          ),
        ));
}

class $$CartItemsTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $CartItemsTable,
    CartItem,
    $$CartItemsTableFilterComposer,
    $$CartItemsTableOrderingComposer,
    $$CartItemsTableProcessedTableManager,
    $$CartItemsTableInsertCompanionBuilder,
    $$CartItemsTableUpdateCompanionBuilder> {
  $$CartItemsTableProcessedTableManager(super.$state);
}

class $$CartItemsTableFilterComposer
    extends FilterComposer<_$DatabaseService, $CartItemsTable> {
  $$CartItemsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get productId => $state.composableBuilder(
      column: $state.table.productId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get productName => $state.composableBuilder(
      column: $state.table.productName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get quantity => $state.composableBuilder(
      column: $state.table.quantity,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get unitPrice => $state.composableBuilder(
      column: $state.table.unitPrice,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxPercent => $state.composableBuilder(
      column: $state.table.taxPercent,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxAmount => $state.composableBuilder(
      column: $state.table.taxAmount,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get totalAmount => $state.composableBuilder(
      column: $state.table.totalAmount,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get totalTax => $state.composableBuilder(
      column: $state.table.totalTax,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get grandTotal => $state.composableBuilder(
      column: $state.table.grandTotal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$CartItemsTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $CartItemsTable> {
  $$CartItemsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get productId => $state.composableBuilder(
      column: $state.table.productId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get productName => $state.composableBuilder(
      column: $state.table.productName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get quantity => $state.composableBuilder(
      column: $state.table.quantity,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get unitPrice => $state.composableBuilder(
      column: $state.table.unitPrice,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxPercent => $state.composableBuilder(
      column: $state.table.taxPercent,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxAmount => $state.composableBuilder(
      column: $state.table.taxAmount,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get totalAmount => $state.composableBuilder(
      column: $state.table.totalAmount,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get totalTax => $state.composableBuilder(
      column: $state.table.totalTax,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get grandTotal => $state.composableBuilder(
      column: $state.table.grandTotal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$OrdersTableInsertCompanionBuilder = OrdersCompanion Function({
  Value<String?> appOrderId,
  Value<String?> id,
  Value<String?> salesAppId,
  Value<String?> accountId,
  Value<String?> appAccountId,
  Value<String?> accountName,
  Value<double?> grandTotal,
  Value<double?> totalAmount,
  Value<double?> totalTax,
  Value<String?> status,
  Value<DateTime?> orderDate,
  Value<String?> name,
  Value<String?> description,
  Value<DateTime?> createdDate,
  Value<bool?> synced,
  Value<int> rowid,
});
typedef $$OrdersTableUpdateCompanionBuilder = OrdersCompanion Function({
  Value<String?> appOrderId,
  Value<String?> id,
  Value<String?> salesAppId,
  Value<String?> accountId,
  Value<String?> appAccountId,
  Value<String?> accountName,
  Value<double?> grandTotal,
  Value<double?> totalAmount,
  Value<double?> totalTax,
  Value<String?> status,
  Value<DateTime?> orderDate,
  Value<String?> name,
  Value<String?> description,
  Value<DateTime?> createdDate,
  Value<bool?> synced,
  Value<int> rowid,
});

class $$OrdersTableTableManager extends RootTableManager<
    _$DatabaseService,
    $OrdersTable,
    Order,
    $$OrdersTableFilterComposer,
    $$OrdersTableOrderingComposer,
    $$OrdersTableProcessedTableManager,
    $$OrdersTableInsertCompanionBuilder,
    $$OrdersTableUpdateCompanionBuilder> {
  $$OrdersTableTableManager(_$DatabaseService db, $OrdersTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$OrdersTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$OrdersTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) => $$OrdersTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> appOrderId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<String?> salesAppId = const Value.absent(),
            Value<String?> accountId = const Value.absent(),
            Value<String?> appAccountId = const Value.absent(),
            Value<String?> accountName = const Value.absent(),
            Value<double?> grandTotal = const Value.absent(),
            Value<double?> totalAmount = const Value.absent(),
            Value<double?> totalTax = const Value.absent(),
            Value<String?> status = const Value.absent(),
            Value<DateTime?> orderDate = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<String?> description = const Value.absent(),
            Value<DateTime?> createdDate = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              OrdersCompanion(
            appOrderId: appOrderId,
            id: id,
            salesAppId: salesAppId,
            accountId: accountId,
            appAccountId: appAccountId,
            accountName: accountName,
            grandTotal: grandTotal,
            totalAmount: totalAmount,
            totalTax: totalTax,
            status: status,
            orderDate: orderDate,
            name: name,
            description: description,
            createdDate: createdDate,
            synced: synced,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> appOrderId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<String?> salesAppId = const Value.absent(),
            Value<String?> accountId = const Value.absent(),
            Value<String?> appAccountId = const Value.absent(),
            Value<String?> accountName = const Value.absent(),
            Value<double?> grandTotal = const Value.absent(),
            Value<double?> totalAmount = const Value.absent(),
            Value<double?> totalTax = const Value.absent(),
            Value<String?> status = const Value.absent(),
            Value<DateTime?> orderDate = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<String?> description = const Value.absent(),
            Value<DateTime?> createdDate = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              OrdersCompanion.insert(
            appOrderId: appOrderId,
            id: id,
            salesAppId: salesAppId,
            accountId: accountId,
            appAccountId: appAccountId,
            accountName: accountName,
            grandTotal: grandTotal,
            totalAmount: totalAmount,
            totalTax: totalTax,
            status: status,
            orderDate: orderDate,
            name: name,
            description: description,
            createdDate: createdDate,
            synced: synced,
            rowid: rowid,
          ),
        ));
}

class $$OrdersTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $OrdersTable,
    Order,
    $$OrdersTableFilterComposer,
    $$OrdersTableOrderingComposer,
    $$OrdersTableProcessedTableManager,
    $$OrdersTableInsertCompanionBuilder,
    $$OrdersTableUpdateCompanionBuilder> {
  $$OrdersTableProcessedTableManager(super.$state);
}

class $$OrdersTableFilterComposer
    extends FilterComposer<_$DatabaseService, $OrdersTable> {
  $$OrdersTableFilterComposer(super.$state);
  ColumnFilters<String> get appOrderId => $state.composableBuilder(
      column: $state.table.appOrderId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get salesAppId => $state.composableBuilder(
      column: $state.table.salesAppId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountId => $state.composableBuilder(
      column: $state.table.accountId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get appAccountId => $state.composableBuilder(
      column: $state.table.appAccountId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountName => $state.composableBuilder(
      column: $state.table.accountName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get grandTotal => $state.composableBuilder(
      column: $state.table.grandTotal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get totalAmount => $state.composableBuilder(
      column: $state.table.totalAmount,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get totalTax => $state.composableBuilder(
      column: $state.table.totalTax,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get status => $state.composableBuilder(
      column: $state.table.status,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get orderDate => $state.composableBuilder(
      column: $state.table.orderDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get description => $state.composableBuilder(
      column: $state.table.description,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get createdDate => $state.composableBuilder(
      column: $state.table.createdDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$OrdersTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $OrdersTable> {
  $$OrdersTableOrderingComposer(super.$state);
  ColumnOrderings<String> get appOrderId => $state.composableBuilder(
      column: $state.table.appOrderId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get salesAppId => $state.composableBuilder(
      column: $state.table.salesAppId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountId => $state.composableBuilder(
      column: $state.table.accountId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get appAccountId => $state.composableBuilder(
      column: $state.table.appAccountId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountName => $state.composableBuilder(
      column: $state.table.accountName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get grandTotal => $state.composableBuilder(
      column: $state.table.grandTotal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get totalAmount => $state.composableBuilder(
      column: $state.table.totalAmount,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get totalTax => $state.composableBuilder(
      column: $state.table.totalTax,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get status => $state.composableBuilder(
      column: $state.table.status,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get orderDate => $state.composableBuilder(
      column: $state.table.orderDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get description => $state.composableBuilder(
      column: $state.table.description,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get createdDate => $state.composableBuilder(
      column: $state.table.createdDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$OrderItemsTableInsertCompanionBuilder = OrderItemsCompanion Function({
  Value<int?> id,
  Value<String?> appOrderId,
  Value<String?> productId,
  Value<String?> productName,
  Value<int?> quantity,
  Value<double?> unitPrice,
  Value<double?> taxPercent,
  Value<double?> taxAmount,
  Value<double?> totalAmount,
  Value<double?> totalTax,
  Value<double?> grandTotal,
});
typedef $$OrderItemsTableUpdateCompanionBuilder = OrderItemsCompanion Function({
  Value<int?> id,
  Value<String?> appOrderId,
  Value<String?> productId,
  Value<String?> productName,
  Value<int?> quantity,
  Value<double?> unitPrice,
  Value<double?> taxPercent,
  Value<double?> taxAmount,
  Value<double?> totalAmount,
  Value<double?> totalTax,
  Value<double?> grandTotal,
});

class $$OrderItemsTableTableManager extends RootTableManager<
    _$DatabaseService,
    $OrderItemsTable,
    OrderItem,
    $$OrderItemsTableFilterComposer,
    $$OrderItemsTableOrderingComposer,
    $$OrderItemsTableProcessedTableManager,
    $$OrderItemsTableInsertCompanionBuilder,
    $$OrderItemsTableUpdateCompanionBuilder> {
  $$OrderItemsTableTableManager(_$DatabaseService db, $OrderItemsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$OrderItemsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$OrderItemsTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$OrderItemsTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<String?> appOrderId = const Value.absent(),
            Value<String?> productId = const Value.absent(),
            Value<String?> productName = const Value.absent(),
            Value<int?> quantity = const Value.absent(),
            Value<double?> unitPrice = const Value.absent(),
            Value<double?> taxPercent = const Value.absent(),
            Value<double?> taxAmount = const Value.absent(),
            Value<double?> totalAmount = const Value.absent(),
            Value<double?> totalTax = const Value.absent(),
            Value<double?> grandTotal = const Value.absent(),
          }) =>
              OrderItemsCompanion(
            id: id,
            appOrderId: appOrderId,
            productId: productId,
            productName: productName,
            quantity: quantity,
            unitPrice: unitPrice,
            taxPercent: taxPercent,
            taxAmount: taxAmount,
            totalAmount: totalAmount,
            totalTax: totalTax,
            grandTotal: grandTotal,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<String?> appOrderId = const Value.absent(),
            Value<String?> productId = const Value.absent(),
            Value<String?> productName = const Value.absent(),
            Value<int?> quantity = const Value.absent(),
            Value<double?> unitPrice = const Value.absent(),
            Value<double?> taxPercent = const Value.absent(),
            Value<double?> taxAmount = const Value.absent(),
            Value<double?> totalAmount = const Value.absent(),
            Value<double?> totalTax = const Value.absent(),
            Value<double?> grandTotal = const Value.absent(),
          }) =>
              OrderItemsCompanion.insert(
            id: id,
            appOrderId: appOrderId,
            productId: productId,
            productName: productName,
            quantity: quantity,
            unitPrice: unitPrice,
            taxPercent: taxPercent,
            taxAmount: taxAmount,
            totalAmount: totalAmount,
            totalTax: totalTax,
            grandTotal: grandTotal,
          ),
        ));
}

class $$OrderItemsTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $OrderItemsTable,
    OrderItem,
    $$OrderItemsTableFilterComposer,
    $$OrderItemsTableOrderingComposer,
    $$OrderItemsTableProcessedTableManager,
    $$OrderItemsTableInsertCompanionBuilder,
    $$OrderItemsTableUpdateCompanionBuilder> {
  $$OrderItemsTableProcessedTableManager(super.$state);
}

class $$OrderItemsTableFilterComposer
    extends FilterComposer<_$DatabaseService, $OrderItemsTable> {
  $$OrderItemsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get appOrderId => $state.composableBuilder(
      column: $state.table.appOrderId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get productId => $state.composableBuilder(
      column: $state.table.productId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get productName => $state.composableBuilder(
      column: $state.table.productName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get quantity => $state.composableBuilder(
      column: $state.table.quantity,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get unitPrice => $state.composableBuilder(
      column: $state.table.unitPrice,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxPercent => $state.composableBuilder(
      column: $state.table.taxPercent,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxAmount => $state.composableBuilder(
      column: $state.table.taxAmount,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get totalAmount => $state.composableBuilder(
      column: $state.table.totalAmount,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get totalTax => $state.composableBuilder(
      column: $state.table.totalTax,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get grandTotal => $state.composableBuilder(
      column: $state.table.grandTotal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$OrderItemsTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $OrderItemsTable> {
  $$OrderItemsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get appOrderId => $state.composableBuilder(
      column: $state.table.appOrderId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get productId => $state.composableBuilder(
      column: $state.table.productId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get productName => $state.composableBuilder(
      column: $state.table.productName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get quantity => $state.composableBuilder(
      column: $state.table.quantity,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get unitPrice => $state.composableBuilder(
      column: $state.table.unitPrice,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxPercent => $state.composableBuilder(
      column: $state.table.taxPercent,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxAmount => $state.composableBuilder(
      column: $state.table.taxAmount,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get totalAmount => $state.composableBuilder(
      column: $state.table.totalAmount,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get totalTax => $state.composableBuilder(
      column: $state.table.totalTax,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get grandTotal => $state.composableBuilder(
      column: $state.table.grandTotal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$VisitFilesTableInsertCompanionBuilder = VisitFilesCompanion Function({
  Value<String?> id,
  required String salesAppId,
  required Uint8List file,
  Value<String?> fileName,
  Value<bool?> synced,
  Value<int> rowid,
});
typedef $$VisitFilesTableUpdateCompanionBuilder = VisitFilesCompanion Function({
  Value<String?> id,
  Value<String> salesAppId,
  Value<Uint8List> file,
  Value<String?> fileName,
  Value<bool?> synced,
  Value<int> rowid,
});

class $$VisitFilesTableTableManager extends RootTableManager<
    _$DatabaseService,
    $VisitFilesTable,
    VisitFile,
    $$VisitFilesTableFilterComposer,
    $$VisitFilesTableOrderingComposer,
    $$VisitFilesTableProcessedTableManager,
    $$VisitFilesTableInsertCompanionBuilder,
    $$VisitFilesTableUpdateCompanionBuilder> {
  $$VisitFilesTableTableManager(_$DatabaseService db, $VisitFilesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$VisitFilesTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$VisitFilesTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$VisitFilesTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> id = const Value.absent(),
            Value<String> salesAppId = const Value.absent(),
            Value<Uint8List> file = const Value.absent(),
            Value<String?> fileName = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              VisitFilesCompanion(
            id: id,
            salesAppId: salesAppId,
            file: file,
            fileName: fileName,
            synced: synced,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> id = const Value.absent(),
            required String salesAppId,
            required Uint8List file,
            Value<String?> fileName = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              VisitFilesCompanion.insert(
            id: id,
            salesAppId: salesAppId,
            file: file,
            fileName: fileName,
            synced: synced,
            rowid: rowid,
          ),
        ));
}

class $$VisitFilesTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $VisitFilesTable,
    VisitFile,
    $$VisitFilesTableFilterComposer,
    $$VisitFilesTableOrderingComposer,
    $$VisitFilesTableProcessedTableManager,
    $$VisitFilesTableInsertCompanionBuilder,
    $$VisitFilesTableUpdateCompanionBuilder> {
  $$VisitFilesTableProcessedTableManager(super.$state);
}

class $$VisitFilesTableFilterComposer
    extends FilterComposer<_$DatabaseService, $VisitFilesTable> {
  $$VisitFilesTableFilterComposer(super.$state);
  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<Uint8List> get file => $state.composableBuilder(
      column: $state.table.file,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get fileName => $state.composableBuilder(
      column: $state.table.fileName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  $$VisitsTableFilterComposer get salesAppId {
    final $$VisitsTableFilterComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.salesAppId,
        referencedTable: $state.db.visits,
        getReferencedColumn: (t) => t.salesAppId,
        builder: (joinBuilder, parentComposers) => $$VisitsTableFilterComposer(
            ComposerState(
                $state.db, $state.db.visits, joinBuilder, parentComposers)));
    return composer;
  }
}

class $$VisitFilesTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $VisitFilesTable> {
  $$VisitFilesTableOrderingComposer(super.$state);
  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<Uint8List> get file => $state.composableBuilder(
      column: $state.table.file,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get fileName => $state.composableBuilder(
      column: $state.table.fileName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  $$VisitsTableOrderingComposer get salesAppId {
    final $$VisitsTableOrderingComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.salesAppId,
        referencedTable: $state.db.visits,
        getReferencedColumn: (t) => t.salesAppId,
        builder: (joinBuilder, parentComposers) =>
            $$VisitsTableOrderingComposer(ComposerState(
                $state.db, $state.db.visits, joinBuilder, parentComposers)));
    return composer;
  }
}

typedef $$AccountRoutesTableInsertCompanionBuilder = AccountRoutesCompanion
    Function({
  Value<String?> id,
  Value<String?> name,
  Value<String?> warehouseId,
  Value<String?> warehouseName,
  Value<int> rowid,
});
typedef $$AccountRoutesTableUpdateCompanionBuilder = AccountRoutesCompanion
    Function({
  Value<String?> id,
  Value<String?> name,
  Value<String?> warehouseId,
  Value<String?> warehouseName,
  Value<int> rowid,
});

class $$AccountRoutesTableTableManager extends RootTableManager<
    _$DatabaseService,
    $AccountRoutesTable,
    AccountRoute,
    $$AccountRoutesTableFilterComposer,
    $$AccountRoutesTableOrderingComposer,
    $$AccountRoutesTableProcessedTableManager,
    $$AccountRoutesTableInsertCompanionBuilder,
    $$AccountRoutesTableUpdateCompanionBuilder> {
  $$AccountRoutesTableTableManager(
      _$DatabaseService db, $AccountRoutesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$AccountRoutesTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$AccountRoutesTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$AccountRoutesTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> id = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<String?> warehouseId = const Value.absent(),
            Value<String?> warehouseName = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              AccountRoutesCompanion(
            id: id,
            name: name,
            warehouseId: warehouseId,
            warehouseName: warehouseName,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> id = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<String?> warehouseId = const Value.absent(),
            Value<String?> warehouseName = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              AccountRoutesCompanion.insert(
            id: id,
            name: name,
            warehouseId: warehouseId,
            warehouseName: warehouseName,
            rowid: rowid,
          ),
        ));
}

class $$AccountRoutesTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $AccountRoutesTable,
    AccountRoute,
    $$AccountRoutesTableFilterComposer,
    $$AccountRoutesTableOrderingComposer,
    $$AccountRoutesTableProcessedTableManager,
    $$AccountRoutesTableInsertCompanionBuilder,
    $$AccountRoutesTableUpdateCompanionBuilder> {
  $$AccountRoutesTableProcessedTableManager(super.$state);
}

class $$AccountRoutesTableFilterComposer
    extends FilterComposer<_$DatabaseService, $AccountRoutesTable> {
  $$AccountRoutesTableFilterComposer(super.$state);
  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get warehouseId => $state.composableBuilder(
      column: $state.table.warehouseId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get warehouseName => $state.composableBuilder(
      column: $state.table.warehouseName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$AccountRoutesTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $AccountRoutesTable> {
  $$AccountRoutesTableOrderingComposer(super.$state);
  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get warehouseId => $state.composableBuilder(
      column: $state.table.warehouseId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get warehouseName => $state.composableBuilder(
      column: $state.table.warehouseName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ExpensesTableInsertCompanionBuilder = ExpensesCompanion Function({
  Value<String?> appExpId,
  Value<String?> id,
  Value<DateTime?> expenseDate,
  Value<String?> expenseName,
  Value<String?> executiveId,
  Value<String?> executiveName,
  Value<String?> createdBy,
  Value<DateTime?> createdDate,
  Value<bool?> synced,
  Value<String?> approvalStatus,
  Value<int> rowid,
});
typedef $$ExpensesTableUpdateCompanionBuilder = ExpensesCompanion Function({
  Value<String?> appExpId,
  Value<String?> id,
  Value<DateTime?> expenseDate,
  Value<String?> expenseName,
  Value<String?> executiveId,
  Value<String?> executiveName,
  Value<String?> createdBy,
  Value<DateTime?> createdDate,
  Value<bool?> synced,
  Value<String?> approvalStatus,
  Value<int> rowid,
});

class $$ExpensesTableTableManager extends RootTableManager<
    _$DatabaseService,
    $ExpensesTable,
    Expense,
    $$ExpensesTableFilterComposer,
    $$ExpensesTableOrderingComposer,
    $$ExpensesTableProcessedTableManager,
    $$ExpensesTableInsertCompanionBuilder,
    $$ExpensesTableUpdateCompanionBuilder> {
  $$ExpensesTableTableManager(_$DatabaseService db, $ExpensesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ExpensesTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$ExpensesTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$ExpensesTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> appExpId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<DateTime?> expenseDate = const Value.absent(),
            Value<String?> expenseName = const Value.absent(),
            Value<String?> executiveId = const Value.absent(),
            Value<String?> executiveName = const Value.absent(),
            Value<String?> createdBy = const Value.absent(),
            Value<DateTime?> createdDate = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<String?> approvalStatus = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ExpensesCompanion(
            appExpId: appExpId,
            id: id,
            expenseDate: expenseDate,
            expenseName: expenseName,
            executiveId: executiveId,
            executiveName: executiveName,
            createdBy: createdBy,
            createdDate: createdDate,
            synced: synced,
            approvalStatus: approvalStatus,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> appExpId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<DateTime?> expenseDate = const Value.absent(),
            Value<String?> expenseName = const Value.absent(),
            Value<String?> executiveId = const Value.absent(),
            Value<String?> executiveName = const Value.absent(),
            Value<String?> createdBy = const Value.absent(),
            Value<DateTime?> createdDate = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<String?> approvalStatus = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ExpensesCompanion.insert(
            appExpId: appExpId,
            id: id,
            expenseDate: expenseDate,
            expenseName: expenseName,
            executiveId: executiveId,
            executiveName: executiveName,
            createdBy: createdBy,
            createdDate: createdDate,
            synced: synced,
            approvalStatus: approvalStatus,
            rowid: rowid,
          ),
        ));
}

class $$ExpensesTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $ExpensesTable,
    Expense,
    $$ExpensesTableFilterComposer,
    $$ExpensesTableOrderingComposer,
    $$ExpensesTableProcessedTableManager,
    $$ExpensesTableInsertCompanionBuilder,
    $$ExpensesTableUpdateCompanionBuilder> {
  $$ExpensesTableProcessedTableManager(super.$state);
}

class $$ExpensesTableFilterComposer
    extends FilterComposer<_$DatabaseService, $ExpensesTable> {
  $$ExpensesTableFilterComposer(super.$state);
  ColumnFilters<String> get appExpId => $state.composableBuilder(
      column: $state.table.appExpId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get expenseDate => $state.composableBuilder(
      column: $state.table.expenseDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get expenseName => $state.composableBuilder(
      column: $state.table.expenseName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get executiveId => $state.composableBuilder(
      column: $state.table.executiveId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get executiveName => $state.composableBuilder(
      column: $state.table.executiveName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get createdBy => $state.composableBuilder(
      column: $state.table.createdBy,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get createdDate => $state.composableBuilder(
      column: $state.table.createdDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get approvalStatus => $state.composableBuilder(
      column: $state.table.approvalStatus,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ComposableFilter expenseItemsRefs(
      ComposableFilter Function($$ExpenseItemsTableFilterComposer f) f) {
    final $$ExpenseItemsTableFilterComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.appExpId,
        referencedTable: $state.db.expenseItems,
        getReferencedColumn: (t) => t.appExpId,
        builder: (joinBuilder, parentComposers) =>
            $$ExpenseItemsTableFilterComposer(ComposerState($state.db,
                $state.db.expenseItems, joinBuilder, parentComposers)));
    return f(composer);
  }

  ComposableFilter expenseItemFilesRefs(
      ComposableFilter Function($$ExpenseItemFilesTableFilterComposer f) f) {
    final $$ExpenseItemFilesTableFilterComposer composer =
        $state.composerBuilder(
            composer: this,
            getCurrentColumn: (t) => t.appExpId,
            referencedTable: $state.db.expenseItemFiles,
            getReferencedColumn: (t) => t.appExpId,
            builder: (joinBuilder, parentComposers) =>
                $$ExpenseItemFilesTableFilterComposer(ComposerState($state.db,
                    $state.db.expenseItemFiles, joinBuilder, parentComposers)));
    return f(composer);
  }
}

class $$ExpensesTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $ExpensesTable> {
  $$ExpensesTableOrderingComposer(super.$state);
  ColumnOrderings<String> get appExpId => $state.composableBuilder(
      column: $state.table.appExpId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get expenseDate => $state.composableBuilder(
      column: $state.table.expenseDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get expenseName => $state.composableBuilder(
      column: $state.table.expenseName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get executiveId => $state.composableBuilder(
      column: $state.table.executiveId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get executiveName => $state.composableBuilder(
      column: $state.table.executiveName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get createdBy => $state.composableBuilder(
      column: $state.table.createdBy,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get createdDate => $state.composableBuilder(
      column: $state.table.createdDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get approvalStatus => $state.composableBuilder(
      column: $state.table.approvalStatus,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ExpenseItemsTableInsertCompanionBuilder = ExpenseItemsCompanion
    Function({
  Value<String?> appExpItemId,
  Value<String?> appExpId,
  Value<String?> type,
  Value<String?> description,
  Value<String?> amount,
  Value<int> rowid,
});
typedef $$ExpenseItemsTableUpdateCompanionBuilder = ExpenseItemsCompanion
    Function({
  Value<String?> appExpItemId,
  Value<String?> appExpId,
  Value<String?> type,
  Value<String?> description,
  Value<String?> amount,
  Value<int> rowid,
});

class $$ExpenseItemsTableTableManager extends RootTableManager<
    _$DatabaseService,
    $ExpenseItemsTable,
    ExpenseItem,
    $$ExpenseItemsTableFilterComposer,
    $$ExpenseItemsTableOrderingComposer,
    $$ExpenseItemsTableProcessedTableManager,
    $$ExpenseItemsTableInsertCompanionBuilder,
    $$ExpenseItemsTableUpdateCompanionBuilder> {
  $$ExpenseItemsTableTableManager(
      _$DatabaseService db, $ExpenseItemsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ExpenseItemsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$ExpenseItemsTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$ExpenseItemsTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> appExpItemId = const Value.absent(),
            Value<String?> appExpId = const Value.absent(),
            Value<String?> type = const Value.absent(),
            Value<String?> description = const Value.absent(),
            Value<String?> amount = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ExpenseItemsCompanion(
            appExpItemId: appExpItemId,
            appExpId: appExpId,
            type: type,
            description: description,
            amount: amount,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> appExpItemId = const Value.absent(),
            Value<String?> appExpId = const Value.absent(),
            Value<String?> type = const Value.absent(),
            Value<String?> description = const Value.absent(),
            Value<String?> amount = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ExpenseItemsCompanion.insert(
            appExpItemId: appExpItemId,
            appExpId: appExpId,
            type: type,
            description: description,
            amount: amount,
            rowid: rowid,
          ),
        ));
}

class $$ExpenseItemsTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $ExpenseItemsTable,
    ExpenseItem,
    $$ExpenseItemsTableFilterComposer,
    $$ExpenseItemsTableOrderingComposer,
    $$ExpenseItemsTableProcessedTableManager,
    $$ExpenseItemsTableInsertCompanionBuilder,
    $$ExpenseItemsTableUpdateCompanionBuilder> {
  $$ExpenseItemsTableProcessedTableManager(super.$state);
}

class $$ExpenseItemsTableFilterComposer
    extends FilterComposer<_$DatabaseService, $ExpenseItemsTable> {
  $$ExpenseItemsTableFilterComposer(super.$state);
  ColumnFilters<String> get appExpItemId => $state.composableBuilder(
      column: $state.table.appExpItemId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get type => $state.composableBuilder(
      column: $state.table.type,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get description => $state.composableBuilder(
      column: $state.table.description,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get amount => $state.composableBuilder(
      column: $state.table.amount,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  $$ExpensesTableFilterComposer get appExpId {
    final $$ExpensesTableFilterComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.appExpId,
        referencedTable: $state.db.expenses,
        getReferencedColumn: (t) => t.appExpId,
        builder: (joinBuilder, parentComposers) =>
            $$ExpensesTableFilterComposer(ComposerState(
                $state.db, $state.db.expenses, joinBuilder, parentComposers)));
    return composer;
  }

  ComposableFilter expenseItemFilesRefs(
      ComposableFilter Function($$ExpenseItemFilesTableFilterComposer f) f) {
    final $$ExpenseItemFilesTableFilterComposer composer =
        $state.composerBuilder(
            composer: this,
            getCurrentColumn: (t) => t.appExpItemId,
            referencedTable: $state.db.expenseItemFiles,
            getReferencedColumn: (t) => t.appExpItemId,
            builder: (joinBuilder, parentComposers) =>
                $$ExpenseItemFilesTableFilterComposer(ComposerState($state.db,
                    $state.db.expenseItemFiles, joinBuilder, parentComposers)));
    return f(composer);
  }
}

class $$ExpenseItemsTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $ExpenseItemsTable> {
  $$ExpenseItemsTableOrderingComposer(super.$state);
  ColumnOrderings<String> get appExpItemId => $state.composableBuilder(
      column: $state.table.appExpItemId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get type => $state.composableBuilder(
      column: $state.table.type,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get description => $state.composableBuilder(
      column: $state.table.description,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get amount => $state.composableBuilder(
      column: $state.table.amount,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  $$ExpensesTableOrderingComposer get appExpId {
    final $$ExpensesTableOrderingComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.appExpId,
        referencedTable: $state.db.expenses,
        getReferencedColumn: (t) => t.appExpId,
        builder: (joinBuilder, parentComposers) =>
            $$ExpensesTableOrderingComposer(ComposerState(
                $state.db, $state.db.expenses, joinBuilder, parentComposers)));
    return composer;
  }
}

typedef $$ExpenseItemFilesTableInsertCompanionBuilder
    = ExpenseItemFilesCompanion Function({
  Value<String?> id,
  Value<String?> appExpItemId,
  Value<String?> appExpId,
  required Uint8List file,
  Value<String?> fileName,
  Value<bool?> synced,
  Value<int> rowid,
});
typedef $$ExpenseItemFilesTableUpdateCompanionBuilder
    = ExpenseItemFilesCompanion Function({
  Value<String?> id,
  Value<String?> appExpItemId,
  Value<String?> appExpId,
  Value<Uint8List> file,
  Value<String?> fileName,
  Value<bool?> synced,
  Value<int> rowid,
});

class $$ExpenseItemFilesTableTableManager extends RootTableManager<
    _$DatabaseService,
    $ExpenseItemFilesTable,
    ExpenseItemFile,
    $$ExpenseItemFilesTableFilterComposer,
    $$ExpenseItemFilesTableOrderingComposer,
    $$ExpenseItemFilesTableProcessedTableManager,
    $$ExpenseItemFilesTableInsertCompanionBuilder,
    $$ExpenseItemFilesTableUpdateCompanionBuilder> {
  $$ExpenseItemFilesTableTableManager(
      _$DatabaseService db, $ExpenseItemFilesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ExpenseItemFilesTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$ExpenseItemFilesTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$ExpenseItemFilesTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> id = const Value.absent(),
            Value<String?> appExpItemId = const Value.absent(),
            Value<String?> appExpId = const Value.absent(),
            Value<Uint8List> file = const Value.absent(),
            Value<String?> fileName = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ExpenseItemFilesCompanion(
            id: id,
            appExpItemId: appExpItemId,
            appExpId: appExpId,
            file: file,
            fileName: fileName,
            synced: synced,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> id = const Value.absent(),
            Value<String?> appExpItemId = const Value.absent(),
            Value<String?> appExpId = const Value.absent(),
            required Uint8List file,
            Value<String?> fileName = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ExpenseItemFilesCompanion.insert(
            id: id,
            appExpItemId: appExpItemId,
            appExpId: appExpId,
            file: file,
            fileName: fileName,
            synced: synced,
            rowid: rowid,
          ),
        ));
}

class $$ExpenseItemFilesTableProcessedTableManager
    extends ProcessedTableManager<
        _$DatabaseService,
        $ExpenseItemFilesTable,
        ExpenseItemFile,
        $$ExpenseItemFilesTableFilterComposer,
        $$ExpenseItemFilesTableOrderingComposer,
        $$ExpenseItemFilesTableProcessedTableManager,
        $$ExpenseItemFilesTableInsertCompanionBuilder,
        $$ExpenseItemFilesTableUpdateCompanionBuilder> {
  $$ExpenseItemFilesTableProcessedTableManager(super.$state);
}

class $$ExpenseItemFilesTableFilterComposer
    extends FilterComposer<_$DatabaseService, $ExpenseItemFilesTable> {
  $$ExpenseItemFilesTableFilterComposer(super.$state);
  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<Uint8List> get file => $state.composableBuilder(
      column: $state.table.file,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get fileName => $state.composableBuilder(
      column: $state.table.fileName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  $$ExpenseItemsTableFilterComposer get appExpItemId {
    final $$ExpenseItemsTableFilterComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.appExpItemId,
        referencedTable: $state.db.expenseItems,
        getReferencedColumn: (t) => t.appExpItemId,
        builder: (joinBuilder, parentComposers) =>
            $$ExpenseItemsTableFilterComposer(ComposerState($state.db,
                $state.db.expenseItems, joinBuilder, parentComposers)));
    return composer;
  }

  $$ExpensesTableFilterComposer get appExpId {
    final $$ExpensesTableFilterComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.appExpId,
        referencedTable: $state.db.expenses,
        getReferencedColumn: (t) => t.appExpId,
        builder: (joinBuilder, parentComposers) =>
            $$ExpensesTableFilterComposer(ComposerState(
                $state.db, $state.db.expenses, joinBuilder, parentComposers)));
    return composer;
  }
}

class $$ExpenseItemFilesTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $ExpenseItemFilesTable> {
  $$ExpenseItemFilesTableOrderingComposer(super.$state);
  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<Uint8List> get file => $state.composableBuilder(
      column: $state.table.file,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get fileName => $state.composableBuilder(
      column: $state.table.fileName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  $$ExpenseItemsTableOrderingComposer get appExpItemId {
    final $$ExpenseItemsTableOrderingComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.appExpItemId,
        referencedTable: $state.db.expenseItems,
        getReferencedColumn: (t) => t.appExpItemId,
        builder: (joinBuilder, parentComposers) =>
            $$ExpenseItemsTableOrderingComposer(ComposerState($state.db,
                $state.db.expenseItems, joinBuilder, parentComposers)));
    return composer;
  }

  $$ExpensesTableOrderingComposer get appExpId {
    final $$ExpensesTableOrderingComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.appExpId,
        referencedTable: $state.db.expenses,
        getReferencedColumn: (t) => t.appExpId,
        builder: (joinBuilder, parentComposers) =>
            $$ExpensesTableOrderingComposer(ComposerState(
                $state.db, $state.db.expenses, joinBuilder, parentComposers)));
    return composer;
  }
}

typedef $$StocksTableInsertCompanionBuilder = StocksCompanion Function({
  Value<String?> appStockId,
  Value<String?> salesAppId,
  Value<String?> id,
  Value<String?> productId,
  Value<String?> productName,
  Value<String?> productCategory,
  Value<double?> unitPrice,
  Value<int?> quantity,
  Value<String?> accountId,
  Value<String?> accountName,
  Value<bool?> synced,
  Value<int> rowid,
});
typedef $$StocksTableUpdateCompanionBuilder = StocksCompanion Function({
  Value<String?> appStockId,
  Value<String?> salesAppId,
  Value<String?> id,
  Value<String?> productId,
  Value<String?> productName,
  Value<String?> productCategory,
  Value<double?> unitPrice,
  Value<int?> quantity,
  Value<String?> accountId,
  Value<String?> accountName,
  Value<bool?> synced,
  Value<int> rowid,
});

class $$StocksTableTableManager extends RootTableManager<
    _$DatabaseService,
    $StocksTable,
    Stock,
    $$StocksTableFilterComposer,
    $$StocksTableOrderingComposer,
    $$StocksTableProcessedTableManager,
    $$StocksTableInsertCompanionBuilder,
    $$StocksTableUpdateCompanionBuilder> {
  $$StocksTableTableManager(_$DatabaseService db, $StocksTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$StocksTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$StocksTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) => $$StocksTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> appStockId = const Value.absent(),
            Value<String?> salesAppId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<String?> productId = const Value.absent(),
            Value<String?> productName = const Value.absent(),
            Value<String?> productCategory = const Value.absent(),
            Value<double?> unitPrice = const Value.absent(),
            Value<int?> quantity = const Value.absent(),
            Value<String?> accountId = const Value.absent(),
            Value<String?> accountName = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              StocksCompanion(
            appStockId: appStockId,
            salesAppId: salesAppId,
            id: id,
            productId: productId,
            productName: productName,
            productCategory: productCategory,
            unitPrice: unitPrice,
            quantity: quantity,
            accountId: accountId,
            accountName: accountName,
            synced: synced,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> appStockId = const Value.absent(),
            Value<String?> salesAppId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<String?> productId = const Value.absent(),
            Value<String?> productName = const Value.absent(),
            Value<String?> productCategory = const Value.absent(),
            Value<double?> unitPrice = const Value.absent(),
            Value<int?> quantity = const Value.absent(),
            Value<String?> accountId = const Value.absent(),
            Value<String?> accountName = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              StocksCompanion.insert(
            appStockId: appStockId,
            salesAppId: salesAppId,
            id: id,
            productId: productId,
            productName: productName,
            productCategory: productCategory,
            unitPrice: unitPrice,
            quantity: quantity,
            accountId: accountId,
            accountName: accountName,
            synced: synced,
            rowid: rowid,
          ),
        ));
}

class $$StocksTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $StocksTable,
    Stock,
    $$StocksTableFilterComposer,
    $$StocksTableOrderingComposer,
    $$StocksTableProcessedTableManager,
    $$StocksTableInsertCompanionBuilder,
    $$StocksTableUpdateCompanionBuilder> {
  $$StocksTableProcessedTableManager(super.$state);
}

class $$StocksTableFilterComposer
    extends FilterComposer<_$DatabaseService, $StocksTable> {
  $$StocksTableFilterComposer(super.$state);
  ColumnFilters<String> get appStockId => $state.composableBuilder(
      column: $state.table.appStockId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get productId => $state.composableBuilder(
      column: $state.table.productId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get productName => $state.composableBuilder(
      column: $state.table.productName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get productCategory => $state.composableBuilder(
      column: $state.table.productCategory,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get unitPrice => $state.composableBuilder(
      column: $state.table.unitPrice,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get quantity => $state.composableBuilder(
      column: $state.table.quantity,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountId => $state.composableBuilder(
      column: $state.table.accountId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountName => $state.composableBuilder(
      column: $state.table.accountName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  $$VisitsTableFilterComposer get salesAppId {
    final $$VisitsTableFilterComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.salesAppId,
        referencedTable: $state.db.visits,
        getReferencedColumn: (t) => t.salesAppId,
        builder: (joinBuilder, parentComposers) => $$VisitsTableFilterComposer(
            ComposerState(
                $state.db, $state.db.visits, joinBuilder, parentComposers)));
    return composer;
  }
}

class $$StocksTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $StocksTable> {
  $$StocksTableOrderingComposer(super.$state);
  ColumnOrderings<String> get appStockId => $state.composableBuilder(
      column: $state.table.appStockId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get productId => $state.composableBuilder(
      column: $state.table.productId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get productName => $state.composableBuilder(
      column: $state.table.productName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get productCategory => $state.composableBuilder(
      column: $state.table.productCategory,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get unitPrice => $state.composableBuilder(
      column: $state.table.unitPrice,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get quantity => $state.composableBuilder(
      column: $state.table.quantity,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountId => $state.composableBuilder(
      column: $state.table.accountId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountName => $state.composableBuilder(
      column: $state.table.accountName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  $$VisitsTableOrderingComposer get salesAppId {
    final $$VisitsTableOrderingComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.salesAppId,
        referencedTable: $state.db.visits,
        getReferencedColumn: (t) => t.salesAppId,
        builder: (joinBuilder, parentComposers) =>
            $$VisitsTableOrderingComposer(ComposerState(
                $state.db, $state.db.visits, joinBuilder, parentComposers)));
    return composer;
  }
}

typedef $$TicketsTableInsertCompanionBuilder = TicketsCompanion Function({
  Value<String?> appTicketId,
  Value<String?> salesAppId,
  Value<String?> visitId,
  Value<String?> id,
  Value<String?> complaintType,
  Value<String?> description,
  Value<String?> status,
  Value<String?> subject,
  Value<String?> accountId,
  Value<String?> appAccountId,
  Value<String?> accountName,
  Value<DateTime?> createdDate,
  Value<bool?> synced,
  Value<int> rowid,
});
typedef $$TicketsTableUpdateCompanionBuilder = TicketsCompanion Function({
  Value<String?> appTicketId,
  Value<String?> salesAppId,
  Value<String?> visitId,
  Value<String?> id,
  Value<String?> complaintType,
  Value<String?> description,
  Value<String?> status,
  Value<String?> subject,
  Value<String?> accountId,
  Value<String?> appAccountId,
  Value<String?> accountName,
  Value<DateTime?> createdDate,
  Value<bool?> synced,
  Value<int> rowid,
});

class $$TicketsTableTableManager extends RootTableManager<
    _$DatabaseService,
    $TicketsTable,
    Ticket,
    $$TicketsTableFilterComposer,
    $$TicketsTableOrderingComposer,
    $$TicketsTableProcessedTableManager,
    $$TicketsTableInsertCompanionBuilder,
    $$TicketsTableUpdateCompanionBuilder> {
  $$TicketsTableTableManager(_$DatabaseService db, $TicketsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$TicketsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$TicketsTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) => $$TicketsTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> appTicketId = const Value.absent(),
            Value<String?> salesAppId = const Value.absent(),
            Value<String?> visitId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<String?> complaintType = const Value.absent(),
            Value<String?> description = const Value.absent(),
            Value<String?> status = const Value.absent(),
            Value<String?> subject = const Value.absent(),
            Value<String?> accountId = const Value.absent(),
            Value<String?> appAccountId = const Value.absent(),
            Value<String?> accountName = const Value.absent(),
            Value<DateTime?> createdDate = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              TicketsCompanion(
            appTicketId: appTicketId,
            salesAppId: salesAppId,
            visitId: visitId,
            id: id,
            complaintType: complaintType,
            description: description,
            status: status,
            subject: subject,
            accountId: accountId,
            appAccountId: appAccountId,
            accountName: accountName,
            createdDate: createdDate,
            synced: synced,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> appTicketId = const Value.absent(),
            Value<String?> salesAppId = const Value.absent(),
            Value<String?> visitId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<String?> complaintType = const Value.absent(),
            Value<String?> description = const Value.absent(),
            Value<String?> status = const Value.absent(),
            Value<String?> subject = const Value.absent(),
            Value<String?> accountId = const Value.absent(),
            Value<String?> appAccountId = const Value.absent(),
            Value<String?> accountName = const Value.absent(),
            Value<DateTime?> createdDate = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              TicketsCompanion.insert(
            appTicketId: appTicketId,
            salesAppId: salesAppId,
            visitId: visitId,
            id: id,
            complaintType: complaintType,
            description: description,
            status: status,
            subject: subject,
            accountId: accountId,
            appAccountId: appAccountId,
            accountName: accountName,
            createdDate: createdDate,
            synced: synced,
            rowid: rowid,
          ),
        ));
}

class $$TicketsTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $TicketsTable,
    Ticket,
    $$TicketsTableFilterComposer,
    $$TicketsTableOrderingComposer,
    $$TicketsTableProcessedTableManager,
    $$TicketsTableInsertCompanionBuilder,
    $$TicketsTableUpdateCompanionBuilder> {
  $$TicketsTableProcessedTableManager(super.$state);
}

class $$TicketsTableFilterComposer
    extends FilterComposer<_$DatabaseService, $TicketsTable> {
  $$TicketsTableFilterComposer(super.$state);
  ColumnFilters<String> get appTicketId => $state.composableBuilder(
      column: $state.table.appTicketId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get salesAppId => $state.composableBuilder(
      column: $state.table.salesAppId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get visitId => $state.composableBuilder(
      column: $state.table.visitId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get complaintType => $state.composableBuilder(
      column: $state.table.complaintType,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get description => $state.composableBuilder(
      column: $state.table.description,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get status => $state.composableBuilder(
      column: $state.table.status,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get subject => $state.composableBuilder(
      column: $state.table.subject,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountId => $state.composableBuilder(
      column: $state.table.accountId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get appAccountId => $state.composableBuilder(
      column: $state.table.appAccountId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountName => $state.composableBuilder(
      column: $state.table.accountName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get createdDate => $state.composableBuilder(
      column: $state.table.createdDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$TicketsTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $TicketsTable> {
  $$TicketsTableOrderingComposer(super.$state);
  ColumnOrderings<String> get appTicketId => $state.composableBuilder(
      column: $state.table.appTicketId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get salesAppId => $state.composableBuilder(
      column: $state.table.salesAppId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get visitId => $state.composableBuilder(
      column: $state.table.visitId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get complaintType => $state.composableBuilder(
      column: $state.table.complaintType,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get description => $state.composableBuilder(
      column: $state.table.description,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get status => $state.composableBuilder(
      column: $state.table.status,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get subject => $state.composableBuilder(
      column: $state.table.subject,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountId => $state.composableBuilder(
      column: $state.table.accountId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get appAccountId => $state.composableBuilder(
      column: $state.table.appAccountId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountName => $state.composableBuilder(
      column: $state.table.accountName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get createdDate => $state.composableBuilder(
      column: $state.table.createdDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$CompetitiorsTableInsertCompanionBuilder = CompetitiorsCompanion
    Function({
  Value<String?> id,
  Value<String?> name,
  Value<int> rowid,
});
typedef $$CompetitiorsTableUpdateCompanionBuilder = CompetitiorsCompanion
    Function({
  Value<String?> id,
  Value<String?> name,
  Value<int> rowid,
});

class $$CompetitiorsTableTableManager extends RootTableManager<
    _$DatabaseService,
    $CompetitiorsTable,
    Competitior,
    $$CompetitiorsTableFilterComposer,
    $$CompetitiorsTableOrderingComposer,
    $$CompetitiorsTableProcessedTableManager,
    $$CompetitiorsTableInsertCompanionBuilder,
    $$CompetitiorsTableUpdateCompanionBuilder> {
  $$CompetitiorsTableTableManager(
      _$DatabaseService db, $CompetitiorsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$CompetitiorsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$CompetitiorsTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$CompetitiorsTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> id = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              CompetitiorsCompanion(
            id: id,
            name: name,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> id = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              CompetitiorsCompanion.insert(
            id: id,
            name: name,
            rowid: rowid,
          ),
        ));
}

class $$CompetitiorsTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $CompetitiorsTable,
    Competitior,
    $$CompetitiorsTableFilterComposer,
    $$CompetitiorsTableOrderingComposer,
    $$CompetitiorsTableProcessedTableManager,
    $$CompetitiorsTableInsertCompanionBuilder,
    $$CompetitiorsTableUpdateCompanionBuilder> {
  $$CompetitiorsTableProcessedTableManager(super.$state);
}

class $$CompetitiorsTableFilterComposer
    extends FilterComposer<_$DatabaseService, $CompetitiorsTable> {
  $$CompetitiorsTableFilterComposer(super.$state);
  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$CompetitiorsTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $CompetitiorsTable> {
  $$CompetitiorsTableOrderingComposer(super.$state);
  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$CompetitionsTableInsertCompanionBuilder = CompetitionsCompanion
    Function({
  Value<String?> appCompetitionId,
  Value<String?> salesAppId,
  Value<String?> id,
  Value<String?> productId,
  Value<String?> productName,
  Value<String?> currentStock,
  Value<double?> rate,
  Value<String?> accountId,
  Value<String?> accountName,
  Value<String?> competitorId,
  Value<String?> competitorName,
  Value<bool?> synced,
  Value<int> rowid,
});
typedef $$CompetitionsTableUpdateCompanionBuilder = CompetitionsCompanion
    Function({
  Value<String?> appCompetitionId,
  Value<String?> salesAppId,
  Value<String?> id,
  Value<String?> productId,
  Value<String?> productName,
  Value<String?> currentStock,
  Value<double?> rate,
  Value<String?> accountId,
  Value<String?> accountName,
  Value<String?> competitorId,
  Value<String?> competitorName,
  Value<bool?> synced,
  Value<int> rowid,
});

class $$CompetitionsTableTableManager extends RootTableManager<
    _$DatabaseService,
    $CompetitionsTable,
    Competition,
    $$CompetitionsTableFilterComposer,
    $$CompetitionsTableOrderingComposer,
    $$CompetitionsTableProcessedTableManager,
    $$CompetitionsTableInsertCompanionBuilder,
    $$CompetitionsTableUpdateCompanionBuilder> {
  $$CompetitionsTableTableManager(
      _$DatabaseService db, $CompetitionsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$CompetitionsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$CompetitionsTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$CompetitionsTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> appCompetitionId = const Value.absent(),
            Value<String?> salesAppId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<String?> productId = const Value.absent(),
            Value<String?> productName = const Value.absent(),
            Value<String?> currentStock = const Value.absent(),
            Value<double?> rate = const Value.absent(),
            Value<String?> accountId = const Value.absent(),
            Value<String?> accountName = const Value.absent(),
            Value<String?> competitorId = const Value.absent(),
            Value<String?> competitorName = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              CompetitionsCompanion(
            appCompetitionId: appCompetitionId,
            salesAppId: salesAppId,
            id: id,
            productId: productId,
            productName: productName,
            currentStock: currentStock,
            rate: rate,
            accountId: accountId,
            accountName: accountName,
            competitorId: competitorId,
            competitorName: competitorName,
            synced: synced,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> appCompetitionId = const Value.absent(),
            Value<String?> salesAppId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<String?> productId = const Value.absent(),
            Value<String?> productName = const Value.absent(),
            Value<String?> currentStock = const Value.absent(),
            Value<double?> rate = const Value.absent(),
            Value<String?> accountId = const Value.absent(),
            Value<String?> accountName = const Value.absent(),
            Value<String?> competitorId = const Value.absent(),
            Value<String?> competitorName = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              CompetitionsCompanion.insert(
            appCompetitionId: appCompetitionId,
            salesAppId: salesAppId,
            id: id,
            productId: productId,
            productName: productName,
            currentStock: currentStock,
            rate: rate,
            accountId: accountId,
            accountName: accountName,
            competitorId: competitorId,
            competitorName: competitorName,
            synced: synced,
            rowid: rowid,
          ),
        ));
}

class $$CompetitionsTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $CompetitionsTable,
    Competition,
    $$CompetitionsTableFilterComposer,
    $$CompetitionsTableOrderingComposer,
    $$CompetitionsTableProcessedTableManager,
    $$CompetitionsTableInsertCompanionBuilder,
    $$CompetitionsTableUpdateCompanionBuilder> {
  $$CompetitionsTableProcessedTableManager(super.$state);
}

class $$CompetitionsTableFilterComposer
    extends FilterComposer<_$DatabaseService, $CompetitionsTable> {
  $$CompetitionsTableFilterComposer(super.$state);
  ColumnFilters<String> get appCompetitionId => $state.composableBuilder(
      column: $state.table.appCompetitionId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get productId => $state.composableBuilder(
      column: $state.table.productId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get productName => $state.composableBuilder(
      column: $state.table.productName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get currentStock => $state.composableBuilder(
      column: $state.table.currentStock,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get rate => $state.composableBuilder(
      column: $state.table.rate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountId => $state.composableBuilder(
      column: $state.table.accountId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountName => $state.composableBuilder(
      column: $state.table.accountName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get competitorId => $state.composableBuilder(
      column: $state.table.competitorId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get competitorName => $state.composableBuilder(
      column: $state.table.competitorName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  $$VisitsTableFilterComposer get salesAppId {
    final $$VisitsTableFilterComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.salesAppId,
        referencedTable: $state.db.visits,
        getReferencedColumn: (t) => t.salesAppId,
        builder: (joinBuilder, parentComposers) => $$VisitsTableFilterComposer(
            ComposerState(
                $state.db, $state.db.visits, joinBuilder, parentComposers)));
    return composer;
  }
}

class $$CompetitionsTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $CompetitionsTable> {
  $$CompetitionsTableOrderingComposer(super.$state);
  ColumnOrderings<String> get appCompetitionId => $state.composableBuilder(
      column: $state.table.appCompetitionId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get productId => $state.composableBuilder(
      column: $state.table.productId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get productName => $state.composableBuilder(
      column: $state.table.productName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get currentStock => $state.composableBuilder(
      column: $state.table.currentStock,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get rate => $state.composableBuilder(
      column: $state.table.rate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountId => $state.composableBuilder(
      column: $state.table.accountId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountName => $state.composableBuilder(
      column: $state.table.accountName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get competitorId => $state.composableBuilder(
      column: $state.table.competitorId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get competitorName => $state.composableBuilder(
      column: $state.table.competitorName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  $$VisitsTableOrderingComposer get salesAppId {
    final $$VisitsTableOrderingComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.salesAppId,
        referencedTable: $state.db.visits,
        getReferencedColumn: (t) => t.salesAppId,
        builder: (joinBuilder, parentComposers) =>
            $$VisitsTableOrderingComposer(ComposerState(
                $state.db, $state.db.visits, joinBuilder, parentComposers)));
    return composer;
  }
}

typedef $$AccountFilesTableInsertCompanionBuilder = AccountFilesCompanion
    Function({
  Value<String?> id,
  required String appAccountId,
  required Uint8List file,
  Value<String?> fileName,
  Value<bool?> synced,
  Value<int> rowid,
});
typedef $$AccountFilesTableUpdateCompanionBuilder = AccountFilesCompanion
    Function({
  Value<String?> id,
  Value<String> appAccountId,
  Value<Uint8List> file,
  Value<String?> fileName,
  Value<bool?> synced,
  Value<int> rowid,
});

class $$AccountFilesTableTableManager extends RootTableManager<
    _$DatabaseService,
    $AccountFilesTable,
    AccountFile,
    $$AccountFilesTableFilterComposer,
    $$AccountFilesTableOrderingComposer,
    $$AccountFilesTableProcessedTableManager,
    $$AccountFilesTableInsertCompanionBuilder,
    $$AccountFilesTableUpdateCompanionBuilder> {
  $$AccountFilesTableTableManager(
      _$DatabaseService db, $AccountFilesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$AccountFilesTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$AccountFilesTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$AccountFilesTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> id = const Value.absent(),
            Value<String> appAccountId = const Value.absent(),
            Value<Uint8List> file = const Value.absent(),
            Value<String?> fileName = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              AccountFilesCompanion(
            id: id,
            appAccountId: appAccountId,
            file: file,
            fileName: fileName,
            synced: synced,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> id = const Value.absent(),
            required String appAccountId,
            required Uint8List file,
            Value<String?> fileName = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              AccountFilesCompanion.insert(
            id: id,
            appAccountId: appAccountId,
            file: file,
            fileName: fileName,
            synced: synced,
            rowid: rowid,
          ),
        ));
}

class $$AccountFilesTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $AccountFilesTable,
    AccountFile,
    $$AccountFilesTableFilterComposer,
    $$AccountFilesTableOrderingComposer,
    $$AccountFilesTableProcessedTableManager,
    $$AccountFilesTableInsertCompanionBuilder,
    $$AccountFilesTableUpdateCompanionBuilder> {
  $$AccountFilesTableProcessedTableManager(super.$state);
}

class $$AccountFilesTableFilterComposer
    extends FilterComposer<_$DatabaseService, $AccountFilesTable> {
  $$AccountFilesTableFilterComposer(super.$state);
  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<Uint8List> get file => $state.composableBuilder(
      column: $state.table.file,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get fileName => $state.composableBuilder(
      column: $state.table.fileName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  $$AccountsTableFilterComposer get appAccountId {
    final $$AccountsTableFilterComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.appAccountId,
        referencedTable: $state.db.accounts,
        getReferencedColumn: (t) => t.appAccountId,
        builder: (joinBuilder, parentComposers) =>
            $$AccountsTableFilterComposer(ComposerState(
                $state.db, $state.db.accounts, joinBuilder, parentComposers)));
    return composer;
  }
}

class $$AccountFilesTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $AccountFilesTable> {
  $$AccountFilesTableOrderingComposer(super.$state);
  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<Uint8List> get file => $state.composableBuilder(
      column: $state.table.file,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get fileName => $state.composableBuilder(
      column: $state.table.fileName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  $$AccountsTableOrderingComposer get appAccountId {
    final $$AccountsTableOrderingComposer composer = $state.composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.appAccountId,
        referencedTable: $state.db.accounts,
        getReferencedColumn: (t) => t.appAccountId,
        builder: (joinBuilder, parentComposers) =>
            $$AccountsTableOrderingComposer(ComposerState(
                $state.db, $state.db.accounts, joinBuilder, parentComposers)));
    return composer;
  }
}

typedef $$PaymentFollowUpsTableInsertCompanionBuilder
    = PaymentFollowUpsCompanion Function({
  Value<String?> appPaymentFollowUpId,
  Value<String?> id,
  Value<String?> name,
  Value<DateTime?> expectedPaymentDate,
  Value<String?> expectedAmount,
  Value<String?> comment,
  Value<String?> appAccountId,
  Value<String?> accountId,
  Value<String?> accountName,
  Value<String?> visitId,
  Value<String?> appVisitId,
  Value<bool?> synced,
  Value<int> rowid,
});
typedef $$PaymentFollowUpsTableUpdateCompanionBuilder
    = PaymentFollowUpsCompanion Function({
  Value<String?> appPaymentFollowUpId,
  Value<String?> id,
  Value<String?> name,
  Value<DateTime?> expectedPaymentDate,
  Value<String?> expectedAmount,
  Value<String?> comment,
  Value<String?> appAccountId,
  Value<String?> accountId,
  Value<String?> accountName,
  Value<String?> visitId,
  Value<String?> appVisitId,
  Value<bool?> synced,
  Value<int> rowid,
});

class $$PaymentFollowUpsTableTableManager extends RootTableManager<
    _$DatabaseService,
    $PaymentFollowUpsTable,
    PaymentFollowUp,
    $$PaymentFollowUpsTableFilterComposer,
    $$PaymentFollowUpsTableOrderingComposer,
    $$PaymentFollowUpsTableProcessedTableManager,
    $$PaymentFollowUpsTableInsertCompanionBuilder,
    $$PaymentFollowUpsTableUpdateCompanionBuilder> {
  $$PaymentFollowUpsTableTableManager(
      _$DatabaseService db, $PaymentFollowUpsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$PaymentFollowUpsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$PaymentFollowUpsTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$PaymentFollowUpsTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> appPaymentFollowUpId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<DateTime?> expectedPaymentDate = const Value.absent(),
            Value<String?> expectedAmount = const Value.absent(),
            Value<String?> comment = const Value.absent(),
            Value<String?> appAccountId = const Value.absent(),
            Value<String?> accountId = const Value.absent(),
            Value<String?> accountName = const Value.absent(),
            Value<String?> visitId = const Value.absent(),
            Value<String?> appVisitId = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              PaymentFollowUpsCompanion(
            appPaymentFollowUpId: appPaymentFollowUpId,
            id: id,
            name: name,
            expectedPaymentDate: expectedPaymentDate,
            expectedAmount: expectedAmount,
            comment: comment,
            appAccountId: appAccountId,
            accountId: accountId,
            accountName: accountName,
            visitId: visitId,
            appVisitId: appVisitId,
            synced: synced,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> appPaymentFollowUpId = const Value.absent(),
            Value<String?> id = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<DateTime?> expectedPaymentDate = const Value.absent(),
            Value<String?> expectedAmount = const Value.absent(),
            Value<String?> comment = const Value.absent(),
            Value<String?> appAccountId = const Value.absent(),
            Value<String?> accountId = const Value.absent(),
            Value<String?> accountName = const Value.absent(),
            Value<String?> visitId = const Value.absent(),
            Value<String?> appVisitId = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              PaymentFollowUpsCompanion.insert(
            appPaymentFollowUpId: appPaymentFollowUpId,
            id: id,
            name: name,
            expectedPaymentDate: expectedPaymentDate,
            expectedAmount: expectedAmount,
            comment: comment,
            appAccountId: appAccountId,
            accountId: accountId,
            accountName: accountName,
            visitId: visitId,
            appVisitId: appVisitId,
            synced: synced,
            rowid: rowid,
          ),
        ));
}

class $$PaymentFollowUpsTableProcessedTableManager
    extends ProcessedTableManager<
        _$DatabaseService,
        $PaymentFollowUpsTable,
        PaymentFollowUp,
        $$PaymentFollowUpsTableFilterComposer,
        $$PaymentFollowUpsTableOrderingComposer,
        $$PaymentFollowUpsTableProcessedTableManager,
        $$PaymentFollowUpsTableInsertCompanionBuilder,
        $$PaymentFollowUpsTableUpdateCompanionBuilder> {
  $$PaymentFollowUpsTableProcessedTableManager(super.$state);
}

class $$PaymentFollowUpsTableFilterComposer
    extends FilterComposer<_$DatabaseService, $PaymentFollowUpsTable> {
  $$PaymentFollowUpsTableFilterComposer(super.$state);
  ColumnFilters<String> get appPaymentFollowUpId => $state.composableBuilder(
      column: $state.table.appPaymentFollowUpId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get expectedPaymentDate => $state.composableBuilder(
      column: $state.table.expectedPaymentDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get expectedAmount => $state.composableBuilder(
      column: $state.table.expectedAmount,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get comment => $state.composableBuilder(
      column: $state.table.comment,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get appAccountId => $state.composableBuilder(
      column: $state.table.appAccountId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountId => $state.composableBuilder(
      column: $state.table.accountId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountName => $state.composableBuilder(
      column: $state.table.accountName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get visitId => $state.composableBuilder(
      column: $state.table.visitId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get appVisitId => $state.composableBuilder(
      column: $state.table.appVisitId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PaymentFollowUpsTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $PaymentFollowUpsTable> {
  $$PaymentFollowUpsTableOrderingComposer(super.$state);
  ColumnOrderings<String> get appPaymentFollowUpId => $state.composableBuilder(
      column: $state.table.appPaymentFollowUpId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get expectedPaymentDate => $state.composableBuilder(
      column: $state.table.expectedPaymentDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get expectedAmount => $state.composableBuilder(
      column: $state.table.expectedAmount,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get comment => $state.composableBuilder(
      column: $state.table.comment,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get appAccountId => $state.composableBuilder(
      column: $state.table.appAccountId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountId => $state.composableBuilder(
      column: $state.table.accountId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountName => $state.composableBuilder(
      column: $state.table.accountName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get visitId => $state.composableBuilder(
      column: $state.table.visitId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get appVisitId => $state.composableBuilder(
      column: $state.table.appVisitId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$PaymentReceiptsTableInsertCompanionBuilder = PaymentReceiptsCompanion
    Function({
  Value<String?> id,
  Value<String?> status,
  Value<String?> remark,
  Value<String?> paymentType,
  Value<DateTime?> paymentDate,
  Value<String?> name,
  Value<String?> invoiceName,
  Value<String?> checkNo,
  Value<DateTime?> checkDate,
  Value<String?> appInvoiceId,
  Value<String?> appAccountId,
  Value<double?> amount,
  Value<String?> accountName,
  Value<String?> accountId,
  Value<DateTime?> createdDate,
  Value<int> rowid,
});
typedef $$PaymentReceiptsTableUpdateCompanionBuilder = PaymentReceiptsCompanion
    Function({
  Value<String?> id,
  Value<String?> status,
  Value<String?> remark,
  Value<String?> paymentType,
  Value<DateTime?> paymentDate,
  Value<String?> name,
  Value<String?> invoiceName,
  Value<String?> checkNo,
  Value<DateTime?> checkDate,
  Value<String?> appInvoiceId,
  Value<String?> appAccountId,
  Value<double?> amount,
  Value<String?> accountName,
  Value<String?> accountId,
  Value<DateTime?> createdDate,
  Value<int> rowid,
});

class $$PaymentReceiptsTableTableManager extends RootTableManager<
    _$DatabaseService,
    $PaymentReceiptsTable,
    PaymentReceipt,
    $$PaymentReceiptsTableFilterComposer,
    $$PaymentReceiptsTableOrderingComposer,
    $$PaymentReceiptsTableProcessedTableManager,
    $$PaymentReceiptsTableInsertCompanionBuilder,
    $$PaymentReceiptsTableUpdateCompanionBuilder> {
  $$PaymentReceiptsTableTableManager(
      _$DatabaseService db, $PaymentReceiptsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$PaymentReceiptsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$PaymentReceiptsTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$PaymentReceiptsTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> id = const Value.absent(),
            Value<String?> status = const Value.absent(),
            Value<String?> remark = const Value.absent(),
            Value<String?> paymentType = const Value.absent(),
            Value<DateTime?> paymentDate = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<String?> invoiceName = const Value.absent(),
            Value<String?> checkNo = const Value.absent(),
            Value<DateTime?> checkDate = const Value.absent(),
            Value<String?> appInvoiceId = const Value.absent(),
            Value<String?> appAccountId = const Value.absent(),
            Value<double?> amount = const Value.absent(),
            Value<String?> accountName = const Value.absent(),
            Value<String?> accountId = const Value.absent(),
            Value<DateTime?> createdDate = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              PaymentReceiptsCompanion(
            id: id,
            status: status,
            remark: remark,
            paymentType: paymentType,
            paymentDate: paymentDate,
            name: name,
            invoiceName: invoiceName,
            checkNo: checkNo,
            checkDate: checkDate,
            appInvoiceId: appInvoiceId,
            appAccountId: appAccountId,
            amount: amount,
            accountName: accountName,
            accountId: accountId,
            createdDate: createdDate,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> id = const Value.absent(),
            Value<String?> status = const Value.absent(),
            Value<String?> remark = const Value.absent(),
            Value<String?> paymentType = const Value.absent(),
            Value<DateTime?> paymentDate = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<String?> invoiceName = const Value.absent(),
            Value<String?> checkNo = const Value.absent(),
            Value<DateTime?> checkDate = const Value.absent(),
            Value<String?> appInvoiceId = const Value.absent(),
            Value<String?> appAccountId = const Value.absent(),
            Value<double?> amount = const Value.absent(),
            Value<String?> accountName = const Value.absent(),
            Value<String?> accountId = const Value.absent(),
            Value<DateTime?> createdDate = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              PaymentReceiptsCompanion.insert(
            id: id,
            status: status,
            remark: remark,
            paymentType: paymentType,
            paymentDate: paymentDate,
            name: name,
            invoiceName: invoiceName,
            checkNo: checkNo,
            checkDate: checkDate,
            appInvoiceId: appInvoiceId,
            appAccountId: appAccountId,
            amount: amount,
            accountName: accountName,
            accountId: accountId,
            createdDate: createdDate,
            rowid: rowid,
          ),
        ));
}

class $$PaymentReceiptsTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $PaymentReceiptsTable,
    PaymentReceipt,
    $$PaymentReceiptsTableFilterComposer,
    $$PaymentReceiptsTableOrderingComposer,
    $$PaymentReceiptsTableProcessedTableManager,
    $$PaymentReceiptsTableInsertCompanionBuilder,
    $$PaymentReceiptsTableUpdateCompanionBuilder> {
  $$PaymentReceiptsTableProcessedTableManager(super.$state);
}

class $$PaymentReceiptsTableFilterComposer
    extends FilterComposer<_$DatabaseService, $PaymentReceiptsTable> {
  $$PaymentReceiptsTableFilterComposer(super.$state);
  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get status => $state.composableBuilder(
      column: $state.table.status,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get remark => $state.composableBuilder(
      column: $state.table.remark,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get paymentType => $state.composableBuilder(
      column: $state.table.paymentType,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get paymentDate => $state.composableBuilder(
      column: $state.table.paymentDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get invoiceName => $state.composableBuilder(
      column: $state.table.invoiceName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get checkNo => $state.composableBuilder(
      column: $state.table.checkNo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get checkDate => $state.composableBuilder(
      column: $state.table.checkDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get appInvoiceId => $state.composableBuilder(
      column: $state.table.appInvoiceId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get appAccountId => $state.composableBuilder(
      column: $state.table.appAccountId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get amount => $state.composableBuilder(
      column: $state.table.amount,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountName => $state.composableBuilder(
      column: $state.table.accountName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountId => $state.composableBuilder(
      column: $state.table.accountId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get createdDate => $state.composableBuilder(
      column: $state.table.createdDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PaymentReceiptsTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $PaymentReceiptsTable> {
  $$PaymentReceiptsTableOrderingComposer(super.$state);
  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get status => $state.composableBuilder(
      column: $state.table.status,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get remark => $state.composableBuilder(
      column: $state.table.remark,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get paymentType => $state.composableBuilder(
      column: $state.table.paymentType,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get paymentDate => $state.composableBuilder(
      column: $state.table.paymentDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get invoiceName => $state.composableBuilder(
      column: $state.table.invoiceName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get checkNo => $state.composableBuilder(
      column: $state.table.checkNo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get checkDate => $state.composableBuilder(
      column: $state.table.checkDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get appInvoiceId => $state.composableBuilder(
      column: $state.table.appInvoiceId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get appAccountId => $state.composableBuilder(
      column: $state.table.appAccountId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get amount => $state.composableBuilder(
      column: $state.table.amount,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountName => $state.composableBuilder(
      column: $state.table.accountName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountId => $state.composableBuilder(
      column: $state.table.accountId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get createdDate => $state.composableBuilder(
      column: $state.table.createdDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$InvoicesTableInsertCompanionBuilder = InvoicesCompanion Function({
  Value<String?> id,
  Value<String?> appInvoiceId,
  Value<String?> name,
  Value<String?> status,
  Value<int?> totalQuantity,
  Value<double?> totalAmount,
  Value<double?> grandTotal,
  Value<double?> balance,
  Value<DateTime?> invoiceDate,
  Value<DateTime?> dueDate,
  Value<String?> accountName,
  Value<String?> accountId,
  Value<DateTime?> createdDate,
  Value<int> rowid,
});
typedef $$InvoicesTableUpdateCompanionBuilder = InvoicesCompanion Function({
  Value<String?> id,
  Value<String?> appInvoiceId,
  Value<String?> name,
  Value<String?> status,
  Value<int?> totalQuantity,
  Value<double?> totalAmount,
  Value<double?> grandTotal,
  Value<double?> balance,
  Value<DateTime?> invoiceDate,
  Value<DateTime?> dueDate,
  Value<String?> accountName,
  Value<String?> accountId,
  Value<DateTime?> createdDate,
  Value<int> rowid,
});

class $$InvoicesTableTableManager extends RootTableManager<
    _$DatabaseService,
    $InvoicesTable,
    Invoice,
    $$InvoicesTableFilterComposer,
    $$InvoicesTableOrderingComposer,
    $$InvoicesTableProcessedTableManager,
    $$InvoicesTableInsertCompanionBuilder,
    $$InvoicesTableUpdateCompanionBuilder> {
  $$InvoicesTableTableManager(_$DatabaseService db, $InvoicesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$InvoicesTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$InvoicesTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$InvoicesTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> id = const Value.absent(),
            Value<String?> appInvoiceId = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<String?> status = const Value.absent(),
            Value<int?> totalQuantity = const Value.absent(),
            Value<double?> totalAmount = const Value.absent(),
            Value<double?> grandTotal = const Value.absent(),
            Value<double?> balance = const Value.absent(),
            Value<DateTime?> invoiceDate = const Value.absent(),
            Value<DateTime?> dueDate = const Value.absent(),
            Value<String?> accountName = const Value.absent(),
            Value<String?> accountId = const Value.absent(),
            Value<DateTime?> createdDate = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              InvoicesCompanion(
            id: id,
            appInvoiceId: appInvoiceId,
            name: name,
            status: status,
            totalQuantity: totalQuantity,
            totalAmount: totalAmount,
            grandTotal: grandTotal,
            balance: balance,
            invoiceDate: invoiceDate,
            dueDate: dueDate,
            accountName: accountName,
            accountId: accountId,
            createdDate: createdDate,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> id = const Value.absent(),
            Value<String?> appInvoiceId = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<String?> status = const Value.absent(),
            Value<int?> totalQuantity = const Value.absent(),
            Value<double?> totalAmount = const Value.absent(),
            Value<double?> grandTotal = const Value.absent(),
            Value<double?> balance = const Value.absent(),
            Value<DateTime?> invoiceDate = const Value.absent(),
            Value<DateTime?> dueDate = const Value.absent(),
            Value<String?> accountName = const Value.absent(),
            Value<String?> accountId = const Value.absent(),
            Value<DateTime?> createdDate = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              InvoicesCompanion.insert(
            id: id,
            appInvoiceId: appInvoiceId,
            name: name,
            status: status,
            totalQuantity: totalQuantity,
            totalAmount: totalAmount,
            grandTotal: grandTotal,
            balance: balance,
            invoiceDate: invoiceDate,
            dueDate: dueDate,
            accountName: accountName,
            accountId: accountId,
            createdDate: createdDate,
            rowid: rowid,
          ),
        ));
}

class $$InvoicesTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $InvoicesTable,
    Invoice,
    $$InvoicesTableFilterComposer,
    $$InvoicesTableOrderingComposer,
    $$InvoicesTableProcessedTableManager,
    $$InvoicesTableInsertCompanionBuilder,
    $$InvoicesTableUpdateCompanionBuilder> {
  $$InvoicesTableProcessedTableManager(super.$state);
}

class $$InvoicesTableFilterComposer
    extends FilterComposer<_$DatabaseService, $InvoicesTable> {
  $$InvoicesTableFilterComposer(super.$state);
  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get appInvoiceId => $state.composableBuilder(
      column: $state.table.appInvoiceId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get status => $state.composableBuilder(
      column: $state.table.status,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get totalQuantity => $state.composableBuilder(
      column: $state.table.totalQuantity,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get totalAmount => $state.composableBuilder(
      column: $state.table.totalAmount,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get grandTotal => $state.composableBuilder(
      column: $state.table.grandTotal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get balance => $state.composableBuilder(
      column: $state.table.balance,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get invoiceDate => $state.composableBuilder(
      column: $state.table.invoiceDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dueDate => $state.composableBuilder(
      column: $state.table.dueDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountName => $state.composableBuilder(
      column: $state.table.accountName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get accountId => $state.composableBuilder(
      column: $state.table.accountId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get createdDate => $state.composableBuilder(
      column: $state.table.createdDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$InvoicesTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $InvoicesTable> {
  $$InvoicesTableOrderingComposer(super.$state);
  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get appInvoiceId => $state.composableBuilder(
      column: $state.table.appInvoiceId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get status => $state.composableBuilder(
      column: $state.table.status,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get totalQuantity => $state.composableBuilder(
      column: $state.table.totalQuantity,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get totalAmount => $state.composableBuilder(
      column: $state.table.totalAmount,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get grandTotal => $state.composableBuilder(
      column: $state.table.grandTotal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get balance => $state.composableBuilder(
      column: $state.table.balance,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get invoiceDate => $state.composableBuilder(
      column: $state.table.invoiceDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dueDate => $state.composableBuilder(
      column: $state.table.dueDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountName => $state.composableBuilder(
      column: $state.table.accountName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get accountId => $state.composableBuilder(
      column: $state.table.accountId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get createdDate => $state.composableBuilder(
      column: $state.table.createdDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$InvoiceItemsTableInsertCompanionBuilder = InvoiceItemsCompanion
    Function({
  Value<int?> id,
  Value<String?> appInvoiceId,
  Value<String?> productId,
  Value<String?> productName,
  Value<int?> quantity,
  Value<double?> unitPrice,
  Value<double?> taxPercent,
  Value<double?> taxAmount,
  Value<double?> totalAmount,
  Value<double?> totalTax,
  Value<double?> grandTotal,
});
typedef $$InvoiceItemsTableUpdateCompanionBuilder = InvoiceItemsCompanion
    Function({
  Value<int?> id,
  Value<String?> appInvoiceId,
  Value<String?> productId,
  Value<String?> productName,
  Value<int?> quantity,
  Value<double?> unitPrice,
  Value<double?> taxPercent,
  Value<double?> taxAmount,
  Value<double?> totalAmount,
  Value<double?> totalTax,
  Value<double?> grandTotal,
});

class $$InvoiceItemsTableTableManager extends RootTableManager<
    _$DatabaseService,
    $InvoiceItemsTable,
    InvoiceItem,
    $$InvoiceItemsTableFilterComposer,
    $$InvoiceItemsTableOrderingComposer,
    $$InvoiceItemsTableProcessedTableManager,
    $$InvoiceItemsTableInsertCompanionBuilder,
    $$InvoiceItemsTableUpdateCompanionBuilder> {
  $$InvoiceItemsTableTableManager(
      _$DatabaseService db, $InvoiceItemsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$InvoiceItemsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$InvoiceItemsTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$InvoiceItemsTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<String?> appInvoiceId = const Value.absent(),
            Value<String?> productId = const Value.absent(),
            Value<String?> productName = const Value.absent(),
            Value<int?> quantity = const Value.absent(),
            Value<double?> unitPrice = const Value.absent(),
            Value<double?> taxPercent = const Value.absent(),
            Value<double?> taxAmount = const Value.absent(),
            Value<double?> totalAmount = const Value.absent(),
            Value<double?> totalTax = const Value.absent(),
            Value<double?> grandTotal = const Value.absent(),
          }) =>
              InvoiceItemsCompanion(
            id: id,
            appInvoiceId: appInvoiceId,
            productId: productId,
            productName: productName,
            quantity: quantity,
            unitPrice: unitPrice,
            taxPercent: taxPercent,
            taxAmount: taxAmount,
            totalAmount: totalAmount,
            totalTax: totalTax,
            grandTotal: grandTotal,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<String?> appInvoiceId = const Value.absent(),
            Value<String?> productId = const Value.absent(),
            Value<String?> productName = const Value.absent(),
            Value<int?> quantity = const Value.absent(),
            Value<double?> unitPrice = const Value.absent(),
            Value<double?> taxPercent = const Value.absent(),
            Value<double?> taxAmount = const Value.absent(),
            Value<double?> totalAmount = const Value.absent(),
            Value<double?> totalTax = const Value.absent(),
            Value<double?> grandTotal = const Value.absent(),
          }) =>
              InvoiceItemsCompanion.insert(
            id: id,
            appInvoiceId: appInvoiceId,
            productId: productId,
            productName: productName,
            quantity: quantity,
            unitPrice: unitPrice,
            taxPercent: taxPercent,
            taxAmount: taxAmount,
            totalAmount: totalAmount,
            totalTax: totalTax,
            grandTotal: grandTotal,
          ),
        ));
}

class $$InvoiceItemsTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $InvoiceItemsTable,
    InvoiceItem,
    $$InvoiceItemsTableFilterComposer,
    $$InvoiceItemsTableOrderingComposer,
    $$InvoiceItemsTableProcessedTableManager,
    $$InvoiceItemsTableInsertCompanionBuilder,
    $$InvoiceItemsTableUpdateCompanionBuilder> {
  $$InvoiceItemsTableProcessedTableManager(super.$state);
}

class $$InvoiceItemsTableFilterComposer
    extends FilterComposer<_$DatabaseService, $InvoiceItemsTable> {
  $$InvoiceItemsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get appInvoiceId => $state.composableBuilder(
      column: $state.table.appInvoiceId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get productId => $state.composableBuilder(
      column: $state.table.productId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get productName => $state.composableBuilder(
      column: $state.table.productName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get quantity => $state.composableBuilder(
      column: $state.table.quantity,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get unitPrice => $state.composableBuilder(
      column: $state.table.unitPrice,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxPercent => $state.composableBuilder(
      column: $state.table.taxPercent,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxAmount => $state.composableBuilder(
      column: $state.table.taxAmount,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get totalAmount => $state.composableBuilder(
      column: $state.table.totalAmount,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get totalTax => $state.composableBuilder(
      column: $state.table.totalTax,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get grandTotal => $state.composableBuilder(
      column: $state.table.grandTotal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$InvoiceItemsTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $InvoiceItemsTable> {
  $$InvoiceItemsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get appInvoiceId => $state.composableBuilder(
      column: $state.table.appInvoiceId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get productId => $state.composableBuilder(
      column: $state.table.productId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get productName => $state.composableBuilder(
      column: $state.table.productName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get quantity => $state.composableBuilder(
      column: $state.table.quantity,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get unitPrice => $state.composableBuilder(
      column: $state.table.unitPrice,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxPercent => $state.composableBuilder(
      column: $state.table.taxPercent,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxAmount => $state.composableBuilder(
      column: $state.table.taxAmount,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get totalAmount => $state.composableBuilder(
      column: $state.table.totalAmount,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get totalTax => $state.composableBuilder(
      column: $state.table.totalTax,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get grandTotal => $state.composableBuilder(
      column: $state.table.grandTotal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$LeavesTableInsertCompanionBuilder = LeavesCompanion Function({
  Value<String?> id,
  Value<String?> appLeaveId,
  Value<String?> name,
  Value<DateTime?> startDate,
  Value<DateTime?> endDate,
  Value<String?> comments,
  Value<String?> reason,
  Value<String?> leaveType,
  Value<String?> leaveStatus,
  Value<DateTime?> lastModifiedDate,
  Value<String?> firstSecond,
  Value<String?> duration,
  Value<String?> executiveName,
  Value<String?> executiveId,
  Value<DateTime?> createdDate,
  Value<bool?> synced,
  Value<int> rowid,
});
typedef $$LeavesTableUpdateCompanionBuilder = LeavesCompanion Function({
  Value<String?> id,
  Value<String?> appLeaveId,
  Value<String?> name,
  Value<DateTime?> startDate,
  Value<DateTime?> endDate,
  Value<String?> comments,
  Value<String?> reason,
  Value<String?> leaveType,
  Value<String?> leaveStatus,
  Value<DateTime?> lastModifiedDate,
  Value<String?> firstSecond,
  Value<String?> duration,
  Value<String?> executiveName,
  Value<String?> executiveId,
  Value<DateTime?> createdDate,
  Value<bool?> synced,
  Value<int> rowid,
});

class $$LeavesTableTableManager extends RootTableManager<
    _$DatabaseService,
    $LeavesTable,
    Leave,
    $$LeavesTableFilterComposer,
    $$LeavesTableOrderingComposer,
    $$LeavesTableProcessedTableManager,
    $$LeavesTableInsertCompanionBuilder,
    $$LeavesTableUpdateCompanionBuilder> {
  $$LeavesTableTableManager(_$DatabaseService db, $LeavesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$LeavesTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$LeavesTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) => $$LeavesTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<String?> id = const Value.absent(),
            Value<String?> appLeaveId = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<DateTime?> startDate = const Value.absent(),
            Value<DateTime?> endDate = const Value.absent(),
            Value<String?> comments = const Value.absent(),
            Value<String?> reason = const Value.absent(),
            Value<String?> leaveType = const Value.absent(),
            Value<String?> leaveStatus = const Value.absent(),
            Value<DateTime?> lastModifiedDate = const Value.absent(),
            Value<String?> firstSecond = const Value.absent(),
            Value<String?> duration = const Value.absent(),
            Value<String?> executiveName = const Value.absent(),
            Value<String?> executiveId = const Value.absent(),
            Value<DateTime?> createdDate = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              LeavesCompanion(
            id: id,
            appLeaveId: appLeaveId,
            name: name,
            startDate: startDate,
            endDate: endDate,
            comments: comments,
            reason: reason,
            leaveType: leaveType,
            leaveStatus: leaveStatus,
            lastModifiedDate: lastModifiedDate,
            firstSecond: firstSecond,
            duration: duration,
            executiveName: executiveName,
            executiveId: executiveId,
            createdDate: createdDate,
            synced: synced,
            rowid: rowid,
          ),
          getInsertCompanionBuilder: ({
            Value<String?> id = const Value.absent(),
            Value<String?> appLeaveId = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<DateTime?> startDate = const Value.absent(),
            Value<DateTime?> endDate = const Value.absent(),
            Value<String?> comments = const Value.absent(),
            Value<String?> reason = const Value.absent(),
            Value<String?> leaveType = const Value.absent(),
            Value<String?> leaveStatus = const Value.absent(),
            Value<DateTime?> lastModifiedDate = const Value.absent(),
            Value<String?> firstSecond = const Value.absent(),
            Value<String?> duration = const Value.absent(),
            Value<String?> executiveName = const Value.absent(),
            Value<String?> executiveId = const Value.absent(),
            Value<DateTime?> createdDate = const Value.absent(),
            Value<bool?> synced = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              LeavesCompanion.insert(
            id: id,
            appLeaveId: appLeaveId,
            name: name,
            startDate: startDate,
            endDate: endDate,
            comments: comments,
            reason: reason,
            leaveType: leaveType,
            leaveStatus: leaveStatus,
            lastModifiedDate: lastModifiedDate,
            firstSecond: firstSecond,
            duration: duration,
            executiveName: executiveName,
            executiveId: executiveId,
            createdDate: createdDate,
            synced: synced,
            rowid: rowid,
          ),
        ));
}

class $$LeavesTableProcessedTableManager extends ProcessedTableManager<
    _$DatabaseService,
    $LeavesTable,
    Leave,
    $$LeavesTableFilterComposer,
    $$LeavesTableOrderingComposer,
    $$LeavesTableProcessedTableManager,
    $$LeavesTableInsertCompanionBuilder,
    $$LeavesTableUpdateCompanionBuilder> {
  $$LeavesTableProcessedTableManager(super.$state);
}

class $$LeavesTableFilterComposer
    extends FilterComposer<_$DatabaseService, $LeavesTable> {
  $$LeavesTableFilterComposer(super.$state);
  ColumnFilters<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get appLeaveId => $state.composableBuilder(
      column: $state.table.appLeaveId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get startDate => $state.composableBuilder(
      column: $state.table.startDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get endDate => $state.composableBuilder(
      column: $state.table.endDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get comments => $state.composableBuilder(
      column: $state.table.comments,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get reason => $state.composableBuilder(
      column: $state.table.reason,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get leaveType => $state.composableBuilder(
      column: $state.table.leaveType,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get leaveStatus => $state.composableBuilder(
      column: $state.table.leaveStatus,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get lastModifiedDate => $state.composableBuilder(
      column: $state.table.lastModifiedDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get firstSecond => $state.composableBuilder(
      column: $state.table.firstSecond,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get duration => $state.composableBuilder(
      column: $state.table.duration,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get executiveName => $state.composableBuilder(
      column: $state.table.executiveName,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get executiveId => $state.composableBuilder(
      column: $state.table.executiveId,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get createdDate => $state.composableBuilder(
      column: $state.table.createdDate,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$LeavesTableOrderingComposer
    extends OrderingComposer<_$DatabaseService, $LeavesTable> {
  $$LeavesTableOrderingComposer(super.$state);
  ColumnOrderings<String> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get appLeaveId => $state.composableBuilder(
      column: $state.table.appLeaveId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get name => $state.composableBuilder(
      column: $state.table.name,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get startDate => $state.composableBuilder(
      column: $state.table.startDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get endDate => $state.composableBuilder(
      column: $state.table.endDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get comments => $state.composableBuilder(
      column: $state.table.comments,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get reason => $state.composableBuilder(
      column: $state.table.reason,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get leaveType => $state.composableBuilder(
      column: $state.table.leaveType,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get leaveStatus => $state.composableBuilder(
      column: $state.table.leaveStatus,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get lastModifiedDate => $state.composableBuilder(
      column: $state.table.lastModifiedDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get firstSecond => $state.composableBuilder(
      column: $state.table.firstSecond,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get duration => $state.composableBuilder(
      column: $state.table.duration,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get executiveName => $state.composableBuilder(
      column: $state.table.executiveName,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get executiveId => $state.composableBuilder(
      column: $state.table.executiveId,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get createdDate => $state.composableBuilder(
      column: $state.table.createdDate,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<bool> get synced => $state.composableBuilder(
      column: $state.table.synced,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

class _$DatabaseServiceManager {
  final _$DatabaseService _db;
  _$DatabaseServiceManager(this._db);
  $$AccountsTableTableManager get accounts =>
      $$AccountsTableTableManager(_db, _db.accounts);
  $$ProductsTableTableManager get products =>
      $$ProductsTableTableManager(_db, _db.products);
  $$VisitPlansTableTableManager get visitPlans =>
      $$VisitPlansTableTableManager(_db, _db.visitPlans);
  $$VisitsTableTableManager get visits =>
      $$VisitsTableTableManager(_db, _db.visits);
  $$DayLogsTableTableManager get dayLogs =>
      $$DayLogsTableTableManager(_db, _db.dayLogs);
  $$CartItemsTableTableManager get cartItems =>
      $$CartItemsTableTableManager(_db, _db.cartItems);
  $$OrdersTableTableManager get orders =>
      $$OrdersTableTableManager(_db, _db.orders);
  $$OrderItemsTableTableManager get orderItems =>
      $$OrderItemsTableTableManager(_db, _db.orderItems);
  $$VisitFilesTableTableManager get visitFiles =>
      $$VisitFilesTableTableManager(_db, _db.visitFiles);
  $$AccountRoutesTableTableManager get accountRoutes =>
      $$AccountRoutesTableTableManager(_db, _db.accountRoutes);
  $$ExpensesTableTableManager get expenses =>
      $$ExpensesTableTableManager(_db, _db.expenses);
  $$ExpenseItemsTableTableManager get expenseItems =>
      $$ExpenseItemsTableTableManager(_db, _db.expenseItems);
  $$ExpenseItemFilesTableTableManager get expenseItemFiles =>
      $$ExpenseItemFilesTableTableManager(_db, _db.expenseItemFiles);
  $$StocksTableTableManager get stocks =>
      $$StocksTableTableManager(_db, _db.stocks);
  $$TicketsTableTableManager get tickets =>
      $$TicketsTableTableManager(_db, _db.tickets);
  $$CompetitiorsTableTableManager get competitiors =>
      $$CompetitiorsTableTableManager(_db, _db.competitiors);
  $$CompetitionsTableTableManager get competitions =>
      $$CompetitionsTableTableManager(_db, _db.competitions);
  $$AccountFilesTableTableManager get accountFiles =>
      $$AccountFilesTableTableManager(_db, _db.accountFiles);
  $$PaymentFollowUpsTableTableManager get paymentFollowUps =>
      $$PaymentFollowUpsTableTableManager(_db, _db.paymentFollowUps);
  $$PaymentReceiptsTableTableManager get paymentReceipts =>
      $$PaymentReceiptsTableTableManager(_db, _db.paymentReceipts);
  $$InvoicesTableTableManager get invoices =>
      $$InvoicesTableTableManager(_db, _db.invoices);
  $$InvoiceItemsTableTableManager get invoiceItems =>
      $$InvoiceItemsTableTableManager(_db, _db.invoiceItems);
  $$LeavesTableTableManager get leaves =>
      $$LeavesTableTableManager(_db, _db.leaves);
}
