import 'package:drift/drift.dart';

import '../extensions/string.dart';
import '../models/latlng.dart';
import '../ui/tools/parse.dart';

import 'database.dart';

Visit? findLatestVisit({
  required List<Visit> visits,
  required Visit currentVisit,
}) {
  if (visits.isEmpty || currentVisit.actualStartTime == null) {
    return null;
  }

  List<Visit> filteredVisits = visits.where((visit) {
    return visit.actualEndTime != null &&
        visit.actualEndTime!.isBefore(currentVisit.actualStartTime!);
  }).toList();

  if (filteredVisits.isEmpty) return null;

  filteredVisits.sort((a, b) => b.actualEndTime!.compareTo(a.actualEndTime!));

  return filteredVisits.first;
  /* 
  if (visits.isEmpty) return null;

  visits.sort((a, b) {
    if (a.actualEndTime == null && b.actualEndTime == null) return 0;
    if (a.actualEndTime == null) return 1;
    if (b.actualEndTime == null) return -1;
    return b.actualEndTime!.compareTo(a.actualEndTime!);
  });

  return visits.first; 
  */
}

class CustomValueSerializer extends ValueSerializer {
  final bool serializeDateTimeValuesAsString;

  const CustomValueSerializer({
    this.serializeDateTimeValuesAsString = true,
  });

  @override
  T fromJson<T>(dynamic json) {
    if (json == null) {
      return null as T;
    }

    final typeList = <T>[];

    if (typeList is List<DateTime?>) {
      if (json is int) {
        return DateTime.fromMillisecondsSinceEpoch(json) as T;
      } else {
        return DateTime.tryParse(json.toString()) as T;
      }
    }

    if (typeList is List<double?> && json is int) {
      return json.toDouble() as T;
    }

    // blobs are encoded as a regular json array, so we manually convert that to
    // a Uint8List
    if (typeList is List<Uint8List?> && json is! Uint8List) {
      final asList = (json as List).cast<int>();
      return Uint8List.fromList(asList) as T;
    }

    if (json is Map) {
      Map map = json;
      Map<String, dynamic> newMap = map.map(
        (key, value) => MapEntry(key.toString(), value),
      );
      if (T.toString() == "LatLng?") {
        return LatLng.fromJson(newMap) as T;
      }
    }

    if (T.toString() == "String" || T.toString() == "String?") {
      return parseToString(json) as T;
    }

    if (T.toString() == "int" || T.toString() == "int?") {
      return parseToInt(json) as T;
    }

    if (T.toString() == "double" || T.toString() == "double?") {
      return parseToDouble(json) as T;
    }

    if (T.toString() == "bool" || T.toString() == "bool?") {
      return parseToBool(json) as T;
    }

    return json as T;
  }

  @override
  dynamic toJson<T>(T value) {
    if (value is DateTime) {
      return serializeDateTimeValuesAsString
          ? value.toIso8601String()
          : value.millisecondsSinceEpoch;
    }

    if (value is LatLng) {
      return value.toJson();
    }
    if (T.toString() == "LatLng?") {
      LatLng? latLng = value as LatLng?;
      return latLng?.toJson();
    }

    if (value is String) {
      if (value.isEmptyOrNull) {
        return null;
      }
    }

    return value;
  }
}
