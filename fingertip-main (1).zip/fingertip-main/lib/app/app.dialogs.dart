// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// StackedDialogGenerator
// **************************************************************************

import 'package:stacked_services/stacked_services.dart';

import 'app.locator.dart';
import '../ui/dialogs/account_file_upload/account_file_upload_dialog.dart';
import '../ui/dialogs/add_filter/add_filter_dialog.dart';
import '../ui/dialogs/add_product/add_product_dialog.dart';
import '../ui/dialogs/checkout/checkout_dialog.dart';
import '../ui/dialogs/choice/choice_dialog.dart';
import '../ui/dialogs/confirm/confirm_dialog.dart';
import '../ui/dialogs/info/info_dialog.dart';
import '../ui/dialogs/missed/missed_dialog.dart';

enum DialogType {
  confirm,
  missed,
  addProduct,
  checkout,
  info,
  addFilter,
  choice,
  accountFileUpload,
}

void setupDialogUi() {
  final dialogService = locator<DialogService>();

  final Map<DialogType, DialogBuilder> builders = {
    DialogType.confirm: (context, request, completer) =>
        ConfirmDialog(request: request, completer: completer),
    DialogType.missed: (context, request, completer) =>
        MissedDialog(request: request, completer: completer),
    DialogType.addProduct: (context, request, completer) =>
        AddProductDialog(request: request, completer: completer),
    DialogType.checkout: (context, request, completer) =>
        CheckoutDialog(request: request, completer: completer),
    DialogType.info: (context, request, completer) =>
        InfoDialog(request: request, completer: completer),
    DialogType.addFilter: (context, request, completer) =>
        AddFilterDialog(request: request, completer: completer),
    DialogType.choice: (context, request, completer) =>
        ChoiceDialog(request: request, completer: completer),
    DialogType.accountFileUpload: (context, request, completer) =>
        AccountFileUploadDialog(request: request, completer: completer),
  };

  dialogService.registerCustomDialogBuilders(builders);
}
