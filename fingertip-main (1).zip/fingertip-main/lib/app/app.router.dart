// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// StackedNavigatorGenerator
// **************************************************************************

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:fieldsales/models/sort.dart' as _i58;
import 'package:fieldsales/models/visit_plan.dart' as _i57;
import 'package:fieldsales/ui/screens/account/account_view.dart' as _i25;
import 'package:fieldsales/ui/screens/account_add/account_add_view.dart'
    as _i26;
import 'package:fieldsales/ui/screens/account_details/account_details_view.dart'
    as _i27;
import 'package:fieldsales/ui/screens/account_payment_follow_up/account_payment_follow_up_view.dart'
    as _i38;
import 'package:fieldsales/ui/screens/account_payment_follow_up_details/account_payment_follow_up_details_view.dart'
    as _i39;
import 'package:fieldsales/ui/screens/account_payment_receipt/account_payment_receipt_view.dart'
    as _i40;
import 'package:fieldsales/ui/screens/account_visits/account_visits_view.dart'
    as _i35;
import 'package:fieldsales/ui/screens/account_visits_details/account_visits_details_view.dart'
    as _i36;
import 'package:fieldsales/ui/screens/add_visit/add_visit_view.dart' as _i7;
import 'package:fieldsales/ui/screens/cart/cart_view.dart' as _i10;
import 'package:fieldsales/ui/screens/competition/competition_view.dart'
    as _i32;
import 'package:fieldsales/ui/screens/dashboard/dashboard_view.dart' as _i14;
import 'package:fieldsales/ui/screens/expense/expense_view.dart' as _i30;
import 'package:fieldsales/ui/screens/expense_new/expense_new_view.dart'
    as _i31;
import 'package:fieldsales/ui/screens/fetch/fetch_view.dart' as _i13;
import 'package:fieldsales/ui/screens/filter/filter_view.dart' as _i29;
import 'package:fieldsales/ui/screens/forgot_password/forgot_password_view.dart'
    as _i5;
import 'package:fieldsales/ui/screens/home/home_view.dart' as _i2;
import 'package:fieldsales/ui/screens/invoice/invoice_view.dart' as _i48;
import 'package:fieldsales/ui/screens/invoice_details/invoice_details_view.dart'
    as _i49;
import 'package:fieldsales/ui/screens/invoice_line_item/invoice_line_item_view.dart'
    as _i50;
import 'package:fieldsales/ui/screens/kpi/kpi_view.dart' as _i16;
import 'package:fieldsales/ui/screens/last_orders/last_orders_view.dart'
    as _i12;
import 'package:fieldsales/ui/screens/leave/leave_view.dart' as _i51;
import 'package:fieldsales/ui/screens/leave_details/leave_details_view.dart'
    as _i53;
import 'package:fieldsales/ui/screens/leave_new/leave_new_view.dart' as _i52;
import 'package:fieldsales/ui/screens/login/login_view.dart' as _i4;
import 'package:fieldsales/ui/screens/menu/menu_view.dart' as _i6;
import 'package:fieldsales/ui/screens/order/order_view.dart' as _i43;
import 'package:fieldsales/ui/screens/order_details/order_details_view.dart'
    as _i44;
import 'package:fieldsales/ui/screens/order_line_item/order_line_item_view.dart'
    as _i45;
import 'package:fieldsales/ui/screens/order_success/order_success_view.dart'
    as _i11;
import 'package:fieldsales/ui/screens/payment_follow_up_add/payment_follow_up_add_view.dart'
    as _i37;
import 'package:fieldsales/ui/screens/payment_receipt/payment_receipt_view.dart'
    as _i42;
import 'package:fieldsales/ui/screens/payment_receipt_details/payment_receipt_details_view.dart'
    as _i41;
import 'package:fieldsales/ui/screens/products/products_view.dart' as _i9;
import 'package:fieldsales/ui/screens/profile/profile_view.dart' as _i15;
import 'package:fieldsales/ui/screens/search/search_view.dart' as _i17;
import 'package:fieldsales/ui/screens/sort/sort_view.dart' as _i28;
import 'package:fieldsales/ui/screens/splash/splash_view.dart' as _i3;
import 'package:fieldsales/ui/screens/stock/stock_view.dart' as _i33;
import 'package:fieldsales/ui/screens/ticket/ticket_view.dart' as _i34;
import 'package:fieldsales/ui/screens/ticket_details/ticket_details_view.dart'
    as _i47;
import 'package:fieldsales/ui/screens/ticket_new/ticket_new_view.dart' as _i46;
import 'package:fieldsales/ui/screens/todays_visit/todays_visit_view.dart'
    as _i18;
import 'package:fieldsales/ui/screens/visit/visit_view.dart' as _i8;
import 'package:fieldsales/ui/screens/visit_plan/visit_plan_view.dart' as _i19;
import 'package:fieldsales/ui/screens/visit_plan_add_one/visit_plan_add_one_view.dart'
    as _i22;
import 'package:fieldsales/ui/screens/visit_plan_add_two/visit_plan_add_two_view.dart'
    as _i23;
import 'package:fieldsales/ui/screens/visit_plan_details/visit_plan_details_view.dart'
    as _i21;
import 'package:fieldsales/ui/screens/visit_plan_new/visit_plan_new_view.dart'
    as _i20;
import 'package:fieldsales/ui/screens/visit_plan_visits/visit_plan_visits_view.dart'
    as _i24;
import 'package:fieldsales/ui/screens/visit_preview/visit_preview_view.dart'
    as _i54;
import 'package:flutter/foundation.dart' as _i56;
import 'package:flutter/material.dart';
import 'package:flutter/material.dart' as _i55;
import 'package:stacked/stacked.dart' as _i1;
import 'package:stacked_services/stacked_services.dart' as _i59;

class Routes {
  static const homeView = '/home-view';

  static const splashView = '/splash-view';

  static const loginView = '/login-view';

  static const forgotPasswordView = '/forgot-password-view';

  static const menuView = '/menu-view';

  static const addVisitView = '/add-visit-view';

  static const visitView = '/visit-view';

  static const productsView = '/products-view';

  static const cartView = '/cart-view';

  static const orderSuccessView = '/order-success-view';

  static const lastOrdersView = '/last-orders-view';

  static const fetchView = '/fetch-view';

  static const dashboardView = '/dashboard-view';

  static const profileView = '/profile-view';

  static const kpiView = '/kpi-view';

  static const searchView = '/search-view';

  static const todaysVisitView = '/todays-visit-view';

  static const visitPlanView = '/visit-plan-view';

  static const visitPlanNewView = '/visit-plan-new-view';

  static const visitPlanDetailsView = '/visit-plan-details-view';

  static const visitPlanAddOneView = '/visit-plan-add-one-view';

  static const visitPlanAddTwoView = '/visit-plan-add-two-view';

  static const visitPlanVisitsView = '/visit-plan-visits-view';

  static const accountView = '/account-view';

  static const accountAddView = '/account-add-view';

  static const accountDetailsView = '/account-details-view';

  static const sortView = '/sort-view';

  static const filterView = '/filter-view';

  static const expenseView = '/expense-view';

  static const expenseNewView = '/expense-new-view';

  static const competitionView = '/competition-view';

  static const stockView = '/stock-view';

  static const ticketView = '/ticket-view';

  static const accountVisitsView = '/account-visits-view';

  static const accountVisitsDetailsView = '/account-visits-details-view';

  static const paymentFollowUpAddView = '/payment-follow-up-add-view';

  static const accountPaymentFollowUpView = '/account-payment-follow-up-view';

  static const accountPaymentFollowUpDetailsView =
      '/account-payment-follow-up-details-view';

  static const accountPaymentReceiptView = '/account-payment-receipt-view';

  static const paymentReceiptDetailsView = '/payment-receipt-details-view';

  static const paymentReceiptView = '/payment-receipt-view';

  static const orderView = '/order-view';

  static const orderDetailsView = '/order-details-view';

  static const orderLineItemView = '/order-line-item-view';

  static const ticketNewView = '/ticket-new-view';

  static const ticketDetailsView = '/ticket-details-view';

  static const invoiceView = '/invoice-view';

  static const invoiceDetailsView = '/invoice-details-view';

  static const invoiceLineItemView = '/invoice-line-item-view';

  static const leaveView = '/leave-view';

  static const leaveNewView = '/leave-new-view';

  static const leaveDetailsView = '/leave-details-view';

  static const visitPreviewView = '/visit-preview-view';

  static const all = <String>{
    homeView,
    splashView,
    loginView,
    forgotPasswordView,
    menuView,
    addVisitView,
    visitView,
    productsView,
    cartView,
    orderSuccessView,
    lastOrdersView,
    fetchView,
    dashboardView,
    profileView,
    kpiView,
    searchView,
    todaysVisitView,
    visitPlanView,
    visitPlanNewView,
    visitPlanDetailsView,
    visitPlanAddOneView,
    visitPlanAddTwoView,
    visitPlanVisitsView,
    accountView,
    accountAddView,
    accountDetailsView,
    sortView,
    filterView,
    expenseView,
    expenseNewView,
    competitionView,
    stockView,
    ticketView,
    accountVisitsView,
    accountVisitsDetailsView,
    paymentFollowUpAddView,
    accountPaymentFollowUpView,
    accountPaymentFollowUpDetailsView,
    accountPaymentReceiptView,
    paymentReceiptDetailsView,
    paymentReceiptView,
    orderView,
    orderDetailsView,
    orderLineItemView,
    ticketNewView,
    ticketDetailsView,
    invoiceView,
    invoiceDetailsView,
    invoiceLineItemView,
    leaveView,
    leaveNewView,
    leaveDetailsView,
    visitPreviewView,
  };
}

class StackedRouter extends _i1.RouterBase {
  final _routes = <_i1.RouteDef>[
    _i1.RouteDef(
      Routes.homeView,
      page: _i2.HomeView,
    ),
    _i1.RouteDef(
      Routes.splashView,
      page: _i3.SplashView,
    ),
    _i1.RouteDef(
      Routes.loginView,
      page: _i4.LoginView,
    ),
    _i1.RouteDef(
      Routes.forgotPasswordView,
      page: _i5.ForgotPasswordView,
    ),
    _i1.RouteDef(
      Routes.menuView,
      page: _i6.MenuView,
    ),
    _i1.RouteDef(
      Routes.addVisitView,
      page: _i7.AddVisitView,
    ),
    _i1.RouteDef(
      Routes.visitView,
      page: _i8.VisitView,
    ),
    _i1.RouteDef(
      Routes.productsView,
      page: _i9.ProductsView,
    ),
    _i1.RouteDef(
      Routes.cartView,
      page: _i10.CartView,
    ),
    _i1.RouteDef(
      Routes.orderSuccessView,
      page: _i11.OrderSuccessView,
    ),
    _i1.RouteDef(
      Routes.lastOrdersView,
      page: _i12.LastOrdersView,
    ),
    _i1.RouteDef(
      Routes.fetchView,
      page: _i13.FetchView,
    ),
    _i1.RouteDef(
      Routes.dashboardView,
      page: _i14.DashboardView,
    ),
    _i1.RouteDef(
      Routes.profileView,
      page: _i15.ProfileView,
    ),
    _i1.RouteDef(
      Routes.kpiView,
      page: _i16.KpiView,
    ),
    _i1.RouteDef(
      Routes.searchView,
      page: _i17.SearchView,
    ),
    _i1.RouteDef(
      Routes.todaysVisitView,
      page: _i18.TodaysVisitView,
    ),
    _i1.RouteDef(
      Routes.visitPlanView,
      page: _i19.VisitPlanView,
    ),
    _i1.RouteDef(
      Routes.visitPlanNewView,
      page: _i20.VisitPlanNewView,
    ),
    _i1.RouteDef(
      Routes.visitPlanDetailsView,
      page: _i21.VisitPlanDetailsView,
    ),
    _i1.RouteDef(
      Routes.visitPlanAddOneView,
      page: _i22.VisitPlanAddOneView,
    ),
    _i1.RouteDef(
      Routes.visitPlanAddTwoView,
      page: _i23.VisitPlanAddTwoView,
    ),
    _i1.RouteDef(
      Routes.visitPlanVisitsView,
      page: _i24.VisitPlanVisitsView,
    ),
    _i1.RouteDef(
      Routes.accountView,
      page: _i25.AccountView,
    ),
    _i1.RouteDef(
      Routes.accountAddView,
      page: _i26.AccountAddView,
    ),
    _i1.RouteDef(
      Routes.accountDetailsView,
      page: _i27.AccountDetailsView,
    ),
    _i1.RouteDef(
      Routes.sortView,
      page: _i28.SortView,
    ),
    _i1.RouteDef(
      Routes.filterView,
      page: _i29.FilterView,
    ),
    _i1.RouteDef(
      Routes.expenseView,
      page: _i30.ExpenseView,
    ),
    _i1.RouteDef(
      Routes.expenseNewView,
      page: _i31.ExpenseNewView,
    ),
    _i1.RouteDef(
      Routes.competitionView,
      page: _i32.CompetitionView,
    ),
    _i1.RouteDef(
      Routes.stockView,
      page: _i33.StockView,
    ),
    _i1.RouteDef(
      Routes.ticketView,
      page: _i34.TicketView,
    ),
    _i1.RouteDef(
      Routes.accountVisitsView,
      page: _i35.AccountVisitsView,
    ),
    _i1.RouteDef(
      Routes.accountVisitsDetailsView,
      page: _i36.AccountVisitsDetailsView,
    ),
    _i1.RouteDef(
      Routes.paymentFollowUpAddView,
      page: _i37.PaymentFollowUpAddView,
    ),
    _i1.RouteDef(
      Routes.accountPaymentFollowUpView,
      page: _i38.AccountPaymentFollowUpView,
    ),
    _i1.RouteDef(
      Routes.accountPaymentFollowUpDetailsView,
      page: _i39.AccountPaymentFollowUpDetailsView,
    ),
    _i1.RouteDef(
      Routes.accountPaymentReceiptView,
      page: _i40.AccountPaymentReceiptView,
    ),
    _i1.RouteDef(
      Routes.paymentReceiptDetailsView,
      page: _i41.PaymentReceiptDetailsView,
    ),
    _i1.RouteDef(
      Routes.paymentReceiptView,
      page: _i42.PaymentReceiptView,
    ),
    _i1.RouteDef(
      Routes.orderView,
      page: _i43.OrderView,
    ),
    _i1.RouteDef(
      Routes.orderDetailsView,
      page: _i44.OrderDetailsView,
    ),
    _i1.RouteDef(
      Routes.orderLineItemView,
      page: _i45.OrderLineItemView,
    ),
    _i1.RouteDef(
      Routes.ticketNewView,
      page: _i46.TicketNewView,
    ),
    _i1.RouteDef(
      Routes.ticketDetailsView,
      page: _i47.TicketDetailsView,
    ),
    _i1.RouteDef(
      Routes.invoiceView,
      page: _i48.InvoiceView,
    ),
    _i1.RouteDef(
      Routes.invoiceDetailsView,
      page: _i49.InvoiceDetailsView,
    ),
    _i1.RouteDef(
      Routes.invoiceLineItemView,
      page: _i50.InvoiceLineItemView,
    ),
    _i1.RouteDef(
      Routes.leaveView,
      page: _i51.LeaveView,
    ),
    _i1.RouteDef(
      Routes.leaveNewView,
      page: _i52.LeaveNewView,
    ),
    _i1.RouteDef(
      Routes.leaveDetailsView,
      page: _i53.LeaveDetailsView,
    ),
    _i1.RouteDef(
      Routes.visitPreviewView,
      page: _i54.VisitPreviewView,
    ),
  ];

  final _pagesMap = <Type, _i1.StackedRouteFactory>{
    _i2.HomeView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i2.HomeView(),
        settings: data,
      );
    },
    _i3.SplashView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i3.SplashView(),
        settings: data,
      );
    },
    _i4.LoginView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i4.LoginView(),
        settings: data,
      );
    },
    _i5.ForgotPasswordView: (data) {
      final args = data.getArgs<ForgotPasswordViewArguments>(
        orElse: () => const ForgotPasswordViewArguments(),
      );
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i5.ForgotPasswordView(key: args.key, userName: args.userName),
        settings: data,
      );
    },
    _i6.MenuView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i6.MenuView(),
        settings: data,
      );
    },
    _i7.AddVisitView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i7.AddVisitView(),
        settings: data,
      );
    },
    _i8.VisitView: (data) {
      final args = data.getArgs<VisitViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i8.VisitView(key: args.key, visitMap: args.visitMap),
        settings: data,
      );
    },
    _i9.ProductsView: (data) {
      final args = data.getArgs<ProductsViewArguments>(
        orElse: () => const ProductsViewArguments(),
      );
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i9.ProductsView(key: args.key, visitMap: args.visitMap),
        settings: data,
      );
    },
    _i10.CartView: (data) {
      final args = data.getArgs<CartViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => _i10.CartView(
            key: args.key,
            visitMap: args.visitMap,
            accountMap: args.accountMap),
        settings: data,
      );
    },
    _i11.OrderSuccessView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i11.OrderSuccessView(),
        settings: data,
      );
    },
    _i12.LastOrdersView: (data) {
      final args = data.getArgs<LastOrdersViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i12.LastOrdersView(key: args.key, lastVisitMap: args.lastVisitMap),
        settings: data,
      );
    },
    _i13.FetchView: (data) {
      final args = data.getArgs<FetchViewArguments>(
        orElse: () => const FetchViewArguments(),
      );
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => _i13.FetchView(
            key: args.key,
            clearData: args.clearData,
            clearSyncedData: args.clearSyncedData),
        settings: data,
      );
    },
    _i14.DashboardView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i14.DashboardView(),
        settings: data,
      );
    },
    _i15.ProfileView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i15.ProfileView(),
        settings: data,
      );
    },
    _i16.KpiView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i16.KpiView(),
        settings: data,
      );
    },
    _i17.SearchView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i17.SearchView(),
        settings: data,
      );
    },
    _i18.TodaysVisitView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i18.TodaysVisitView(),
        settings: data,
      );
    },
    _i19.VisitPlanView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i19.VisitPlanView(),
        settings: data,
      );
    },
    _i20.VisitPlanNewView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i20.VisitPlanNewView(),
        settings: data,
      );
    },
    _i21.VisitPlanDetailsView: (data) {
      final args = data.getArgs<VisitPlanDetailsViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => _i21.VisitPlanDetailsView(
            key: args.key, appVisitPlanId: args.appVisitPlanId),
        settings: data,
      );
    },
    _i22.VisitPlanAddOneView: (data) {
      final args = data.getArgs<VisitPlanAddOneViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i22.VisitPlanAddOneView(key: args.key, params: args.params),
        settings: data,
      );
    },
    _i23.VisitPlanAddTwoView: (data) {
      final args = data.getArgs<VisitPlanAddTwoViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i23.VisitPlanAddTwoView(key: args.key, params: args.params),
        settings: data,
      );
    },
    _i24.VisitPlanVisitsView: (data) {
      final args = data.getArgs<VisitPlanVisitsViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => _i24.VisitPlanVisitsView(
            key: args.key,
            appVisitPlanId: args.appVisitPlanId,
            date: args.date),
        settings: data,
      );
    },
    _i25.AccountView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i25.AccountView(),
        settings: data,
      );
    },
    _i26.AccountAddView: (data) {
      final args = data.getArgs<AccountAddViewArguments>(
        orElse: () => const AccountAddViewArguments(),
      );
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i26.AccountAddView(key: args.key, appAccountId: args.appAccountId),
        settings: data,
      );
    },
    _i27.AccountDetailsView: (data) {
      final args = data.getArgs<AccountDetailsViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => _i27.AccountDetailsView(
            key: args.key,
            appAccountId: args.appAccountId,
            accountId: args.accountId),
        settings: data,
      );
    },
    _i28.SortView: (data) {
      final args = data.getArgs<SortViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => _i28.SortView(
            key: args.key,
            initalValue: args.initalValue,
            sortOptions: args.sortOptions),
        settings: data,
      );
    },
    _i29.FilterView: (data) {
      final args = data.getArgs<FilterViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => _i29.FilterView(
            key: args.key,
            filters: args.filters,
            selectedFilters: args.selectedFilters),
        settings: data,
      );
    },
    _i30.ExpenseView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i30.ExpenseView(),
        settings: data,
      );
    },
    _i31.ExpenseNewView: (data) {
      final args = data.getArgs<ExpenseNewViewArguments>(
        orElse: () => const ExpenseNewViewArguments(),
      );
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i31.ExpenseNewView(key: args.key, appExpId: args.appExpId),
        settings: data,
      );
    },
    _i32.CompetitionView: (data) {
      final args = data.getArgs<CompetitionViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i32.CompetitionView(key: args.key, visitMap: args.visitMap),
        settings: data,
      );
    },
    _i33.StockView: (data) {
      final args = data.getArgs<StockViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i33.StockView(key: args.key, visitMap: args.visitMap),
        settings: data,
      );
    },
    _i34.TicketView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i34.TicketView(),
        settings: data,
      );
    },
    _i35.AccountVisitsView: (data) {
      final args = data.getArgs<AccountVisitsViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => _i35.AccountVisitsView(
            key: args.key, appAccountId: args.appAccountId),
        settings: data,
      );
    },
    _i36.AccountVisitsDetailsView: (data) {
      final args =
          data.getArgs<AccountVisitsDetailsViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => _i36.AccountVisitsDetailsView(
            key: args.key, salesAppId: args.salesAppId),
        settings: data,
      );
    },
    _i37.PaymentFollowUpAddView: (data) {
      final args = data.getArgs<PaymentFollowUpAddViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i37.PaymentFollowUpAddView(key: args.key, visitMap: args.visitMap),
        settings: data,
      );
    },
    _i38.AccountPaymentFollowUpView: (data) {
      final args =
          data.getArgs<AccountPaymentFollowUpViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => _i38.AccountPaymentFollowUpView(
            key: args.key, appAccountId: args.appAccountId),
        settings: data,
      );
    },
    _i39.AccountPaymentFollowUpDetailsView: (data) {
      final args = data.getArgs<AccountPaymentFollowUpDetailsViewArguments>(
          nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => _i39.AccountPaymentFollowUpDetailsView(
            key: args.key, appPaymentFollowUpId: args.appPaymentFollowUpId),
        settings: data,
      );
    },
    _i40.AccountPaymentReceiptView: (data) {
      final args =
          data.getArgs<AccountPaymentReceiptViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => _i40.AccountPaymentReceiptView(
            key: args.key,
            appAccountId: args.appAccountId,
            accountId: args.accountId),
        settings: data,
      );
    },
    _i41.PaymentReceiptDetailsView: (data) {
      final args =
          data.getArgs<PaymentReceiptDetailsViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => _i41.PaymentReceiptDetailsView(
            key: args.key, paymentReceiptId: args.paymentReceiptId),
        settings: data,
      );
    },
    _i42.PaymentReceiptView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i42.PaymentReceiptView(),
        settings: data,
      );
    },
    _i43.OrderView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i43.OrderView(),
        settings: data,
      );
    },
    _i44.OrderDetailsView: (data) {
      final args = data.getArgs<OrderDetailsViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i44.OrderDetailsView(key: args.key, appOrderId: args.appOrderId),
        settings: data,
      );
    },
    _i45.OrderLineItemView: (data) {
      final args = data.getArgs<OrderLineItemViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i45.OrderLineItemView(key: args.key, appOrderId: args.appOrderId),
        settings: data,
      );
    },
    _i46.TicketNewView: (data) {
      final args = data.getArgs<TicketNewViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i46.TicketNewView(key: args.key, visitMap: args.visitMap),
        settings: data,
      );
    },
    _i47.TicketDetailsView: (data) {
      final args = data.getArgs<TicketDetailsViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i47.TicketDetailsView(key: args.key, ticketId: args.ticketId),
        settings: data,
      );
    },
    _i48.InvoiceView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i48.InvoiceView(),
        settings: data,
      );
    },
    _i49.InvoiceDetailsView: (data) {
      final args = data.getArgs<InvoiceDetailsViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => _i49.InvoiceDetailsView(
            key: args.key, appInvoiceId: args.appInvoiceId),
        settings: data,
      );
    },
    _i50.InvoiceLineItemView: (data) {
      final args = data.getArgs<InvoiceLineItemViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => _i50.InvoiceLineItemView(
            key: args.key, appInvoiceId: args.appInvoiceId),
        settings: data,
      );
    },
    _i51.LeaveView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i51.LeaveView(),
        settings: data,
      );
    },
    _i52.LeaveNewView: (data) {
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => const _i52.LeaveNewView(),
        settings: data,
      );
    },
    _i53.LeaveDetailsView: (data) {
      final args = data.getArgs<LeaveDetailsViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) =>
            _i53.LeaveDetailsView(key: args.key, appLeaveId: args.appLeaveId),
        settings: data,
      );
    },
    _i54.VisitPreviewView: (data) {
      final args = data.getArgs<VisitPreviewViewArguments>(nullOk: false);
      return _i55.MaterialPageRoute<dynamic>(
        builder: (context) => _i54.VisitPreviewView(
            key: args.key,
            salesAppId: args.salesAppId,
            accountId: args.accountId),
        settings: data,
      );
    },
  };

  @override
  List<_i1.RouteDef> get routes => _routes;

  @override
  Map<Type, _i1.StackedRouteFactory> get pagesMap => _pagesMap;
}

class ForgotPasswordViewArguments {
  const ForgotPasswordViewArguments({
    this.key,
    this.userName,
  });

  final _i56.Key? key;

  final String? userName;

  @override
  String toString() {
    return '{"key": "$key", "userName": "$userName"}';
  }

  @override
  bool operator ==(covariant ForgotPasswordViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.userName == userName;
  }

  @override
  int get hashCode {
    return key.hashCode ^ userName.hashCode;
  }
}

class VisitViewArguments {
  const VisitViewArguments({
    this.key,
    required this.visitMap,
  });

  final _i56.Key? key;

  final Map<String, dynamic> visitMap;

  @override
  String toString() {
    return '{"key": "$key", "visitMap": "$visitMap"}';
  }

  @override
  bool operator ==(covariant VisitViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.visitMap == visitMap;
  }

  @override
  int get hashCode {
    return key.hashCode ^ visitMap.hashCode;
  }
}

class ProductsViewArguments {
  const ProductsViewArguments({
    this.key,
    this.visitMap,
  });

  final _i56.Key? key;

  final Map<String, dynamic>? visitMap;

  @override
  String toString() {
    return '{"key": "$key", "visitMap": "$visitMap"}';
  }

  @override
  bool operator ==(covariant ProductsViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.visitMap == visitMap;
  }

  @override
  int get hashCode {
    return key.hashCode ^ visitMap.hashCode;
  }
}

class CartViewArguments {
  const CartViewArguments({
    this.key,
    this.visitMap,
    required this.accountMap,
  });

  final _i56.Key? key;

  final Map<String, dynamic>? visitMap;

  final Map<String, dynamic> accountMap;

  @override
  String toString() {
    return '{"key": "$key", "visitMap": "$visitMap", "accountMap": "$accountMap"}';
  }

  @override
  bool operator ==(covariant CartViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key &&
        other.visitMap == visitMap &&
        other.accountMap == accountMap;
  }

  @override
  int get hashCode {
    return key.hashCode ^ visitMap.hashCode ^ accountMap.hashCode;
  }
}

class LastOrdersViewArguments {
  const LastOrdersViewArguments({
    this.key,
    required this.lastVisitMap,
  });

  final _i56.Key? key;

  final Map<String, dynamic> lastVisitMap;

  @override
  String toString() {
    return '{"key": "$key", "lastVisitMap": "$lastVisitMap"}';
  }

  @override
  bool operator ==(covariant LastOrdersViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.lastVisitMap == lastVisitMap;
  }

  @override
  int get hashCode {
    return key.hashCode ^ lastVisitMap.hashCode;
  }
}

class FetchViewArguments {
  const FetchViewArguments({
    this.key,
    this.clearData = false,
    this.clearSyncedData = false,
  });

  final _i56.Key? key;

  final bool clearData;

  final bool clearSyncedData;

  @override
  String toString() {
    return '{"key": "$key", "clearData": "$clearData", "clearSyncedData": "$clearSyncedData"}';
  }

  @override
  bool operator ==(covariant FetchViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key &&
        other.clearData == clearData &&
        other.clearSyncedData == clearSyncedData;
  }

  @override
  int get hashCode {
    return key.hashCode ^ clearData.hashCode ^ clearSyncedData.hashCode;
  }
}

class VisitPlanDetailsViewArguments {
  const VisitPlanDetailsViewArguments({
    this.key,
    required this.appVisitPlanId,
  });

  final _i56.Key? key;

  final String appVisitPlanId;

  @override
  String toString() {
    return '{"key": "$key", "appVisitPlanId": "$appVisitPlanId"}';
  }

  @override
  bool operator ==(covariant VisitPlanDetailsViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.appVisitPlanId == appVisitPlanId;
  }

  @override
  int get hashCode {
    return key.hashCode ^ appVisitPlanId.hashCode;
  }
}

class VisitPlanAddOneViewArguments {
  const VisitPlanAddOneViewArguments({
    this.key,
    required this.params,
  });

  final _i56.Key? key;

  final _i57.VisitPlanAddParams params;

  @override
  String toString() {
    return '{"key": "$key", "params": "$params"}';
  }

  @override
  bool operator ==(covariant VisitPlanAddOneViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.params == params;
  }

  @override
  int get hashCode {
    return key.hashCode ^ params.hashCode;
  }
}

class VisitPlanAddTwoViewArguments {
  const VisitPlanAddTwoViewArguments({
    this.key,
    required this.params,
  });

  final _i56.Key? key;

  final _i57.VisitPlanAddParams params;

  @override
  String toString() {
    return '{"key": "$key", "params": "$params"}';
  }

  @override
  bool operator ==(covariant VisitPlanAddTwoViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.params == params;
  }

  @override
  int get hashCode {
    return key.hashCode ^ params.hashCode;
  }
}

class VisitPlanVisitsViewArguments {
  const VisitPlanVisitsViewArguments({
    this.key,
    required this.appVisitPlanId,
    required this.date,
  });

  final _i56.Key? key;

  final String appVisitPlanId;

  final DateTime date;

  @override
  String toString() {
    return '{"key": "$key", "appVisitPlanId": "$appVisitPlanId", "date": "$date"}';
  }

  @override
  bool operator ==(covariant VisitPlanVisitsViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key &&
        other.appVisitPlanId == appVisitPlanId &&
        other.date == date;
  }

  @override
  int get hashCode {
    return key.hashCode ^ appVisitPlanId.hashCode ^ date.hashCode;
  }
}

class AccountAddViewArguments {
  const AccountAddViewArguments({
    this.key,
    this.appAccountId,
  });

  final _i56.Key? key;

  final String? appAccountId;

  @override
  String toString() {
    return '{"key": "$key", "appAccountId": "$appAccountId"}';
  }

  @override
  bool operator ==(covariant AccountAddViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.appAccountId == appAccountId;
  }

  @override
  int get hashCode {
    return key.hashCode ^ appAccountId.hashCode;
  }
}

class AccountDetailsViewArguments {
  const AccountDetailsViewArguments({
    this.key,
    required this.appAccountId,
    this.accountId,
  });

  final _i56.Key? key;

  final String appAccountId;

  final String? accountId;

  @override
  String toString() {
    return '{"key": "$key", "appAccountId": "$appAccountId", "accountId": "$accountId"}';
  }

  @override
  bool operator ==(covariant AccountDetailsViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key &&
        other.appAccountId == appAccountId &&
        other.accountId == accountId;
  }

  @override
  int get hashCode {
    return key.hashCode ^ appAccountId.hashCode ^ accountId.hashCode;
  }
}

class SortViewArguments {
  const SortViewArguments({
    this.key,
    required this.initalValue,
    required this.sortOptions,
  });

  final _i56.Key? key;

  final _i58.SortModel initalValue;

  final List<_i58.SortModel> sortOptions;

  @override
  String toString() {
    return '{"key": "$key", "initalValue": "$initalValue", "sortOptions": "$sortOptions"}';
  }

  @override
  bool operator ==(covariant SortViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key &&
        other.initalValue == initalValue &&
        other.sortOptions == sortOptions;
  }

  @override
  int get hashCode {
    return key.hashCode ^ initalValue.hashCode ^ sortOptions.hashCode;
  }
}

class FilterViewArguments {
  const FilterViewArguments({
    this.key,
    required this.filters,
    required this.selectedFilters,
  });

  final _i56.Key? key;

  final List<_i58.FilterModel> filters;

  final List<_i58.FilterModel> selectedFilters;

  @override
  String toString() {
    return '{"key": "$key", "filters": "$filters", "selectedFilters": "$selectedFilters"}';
  }

  @override
  bool operator ==(covariant FilterViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key &&
        other.filters == filters &&
        other.selectedFilters == selectedFilters;
  }

  @override
  int get hashCode {
    return key.hashCode ^ filters.hashCode ^ selectedFilters.hashCode;
  }
}

class ExpenseNewViewArguments {
  const ExpenseNewViewArguments({
    this.key,
    this.appExpId,
  });

  final _i56.Key? key;

  final String? appExpId;

  @override
  String toString() {
    return '{"key": "$key", "appExpId": "$appExpId"}';
  }

  @override
  bool operator ==(covariant ExpenseNewViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.appExpId == appExpId;
  }

  @override
  int get hashCode {
    return key.hashCode ^ appExpId.hashCode;
  }
}

class CompetitionViewArguments {
  const CompetitionViewArguments({
    this.key,
    required this.visitMap,
  });

  final _i56.Key? key;

  final Map<String, dynamic> visitMap;

  @override
  String toString() {
    return '{"key": "$key", "visitMap": "$visitMap"}';
  }

  @override
  bool operator ==(covariant CompetitionViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.visitMap == visitMap;
  }

  @override
  int get hashCode {
    return key.hashCode ^ visitMap.hashCode;
  }
}

class StockViewArguments {
  const StockViewArguments({
    this.key,
    required this.visitMap,
  });

  final _i56.Key? key;

  final Map<String, dynamic> visitMap;

  @override
  String toString() {
    return '{"key": "$key", "visitMap": "$visitMap"}';
  }

  @override
  bool operator ==(covariant StockViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.visitMap == visitMap;
  }

  @override
  int get hashCode {
    return key.hashCode ^ visitMap.hashCode;
  }
}

class AccountVisitsViewArguments {
  const AccountVisitsViewArguments({
    this.key,
    required this.appAccountId,
  });

  final _i56.Key? key;

  final String appAccountId;

  @override
  String toString() {
    return '{"key": "$key", "appAccountId": "$appAccountId"}';
  }

  @override
  bool operator ==(covariant AccountVisitsViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.appAccountId == appAccountId;
  }

  @override
  int get hashCode {
    return key.hashCode ^ appAccountId.hashCode;
  }
}

class AccountVisitsDetailsViewArguments {
  const AccountVisitsDetailsViewArguments({
    this.key,
    required this.salesAppId,
  });

  final _i56.Key? key;

  final String salesAppId;

  @override
  String toString() {
    return '{"key": "$key", "salesAppId": "$salesAppId"}';
  }

  @override
  bool operator ==(covariant AccountVisitsDetailsViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.salesAppId == salesAppId;
  }

  @override
  int get hashCode {
    return key.hashCode ^ salesAppId.hashCode;
  }
}

class PaymentFollowUpAddViewArguments {
  const PaymentFollowUpAddViewArguments({
    this.key,
    required this.visitMap,
  });

  final _i56.Key? key;

  final Map<String, dynamic> visitMap;

  @override
  String toString() {
    return '{"key": "$key", "visitMap": "$visitMap"}';
  }

  @override
  bool operator ==(covariant PaymentFollowUpAddViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.visitMap == visitMap;
  }

  @override
  int get hashCode {
    return key.hashCode ^ visitMap.hashCode;
  }
}

class AccountPaymentFollowUpViewArguments {
  const AccountPaymentFollowUpViewArguments({
    this.key,
    required this.appAccountId,
  });

  final _i56.Key? key;

  final String appAccountId;

  @override
  String toString() {
    return '{"key": "$key", "appAccountId": "$appAccountId"}';
  }

  @override
  bool operator ==(covariant AccountPaymentFollowUpViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.appAccountId == appAccountId;
  }

  @override
  int get hashCode {
    return key.hashCode ^ appAccountId.hashCode;
  }
}

class AccountPaymentFollowUpDetailsViewArguments {
  const AccountPaymentFollowUpDetailsViewArguments({
    this.key,
    required this.appPaymentFollowUpId,
  });

  final _i56.Key? key;

  final String appPaymentFollowUpId;

  @override
  String toString() {
    return '{"key": "$key", "appPaymentFollowUpId": "$appPaymentFollowUpId"}';
  }

  @override
  bool operator ==(covariant AccountPaymentFollowUpDetailsViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key &&
        other.appPaymentFollowUpId == appPaymentFollowUpId;
  }

  @override
  int get hashCode {
    return key.hashCode ^ appPaymentFollowUpId.hashCode;
  }
}

class AccountPaymentReceiptViewArguments {
  const AccountPaymentReceiptViewArguments({
    this.key,
    required this.appAccountId,
    this.accountId,
  });

  final _i56.Key? key;

  final String appAccountId;

  final String? accountId;

  @override
  String toString() {
    return '{"key": "$key", "appAccountId": "$appAccountId", "accountId": "$accountId"}';
  }

  @override
  bool operator ==(covariant AccountPaymentReceiptViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key &&
        other.appAccountId == appAccountId &&
        other.accountId == accountId;
  }

  @override
  int get hashCode {
    return key.hashCode ^ appAccountId.hashCode ^ accountId.hashCode;
  }
}

class PaymentReceiptDetailsViewArguments {
  const PaymentReceiptDetailsViewArguments({
    this.key,
    required this.paymentReceiptId,
  });

  final _i56.Key? key;

  final String paymentReceiptId;

  @override
  String toString() {
    return '{"key": "$key", "paymentReceiptId": "$paymentReceiptId"}';
  }

  @override
  bool operator ==(covariant PaymentReceiptDetailsViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.paymentReceiptId == paymentReceiptId;
  }

  @override
  int get hashCode {
    return key.hashCode ^ paymentReceiptId.hashCode;
  }
}

class OrderDetailsViewArguments {
  const OrderDetailsViewArguments({
    this.key,
    required this.appOrderId,
  });

  final _i56.Key? key;

  final String appOrderId;

  @override
  String toString() {
    return '{"key": "$key", "appOrderId": "$appOrderId"}';
  }

  @override
  bool operator ==(covariant OrderDetailsViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.appOrderId == appOrderId;
  }

  @override
  int get hashCode {
    return key.hashCode ^ appOrderId.hashCode;
  }
}

class OrderLineItemViewArguments {
  const OrderLineItemViewArguments({
    this.key,
    required this.appOrderId,
  });

  final _i56.Key? key;

  final String appOrderId;

  @override
  String toString() {
    return '{"key": "$key", "appOrderId": "$appOrderId"}';
  }

  @override
  bool operator ==(covariant OrderLineItemViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.appOrderId == appOrderId;
  }

  @override
  int get hashCode {
    return key.hashCode ^ appOrderId.hashCode;
  }
}

class TicketNewViewArguments {
  const TicketNewViewArguments({
    this.key,
    required this.visitMap,
  });

  final _i56.Key? key;

  final Map<String, dynamic> visitMap;

  @override
  String toString() {
    return '{"key": "$key", "visitMap": "$visitMap"}';
  }

  @override
  bool operator ==(covariant TicketNewViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.visitMap == visitMap;
  }

  @override
  int get hashCode {
    return key.hashCode ^ visitMap.hashCode;
  }
}

class TicketDetailsViewArguments {
  const TicketDetailsViewArguments({
    this.key,
    required this.ticketId,
  });

  final _i56.Key? key;

  final String ticketId;

  @override
  String toString() {
    return '{"key": "$key", "ticketId": "$ticketId"}';
  }

  @override
  bool operator ==(covariant TicketDetailsViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.ticketId == ticketId;
  }

  @override
  int get hashCode {
    return key.hashCode ^ ticketId.hashCode;
  }
}

class InvoiceDetailsViewArguments {
  const InvoiceDetailsViewArguments({
    this.key,
    required this.appInvoiceId,
  });

  final _i56.Key? key;

  final String appInvoiceId;

  @override
  String toString() {
    return '{"key": "$key", "appInvoiceId": "$appInvoiceId"}';
  }

  @override
  bool operator ==(covariant InvoiceDetailsViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.appInvoiceId == appInvoiceId;
  }

  @override
  int get hashCode {
    return key.hashCode ^ appInvoiceId.hashCode;
  }
}

class InvoiceLineItemViewArguments {
  const InvoiceLineItemViewArguments({
    this.key,
    required this.appInvoiceId,
  });

  final _i56.Key? key;

  final String appInvoiceId;

  @override
  String toString() {
    return '{"key": "$key", "appInvoiceId": "$appInvoiceId"}';
  }

  @override
  bool operator ==(covariant InvoiceLineItemViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.appInvoiceId == appInvoiceId;
  }

  @override
  int get hashCode {
    return key.hashCode ^ appInvoiceId.hashCode;
  }
}

class LeaveDetailsViewArguments {
  const LeaveDetailsViewArguments({
    this.key,
    required this.appLeaveId,
  });

  final _i56.Key? key;

  final String appLeaveId;

  @override
  String toString() {
    return '{"key": "$key", "appLeaveId": "$appLeaveId"}';
  }

  @override
  bool operator ==(covariant LeaveDetailsViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key && other.appLeaveId == appLeaveId;
  }

  @override
  int get hashCode {
    return key.hashCode ^ appLeaveId.hashCode;
  }
}

class VisitPreviewViewArguments {
  const VisitPreviewViewArguments({
    this.key,
    required this.salesAppId,
    this.accountId,
  });

  final _i56.Key? key;

  final String salesAppId;

  final String? accountId;

  @override
  String toString() {
    return '{"key": "$key", "salesAppId": "$salesAppId", "accountId": "$accountId"}';
  }

  @override
  bool operator ==(covariant VisitPreviewViewArguments other) {
    if (identical(this, other)) return true;
    return other.key == key &&
        other.salesAppId == salesAppId &&
        other.accountId == accountId;
  }

  @override
  int get hashCode {
    return key.hashCode ^ salesAppId.hashCode ^ accountId.hashCode;
  }
}

extension NavigatorStateExtension on _i59.NavigationService {
  Future<dynamic> navigateToHomeView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.homeView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToSplashView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.splashView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToLoginView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.loginView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToForgotPasswordView({
    _i56.Key? key,
    String? userName,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.forgotPasswordView,
        arguments: ForgotPasswordViewArguments(key: key, userName: userName),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToMenuView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.menuView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToAddVisitView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.addVisitView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToVisitView({
    _i56.Key? key,
    required Map<String, dynamic> visitMap,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.visitView,
        arguments: VisitViewArguments(key: key, visitMap: visitMap),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToProductsView({
    _i56.Key? key,
    Map<String, dynamic>? visitMap,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.productsView,
        arguments: ProductsViewArguments(key: key, visitMap: visitMap),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToCartView({
    _i56.Key? key,
    Map<String, dynamic>? visitMap,
    required Map<String, dynamic> accountMap,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.cartView,
        arguments: CartViewArguments(
            key: key, visitMap: visitMap, accountMap: accountMap),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToOrderSuccessView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.orderSuccessView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToLastOrdersView({
    _i56.Key? key,
    required Map<String, dynamic> lastVisitMap,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.lastOrdersView,
        arguments:
            LastOrdersViewArguments(key: key, lastVisitMap: lastVisitMap),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToFetchView({
    _i56.Key? key,
    bool clearData = false,
    bool clearSyncedData = false,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.fetchView,
        arguments: FetchViewArguments(
            key: key, clearData: clearData, clearSyncedData: clearSyncedData),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToDashboardView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.dashboardView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToProfileView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.profileView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToKpiView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.kpiView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToSearchView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.searchView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToTodaysVisitView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.todaysVisitView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToVisitPlanView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.visitPlanView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToVisitPlanNewView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.visitPlanNewView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToVisitPlanDetailsView({
    _i56.Key? key,
    required String appVisitPlanId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.visitPlanDetailsView,
        arguments: VisitPlanDetailsViewArguments(
            key: key, appVisitPlanId: appVisitPlanId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToVisitPlanAddOneView({
    _i56.Key? key,
    required _i57.VisitPlanAddParams params,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.visitPlanAddOneView,
        arguments: VisitPlanAddOneViewArguments(key: key, params: params),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToVisitPlanAddTwoView({
    _i56.Key? key,
    required _i57.VisitPlanAddParams params,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.visitPlanAddTwoView,
        arguments: VisitPlanAddTwoViewArguments(key: key, params: params),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToVisitPlanVisitsView({
    _i56.Key? key,
    required String appVisitPlanId,
    required DateTime date,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.visitPlanVisitsView,
        arguments: VisitPlanVisitsViewArguments(
            key: key, appVisitPlanId: appVisitPlanId, date: date),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToAccountView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.accountView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToAccountAddView({
    _i56.Key? key,
    String? appAccountId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.accountAddView,
        arguments:
            AccountAddViewArguments(key: key, appAccountId: appAccountId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToAccountDetailsView({
    _i56.Key? key,
    required String appAccountId,
    String? accountId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.accountDetailsView,
        arguments: AccountDetailsViewArguments(
            key: key, appAccountId: appAccountId, accountId: accountId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToSortView({
    _i56.Key? key,
    required _i58.SortModel initalValue,
    required List<_i58.SortModel> sortOptions,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.sortView,
        arguments: SortViewArguments(
            key: key, initalValue: initalValue, sortOptions: sortOptions),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToFilterView({
    _i56.Key? key,
    required List<_i58.FilterModel> filters,
    required List<_i58.FilterModel> selectedFilters,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.filterView,
        arguments: FilterViewArguments(
            key: key, filters: filters, selectedFilters: selectedFilters),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToExpenseView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.expenseView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToExpenseNewView({
    _i56.Key? key,
    String? appExpId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.expenseNewView,
        arguments: ExpenseNewViewArguments(key: key, appExpId: appExpId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToCompetitionView({
    _i56.Key? key,
    required Map<String, dynamic> visitMap,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.competitionView,
        arguments: CompetitionViewArguments(key: key, visitMap: visitMap),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToStockView({
    _i56.Key? key,
    required Map<String, dynamic> visitMap,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.stockView,
        arguments: StockViewArguments(key: key, visitMap: visitMap),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToTicketView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.ticketView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToAccountVisitsView({
    _i56.Key? key,
    required String appAccountId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.accountVisitsView,
        arguments:
            AccountVisitsViewArguments(key: key, appAccountId: appAccountId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToAccountVisitsDetailsView({
    _i56.Key? key,
    required String salesAppId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.accountVisitsDetailsView,
        arguments:
            AccountVisitsDetailsViewArguments(key: key, salesAppId: salesAppId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToPaymentFollowUpAddView({
    _i56.Key? key,
    required Map<String, dynamic> visitMap,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.paymentFollowUpAddView,
        arguments:
            PaymentFollowUpAddViewArguments(key: key, visitMap: visitMap),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToAccountPaymentFollowUpView({
    _i56.Key? key,
    required String appAccountId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.accountPaymentFollowUpView,
        arguments: AccountPaymentFollowUpViewArguments(
            key: key, appAccountId: appAccountId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToAccountPaymentFollowUpDetailsView({
    _i56.Key? key,
    required String appPaymentFollowUpId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.accountPaymentFollowUpDetailsView,
        arguments: AccountPaymentFollowUpDetailsViewArguments(
            key: key, appPaymentFollowUpId: appPaymentFollowUpId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToAccountPaymentReceiptView({
    _i56.Key? key,
    required String appAccountId,
    String? accountId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.accountPaymentReceiptView,
        arguments: AccountPaymentReceiptViewArguments(
            key: key, appAccountId: appAccountId, accountId: accountId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToPaymentReceiptDetailsView({
    _i56.Key? key,
    required String paymentReceiptId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.paymentReceiptDetailsView,
        arguments: PaymentReceiptDetailsViewArguments(
            key: key, paymentReceiptId: paymentReceiptId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToPaymentReceiptView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.paymentReceiptView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToOrderView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.orderView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToOrderDetailsView({
    _i56.Key? key,
    required String appOrderId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.orderDetailsView,
        arguments: OrderDetailsViewArguments(key: key, appOrderId: appOrderId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToOrderLineItemView({
    _i56.Key? key,
    required String appOrderId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.orderLineItemView,
        arguments: OrderLineItemViewArguments(key: key, appOrderId: appOrderId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToTicketNewView({
    _i56.Key? key,
    required Map<String, dynamic> visitMap,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.ticketNewView,
        arguments: TicketNewViewArguments(key: key, visitMap: visitMap),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToTicketDetailsView({
    _i56.Key? key,
    required String ticketId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.ticketDetailsView,
        arguments: TicketDetailsViewArguments(key: key, ticketId: ticketId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToInvoiceView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.invoiceView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToInvoiceDetailsView({
    _i56.Key? key,
    required String appInvoiceId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.invoiceDetailsView,
        arguments:
            InvoiceDetailsViewArguments(key: key, appInvoiceId: appInvoiceId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToInvoiceLineItemView({
    _i56.Key? key,
    required String appInvoiceId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.invoiceLineItemView,
        arguments:
            InvoiceLineItemViewArguments(key: key, appInvoiceId: appInvoiceId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToLeaveView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.leaveView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToLeaveNewView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return navigateTo<dynamic>(Routes.leaveNewView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToLeaveDetailsView({
    _i56.Key? key,
    required String appLeaveId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.leaveDetailsView,
        arguments: LeaveDetailsViewArguments(key: key, appLeaveId: appLeaveId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> navigateToVisitPreviewView({
    _i56.Key? key,
    required String salesAppId,
    String? accountId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return navigateTo<dynamic>(Routes.visitPreviewView,
        arguments: VisitPreviewViewArguments(
            key: key, salesAppId: salesAppId, accountId: accountId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithHomeView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.homeView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithSplashView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.splashView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithLoginView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.loginView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithForgotPasswordView({
    _i56.Key? key,
    String? userName,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.forgotPasswordView,
        arguments: ForgotPasswordViewArguments(key: key, userName: userName),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithMenuView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.menuView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithAddVisitView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.addVisitView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithVisitView({
    _i56.Key? key,
    required Map<String, dynamic> visitMap,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.visitView,
        arguments: VisitViewArguments(key: key, visitMap: visitMap),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithProductsView({
    _i56.Key? key,
    Map<String, dynamic>? visitMap,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.productsView,
        arguments: ProductsViewArguments(key: key, visitMap: visitMap),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithCartView({
    _i56.Key? key,
    Map<String, dynamic>? visitMap,
    required Map<String, dynamic> accountMap,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.cartView,
        arguments: CartViewArguments(
            key: key, visitMap: visitMap, accountMap: accountMap),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithOrderSuccessView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.orderSuccessView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithLastOrdersView({
    _i56.Key? key,
    required Map<String, dynamic> lastVisitMap,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.lastOrdersView,
        arguments:
            LastOrdersViewArguments(key: key, lastVisitMap: lastVisitMap),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithFetchView({
    _i56.Key? key,
    bool clearData = false,
    bool clearSyncedData = false,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.fetchView,
        arguments: FetchViewArguments(
            key: key, clearData: clearData, clearSyncedData: clearSyncedData),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithDashboardView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.dashboardView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithProfileView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.profileView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithKpiView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.kpiView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithSearchView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.searchView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithTodaysVisitView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.todaysVisitView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithVisitPlanView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.visitPlanView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithVisitPlanNewView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.visitPlanNewView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithVisitPlanDetailsView({
    _i56.Key? key,
    required String appVisitPlanId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.visitPlanDetailsView,
        arguments: VisitPlanDetailsViewArguments(
            key: key, appVisitPlanId: appVisitPlanId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithVisitPlanAddOneView({
    _i56.Key? key,
    required _i57.VisitPlanAddParams params,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.visitPlanAddOneView,
        arguments: VisitPlanAddOneViewArguments(key: key, params: params),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithVisitPlanAddTwoView({
    _i56.Key? key,
    required _i57.VisitPlanAddParams params,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.visitPlanAddTwoView,
        arguments: VisitPlanAddTwoViewArguments(key: key, params: params),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithVisitPlanVisitsView({
    _i56.Key? key,
    required String appVisitPlanId,
    required DateTime date,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.visitPlanVisitsView,
        arguments: VisitPlanVisitsViewArguments(
            key: key, appVisitPlanId: appVisitPlanId, date: date),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithAccountView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.accountView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithAccountAddView({
    _i56.Key? key,
    String? appAccountId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.accountAddView,
        arguments:
            AccountAddViewArguments(key: key, appAccountId: appAccountId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithAccountDetailsView({
    _i56.Key? key,
    required String appAccountId,
    String? accountId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.accountDetailsView,
        arguments: AccountDetailsViewArguments(
            key: key, appAccountId: appAccountId, accountId: accountId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithSortView({
    _i56.Key? key,
    required _i58.SortModel initalValue,
    required List<_i58.SortModel> sortOptions,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.sortView,
        arguments: SortViewArguments(
            key: key, initalValue: initalValue, sortOptions: sortOptions),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithFilterView({
    _i56.Key? key,
    required List<_i58.FilterModel> filters,
    required List<_i58.FilterModel> selectedFilters,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.filterView,
        arguments: FilterViewArguments(
            key: key, filters: filters, selectedFilters: selectedFilters),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithExpenseView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.expenseView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithExpenseNewView({
    _i56.Key? key,
    String? appExpId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.expenseNewView,
        arguments: ExpenseNewViewArguments(key: key, appExpId: appExpId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithCompetitionView({
    _i56.Key? key,
    required Map<String, dynamic> visitMap,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.competitionView,
        arguments: CompetitionViewArguments(key: key, visitMap: visitMap),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithStockView({
    _i56.Key? key,
    required Map<String, dynamic> visitMap,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.stockView,
        arguments: StockViewArguments(key: key, visitMap: visitMap),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithTicketView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.ticketView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithAccountVisitsView({
    _i56.Key? key,
    required String appAccountId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.accountVisitsView,
        arguments:
            AccountVisitsViewArguments(key: key, appAccountId: appAccountId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithAccountVisitsDetailsView({
    _i56.Key? key,
    required String salesAppId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.accountVisitsDetailsView,
        arguments:
            AccountVisitsDetailsViewArguments(key: key, salesAppId: salesAppId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithPaymentFollowUpAddView({
    _i56.Key? key,
    required Map<String, dynamic> visitMap,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.paymentFollowUpAddView,
        arguments:
            PaymentFollowUpAddViewArguments(key: key, visitMap: visitMap),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithAccountPaymentFollowUpView({
    _i56.Key? key,
    required String appAccountId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.accountPaymentFollowUpView,
        arguments: AccountPaymentFollowUpViewArguments(
            key: key, appAccountId: appAccountId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithAccountPaymentFollowUpDetailsView({
    _i56.Key? key,
    required String appPaymentFollowUpId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.accountPaymentFollowUpDetailsView,
        arguments: AccountPaymentFollowUpDetailsViewArguments(
            key: key, appPaymentFollowUpId: appPaymentFollowUpId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithAccountPaymentReceiptView({
    _i56.Key? key,
    required String appAccountId,
    String? accountId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.accountPaymentReceiptView,
        arguments: AccountPaymentReceiptViewArguments(
            key: key, appAccountId: appAccountId, accountId: accountId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithPaymentReceiptDetailsView({
    _i56.Key? key,
    required String paymentReceiptId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.paymentReceiptDetailsView,
        arguments: PaymentReceiptDetailsViewArguments(
            key: key, paymentReceiptId: paymentReceiptId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithPaymentReceiptView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.paymentReceiptView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithOrderView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.orderView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithOrderDetailsView({
    _i56.Key? key,
    required String appOrderId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.orderDetailsView,
        arguments: OrderDetailsViewArguments(key: key, appOrderId: appOrderId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithOrderLineItemView({
    _i56.Key? key,
    required String appOrderId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.orderLineItemView,
        arguments: OrderLineItemViewArguments(key: key, appOrderId: appOrderId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithTicketNewView({
    _i56.Key? key,
    required Map<String, dynamic> visitMap,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.ticketNewView,
        arguments: TicketNewViewArguments(key: key, visitMap: visitMap),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithTicketDetailsView({
    _i56.Key? key,
    required String ticketId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.ticketDetailsView,
        arguments: TicketDetailsViewArguments(key: key, ticketId: ticketId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithInvoiceView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.invoiceView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithInvoiceDetailsView({
    _i56.Key? key,
    required String appInvoiceId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.invoiceDetailsView,
        arguments:
            InvoiceDetailsViewArguments(key: key, appInvoiceId: appInvoiceId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithInvoiceLineItemView({
    _i56.Key? key,
    required String appInvoiceId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.invoiceLineItemView,
        arguments:
            InvoiceLineItemViewArguments(key: key, appInvoiceId: appInvoiceId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithLeaveView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.leaveView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithLeaveNewView([
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  ]) async {
    return replaceWith<dynamic>(Routes.leaveNewView,
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithLeaveDetailsView({
    _i56.Key? key,
    required String appLeaveId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.leaveDetailsView,
        arguments: LeaveDetailsViewArguments(key: key, appLeaveId: appLeaveId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }

  Future<dynamic> replaceWithVisitPreviewView({
    _i56.Key? key,
    required String salesAppId,
    String? accountId,
    int? routerId,
    bool preventDuplicates = true,
    Map<String, String>? parameters,
    Widget Function(BuildContext, Animation<double>, Animation<double>, Widget)?
        transition,
  }) async {
    return replaceWith<dynamic>(Routes.visitPreviewView,
        arguments: VisitPreviewViewArguments(
            key: key, salesAppId: salesAppId, accountId: accountId),
        id: routerId,
        preventDuplicates: preventDuplicates,
        parameters: parameters,
        transition: transition);
  }
}
