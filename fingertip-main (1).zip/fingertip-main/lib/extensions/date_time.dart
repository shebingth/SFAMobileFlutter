import 'package:flutter/foundation.dart';

import 'package:intl/intl.dart';

extension DateTimeExtensions on DateTime? {
  bool isBetweenDates({
    required DateTime startDate,
    required DateTime endDate,
  }) {
    DateTime startDateIST = startDate.toLocal();
    DateTime endDateIST = endDate.toLocal();
    if (this != null) {
      DateTime thisIST = this!.toLocal();
      if (thisIST.isDateEqual(date: startDateIST) ||
          thisIST.isDateEqual(date: endDateIST)) {
        return true;
      }

      return thisIST.isAfter(startDate) && thisIST.isBefore(endDate);
    }

    return false;
  }

  bool isDateEqual({DateTime? date}) {
    if (date != null && this != null) {
      DateTime dateIST = date.toLocal();
      DateTime thisIST = this!.toLocal();

      return dateIST.year == thisIST.year &&
          dateIST.month == thisIST.month &&
          dateIST.day == thisIST.day;
    }

    return false;
  }

  // DateTime? toIST() {
  //   if (this != null) {
  //     return this!.isUtc
  //         ? this!.add(const Duration(hours: 5, minutes: 30))
  //         : this!.toUtc().add(const Duration(hours: 5, minutes: 30));
  //   }

  //   return null;
  // }

  String? toFormattedDateTime({
    String format = "dd-MM-yyyy hh:mm a",
  }) {
    try {
      if (this != null) {
        var ist = this!.toLocal();
        return DateFormat(format).format(ist);
      }
    } catch (e) {
      debugPrint("Date Format Exception : $e");
    }

    return null;
  }

  String? toFormattedDate({
    String format = "dd-MM-yyyy",
  }) {
    try {
      if (this != null) {
        var ist = this!.toLocal();
        return DateFormat(format).format(ist);
      }
    } catch (e) {
      debugPrint("Date Format Exception : $e");
    }

    return null;
  }

  String? toFormattedTime({
    String format = "hh:mm a",
  }) {
    try {
      if (this != null) {
        var ist = this!.toLocal();
        return DateFormat(format).format(ist);
      }
    } catch (e) {
      debugPrint("Date Format Exception : $e");
    }

    return null;
  }
}
