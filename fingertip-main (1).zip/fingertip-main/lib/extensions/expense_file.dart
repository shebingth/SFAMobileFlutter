import 'dart:convert';

import '../database/database.dart';

extension ExpenseItemFileExtension on ExpenseItemFile {
  String get fileNameWithoutExtension {
    List<String> parts = fileName?.split('.') ?? [];

    if (parts.isEmpty) return '';

    if (parts.length > 1) {
      parts.removeLast();
    }
    return parts.join('.');
  }

  Map<String, dynamic> toApi({
    required String? recordId,
  }) {
    return <String, dynamic>{
      "attributes": {"type": "ContentVersion", "referenceId": id},
      "Title": fileNameWithoutExtension,
      "PathOnClient": fileName,
      "ContentLocation": "S",
      "ExternalDocumentInfo1": recordId,
      "ExternalDocumentInfo2": "FromApp",
      "VersionData": base64Encode(file),
    };
  }
}
