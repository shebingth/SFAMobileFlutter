import '../database/database.dart';
import '../database/tools.dart';
import '../models/latlng.dart';

extension DayLogExtension on DayLog {
  Map<String, dynamic> toApi() {
    var serializer = const CustomValueSerializer();
    return <String, dynamic>{
      'dayStartTime': serializer.toJson<DateTime>(dayStartTime),
      'dayEndTime': serializer.toJson<DateTime?>(dayEndTime),
      'startLocation': serializer.toJson<LatLng>(startLocation),
      'endLocation': serializer.toJson<LatLng?>(endLocation),
    };
  }
}
