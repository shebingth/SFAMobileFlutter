import 'dart:io';

extension FileExtensions on File {
  String get fileName {
    return uri.pathSegments.last;
  }

  String get formatedSize {
    const int kb = 1024;
    const int mb = kb * 1024;
    const int gb = mb * 1024;

    final int fileSize = lengthSync();

    if (fileSize < kb) {
      return '$fileSize B';
    } else if (fileSize < mb) {
      final double sizeInKB = fileSize / kb;
      return '${sizeInKB.toStringAsFixed(2)} KB';
    } else if (fileSize < gb) {
      final double sizeInMB = fileSize / mb;
      return '${sizeInMB.toStringAsFixed(2)} MB';
    } else {
      final double sizeInGB = fileSize / gb;
      return '${sizeInGB.toStringAsFixed(2)} GB';
    }
  }
}

extension FileListExtensions on List<File> {
  String get formattedTotalSize {
    final int totalSize = fold<int>(0, (acc, file) => acc + file.lengthSync());
    return _formatBytes(totalSize);
  }

  double get totalSizeInMB {
    final int totalSize = fold<int>(0, (acc, file) => acc + file.lengthSync());
    return totalSize / (1024 * 1024);
  }

  String _formatBytes(int bytes) {
    const int kb = 1024;
    const int mb = kb * 1024;
    const int gb = mb * 1024;

    if (bytes < kb) {
      return '$bytes B';
    } else if (bytes < mb) {
      final double sizeInKB = bytes / kb;
      return '${sizeInKB.toStringAsFixed(2)} KB';
    } else if (bytes < gb) {
      final double sizeInMB = bytes / mb;
      return '${sizeInMB.toStringAsFixed(2)} MB';
    } else {
      final double sizeInGB = bytes / gb;
      return '${sizeInGB.toStringAsFixed(2)} GB';
    }
  }
}
