import 'dart:convert';

import '../database/database.dart';

extension VisitFileExtension on VisitFile {
  String get fileNameWithoutExtension {
    List<String> parts = fileName?.split('.') ?? [];

    if (parts.isEmpty) return '';

    if (parts.length > 1) {
      parts.removeLast();
    }
    return parts.join('.');
  }

  Map<String, dynamic> toApi({
    required String? visitRecordId,
  }) {
    return <String, dynamic>{
      "attributes": {"type": "ContentVersion", "referenceId": id},
      "Title": fileNameWithoutExtension,
      "PathOnClient": fileName,
      "ContentLocation": "S",
      "ExternalDocumentInfo1": visitRecordId,
      "ExternalDocumentInfo2": "FromApp",
      "VersionData": base64Encode(file),
    };
  }
}
