extension StringExtensions on String? {
  bool get isNotEmptyOrNull {
    return this != null && this!.isNotEmpty;
  }

  bool get isEmptyOrNull {
    return this == null || this!.isEmpty;
  }

  String get toFirstLetters {
    if (isEmptyOrNull) {
      return '';
    }

    return this!.split(' ').map((e) {
      if (e.trim().isNotEmpty) {
        return e.trim()[0].toUpperCase();
      }
      return '';
    }).join();
  }

  String? prefixWith(String prefix) {
    if (isNotEmptyOrNull) {
      return "$prefix $this";
    }

    return null;
  }

  String? suffixWith(String suffix) {
    if (isNotEmptyOrNull) {
      return "$this $suffix";
    }

    return null;
  }
}
