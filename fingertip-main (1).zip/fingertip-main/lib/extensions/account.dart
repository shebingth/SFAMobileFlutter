import 'dart:convert';

import '../app/app.router.dart';
import '../database/database.dart';
import '../database/tools.dart';
import '../models/search.dart';
import '../ui/common/assets.gen.dart';
import '../ui/common/utils.dart';

import 'date_time.dart';
import 'iterable.dart';
import 'string.dart';

extension AccountExtension on Account {
  Map<String, dynamic> toApi() {
    var serializer = const CustomValueSerializer();

    return <String, dynamic>{
      'appAccountId': serializer.toJson<String?>(appAccountId),
      'id': serializer.toJson<String?>(id),
      'name': serializer.toJson<String?>(name),
      'accountOwnerId': serializer.toJson<String?>(accountOwnerId),
      'accountOwnerName': serializer.toJson<String?>(accountOwnerName),
      'contactPersonName': serializer.toJson<String?>(contactPersonName),
      'email': serializer.toJson<String?>(email),
      'mobile': serializer.toJson<String?>(mobile),
      'alternateMobile': serializer.toJson<String?>(alternateMobile),
      'gstNo': serializer.toJson<String?>(gstNo),
      'description': serializer.toJson<String?>(description),
      'liquidation': serializer.toJson<String?>(liquidation),
      'paymentType': serializer.toJson<String?>(paymentType),
      'accountClassification':
          serializer.toJson<String?>(accountClassification),
      'grade': serializer.toJson<String?>(grade),
      'routesId': serializer.toJson<String?>(routesId),
      'routesName': serializer.toJson<String?>(routesName),
      'actlong': serializer.toJson<String?>(longitude),
      'actlat': serializer.toJson<String?>(latitude),
      'parentAccountId': serializer.toJson<String?>(parentAccountId),
      'parentAccountName': serializer.toJson<String?>(parentAccountName),
      'outstanding': serializer.toJson<String?>(outstanding),
      'avgCreditDays': serializer.toJson<String?>(avgCreditDays),
      'openingBalance': serializer.toJson<String?>(openingBalance),
      'streetName': serializer.toJson<String?>(streetName),
      'panchayat': serializer.toJson<String?>(panchayat),
      'city': serializer.toJson<String?>(city),
      'state': serializer.toJson<String?>(state),
      'district': serializer.toJson<String?>(district),
      'pincode': serializer.toJson<String?>(pincode),
      'approvalStatus': serializer.toJson<String?>(approvalStatus),
      'lastmodifiedDate': serializer.toJson<DateTime?>(lastModifiedDate),
      'lastmodifiedBy': serializer.toJson<String?>(lastModifiedBy),
      'createdDate': serializer.toJson<DateTime?>(createdDate),
      'createdBy': serializer.toJson<String?>(createdBy),
    };
  }

  SearchItemModel? searchField({
    required String? Function() field,
    required String keyword,
  }) {
    var fieldValue = field();
    if (fieldValue?.toLowerCase().contains(keyword.toLowerCase()) ?? false) {
      return SearchItemModel(
        image: Assets.images.user2.image(),
        module: 'Account',
        text: fieldValue!,
        reference: name ?? "",
        onTap: () {
          if (appAccountId.isNotEmptyOrNull) {
            navigationService.navigateToAccountDetailsView(
              appAccountId: appAccountId!,
              accountId: id,
            );
          }
        },
      );
    }

    return null;
  }

  List<SearchItemModel> search(String keyword) {
    return [
      searchField(keyword: keyword, field: () => name),
      searchField(keyword: keyword, field: () => email),
      searchField(keyword: keyword, field: () => mobile),
      searchField(keyword: keyword, field: () => alternateMobile),
      searchField(keyword: keyword, field: () => panchayat),
      searchField(keyword: keyword, field: () => city),
      searchField(keyword: keyword, field: () => district),
      searchField(keyword: keyword, field: () => state),
      searchField(keyword: keyword, field: () => pincode),
      searchField(keyword: keyword, field: () => accountOwnerName),
      searchField(keyword: keyword, field: () => contactPersonName),
      searchField(keyword: keyword, field: () => accountClassification),
      searchField(keyword: keyword, field: () => grade),
      searchField(keyword: keyword, field: () => routesName),
      searchField(keyword: keyword, field: () => approvalStatus),
      searchField(keyword: keyword, field: () => parentAccountName),
      searchField(keyword: keyword, field: () => description),
      searchField(keyword: keyword, field: () => gstNo),
      searchField(keyword: keyword, field: () => openingBalance),
      searchField(keyword: keyword, field: () => liquidation),
      searchField(keyword: keyword, field: () => paymentType),
      searchField(keyword: keyword, field: () => streetName),
      searchField(keyword: keyword, field: () => outstanding),
      searchField(keyword: keyword, field: () => avgCreditDays),
      searchField(keyword: keyword, field: () => latitude),
      searchField(keyword: keyword, field: () => longitude),
      searchField(keyword: keyword, field: () => lastModifiedBy),
      searchField(
        keyword: keyword,
        field: () => lastModifiedDate?.toFormattedDate(),
      ),
      searchField(keyword: keyword, field: () => createdBy),
      searchField(
        keyword: keyword,
        field: () => createdDate?.toFormattedDateTime(),
      ),
    ].whereNotNull().toList();
  }
}

extension AccountListExtension on List<Account> {
  List<SearchItemModel> search(String keyword) {
    return expand(
      (element) => element.search(keyword),
    ).toList();
  }
}

extension AccountFileExtension on AccountFile {
  String get fileNameWithoutExtension {
    List<String> parts = fileName?.split('.') ?? [];

    if (parts.isEmpty) return '';

    if (parts.length > 1) {
      parts.removeLast();
    }
    return parts.join('.');
  }

  Map<String, dynamic> toApi({
    required String? recordId,
  }) {
    return <String, dynamic>{
      "attributes": {"type": "ContentVersion", "referenceId": id},
      "Title": fileNameWithoutExtension,
      "PathOnClient": fileName,
      "ContentLocation": "S",
      "ExternalDocumentInfo1": recordId,
      "ExternalDocumentInfo2": "FromApp",
      "VersionData": base64Encode(file),
    };
  }
}
