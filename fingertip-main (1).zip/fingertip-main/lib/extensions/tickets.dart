import '../app/app.router.dart';
import '../database/database.dart';
import '../models/search.dart';
import '../ui/common/assets.gen.dart';
import '../ui/common/utils.dart';

import 'iterable.dart';
import 'string.dart';

extension TicketsExtensions on Ticket {
  SearchItemModel? searchField({
    required String? Function() field,
    required String keyword,
  }) {
    var fieldValue = field();
    if (fieldValue?.toLowerCase().contains(keyword.toLowerCase()) ?? false) {
      return SearchItemModel(
        image: Assets.images.ticket.image(),
        module: 'Ticket',
        text: fieldValue!,
        reference: subject ?? "",
        onTap: () {
          if (appTicketId.isNotEmptyOrNull) {
            navigationService.navigateToTicketDetailsView(
              ticketId: appTicketId!,
            );
          }
        },
      );
    }

    return null;
  }

  List<SearchItemModel> search(String keyword) {
    return [
      searchField(keyword: keyword, field: () => subject),
      searchField(keyword: keyword, field: () => accountName),
      searchField(keyword: keyword, field: () => description),
      searchField(keyword: keyword, field: () => status),
      searchField(keyword: keyword, field: () => complaintType),
    ].whereNotNull().toList();
  }
}

extension TicketsListExtension on List<Ticket> {
  List<SearchItemModel> search(String keyword) {
    return expand(
      (element) => element.search(keyword),
    ).toList();
  }
}
