import 'package:location/location.dart';

import '../models/latlng.dart';

extension LocationDataExtensions on LocationData? {
  LatLng? get latLng {
    if (this?.latitude != null && this?.longitude != null) {
      return LatLng(lat: this!.latitude!, lng: this!.longitude!);
    }
    return null;
  }
}
