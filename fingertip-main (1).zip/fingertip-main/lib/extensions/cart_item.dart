import '../database/database.dart';

extension CartItemExtensions on CartItem {
  double getTaxAmount() {
    return unitPrice * taxPercent / 100;
  }

  double getTotalTax() {
    return getTaxAmount() * quantity;
  }

  double getTotalAmount() {
    return unitPrice * quantity;
  }

  double getGrantTotal() {
    return getTotalAmount() + getTotalTax();
  }
}
