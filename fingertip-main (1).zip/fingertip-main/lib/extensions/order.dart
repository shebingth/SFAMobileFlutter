import '../app/app.router.dart';
import '../database/database.dart';
import '../models/search.dart';
import '../ui/common/assets.gen.dart';
import '../ui/common/utils.dart';
import '../ui/tools/parse.dart';

import 'date_time.dart';
import 'iterable.dart';
import 'string.dart';

extension OrderExtension on Order {
  SearchItemModel? searchField({
    required String? Function() field,
    required String keyword,
  }) {
    var fieldValue = field();
    if (fieldValue?.toLowerCase().contains(keyword.toLowerCase()) ?? false) {
      return SearchItemModel(
        image: Assets.images.orders.image(),
        module: 'Order',
        text: fieldValue!,
        reference: name ?? "",
        onTap: () {
          if (appOrderId.isNotEmptyOrNull) {
            navigationService.navigateToOrderDetailsView(
              appOrderId: appOrderId!,
            );
          }
        },
      );
    }

    return null;
  }

  List<SearchItemModel> search(String keyword) {
    return [
      searchField(keyword: keyword, field: () => name),
      searchField(keyword: keyword, field: () => accountName),
      searchField(keyword: keyword, field: () => description),
      searchField(keyword: keyword, field: () => status),
      searchField(keyword: keyword, field: () => parseToString(grandTotal)),
      searchField(keyword: keyword, field: () => orderDate?.toFormattedDate()),
      searchField(keyword: keyword, field: () => parseToString(totalAmount)),
      searchField(keyword: keyword, field: () => parseToString(totalTax)),
    ].whereNotNull().toList();
  }
}

extension OrderListExtension on List<Order> {
  List<SearchItemModel> search(String keyword) {
    return expand(
      (element) => element.search(keyword),
    ).toList();
  }
}
