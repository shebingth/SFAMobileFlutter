import 'package:intl/intl.dart';

import '../app/app.router.dart';
import '../database/database.dart';
import '../models/search.dart';
import '../ui/common/assets.gen.dart';
import '../ui/common/utils.dart';
import '../ui/tools/parse.dart';

import 'date_time.dart';
import 'iterable.dart';
import 'string.dart';

extension PaymentFollowUpExtension on PaymentFollowUp {
  Map<String, dynamic> toApi() {
    final data = <String, dynamic>{};
    data['Id'] = id;
    data['appPaymentFollowUpId'] = appPaymentFollowUpId;
    data['name'] = name;
    data['expectedPaymentdate'] = expectedPaymentDate != null
        ? DateFormat("yyyy-MM-dd").format(expectedPaymentDate!)
        : null;
    data['expectedAmount'] = parseToDouble(expectedAmount);
    data['comment'] = comment;
    data['appAccountId'] = appAccountId;
    data['accountId'] = accountId;
    data['accountName'] = accountName;
    data['visitId'] = visitId;
    data['appVisitId'] = appVisitId;
    data['synced'] = synced;
    return data;
  }

  SearchItemModel? searchField({
    required String? Function() field,
    required String keyword,
  }) {
    var fieldValue = field();
    if (fieldValue?.toLowerCase().contains(keyword.toLowerCase()) ?? false) {
      return SearchItemModel(
        image: Assets.images.creditCard.image(),
        module: 'Payment Follow Up',
        text: fieldValue!,
        reference: name ?? "",
        onTap: () {
          if (appPaymentFollowUpId.isNotEmptyOrNull) {
            navigationService.navigateToAccountPaymentFollowUpDetailsView(
              appPaymentFollowUpId: appPaymentFollowUpId!,
            );
          }
        },
      );
    }

    return null;
  }

  List<SearchItemModel> search(String keyword) {
    return [
      searchField(keyword: keyword, field: () => name),
      searchField(keyword: keyword, field: () => accountName),
      searchField(keyword: keyword, field: () => comment),
      searchField(keyword: keyword, field: () => expectedAmount),
      searchField(
        keyword: keyword,
        field: () => expectedPaymentDate?.toFormattedDate(),
      ),
    ].whereNotNull().toList();
  }
}

extension TicketsListExtension on List<PaymentFollowUp> {
  List<SearchItemModel> search(String keyword) {
    return expand(
      (element) => element.search(keyword),
    ).toList();
  }
}
