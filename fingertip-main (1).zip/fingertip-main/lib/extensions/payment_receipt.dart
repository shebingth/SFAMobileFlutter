import '../app/app.router.dart';
import '../database/database.dart';
import '../models/search.dart';
import '../ui/common/assets.gen.dart';
import '../ui/common/utils.dart';
import '../ui/tools/parse.dart';

import 'date_time.dart';
import 'iterable.dart';
import 'string.dart';

extension PaymentReceiptExtension on PaymentReceipt {
  SearchItemModel? searchField({
    required String? Function() field,
    required String keyword,
  }) {
    var fieldValue = field();
    if (fieldValue?.toLowerCase().contains(keyword.toLowerCase()) ?? false) {
      return SearchItemModel(
        image: Assets.images.invoice.image(),
        module: 'Payment Receipt',
        text: fieldValue!,
        reference: name ?? "",
        onTap: () {
          if (id.isNotEmptyOrNull) {
            navigationService.navigateToPaymentReceiptDetailsView(
              paymentReceiptId: id!,
            );
          }
        },
      );
    }

    return null;
  }

  List<SearchItemModel> search(String keyword) {
    return [
      searchField(keyword: keyword, field: () => name),
      searchField(keyword: keyword, field: () => accountName),
      searchField(keyword: keyword, field: () => invoiceName),
      searchField(keyword: keyword, field: () => paymentType),
      searchField(keyword: keyword, field: () => remark),
      searchField(
          keyword: keyword, field: () => paymentDate?.toFormattedDate()),
      searchField(keyword: keyword, field: () => parseToString(amount)),
      searchField(keyword: keyword, field: () => status),
      searchField(keyword: keyword, field: () => checkNo),
      searchField(keyword: keyword, field: () => checkDate?.toFormattedDate()),
    ].whereNotNull().toList();
  }
}

extension PaymentReceiptListExtension on List<PaymentReceipt> {
  List<SearchItemModel> search(String keyword) {
    return expand(
      (element) => element.search(keyword),
    ).toList();
  }
}
