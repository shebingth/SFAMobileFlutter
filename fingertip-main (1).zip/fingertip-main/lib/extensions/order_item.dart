import '../app/app.router.dart';
import '../database/database.dart';
import '../models/search.dart';
import '../ui/common/assets.gen.dart';
import '../ui/common/utils.dart';
import '../ui/tools/parse.dart';

import 'iterable.dart';
import 'list.dart';
import 'string.dart';

extension OrderItemExtensions on OrderItem {
  SearchItemModel? searchField({
    required String? Function() field,
    required String keyword,
    required List<Order> orders,
  }) {
    var fieldValue = field();
    if (fieldValue?.toLowerCase().contains(keyword.toLowerCase()) ?? false) {
      if (appOrderId.isNotEmptyOrNull) {
        var order = orders.firstWhereOrNull((element) {
          return element.appOrderId == appOrderId;
        });
        return SearchItemModel(
          image: Assets.images.settings.image(),
          module: 'Order Item',
          text: fieldValue!,
          reference: order?.name ?? "",
          onTap: () {
            if (appOrderId.isNotEmptyOrNull) {
              navigationService.navigateToOrderDetailsView(
                appOrderId: appOrderId!,
              );
            }
          },
        );
      }
    }

    return null;
  }

  List<SearchItemModel> search(
    String keyword,
    List<Order> orders,
  ) {
    return [
      searchField(
        keyword: keyword,
        orders: orders,
        field: () => productName,
      ),
      searchField(
        keyword: keyword,
        orders: orders,
        field: () => parseToString(taxAmount),
      ),
      searchField(
        keyword: keyword,
        orders: orders,
        field: () => parseToString(totalAmount),
      ),
      searchField(
        keyword: keyword,
        orders: orders,
        field: () => parseToString(unitPrice),
      ),
    ].whereNotNull().toList();
  }
}

extension OrderItemListExtension on List<OrderItem> {
  List<SearchItemModel> search(
    String keyword,
    List<Order> orders,
  ) {
    return expand(
      (element) => element.search(keyword, orders),
    ).toList();
  }
}
