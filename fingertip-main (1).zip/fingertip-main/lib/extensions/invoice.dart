import '../app/app.router.dart';
import '../database/database.dart';
import '../models/search.dart';
import '../ui/common/assets.gen.dart';
import '../ui/common/utils.dart';
import '../ui/tools/parse.dart';

import 'date_time.dart';
import 'iterable.dart';
import 'string.dart';

extension InvoiceExtension on Invoice {
  SearchItemModel? searchField({
    required String? Function() field,
    required String keyword,
  }) {
    var fieldValue = field();
    if (fieldValue?.toLowerCase().contains(keyword.toLowerCase()) ?? false) {
      return SearchItemModel(
        image: Assets.images.receipt.image(),
        module: 'Invoice',
        text: fieldValue!,
        reference: name ?? "",
        onTap: () {
          if (appInvoiceId.isNotEmptyOrNull) {
            navigationService.navigateToInvoiceDetailsView(
              appInvoiceId: appInvoiceId!,
            );
          }
        },
      );
    }

    return null;
  }

  List<SearchItemModel> search(String keyword) {
    return [
      searchField(keyword: keyword, field: () => name),
      searchField(keyword: keyword, field: () => accountName),
      searchField(keyword: keyword, field: () => status),
      searchField(keyword: keyword, field: () => parseToString(balance)),
      searchField(keyword: keyword, field: () => parseToString(totalAmount)),
      searchField(keyword: keyword, field: () => parseToString(grandTotal)),
      searchField(
        keyword: keyword,
        field: () => invoiceDate?.toFormattedDate(),
      ),
      searchField(keyword: keyword, field: () => dueDate?.toFormattedDate()),
    ].whereNotNull().toList();
  }
}

extension InvoiceListExtension on List<Invoice> {
  List<SearchItemModel> search(String keyword) {
    return expand(
      (element) => element.search(keyword),
    ).toList();
  }
}
