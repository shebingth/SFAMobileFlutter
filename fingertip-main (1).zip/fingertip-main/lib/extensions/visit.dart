import '../app/app.router.dart';
import '../database/database.dart';
import '../database/tools.dart';
import '../models/latlng.dart';
import '../models/search.dart';
import '../ui/common/assets.gen.dart';
import '../ui/common/utils.dart';
import '../ui/tools/parse.dart';

import 'date_time.dart';
import 'iterable.dart';
import 'string.dart';

extension VisitExtension on Visit {
  Map<String, dynamic> toApi() {
    var serializer = const CustomValueSerializer();

    return <String, dynamic>{
      'salesAppId': serializer.toJson<String?>(salesAppId),
      'id': serializer.toJson<String?>(id),
      'acccountId': serializer.toJson<String?>(accountId),
      'accountName': serializer.toJson<String?>(accountName),
      'status': serializer.toJson<String?>(status),
      'plannedStartTime': serializer.toJson<DateTime>(plannedStartTime),
      'plannedEndTime': serializer.toJson<DateTime?>(plannedEndTime),
      'actualStartTime': serializer.toJson<DateTime?>(actualStartTime),
      'actualEndTime': serializer.toJson<DateTime?>(actualEndTime),
      'comments': serializer.toJson<String?>(comments),
      'missedReason': serializer.toJson<String?>(missedReason),
      'geoLocation': serializer.toJson<LatLng?>(geoLocation),
      'checkoutLocation': serializer.toJson<LatLng?>(checkoutLocation),
      'typeofVisit': serializer.toJson<String?>(typeofVisit),
      'appVisitPlanId': serializer.toJson<String?>(appVisitPlanId),
      'visitPlanId': serializer.toJson<String?>(visitPlanId),
    };
  }

  SearchItemModel? searchField({
    required String? Function() field,
    required String keyword,
  }) {
    var fieldValue = field();
    if (fieldValue?.toLowerCase().contains(keyword.toLowerCase()) ?? false) {
      return SearchItemModel(
        image: Assets.images.pin.image(),
        module: 'Visit',
        text: fieldValue!,
        reference: "${accountName ?? ""} - ${status ?? ""}",
        onTap: () {
          if (salesAppId.isNotEmptyOrNull) {
            navigationService.navigateToVisitPreviewView(
              salesAppId: salesAppId!,
              accountId: accountId,
            );
          }
        },
      );
    }

    return null;
  }

  List<SearchItemModel> search(String keyword) {
    return [
      searchField(keyword: keyword, field: () => accountName),
      searchField(keyword: keyword, field: () => typeofVisit),
      searchField(keyword: keyword, field: () => comments),
      searchField(keyword: keyword, field: () => status),
      searchField(keyword: keyword, field: () => missedReason),
      searchField(
        keyword: keyword,
        field: () => actualStartTime?.toFormattedDate(),
      ),
      searchField(
        keyword: keyword,
        field: () => actualEndTime?.toFormattedDate(),
      ),
      searchField(
        keyword: keyword,
        field: () => plannedStartTime.toFormattedDate(),
      ),
      searchField(
        keyword: keyword,
        field: () => plannedEndTime?.toFormattedDate(),
      ),
      searchField(keyword: keyword, field: () => lastVisitComment),
      searchField(
        keyword: keyword,
        field: () => lastVisitDate?.toFormattedDate(),
      ),
      searchField(keyword: keyword, field: () => status),
      searchField(keyword: keyword, field: () => parseToString(outstanding)),
    ].whereNotNull().toList();
  }
}

extension VisitListExtension on List<Visit> {
  List<SearchItemModel> search(String keyword) {
    return expand(
      (element) => element.search(keyword),
    ).toList();
  }
}
