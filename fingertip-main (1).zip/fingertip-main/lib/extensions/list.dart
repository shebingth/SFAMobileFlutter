extension ListExtensions<T> on List<T>? {
  bool get isNotEmptyOrNull {
    return this != null && this!.isNotEmpty;
  }

  bool get isEmptyOrNull {
    return this == null || this!.isEmpty;
  }

  T? firstWhereOrNull(bool Function(T element) test) {
    for (var element in this ?? <T>[]) {
      if (test(element)) return element;
    }
    return null;
  }

  void sortByNullableField({
    required Comparable? Function(T e) getField,
    required bool isAscending,
  }) {
    if (this == null) return;
    this!.sort((a, b) {
      var fieldValueA = getField(a);
      var fieldValueB = getField(b);

      if (fieldValueA is String) {
        fieldValueA = fieldValueA.toLowerCase();
      }
      if (fieldValueB is String) {
        fieldValueB = fieldValueB.toLowerCase();
      }

      if (fieldValueA == null && fieldValueB == null) {
        return 0;
      } else if (fieldValueA == null) {
        if (isAscending) {
          return -1;
        } else {
          return 1;
        }
      } else if (fieldValueB == null) {
        if (isAscending) {
          return 1;
        } else {
          return -1;
        }
      } else {
        if (isAscending) {
          return fieldValueA.compareTo(fieldValueB);
        } else {
          return fieldValueB.compareTo(fieldValueA);
        }
      }
    });
  }
}
