import '../app/app.router.dart';
import '../database/database.dart';
import '../models/search.dart';
import '../ui/common/assets.gen.dart';
import '../ui/common/utils.dart';

import 'date_time.dart';
import 'iterable.dart';
import 'string.dart';

extension ExpenseExtension on Expense {
  SearchItemModel? searchField({
    required String? Function() field,
    required String keyword,
  }) {
    var fieldValue = field();
    if (fieldValue?.toLowerCase().contains(keyword.toLowerCase()) ?? false) {
      return SearchItemModel(
        image: Assets.images.doller.image(),
        module: 'Expense',
        text: fieldValue!,
        reference: expenseName ?? "",
        onTap: () {
          if (appExpId.isNotEmptyOrNull) {
            navigationService.navigateToExpenseNewView(
              appExpId: appExpId!,
            );
          }
        },
      );
    }

    return null;
  }

  List<SearchItemModel> search(String keyword) {
    return [
      searchField(keyword: keyword, field: () => expenseName),
      searchField(keyword: keyword, field: () => executiveName),
      searchField(keyword: keyword, field: () => approvalStatus),
      searchField(keyword: keyword, field: () => createdBy),
      searchField(
        keyword: keyword,
        field: () => expenseDate?.toFormattedDate(),
      ),
    ].whereNotNull().toList();
  }
}

extension ExpenseListExtension on List<Expense> {
  List<SearchItemModel> search(String keyword) {
    return expand(
      (element) => element.search(keyword),
    ).toList();
  }
}
