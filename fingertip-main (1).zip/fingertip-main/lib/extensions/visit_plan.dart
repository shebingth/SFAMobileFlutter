import '../app/app.router.dart';
import '../database/database.dart';
import '../database/tools.dart';
import '../models/search.dart';
import '../ui/common/assets.gen.dart';
import '../ui/common/utils.dart';
import '../ui/tools/parse.dart';

import 'date_time.dart';
import 'iterable.dart';
import 'string.dart';

extension VisitPlanExtension on VisitPlan {
  Map<String, dynamic> toApi() {
    var serializer = const CustomValueSerializer();

    return <String, dynamic>{
      'appVisitPlanId': serializer.toJson<String?>(appVisitPlanId),
      'month': serializer.toJson<int?>(month)?.toString(),
      'year': serializer.toJson<int?>(year)?.toString(),
      'name': serializer.toJson<String?>(name),
      'executiveId': serializer.toJson<String?>(executiveId),
      'createdDate': serializer.toJson<DateTime?>(createdDate),
      'visits': [],
    };
  }

  SearchItemModel? searchField({
    required String? Function() field,
    required String keyword,
  }) {
    var fieldValue = field();
    if (fieldValue?.toLowerCase().contains(keyword.toLowerCase()) ?? false) {
      return SearchItemModel(
        image: Assets.images.clipboard.image(),
        module: 'Visit Plan',
        text: fieldValue!,
        reference: name ?? "",
        onTap: () {
          if (appVisitPlanId.isNotEmptyOrNull) {
            navigationService.navigateToVisitPlanDetailsView(
              appVisitPlanId: appVisitPlanId!,
            );
          }
        },
      );
    }

    return null;
  }

  List<SearchItemModel> search(String keyword) {
    return [
      searchField(keyword: keyword, field: () => name),
      searchField(keyword: keyword, field: () => executiveName),
      searchField(keyword: keyword, field: () => endDate?.toFormattedDate()),
      searchField(keyword: keyword, field: () => startDate?.toFormattedDate()),
      searchField(keyword: keyword, field: () => frequency),
      searchField(keyword: keyword, field: () => parseToString(year)),
    ].whereNotNull().toList();
  }
}

extension VisitPlanListExtension on List<VisitPlan> {
  List<SearchItemModel> search(String keyword) {
    return expand(
      (element) => element.search(keyword),
    ).toList();
  }
}
