import 'package:flutter/material.dart';

import '../app/app.router.dart';
import '../database/database.dart';
import '../models/search.dart';
import '../ui/common/app_colors.dart';
import '../ui/common/assets.gen.dart';
import '../ui/common/utils.dart';

import 'date_time.dart';
import 'iterable.dart';
import 'string.dart';

extension LeaveExtensions on Leave {
  Color get leaveStatusColor {
    switch (leaveStatus) {
      case "Approved":
        return Palette.green1;
      case "Pending":
        return Palette.primary;
      case "Rejected":
        return Palette.red;
      default:
        return Palette.green1;
    }
  }

  SearchItemModel? searchField({
    required String? Function() field,
    required String keyword,
  }) {
    var fieldValue = field();
    if (fieldValue?.toLowerCase().contains(keyword.toLowerCase()) ?? false) {
      return SearchItemModel(
        image: Assets.images.calendarRedCheck.image(),
        module: 'Leave',
        text: fieldValue!,
        reference: name ?? "",
        onTap: () {
          if (appLeaveId.isNotEmptyOrNull) {
            navigationService.navigateToLeaveDetailsView(
              appLeaveId: appLeaveId!,
            );
          }
        },
      );
    }

    return null;
  }

  List<SearchItemModel> search(String keyword) {
    return [
      searchField(keyword: keyword, field: () => name),
      searchField(keyword: keyword, field: () => leaveStatus),
      searchField(keyword: keyword, field: () => leaveType),
      searchField(keyword: keyword, field: () => comments),
      searchField(keyword: keyword, field: () => duration),
      searchField(keyword: keyword, field: () => executiveName),
      searchField(keyword: keyword, field: () => firstSecond),
      searchField(keyword: keyword, field: () => reason),
      searchField(keyword: keyword, field: () => startDate?.toFormattedDate()),
      searchField(keyword: keyword, field: () => endDate?.toFormattedDate()),
      searchField(
          keyword: keyword, field: () => lastModifiedDate?.toFormattedDate()),
    ].whereNotNull().toList();
  }
}

extension LeaveListExtension on List<Leave> {
  List<SearchItemModel> search(String keyword) {
    return expand(
      (element) => element.search(keyword),
    ).toList();
  }
}
