import '../app/app.logger.dart';

extension FutureExecutionTimeLogger<T> on Future<T> {
  Future<T> logExecutionTime(String functionName) async {
    final logger = getLogger(functionName);
    final startTime = DateTime.now();
    final result = await this;
    final endTime = DateTime.now();
    final timeTaken = endTime.difference(startTime).inSeconds;
    logger.wtf('Execution time: $timeTaken seconds');
    return result;
  }
}
