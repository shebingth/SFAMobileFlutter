import '../app/app.router.dart';
import '../database/database.dart';
import '../models/search.dart';
import '../ui/common/assets.gen.dart';
import '../ui/common/utils.dart';
import '../ui/tools/parse.dart';

import 'iterable.dart';
import 'list.dart';
import 'string.dart';

extension InvoiceItemExtensions on InvoiceItem {
  SearchItemModel? searchField({
    required String? Function() field,
    required String keyword,
    required List<Invoice> invoices,
  }) {
    var fieldValue = field();
    if (fieldValue?.toLowerCase().contains(keyword.toLowerCase()) ?? false) {
      if (appInvoiceId.isNotEmptyOrNull) {
        var invoice = invoices.firstWhereOrNull((element) {
          return element.appInvoiceId == appInvoiceId;
        });
        return SearchItemModel(
          image: Assets.images.settings.image(),
          module: 'Invoice Item',
          text: fieldValue!,
          reference: invoice?.name ?? "",
          onTap: () {
            if (appInvoiceId.isNotEmptyOrNull) {
              navigationService.navigateToInvoiceDetailsView(
                appInvoiceId: appInvoiceId!,
              );
            }
          },
        );
      }
    }

    return null;
  }

  List<SearchItemModel> search(
    String keyword,
    List<Invoice> invoices,
  ) {
    return [
      searchField(
        keyword: keyword,
        invoices: invoices,
        field: () => productName,
      ),
      searchField(
        keyword: keyword,
        invoices: invoices,
        field: () => parseToString(taxAmount),
      ),
      searchField(
        keyword: keyword,
        invoices: invoices,
        field: () => parseToString(totalAmount),
      ),
      searchField(
        keyword: keyword,
        invoices: invoices,
        field: () => parseToString(unitPrice),
      ),
    ].whereNotNull().toList();
  }
}

extension InvoiceItemListExtension on List<InvoiceItem> {
  List<SearchItemModel> search(
    String keyword,
    List<Invoice> invoices,
  ) {
    return expand(
      (element) => element.search(keyword, invoices),
    ).toList();
  }
}
