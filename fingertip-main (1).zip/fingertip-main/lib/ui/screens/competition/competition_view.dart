import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../database/database.dart';
import '../../../extensions/string.dart';
import '../../common/app_colors.dart';
import '../../common/ui_helpers.dart';
import '../../tools/dismiss_keyboard.dart';
import '../../tools/model_future_builder.dart';
import '../../tools/parse.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/button.dart';
import '../../widgets/form_fields/dropdown_field.dart';
import '../../widgets/form_fields/text_field.dart';

import 'competition_viewmodel.dart';

class CompetitionView extends StackedView<CompetitionViewModel> {
  const CompetitionView({
    super.key,
    required this.visitMap,
  });

  final Map<String, dynamic> visitMap;

  @override
  void onViewModelReady(CompetitionViewModel viewModel) {
    viewModel.init();
  }

  @override
  Widget builder(context, viewModel, child) {
    var data = viewModel.data;

    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Competition",
      ),
      body: SizedBox.expand(
        child: DismissKeyboard(
          child: Visibility(
            visible: !viewModel.isBusy,
            replacement: const ModelBusyWidget(),
            child: Form(
              key: viewModel.formKey,
              autovalidateMode: viewModel.autovalidateMode,
              child: SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(15.w, 25.h, 15.w, 30.h),
                child: Column(
                  children: [
                    CustomDropdownSearchFormField(
                      labelText: "Product Name",
                      items: viewModel.products,
                      itemAsString: (item) => item.name,
                      compareFn: (v1, v2) => v1 == v2,
                      onChanged: (value) {},
                      onSaved: (newValue) {
                        data.productId = newValue?.id;
                        data.productName = newValue?.name;
                      },
                      validator: (value) {
                        if (value == null) {
                          return "Required";
                        }
                        return null;
                      },
                    ),
                    CustomDropdownSearchFormField(
                      top: 20.h,
                      labelText: "Brand Name",
                      items: viewModel.competitors,
                      itemAsString: (item) => item.name ?? "",
                      compareFn: (v1, v2) => v1 == v2,
                      onChanged: (value) {},
                      onSaved: (newValue) {
                        data.competitorId = newValue?.id;
                        data.competitorName = newValue?.name;
                      },
                      validator: (value) {
                        if (value == null) {
                          return "Required";
                        }
                        return null;
                      },
                    ),
                    CustomTextFormField(
                      top: 20.h,
                      labelText: "Rate",
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                        signed: false,
                      ),
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                          RegExp(r'^\d*\.?\d*$'),
                        ),
                      ],
                      prefixText: "₹",
                      hasPrefixTestSeparator: false,
                      onSaved: (newValue) {
                        var value = parseToDouble(newValue);
                        data.rate = value;
                      },
                      validator: (value) {
                        if (value.isEmptyOrNull) {
                          return 'Required';
                        }
                        return null;
                      },
                    ),
                    CustomTextFormField(
                      top: 20.h,
                      labelText: "Stock",
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                        signed: false,
                      ),
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                          RegExp(r'^\d*\.?\d*$'),
                        ),
                      ],
                      hasPrefixTestSeparator: false,
                      onSaved: (newValue) {
                        data.currentStock = newValue;
                      },
                      validator: (value) {
                        if (value.isEmptyOrNull) {
                          return 'Required';
                        }
                        return null;
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
        decoration: const BoxDecoration(
          color: Palette.scaffoldBackground,
          boxShadow: [
            BoxShadow(
              color: Palette.shadow3,
              blurRadius: 5,
              offset: Offset(0, -2),
              spreadRadius: 2,
            )
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.cancel,
                label: "Cancel",
                color: Palette.greyBA,
              ),
            ),
            horizontalSpace(15.w),
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.submit,
                isBusy: viewModel.busy(viewModel.formKey),
                label: "Save",
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  CompetitionViewModel viewModelBuilder(BuildContext context) {
    return CompetitionViewModel(
      visit: Visit.fromJson(visitMap),
    );
  }
}
