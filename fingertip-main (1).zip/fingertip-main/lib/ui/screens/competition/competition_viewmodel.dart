import 'package:flutter/material.dart';

import 'package:stacked/stacked.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../database/database.dart';
import '../../../models/competition.dart';
import '../../common/utils.dart';

class CompetitionViewModel extends BaseViewModel {
  CompetitionViewModel({
    required this.visit,
  }) : data = CompetitionHelper(
          accountId: visit.accountId,
          accountName: visit.accountName,
          salesAppId: visit.salesAppId,
        );

  final Visit visit;
  final _databaseService = locator<DatabaseService>();
  final formKey = GlobalKey<FormState>();

  CompetitionHelper data;
  var autovalidateMode = AutovalidateMode.disabled;
  List<Product> products = [];
  List<Competitior> competitors = [];

  Future<void> init() async {
    setBusy(true);
    try {
      products = await _databaseService.getProducts();
      competitors = await _databaseService.getCompetitors();
    } catch (e) {
      setError(e);
    }
    setBusy(false);
  }

  Future<void> submit() async {
    if (formKey.currentState?.validate() ?? false) {
      formKey.currentState!.save();

      bool status = await runBusyFuture(
        _databaseService.addNewCompetition(data: data),
        busyObject: formKey,
      );

      if (status) {
        await dialogService.showCustomDialog(
          variant: DialogType.confirm,
          title: "Competition Added",
          description: "New Competition added\nsuccessfully.",
          mainButtonTitle: "Continue",
          secondaryButtonTitle: "Cancel",
        );

        navigationService.back();
      }
    } else {
      setAutovalidateMode(AutovalidateMode.always);
    }
  }

  void setAutovalidateMode(AutovalidateMode mode) {
    autovalidateMode = mode;
    notifyListeners();
  }

  void cancel() => navigationService.back();
}
