import 'package:flutter/material.dart';

import 'package:collection/collection.dart';
import 'package:stacked/stacked.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../database/database.dart';
import '../../../database/tools.dart';
import '../../../models/account.dart';
import '../../../models/states.dart';
import '../../../models/user.dart';
import '../../../services/user_service.dart';
import '../../common/utils.dart';
import '../../tools/smart_dialog_config.dart';

class AccountAddViewModel extends BaseViewModel {
  AccountAddViewModel({
    this.appAccountId,
  }) : isEdit = appAccountId != null;

  final formKey = GlobalKey<FormState>();
  final _databaseService = locator<DatabaseService>();
  final _userService = locator<UserService>();
  final String? appAccountId;
  final bool isEdit;

  var autovalidateMode = AutovalidateMode.disabled;
  List<AccountRoute> routes = [];
  List<Account> accounts = [];
  AccountHelper? data;
  final formFieldKeys = List.generate(24, (_) => GlobalKey<FormFieldState>());

  AppUser? get user => _userService.user;

  StateModel? get stateValue {
    if (data?.state != null) {
      return states.firstWhereOrNull((element) {
        return element.name == data!.state!;
      });
    }
    return null;
  }

  List<String> get districts {
    return stateValue?.districts ?? [];
  }

  Account? get parentAccountValue {
    if (data?.parentAccountId != null) {
      return accounts.firstWhereOrNull((element) {
        return element.id == data!.parentAccountId!;
      });
    }
    return null;
  }

  AccountRoute? get routeValue {
    if (data?.routesId != null) {
      return routes.firstWhereOrNull((element) {
        return element.id == data!.routesId!;
      });
    }
    return null;
  }

  Future<void> init() async {
    setBusy(true);
    routes = await _databaseService.getRoutes();
    accounts = await _databaseService.getAccounts();

    if (isEdit) {
      var acc = await _databaseService.getAccount(appAccountId!);

      if (acc != null) {
        data = AccountHelper.fromJson(
          acc.toJson(serializer: const CustomValueSerializer()),
        );
      }
    } else {
      data = AccountHelper();
    }
    setBusy(false);
  }

  Future<void> submit() async {
    if (formKey.currentState?.validate() == true) {
      formKey.currentState!.save();

      bool status = await runBusyFuture(
        isEdit
            ? _databaseService.updateAccount(
                account: data!,
                user: user,
              )
            : _databaseService.addNewAccount(
                account: data!,
                user: user,
              ),
        busyObject: formKey,
      );

      if (status) {
        if (isEdit) {
          await dialogService.showCustomDialog(
            variant: DialogType.confirm,
            title: "Updated",
            description: "Account details updated\nsuccessfully.",
            mainButtonTitle: "Continue",
            secondaryButtonTitle: "Cancel",
          );
        } else {
          await dialogService.showCustomDialog(
            variant: DialogType.confirm,
            title: "Account Added",
            description: "New Account added\nsuccessfully.",
            mainButtonTitle: "Continue",
            secondaryButtonTitle: "Cancel",
          );
        }

        navigationService.back();
      }
    } else {
      showToast("Please fill all the required fields");
      var errorKey = formFieldKeys.firstWhereOrNull((element) {
        return element.currentState?.hasError == true;
      });

      if (errorKey?.currentContext != null) {
        Future.delayed(Duration.zero, () {
          Scrollable.ensureVisible(
            errorKey!.currentContext!,
            alignment: 0.5,
            alignmentPolicy: ScrollPositionAlignmentPolicy.explicit,
          );
        });
      }
      setAutovalidateMode(AutovalidateMode.always);
    }
  }

  void setAutovalidateMode(AutovalidateMode mode) {
    autovalidateMode = mode;
    notifyListeners();
  }

  void setPaymentType(String? value) {
    data?.paymentType = value;
    notifyListeners();
  }

  void setAccountClassification(String? value) {
    data?.accountClassification = value;
    notifyListeners();
  }

  void cancel() => navigationService.back();

  void setState(StateModel? value) {
    data?.state = value?.name;
    data?.district = null;
    notifyListeners();
  }

  void setDistrict(String? value) {
    data?.district = value;
    notifyListeners();
  }

  void setParentAccount(Account? value) {
    data?.parentAccountId = value?.id;
    data?.parentAccountName = value?.name;
    notifyListeners();
  }

  void setRoute(AccountRoute? value) {
    data?.routesId = value?.id;
    data?.routesName = value?.name;
    notifyListeners();
  }
}
