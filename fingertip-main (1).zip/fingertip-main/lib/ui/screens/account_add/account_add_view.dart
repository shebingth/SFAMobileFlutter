import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../extensions/string.dart';
import '../../../models/states.dart';
import '../../common/app_colors.dart';
import '../../common/ui_helpers.dart';
import '../../tools/dismiss_keyboard.dart';
import '../../tools/email_validator.dart';
import '../../tools/model_future_builder.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/button.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/form_fields/dropdown_field.dart';
import '../../widgets/form_fields/text_field.dart';

import 'account_add_viewmodel.dart';

class AccountAddView extends StackedView<AccountAddViewModel> {
  const AccountAddView({
    super.key,
    this.appAccountId,
  });

  final String? appAccountId;

  @override
  void onViewModelReady(AccountAddViewModel viewModel) {
    viewModel.init();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: CustomAppBar(
        titleText: viewModel.isEdit ? "Edit Store" : "Add Account",
      ),
      body: SizedBox.expand(
        child: ModelFutureBuilder(
          busy: viewModel.isBusy,
          data: viewModel.data,
          error: viewModel.modelError,
          builder: (context, data, child) {
            return DismissKeyboard(
              child: Form(
                key: viewModel.formKey,
                autovalidateMode: viewModel.autovalidateMode,
                child: SingleChildScrollView(
                  padding: EdgeInsets.fromLTRB(0, 25.h, 0, 30.h),
                  child: Column(
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 15.w),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CustomText(
                              "Store Information",
                              style: TextStyle(
                                fontSize: 15.sp,
                                fontWeight: FontWeight.bold,
                                color: Palette.grey09,
                              ),
                            ),
                            CustomTextFormField(
                              formFieldKey: viewModel.formFieldKeys[0],
                              top: 17.h,
                              labelText: "Name",
                              initialValue: data.name,
                              onSaved: (newValue) {
                                data.name = newValue;
                              },
                              isRequired: true,
                              validator: (value) {
                                if (value.isEmptyOrNull) {
                                  return 'Required';
                                }
                                return null;
                              },
                            ),
                            CustomTextFormField(
                              formFieldKey: viewModel.formFieldKeys[1],
                              top: 20.h,
                              labelText: "Contact Person",
                              initialValue: data.contactPersonName,
                              isRequired: true,
                              onSaved: (newValue) {
                                data.contactPersonName = newValue;
                              },
                              validator: (value) {
                                if (value.isEmptyOrNull) {
                                  return 'Required';
                                }
                                return null;
                              },
                            ),
                            CustomTextFormField(
                              formFieldKey: viewModel.formFieldKeys[2],
                              top: 20.h,
                              labelText: "Mobile",
                              initialValue: data.mobile,
                              isRequired: true,
                              keyboardType: TextInputType.phone,
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly,
                              ],
                              onSaved: (newValue) {
                                data.mobile = newValue;
                              },
                              validator: (value) {
                                if (value.isEmptyOrNull) {
                                  return 'Required';
                                }
                                if (value!.length != 10) {
                                  return 'Invalid Mobile Number';
                                }
                                return null;
                              },
                            ),
                            CustomTextFormField(
                              formFieldKey: viewModel.formFieldKeys[3],
                              top: 20.h,
                              labelText: "Alternate Mobile",
                              initialValue: data.alternateMobile,
                              keyboardType: TextInputType.phone,
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly,
                              ],
                              onSaved: (newValue) {
                                data.alternateMobile = newValue;
                              },
                              validator: (value) {
                                if (value.isNotEmptyOrNull) {
                                  if (value!.length != 10) {
                                    return 'Invalid Mobile Number';
                                  }
                                }
                                return null;
                              },
                            ),
                            CustomTextFormField(
                              formFieldKey: viewModel.formFieldKeys[4],
                              top: 20.h,
                              labelText: "Email",
                              initialValue: data.email,
                              onSaved: (newValue) {
                                data.email = newValue;
                              },
                              validator: (value) {
                                if (value.isNotEmptyOrNull) {
                                  if (EmailValidator.validate(value!) != true) {
                                    return 'Invalid Email';
                                  }
                                }
                                return null;
                              },
                            ),
                            CustomTextFormField(
                              formFieldKey: viewModel.formFieldKeys[5],
                              top: 20.h,
                              labelText: "GST",
                              initialValue: data.gstNo,
                              onSaved: (newValue) {
                                data.gstNo = newValue;
                              },
                              validator: (value) {
                                if (value.isNotEmptyOrNull) {
                                  if (value!.length != 15) {
                                    return 'Invalid GST Number';
                                  }
                                }
                                return null;
                              },
                            ),
                            CustomTextFormField(
                              formFieldKey: viewModel.formFieldKeys[6],
                              top: 20.h,
                              labelText: "Description",
                              initialValue: data.description,
                              maxLines: 4,
                              onSaved: (newValue) {
                                data.description = newValue;
                              },
                              validator: (value) {
                                return null;
                              },
                            ),
                            CustomTextFormField(
                              formFieldKey: viewModel.formFieldKeys[7],
                              top: 20.h,
                              labelText: "Liquidation",
                              initialValue: data.liquidation,
                              keyboardType: TextInputType.number,
                              prefixText: "₹",
                              onSaved: (newValue) {
                                data.liquidation = newValue;
                              },
                              validator: (value) {
                                return null;
                              },
                            ),
                            CustomDropdownFormField(
                              formFieldKey: viewModel.formFieldKeys[8],
                              top: 20.h,
                              labelText: "Payment Type",
                              hideOuterLabel: true,
                              value: data.paymentType,
                              items: const ["Advance", "Credit"],
                              itemAsString: (item) => item,
                              onChanged: (v) {},
                              onSaved: (newValue) {
                                data.paymentType = newValue;
                              },
                              validator: (value) {
                                return null;
                              },
                            ),
                            CustomDropdownFormField(
                              formFieldKey: viewModel.formFieldKeys[9],
                              top: 20.h,
                              labelText: "Account Classification",
                              hideOuterLabel: true,
                              value: data.accountClassification,
                              items: const [
                                "Platinum",
                                "Gold",
                                "Silver",
                                "Regular"
                              ],
                              itemAsString: (item) => item,
                              onChanged: (v) {},
                              onSaved: (newValue) {
                                data.accountClassification = newValue;
                              },
                              validator: (value) {
                                return null;
                              },
                            ),
                            CustomDropdownFormField(
                              formFieldKey: viewModel.formFieldKeys[10],
                              top: 20.h,
                              labelText: "Grade",
                              hideOuterLabel: true,
                              value: data.grade,
                              items: const ["A", "B", "C", "D"],
                              itemAsString: (item) => item,
                              onChanged: (v) {},
                              isRequired: true,
                              onSaved: (newValue) {
                                data.grade = newValue;
                              },
                              validator: (value) {
                                if (value == null) {
                                  return "Required";
                                }
                                return null;
                              },
                            ),
                            CustomDropdownSearchFormField(
                              formFieldKey: viewModel.formFieldKeys[11],
                              top: 20.h,
                              labelText: "Routes",
                              value: viewModel.routeValue,
                              items: viewModel.routes,
                              isRequired: true,
                              itemAsString: (item) => item.name ?? "",
                              compareFn: (v1, v2) => v1 == v2,
                              onChanged: viewModel.setRoute,
                              onSaved: (newValue) {
                                data.routesId = newValue?.id;
                                data.routesName = newValue?.name;
                              },
                              validator: (value) {
                                if (value == null) {
                                  return "Required";
                                }
                                return null;
                              },
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: double.infinity,
                        height: 6,
                        margin: EdgeInsets.symmetric(vertical: 25.h),
                        color: Palette.greyF5,
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 15.w),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CustomText(
                              "Geo Location",
                              style: TextStyle(
                                fontSize: 15.sp,
                                fontWeight: FontWeight.bold,
                                color: Palette.grey09,
                              ),
                            ),
                            CustomTextFormField(
                              formFieldKey: viewModel.formFieldKeys[12],
                              top: 20.h,
                              labelText: "Latitude",
                              initialValue: data.latitude,
                              keyboardType: TextInputType.number,
                              readOnly: viewModel.isEdit,
                              onSaved: (newValue) {
                                data.latitude = newValue;
                              },
                              validator: (value) {
                                return null;
                              },
                            ),
                            CustomTextFormField(
                              formFieldKey: viewModel.formFieldKeys[13],
                              top: 20.h,
                              labelText: "Longitude",
                              initialValue: data.longitude,
                              readOnly: viewModel.isEdit,
                              keyboardType: TextInputType.number,
                              onSaved: (newValue) {
                                data.longitude = newValue;
                              },
                              validator: (value) {
                                return null;
                              },
                            ),
                            CustomDropdownSearchFormField(
                              formFieldKey: viewModel.formFieldKeys[14],
                              top: 20.h,
                              labelText: "Parent Account",
                              value: viewModel.parentAccountValue,
                              items: viewModel.accounts,
                              itemAsString: (item) => item.name ?? "",
                              compareFn: (v1, v2) => v1 == v2,
                              onChanged: viewModel.setParentAccount,
                              onSaved: (newValue) {
                                data.parentAccountId = newValue?.id;
                                data.parentAccountName = newValue?.name;
                              },
                              validator: (value) {
                                return null;
                              },
                            ),
                            CustomTextFormField(
                              formFieldKey: viewModel.formFieldKeys[15],
                              top: 20.h,
                              labelText: "Outstanding",
                              initialValue: data.outstanding,
                              keyboardType: TextInputType.number,
                              prefixText: "₹",
                              onSaved: (newValue) {
                                data.outstanding = newValue;
                              },
                              validator: (value) {
                                return null;
                              },
                            ),
                            CustomTextFormField(
                              formFieldKey: viewModel.formFieldKeys[16],
                              top: 20.h,
                              labelText: "Avg Credit Days",
                              initialValue: data.avgCreditDays,
                              keyboardType: TextInputType.number,
                              onSaved: (newValue) {
                                data.avgCreditDays = newValue;
                              },
                              validator: (value) {
                                return null;
                              },
                            ),
                            CustomTextFormField(
                              formFieldKey: viewModel.formFieldKeys[17],
                              top: 20.h,
                              labelText: "Opening Balance",
                              initialValue: data.openingBalance,
                              keyboardType: TextInputType.number,
                              prefixText: "₹",
                              onSaved: (newValue) {
                                data.openingBalance = newValue;
                              },
                              validator: (value) {
                                return null;
                              },
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: double.infinity,
                        height: 6,
                        margin: EdgeInsets.symmetric(vertical: 25.h),
                        color: Palette.greyF5,
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 15.w),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CustomText(
                              "Address",
                              style: TextStyle(
                                fontSize: 15.sp,
                                fontWeight: FontWeight.bold,
                                color: Palette.grey09,
                              ),
                            ),
                            CustomTextFormField(
                              formFieldKey: viewModel.formFieldKeys[18],
                              top: 20.h,
                              labelText: "Street Name",
                              initialValue: data.streetName,
                              onSaved: (newValue) {
                                data.streetName = newValue;
                              },
                              validator: (value) {
                                return null;
                              },
                            ),
                            CustomTextFormField(
                              formFieldKey: viewModel.formFieldKeys[19],
                              top: 20.h,
                              labelText: "Panchayath",
                              initialValue: data.panchayat,
                              onSaved: (newValue) {
                                data.panchayat = newValue;
                              },
                              validator: (value) {
                                return null;
                              },
                            ),
                            CustomTextFormField(
                              formFieldKey: viewModel.formFieldKeys[20],
                              top: 20.h,
                              labelText: "City",
                              initialValue: data.city,
                              onSaved: (newValue) {
                                data.city = newValue;
                              },
                              validator: (value) {
                                return null;
                              },
                            ),
                            CustomDropdownSearchFormField(
                              formFieldKey: viewModel.formFieldKeys[21],
                              top: 20.h,
                              labelText: "State",
                              value: viewModel.stateValue,
                              items: states,
                              itemAsString: (item) => item.name,
                              compareFn: (item1, item2) {
                                return item1.name == item2.name;
                              },
                              onChanged: viewModel.setState,
                              onSaved: (newValue) {
                                data.state = newValue?.name;
                              },
                              validator: (value) {
                                return null;
                              },
                            ),
                            CustomDropdownSearchFormField(
                              formFieldKey: viewModel.formFieldKeys[22],
                              top: 20.h,
                              labelText: "District",
                              value: data.district,
                              items: viewModel.districts,
                              itemAsString: (item) => item,
                              onChanged: viewModel.setDistrict,
                              onSaved: (newValue) {
                                data.district = newValue;
                              },
                              validator: (value) {
                                return null;
                              },
                            ),
                            CustomTextFormField(
                              formFieldKey: viewModel.formFieldKeys[23],
                              top: 20.h,
                              labelText: "PIN Code",
                              keyboardType: TextInputType.number,
                              initialValue: data.pincode,
                              onSaved: (newValue) {
                                data.pincode = newValue;
                              },
                              validator: (value) {
                                if (value.isNotEmptyOrNull) {
                                  if (value!.length != 6) {
                                    return "Invalid PIN Code";
                                  }
                                }
                                return null;
                              },
                            ),
                          ],
                        ),
                      ),
                      verticalSpace(30.h),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
        decoration: const BoxDecoration(
          color: Palette.scaffoldBackground,
          boxShadow: [
            BoxShadow(
              color: Palette.shadow3,
              blurRadius: 5,
              offset: Offset(0, -2),
              spreadRadius: 2,
            )
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.cancel,
                label: "Cancel",
                color: Palette.greyBA,
              ),
            ),
            horizontalSpace(15.w),
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.submit,
                isBusy: viewModel.busy(viewModel.formKey),
                label: viewModel.isEdit ? "Update" : "Save",
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  AccountAddViewModel viewModelBuilder(BuildContext context) {
    return AccountAddViewModel(
      appAccountId: appAccountId,
    );
  }
}
