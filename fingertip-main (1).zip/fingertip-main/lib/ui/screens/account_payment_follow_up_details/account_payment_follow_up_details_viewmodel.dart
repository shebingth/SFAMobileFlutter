import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../database/database.dart';

class AccountPaymentFollowUpDetailsViewModel
    extends StreamViewModel<PaymentFollowUp> {
  AccountPaymentFollowUpDetailsViewModel({
    required this.appPaymentFollowUpId,
  });

  final String appPaymentFollowUpId;
  final _databaseService = locator<DatabaseService>();

  @override
  Stream<PaymentFollowUp> get stream {
    return _databaseService.watchPaymentFollowUpsByAppPaymentFollowUpsId(
      appPaymentFollowUpId,
    );
  }
}
