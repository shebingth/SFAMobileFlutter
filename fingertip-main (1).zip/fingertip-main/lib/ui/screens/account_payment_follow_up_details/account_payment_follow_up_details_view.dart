import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../extensions/date_time.dart';
import '../../tools/conditional_widget.dart';
import '../../tools/model_future_builder.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/details_label_value.dart';

import 'account_payment_follow_up_details_viewmodel.dart';

class AccountPaymentFollowUpDetailsView
    extends StackedView<AccountPaymentFollowUpDetailsViewModel> {
  const AccountPaymentFollowUpDetailsView({
    super.key,
    required this.appPaymentFollowUpId,
  });

  final String appPaymentFollowUpId;

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Payment Follow Up",
      ),
      body: SizedBox.expand(
        child: IfNotNull(
          value: viewModel.data,
          replacement: ModelErrorWidget(
            error: viewModel.initialised ? "Something went wrong" : "",
          ),
          builder: (context, data) {
            return SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(15.w, 25.h, 15.w, 30.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  DetailsLabelValueWidget(
                    label: "Name",
                    value: data.name,
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Account",
                    value: data.accountName,
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Expected Amount",
                    value: data.expectedAmount,
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Expected Payment Date",
                    value: data.expectedPaymentDate.toFormattedDateTime(),
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Comment",
                    value: data.comment,
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  AccountPaymentFollowUpDetailsViewModel viewModelBuilder(
      BuildContext context) {
    return AccountPaymentFollowUpDetailsViewModel(
      appPaymentFollowUpId: appPaymentFollowUpId,
    );
  }
}
