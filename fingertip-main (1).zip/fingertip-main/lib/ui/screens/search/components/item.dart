import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../extensions/string.dart';
import '../../../../models/search.dart';
import '../../../common/app_colors.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/custom_text.dart';

class SearchItemWidget extends StatelessWidget {
  const SearchItemWidget({
    super.key,
    required this.item,
    required this.keyword,
  });

  final SearchItemModel item;
  final String keyword;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: item.onTap,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 15.h),
        child: Row(
          children: [
            item.image,
            horizontalSpace(15.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CustomText.rich(
                    TextSpan(
                      children: _getHighlightedText(),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w500,
                      color: Palette.text08,
                    ),
                  ),
                  CustomText(
                    item.reference.isNotEmptyOrNull
                        ? "${item.module}  -  ${item.reference}"
                        : item.module,
                    top: 5.h,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.normal,
                      color: Palette.text08,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<InlineSpan> _getHighlightedText() {
    final List<InlineSpan> spans = [];
    if (item.text.isEmptyOrNull) return spans;

    int queryIndex = item.text.toLowerCase().indexOf(keyword.toLowerCase());

    if (queryIndex == -1) {
      spans.add(TextSpan(text: item.text));
    } else {
      spans.add(TextSpan(text: item.text.substring(0, queryIndex)));
      spans.add(
        TextSpan(
          text: item.text.substring(queryIndex, queryIndex + keyword.length),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      );
      spans.add(
        TextSpan(text: item.text.substring(queryIndex + keyword.length)),
      );
    }

    return spans;
  }
}
