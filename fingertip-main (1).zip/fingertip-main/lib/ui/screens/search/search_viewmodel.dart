import 'dart:async';

import 'package:flutter/material.dart';

import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.logger.dart';
import '../../../database/database.dart';
import '../../../extensions/account.dart';
import '../../../extensions/expense.dart';
import '../../../extensions/invoice.dart';
import '../../../extensions/invoice_item.dart';
import '../../../extensions/leave.dart';
import '../../../extensions/order.dart';
import '../../../extensions/order_item.dart';
import '../../../extensions/payment_follow_up.dart';
import '../../../extensions/payment_receipt.dart';
import '../../../extensions/tickets.dart';
import '../../../extensions/visit.dart';
import '../../../extensions/visit_plan.dart';
import '../../../models/search.dart';

class SearchViewModel extends BaseViewModel {
  final textController = TextEditingController();
  final _databaseService = locator<DatabaseService>();
  final logger = getLogger('SearchViewModel');
  final List<SearchItemModel> results = [];

  SearchDataModel data = SearchDataModel.empty();
  Timer? debounce;

  Future<void> init() async {
    setBusy(true);
    try {
      data.accounts = await _databaseService.getAccounts();
      data.visits = await _databaseService.getVisits();
      data.visitPlans = await _databaseService.getVisitPlans();
      data.expenses = await _databaseService.getExpenses();
      data.orders = await _databaseService.getOrders();
      data.invoices = await _databaseService.getInvoices();
      data.paymentReceipts = await _databaseService.getPaymentReceipts();
      data.leaves = await _databaseService.getLeaves();
      data.tickets = await _databaseService.getTickets();
      data.paymentFollowUps = await _databaseService.getPaymentFollowUps();
      data.orderItems = await _databaseService.getOrderItems();
      data.invoiceItems = await _databaseService.getInvoiceItems();
    } catch (e) {
      logger.e(e);
    }
    setBusy(false);
  }

  void onSearch(String keyword) {
    results.clear();
    notifyListeners();
    if (debounce?.isActive == true) {
      debounce!.cancel();
    }
    debounce = Timer(const Duration(milliseconds: 800), () {
      if (keyword.length >= 3) {
        results.addAll(data.accounts.search(keyword));
        results.addAll(data.visits.search(keyword));
        results.addAll(data.visitPlans.search(keyword));
        results.addAll(data.expenses.search(keyword));
        results.addAll(data.orders.search(keyword));
        results.addAll(data.invoices.search(keyword));
        results.addAll(data.paymentReceipts.search(keyword));
        results.addAll(data.leaves.search(keyword));
        results.addAll(data.tickets.search(keyword));
        results.addAll(data.paymentFollowUps.search(keyword));
        results.addAll(data.orderItems.search(keyword, data.orders));
        results.addAll(data.invoiceItems.search(keyword, data.invoices));
      }

      notifyListeners();
    });
  }

  @override
  void dispose() {
    debounce?.cancel();
    super.dispose();
  }
}
