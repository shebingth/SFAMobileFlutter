import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../models/search.dart';
import '../../common/app_colors.dart';
import '../../common/assets.gen.dart';
import '../../tools/dismiss_keyboard.dart';
import '../../tools/model_future_builder.dart';
import '../../tools/screen_size.dart';
import '../../tools/separated_list.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/custom_back_button.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/form_fields/text_field.dart';

import 'components/item.dart';
import 'search_viewmodel.dart';

class SearchView extends StackedView<SearchViewModel> {
  const SearchView({super.key});

  @override
  void onViewModelReady(SearchViewModel viewModel) {
    viewModel.init();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        leading: CustomBackButton(
          color: Colors.black,
          forceVisible: true,
        ),
        titleText: "Search",
      ),
      body: SizedBox.expand(
        child: DismissKeyboard(
          child: ModelFutureBuilder<SearchDataModel>(
            data: viewModel.data,
            busy: viewModel.isBusy,
            error: viewModel.modelError,
            builder: (context, data, child) {
              return Column(
                children: [
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 5.h),
                    child: CustomTextFormField(
                      labelText: "Search",
                      controller: viewModel.textController,
                      radius: 8,
                      prefixIcon: Assets.images.search.image(width: 18.w),
                      onChanged: viewModel.onSearch,
                    ),
                  ),
                  Expanded(
                    child: Builder(
                      builder: (context) {
                        if (viewModel.textController.text.length >= 3 &&
                            viewModel.results.isEmpty &&
                            viewModel.debounce?.isActive != true) {
                          return Container(
                            width: double.infinity,
                            height: ScreenSize.height * 0.6,
                            alignment: Alignment.center,
                            child: const CustomText(
                              "No results found",
                            ),
                          );
                        }
                        return SingleChildScrollView(
                          padding: EdgeInsets.only(bottom: 30.h),
                          child: SeparatedWidgetList(
                            list: viewModel.results,
                            builder: (item, index) {
                              return SearchItemWidget(
                                item: item,
                                keyword: viewModel.textController.text,
                              );
                            },
                            separationBuilder: (index) {
                              return Container(
                                width: double.infinity,
                                height: 1,
                                color: Palette.divider,
                              );
                            },
                          ),
                        );
                      },
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  @override
  SearchViewModel viewModelBuilder(BuildContext context) {
    return SearchViewModel();
  }
}
