import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../database/database.dart';
import '../../common/app_colors.dart';
import '../../tools/model_future_builder.dart';
import '../../widgets/app_bar.dart';
import 'components/order_item.dart';
import 'last_orders_viewmodel.dart';

class LastOrdersView extends StackedView<LastOrdersViewModel> {
  const LastOrdersView({
    super.key,
    required this.lastVisitMap,
  });

  final Map<String, dynamic> lastVisitMap;

  @override
  void onViewModelReady(LastOrdersViewModel viewModel) {
    viewModel.getOrderItems();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Last visit order",
      ),
      body: SizedBox.expand(
        child: ModelFutureListBuilder(
          data: viewModel.orderItems,
          busy: viewModel.isBusy,
          error: viewModel.modelError?.toString() ?? "No items available",
          builder: (context, orderItems, child) {
            return ListView.separated(
              padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 30.h),
              itemCount: orderItems.length,
              itemBuilder: (context, index) {
                final orderItem = orderItems[index];

                return OrderLineItemWidget(
                  orderItem: orderItem,
                );
              },
              separatorBuilder: (context, index) {
                return const Divider(
                  color: Palette.divider,
                  height: 40,
                  thickness: 1,
                );
              },
            );
          },
        ),
      ),
    );
  }

  @override
  LastOrdersViewModel viewModelBuilder(context) {
    return LastOrdersViewModel(
      lastVisit: Visit.fromJson(lastVisitMap),
    );
  }
}
