import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../database/database.dart';

class LastOrdersViewModel extends BaseViewModel {
  LastOrdersViewModel({
    required this.lastVisit,
  });

  final Visit lastVisit;
  final _databaseService = locator<DatabaseService>();

  List<OrderItem> orderItems = [];

  Future<void> getOrderItems() async {
    if (lastVisit.salesAppId != null) {
      orderItems = await runBusyFuture(
        _databaseService.getOrderItemsByVisit(lastVisit.salesAppId!),
      );
    }
  }
}
