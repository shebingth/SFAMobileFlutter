import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../common/utils.dart';

class OrderDetailsViewModel extends StreamViewModel<Order?> {
  OrderDetailsViewModel({
    required this.appOrderId,
  });

  final String appOrderId;
  final _databaseService = locator<DatabaseService>();

  List<OrderItem> orderItems = [];

  Future<void> init() async {
    orderItems = await _databaseService.getOrderItemsByAppOrderId(appOrderId);
    notifyListeners();
  }

  void onOrderLineItemsTap() {
    navigationService.navigateToOrderLineItemView(
      appOrderId: appOrderId,
    );
  }

  @override
  Stream<Order?> get stream {
    return _databaseService.watchOrder(appOrderId);
  }
}
