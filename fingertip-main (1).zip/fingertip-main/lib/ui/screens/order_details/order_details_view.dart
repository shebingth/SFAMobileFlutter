import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../extensions/date_time.dart';
import '../../../extensions/double.dart';
import '../../common/assets.gen.dart';
import '../../tools/conditional_widget.dart';
import '../../tools/model_future_builder.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/details_label_value.dart';
import '../account_details/account_details_view.dart';

import 'order_details_viewmodel.dart';

class OrderDetailsView extends StackedView<OrderDetailsViewModel> {
  const OrderDetailsView({
    super.key,
    required this.appOrderId,
  });

  final String appOrderId;

  @override
  void onViewModelReady(OrderDetailsViewModel viewModel) {
    viewModel.init();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Order Details",
      ),
      body: SizedBox.expand(
        child: IfNotNull(
          value: viewModel.data,
          replacement: ModelErrorWidget(
            error: viewModel.initialised ? "Something went wrong" : "",
          ),
          builder: (context, data) {
            return SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  DetailsLabelValueWidget(
                    margin: EdgeInsets.fromLTRB(15.w, 25.h, 15.w, 0),
                    label: "Order Number",
                    value: data.name,
                  ),
                  DetailsLabelValueWidget(
                    margin: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 0),
                    label: "Order Date",
                    value: data.orderDate.toFormattedDate(),
                  ),
                  DetailsLabelValueWidget(
                    margin: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 0),
                    label: "Account",
                    value: data.accountName,
                  ),
                  DetailsLabelValueWidget(
                    margin: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 0),
                    label: "Status",
                    value: data.status,
                  ),
                  DetailsLabelValueWidget(
                    margin: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 0),
                    label: "Description",
                    value: data.description,
                  ),
                  DetailsLabelValueWidget(
                    margin: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 0),
                    label: "Total Amount",
                    value: data.totalAmount?.toPrice,
                  ),
                  DetailsLabelValueWidget(
                    margin: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 0),
                    label: "Total Tax",
                    value: data.totalTax?.toPrice,
                  ),
                  DetailsLabelValueWidget(
                    margin: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 0),
                    label: "Grand Total",
                    value: data.grandTotal?.toPrice,
                  ),
                  RelatedItemWidget(
                    top: 20.h,
                    bottom: 32.h,
                    icon: Assets.images.settings.image(),
                    title: "Order Line Items",
                    count: viewModel.orderItems.length,
                    onTap: viewModel.onOrderLineItemsTap,
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  OrderDetailsViewModel viewModelBuilder(BuildContext context) {
    return OrderDetailsViewModel(
      appOrderId: appOrderId,
    );
  }
}
