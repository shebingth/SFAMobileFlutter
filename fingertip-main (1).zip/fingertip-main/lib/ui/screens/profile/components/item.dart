import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/custom_text.dart';

class MenuItemWidget extends StatelessWidget {
  const MenuItemWidget({
    super.key,
    required this.onTap,
    required this.icon,
    required this.label,
  });

  final VoidCallback onTap;
  final Widget icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 20.h),
        child: Row(
          children: [
            icon,
            horizontalSpace(15.w),
            Expanded(
              child: CustomText(
                label,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 15.sp,
                ),
              ),
            ),
            Assets.images.angleRight.image(),
          ],
        ),
      ),
    );
  }
}
