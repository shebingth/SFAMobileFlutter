import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/fonts.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/network_image.dart';
import '../profile_viewmodel.dart';

class UserDetailsWidget extends ViewModelWidget<ProfileViewModel> {
  const UserDetailsWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, ProfileViewModel viewModel) {
    return Container(
      padding: const EdgeInsets.all(15),
      margin: EdgeInsets.symmetric(horizontal: 15.w),
      width: double.infinity,
      decoration: BoxDecoration(
        color: Palette.primaryLite,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: Palette.primary,
              shape: BoxShape.circle,
              image: decorationImage(
                image: Assets.images.profile.path,
                isAsset: true,
              ),
            ),
          ),
          horizontalSpace(15.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomText(
                  'Hello',
                  style: TextStyle(
                    color: Palette.text58,
                    fontSize: 13.sp,
                    fontFamily: FontFamily.manrope,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                CustomText(
                  viewModel.user?.name ?? 'User',
                  style: TextStyle(
                    color: Palette.text3D,
                    fontSize: 18.sp,
                    fontFamily: FontFamily.manrope,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
