import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_colors.dart';
import '../../common/assets.gen.dart';
import '../../common/ui_helpers.dart';
import '../../widgets/app_bar.dart';

import 'components/item.dart';
import 'components/user_details.dart';
import 'profile_viewmodel.dart';

class ProfileView extends StackedView<ProfileViewModel> {
  const ProfileView({super.key});

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Menu",
      ),
      body: SizedBox.expand(
        child: SingleChildScrollView(
          padding: EdgeInsets.only(top: 20.h, bottom: 30.h),
          child: Column(
            children: [
              const UserDetailsWidget(),
              verticalSpace(10.h),
              // MenuItemWidget(
              //   icon: Assets.images.notification.image(),
              //   onTap: () {},
              //   label: "Notifications",
              // ),
              // menuDivider(),
              MenuItemWidget(
                icon: Assets.images.accept.image(),
                onTap: () {},
                label: "Terms & Conditions",
              ),
              menuDivider(),
              MenuItemWidget(
                icon: Assets.images.padlock.image(),
                onTap: () {},
                label: "Privacy Policy",
              ),
              menuDivider(),
              MenuItemWidget(
                icon: Assets.images.logout.image(),
                onTap: () => viewModel.logout(),
                label: "Logout",
              ),
            ],
          ),
        ),
      ),
    );
  }

  Container menuDivider() {
    return Container(
      width: double.infinity,
      height: 1,
      color: Palette.border,
      margin: EdgeInsets.only(left: 50.w, right: 15.w),
    );
  }

  @override
  ProfileViewModel viewModelBuilder(BuildContext context) {
    return ProfileViewModel();
  }
}
