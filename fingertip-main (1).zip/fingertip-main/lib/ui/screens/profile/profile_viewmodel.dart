import 'package:stacked/stacked.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../models/user.dart';
import '../../../services/user_service.dart';
import '../../common/utils.dart';

class ProfileViewModel extends ReactiveViewModel {
  final _userService = locator<UserService>();

  AppUser? get user => _userService.user;

  Future<void> logout() async {
    var res = await dialogService.showCustomDialog(
      variant: DialogType.confirm,
      title: "Logout",
      description: "Are you sure want to logout from this app ?",
      secondaryButtonTitle: "Cancel",
      mainButtonTitle: "Confirm",
    );

    if (res?.confirmed == true) {
      await _userService.logout();
    }
  }

  @override
  List<ListenableServiceMixin> get listenableServices {
    return [_userService];
  }
}
