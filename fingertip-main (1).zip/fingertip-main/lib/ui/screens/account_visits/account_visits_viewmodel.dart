import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/list.dart';
import '../../../extensions/string.dart';
import '../../../models/sort.dart';
import '../../common/app_constants.dart';
import '../../common/utils.dart';

class AccountVisitsViewModel extends StreamViewModel<List<Visit>> {
  AccountVisitsViewModel({
    required this.appAccountId,
  });

  final String appAccountId;
  final _databaseService = locator<DatabaseService>();

  static final sortOptions = [
    SortModel(
      type: "status",
      label: "Status",
    ),
    SortModel(
      type: "visit_type",
      label: "Visit Type",
    ),
  ];

  SortModel currentSort = sortOptions.first;

  List<Visit>? get filteredOrderedData {
    if (data == null) {
      return null;
    }

    switch (currentSort.type) {
      case "status":
        data!.sort((a, b) {
          final statusComparison = currentSort.isAscending
              ? VisitStatus.sortOrder(a.status) -
                  VisitStatus.sortOrder(b.status)
              : VisitStatus.sortOrder(b.status) -
                  VisitStatus.sortOrder(a.status);
          if (statusComparison != 0) {
            return statusComparison;
          } else {
            if (currentSort.isAscending) {
              return a.plannedStartTime.compareTo(b.plannedStartTime);
            } else {
              return b.plannedStartTime.compareTo(a.plannedStartTime);
            }
          }
        });
        break;
      case "visit_type":
        data!.sortByNullableField(
          getField: (e) => e.typeofVisit,
          isAscending: currentSort.isAscending,
        );
        break;

      default:
    }

    return data;
  }

  Future<void> sort() async {
    var res = await navigationService.navigateToSortView(
      initalValue: currentSort,
      sortOptions: sortOptions,
    );

    if (res is SortModel) {
      setSort(res);
    }
  }

  void setSort(SortModel sort) {
    currentSort = sort;
    notifyListeners();
  }

  void goToAccountVisitsDetailsView(Visit visit) {
    if (visit.salesAppId.isNotEmptyOrNull) {
      navigationService.navigateToAccountVisitsDetailsView(
        salesAppId: visit.salesAppId!,
      );
    }
  }

  @override
  Stream<List<Visit>> get stream {
    return _databaseService.watchVisitsByAccountId(appAccountId);
  }
}
