import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../database/database.dart';
import '../../tools/dismiss_keyboard.dart';
import '../../tools/model_future_builder.dart';
import '../../tools/parse.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/form_fields/dropdown_field.dart';

import 'components/bottom.dart';
import 'components/header.dart';
import 'components/product_list.dart';
import 'components/visit_details.dart';
import 'products_viewmodel.dart';

class ProductsView extends StackedView<ProductsViewModel> {
  const ProductsView({
    super.key,
    this.visitMap,
  });

  final Map<String, dynamic>? visitMap;

  @override
  void onViewModelReady(ProductsViewModel viewModel) {
    viewModel.getData();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "New Order",
      ),
      body: SizedBox.expand(
        child: DismissKeyboard(
          child: ModelFutureListBuilder<Product>(
            data: viewModel.products,
            busy: viewModel.isBusy,
            error: viewModel.modelError ?? "No products available",
            builder: (context, value, child) {
              return SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 30.h),
                child: Column(
                  children: [
                    Visibility(
                      visible: !viewModel.fromVisit,
                      child: CustomDropdownSearchFormField(
                        labelText: "Select Store",
                        value: viewModel.account,
                        items: viewModel.accounts,
                        itemAsString: (item) => item.name ?? "",
                        compareFn: (item1, item2) => item1.id == item2.id,
                        onChanged: (value) {
                          viewModel.account = value;
                        },
                      ),
                    ),
                    const VisitDetailsWidget(),
                    const ProductHeaderWidget(),
                    const ProductListWidget(),
                  ],
                ),
              );
            },
          ),
        ),
      ),
      bottomNavigationBar: const ProductBottomWidget(),
    );
  }

  @override
  ProductsViewModel viewModelBuilder(context) {
    return ProductsViewModel(
      visit: parseToObject(visitMap, Visit.fromJson),
    );
  }
}
