import 'package:flutter/material.dart';

import 'package:intl/intl.dart';
import 'package:stacked/stacked.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/iterable.dart';
import '../../../extensions/list.dart';
import '../../../extensions/string.dart';
import '../../common/utils.dart';
import '../../tools/smart_dialog_config.dart';

class ProductsViewModel extends StreamViewModel<List<CartItem>> {
  ProductsViewModel({
    required this.visit,
  })  : fromVisit = visit != null,
        account = visit != null
            ? Account(
                appAccountId: visit.appAccountId,
                id: visit.accountId,
                name: visit.accountName,
              )
            : null;

  final Visit? visit;
  final bool fromVisit;
  final _databaseService = locator<DatabaseService>();
  final textController = TextEditingController();

  Account? account;
  List<Product> products = [];
  List<String> categories = [];
  List<Account> accounts = [];
  String? category;

  Future<void> getData() async {
    setBusy(true);
    try {
      await _databaseService.deleteCartItems();
      products = await _databaseService.getProducts();
      products.sort((a, b) {
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });
      categories =
          products.map((e) => e.category).whereNotNull().toSet().toList();
      categories.sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
      categories.insert(0, "All");
      if (!fromVisit) {
        accounts = await _databaseService.getAccounts();
      }
    } catch (e) {
      debugPrint("$e");
      setError(e.toString());
    }
    setBusy(false);
  }

  Future<void> addProductToCart(Product product) async {
    if (account?.id == null || account?.appAccountId == null) {
      showToast("Please select a store");
      return;
    }

    var cartItem = productFromCart(product);
    if (cartItem != null) {
      await dialogService.showCustomDialog(
        variant: DialogType.addProduct,
        data: cartItem,
      );
    } else {
      var newCartItem = CartItem(
        productId: product.id,
        productName: product.name,
        quantity: 1,
        unitPrice: product.unitPrice,
        taxPercent: product.taxPercent,
        taxAmount: product.unitPrice * product.taxPercent / 100,
        totalTax: product.unitPrice * product.taxPercent / 100,
        totalAmount: product.unitPrice,
        grandTotal:
            product.unitPrice + (product.unitPrice * product.taxPercent / 100),
      );

      await dialogService.showCustomDialog(
        variant: DialogType.addProduct,
        data: newCartItem,
      );
    }
  }

  List<Product> get filteredProducts {
    List<Product> values = products;

    if (category != null) {
      values = products.where((element) {
        return element.category == category;
      }).toList();
    }

    if (textController.text.isNotEmptyOrNull) {
      values = products.where((element) {
        return element.name.toLowerCase().contains(
              textController.text.toLowerCase(),
            );
      }).toList();
    }

    return values;
  }

  int countInCart(Product product) {
    if (data.isNotEmptyOrNull) {
      var qty = data!.firstWhereOrNull((element) {
        return element.productId == product.id;
      })?.quantity;

      return qty ?? 0;
    }
    return 0;
  }

  bool isInCart(Product product) {
    if (data.isNotEmptyOrNull) {
      return data!.any((element) {
        return element.productId == product.id;
      });
    }
    return false;
  }

  CartItem? productFromCart(Product product) {
    return data!.firstWhereOrNull((element) {
      return element.productId == product.id;
    });
  }

  String get checkInDate {
    if (visit?.actualStartTime != null) {
      return DateFormat("dd MMM yyyy, hh:mm:ss a")
          .format(visit!.actualStartTime!.toLocal());
    }

    return "--";
  }

  void onSearch(String keyword) {
    notifyListeners();
  }

  void setCategory(String? value) {
    if (value == "All") {
      category = null;
    } else {
      category = value;
    }
    notifyListeners();
  }

  void clearFilter() {
    category = null;
    notifyListeners();
  }

  void navigateToCart() {
    if (account != null) {
      navigationService.navigateToCartView(
        visitMap: visit?.toJson(),
        accountMap: account!.toJson(),
      );
    }
  }

  @override
  Stream<List<CartItem>> get stream {
    return _databaseService.watchCartItems();
  }
}
