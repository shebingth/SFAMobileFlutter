import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/ui_helpers.dart';
import '../../../tools/conditional_widget.dart';
import '../../../widgets/custom_text.dart';
import '../products_viewmodel.dart';

class VisitDetailsWidget extends ViewModelWidget<ProductsViewModel> {
  const VisitDetailsWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, ProductsViewModel viewModel) {
    return IfNotNull(
      value: viewModel.visit,
      builder: (context, visit) {
        return Container(
          width: double.infinity,
          padding: EdgeInsets.fromLTRB(20.w, 20.h, 20.w, 20.h),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Palette.primaryLite,
          ),
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    flex: 2,
                    child: CustomText(
                      'Store Name',
                      style: TextStyle(
                        color: Palette.text3D,
                        fontSize: 15.sp,
                      ),
                    ),
                  ),
                  CustomText(
                    '    :    ',
                    style: TextStyle(
                      color: Palette.text3D,
                      fontSize: 15.sp,
                    ),
                  ),
                  Expanded(
                    flex: 3,
                    child: CustomText(
                      viewModel.visit!.accountName,
                      style: TextStyle(
                        color: Palette.text3D,
                        fontSize: 15.sp,
                      ),
                    ),
                  ),
                ],
              ),
              verticalSpace(18.h),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    flex: 2,
                    child: CustomText(
                      'Check-in',
                      style: TextStyle(
                        color: Palette.text3D,
                        fontSize: 15.sp,
                      ),
                    ),
                  ),
                  CustomText(
                    '    :    ',
                    style: TextStyle(
                      color: Palette.text3D,
                      fontSize: 15.sp,
                    ),
                  ),
                  Expanded(
                    flex: 3,
                    child: CustomText(
                      viewModel.checkInDate,
                      style: TextStyle(
                        color: Palette.text3D,
                        fontSize: 15.sp,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}
