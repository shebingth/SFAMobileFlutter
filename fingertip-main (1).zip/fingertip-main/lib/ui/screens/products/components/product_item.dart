import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../../database/database.dart';
import '../../../../extensions/double.dart';
import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../tools/conditional_widget.dart';
import '../../../widgets/custom_text.dart';
import '../products_viewmodel.dart';

class ProductItemWidget extends ViewModelWidget<ProductsViewModel> {
  const ProductItemWidget({
    super.key,
    required this.product,
  });

  final Product product;

  @override
  Widget build(BuildContext context, ProductsViewModel viewModel) {
    return GestureDetector(
      onTap: () => viewModel.addProductToCart(product),
      behavior: HitTestBehavior.translucent,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 15.h),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Palette.primaryLite,
          border: Border.all(color: Palette.border),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CustomText(
                    product.name,
                    style: TextStyle(
                      color: Palette.text08,
                      fontSize: 15.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  verticalSpace(12.h),
                  Row(
                    children: [
                      Expanded(
                        child: Text.rich(
                          TextSpan(
                            children: [
                              TextSpan(
                                text: "Rate :  ",
                                style: TextStyle(
                                  color: Palette.text58,
                                  fontSize: 14.sp,
                                ),
                              ),
                              TextSpan(
                                text: product.unitPrice.toPrice,
                                style: TextStyle(
                                  color: Palette.text08,
                                  fontSize: 15.sp,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Expanded(
                        child: If(
                          condition: viewModel.countInCart(product) > 0,
                          builder: (context, value) {
                            return Text.rich(
                              TextSpan(
                                children: [
                                  TextSpan(
                                    text: "Qty :  ",
                                    style: TextStyle(
                                      color: Palette.text58,
                                      fontSize: 14.sp,
                                    ),
                                  ),
                                  TextSpan(
                                    text: "${viewModel.countInCart(product)}",
                                    style: TextStyle(
                                      color: Palette.text08,
                                      fontSize: 15.sp,
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            If(
              condition: viewModel.isInCart(product),
              builder: (context, value) {
                return Assets.images.tickCircle.image();
              },
              replacement: Assets.images.addCircle.image(),
            ),
          ],
        ),
      ),
    );
  }
}
