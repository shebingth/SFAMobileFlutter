import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../tools/conditional_widget.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/form_fields/dropdown_field.dart';
import '../../../widgets/form_fields/text_field.dart';
import '../products_viewmodel.dart';

class ProductHeaderWidget extends ViewModelWidget<ProductsViewModel> {
  const ProductHeaderWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, ProductsViewModel viewModel) {
    return Column(
      children: [
        Container(
          width: double.infinity,
          margin: EdgeInsets.symmetric(vertical: 20.h),
          child: CustomText(
            "Products",
            style: TextStyle(
              color: Palette.text08,
              fontSize: 18.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        Row(
          children: [
            Expanded(
              child: CustomTextFormField(
                labelText: "Search",
                controller: viewModel.textController,
                radius: 8,
                prefixIcon: Assets.images.search.image(width: 18.w),
                onChanged: viewModel.onSearch,
              ),
            ),
            horizontalSpace(10.w),
            CustomDropdownSearchIconButton(
              items: viewModel.categories,
              labelText: "Categories",
              value: viewModel.category ?? "All",
              onChanged: viewModel.setCategory,
              itemAsString: (item) => item,
              compareFn: (item1, item2) => item1 == item2,
            ),
          ],
        ),
        IfNotNull(
          value: viewModel.category,
          condition: (value) => value.isNotEmpty,
          builder: (context, value) {
            return Container(
              width: double.infinity,
              margin: EdgeInsets.only(top: 15.h),
              child: Row(
                children: [
                  Expanded(
                    child: Text.rich(
                      TextSpan(
                        children: [
                          TextSpan(
                            text: "Category :  ",
                            style: TextStyle(
                              color: Palette.text58,
                              fontSize: 14.sp,
                            ),
                          ),
                          TextSpan(
                            text: viewModel.category,
                            style: TextStyle(
                              color: Palette.text08,
                              fontSize: 15.sp,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: viewModel.clearFilter,
                    style: TextButton.styleFrom(
                      visualDensity: VisualDensity.compact,
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                    child: const CustomText("Clear"),
                  ),
                ],
              ),
            );
          },
        )
      ],
    );
  }
}
