import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/button.dart';
import '../../../widgets/custom_text.dart';
import '../products_viewmodel.dart';

class ProductBottomWidget extends ViewModelWidget<ProductsViewModel> {
  const ProductBottomWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, ProductsViewModel viewModel) {
    var count = viewModel.data?.length ?? 0;
    if (count < 1) return const SizedBox.shrink();

    return Container(
      padding: EdgeInsets.fromLTRB(15.w, 10.h, 15.w, 10.h),
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Palette.shadow3,
            blurRadius: 5,
            offset: Offset(0, -2),
            spreadRadius: 2,
          )
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: CustomText(
              "$count items in cart",
              style: TextStyle(
                color: Palette.text3D,
                fontSize: 15.sp,
              ),
            ),
          ),
          PrimaryButton(
            onPressed: () => viewModel.navigateToCart(),
            minWidth: 140.w,
            color: Palette.pink2,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Assets.images.cart.image(),
                horizontalSpace(5.w),
                Container(
                  margin: EdgeInsets.only(bottom: 3.h),
                  child: CustomText(
                    'View Cart',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
