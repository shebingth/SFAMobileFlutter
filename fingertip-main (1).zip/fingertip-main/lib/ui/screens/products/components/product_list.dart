import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../tools/conditional_widget.dart';
import '../../../tools/screen_size.dart';
import '../../../tools/separated_list.dart';
import '../../../widgets/custom_text.dart';
import '../products_viewmodel.dart';

import 'product_item.dart';

class ProductListWidget extends ViewModelWidget<ProductsViewModel> {
  const ProductListWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, ProductsViewModel viewModel) {
    return IfNotNull(
      value: viewModel.filteredProducts,
      condition: (value) => value.isNotEmpty,
      builder: (context, value) {
        return Container(
          margin: EdgeInsets.only(top: 20.h),
          child: SeparatedWidgetList(
            list: viewModel.filteredProducts,
            builder: (product, index) {
              return ProductItemWidget(
                product: product,
              );
            },
            separation: 15.h,
          ),
        );
      },
      replacement: Container(
        alignment: Alignment.center,
        height: ScreenSize.height * 0.35,
        child: CustomText(
          "No Products available",
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 13.sp,
            fontWeight: FontWeight.normal,
            color: Colors.grey[500],
          ),
        ),
      ),
    );
  }
}
