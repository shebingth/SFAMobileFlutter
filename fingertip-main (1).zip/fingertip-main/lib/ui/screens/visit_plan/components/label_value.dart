import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../common/app_colors.dart';
import '../../../widgets/custom_text.dart';

class MainListLabelValueWidget extends StatelessWidget {
  const MainListLabelValueWidget({
    super.key,
    required this.label,
    required this.value,
    this.top,
    this.valueColor,
    this.withReadMore = false,
    this.trimLength = 70,
  });

  final String? label;
  final String? value;
  final double? top;
  final Color? valueColor;
  final bool withReadMore;
  final int trimLength;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: top ?? 0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 2,
            child: CustomText(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Palette.grey3E,
                fontSize: 15.sp,
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.only(left: 5.w, right: 40.w),
            child: CustomText(
              ":",
              style: TextStyle(
                color: Palette.text08,
                fontSize: 15.sp,
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: CustomText(
              value,
              maxLines: 1,
              withReadMore: withReadMore,
              trimLength: trimLength,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: valueColor ?? Palette.text08,
                fontSize: 15.sp,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
