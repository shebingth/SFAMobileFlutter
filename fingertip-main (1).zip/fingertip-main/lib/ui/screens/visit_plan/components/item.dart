import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../database/database.dart';
import '../../../common/app_colors.dart';
import '../../../common/date_time_utils.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/custom_text.dart';

import 'label_value.dart';

class VisitPlanWidget extends StatelessWidget {
  const VisitPlanWidget({
    super.key,
    required this.item,
    required this.onTap,
  });

  final VisitPlan item;
  final void Function(VisitPlan item) onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onTap(item),
      behavior: HitTestBehavior.translucent,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 15.w),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: EdgeInsets.only(top: 25.h, bottom: 20.h),
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: Palette.divider),
                ),
              ),
              child: CustomText(
                item.name,
                style: TextStyle(
                  fontSize: 15.sp,
                  fontWeight: FontWeight.w600,
                  color: Palette.text08,
                ),
              ),
            ),
            MainListLabelValueWidget(
              label: "Executive",
              value: item.executiveName,
              top: 20.h,
            ),
            MainListLabelValueWidget(
              label: "Month",
              value: DateTimeUtils.monthToLabel(item.month),
              top: 15.h,
            ),
            MainListLabelValueWidget(
              label: "Year",
              value: item.year?.toString(),
              top: 15.h,
            ),
            MainListLabelValueWidget(
              label: "Frequency",
              value: item.frequency,
              top: 15.h,
            ),
            verticalSpace(25.h),
          ],
        ),
      ),
    );
  }
}
