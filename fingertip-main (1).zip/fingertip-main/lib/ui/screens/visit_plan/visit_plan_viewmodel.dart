import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/list.dart';
import '../../../extensions/string.dart';
import '../../../models/sort.dart';
import '../../common/app_constants.dart';
import '../../common/date_time_utils.dart';
import '../../common/utils.dart';
import '../../tools/parse.dart';

class VisitPlanViewModel extends StreamViewModel<List<VisitPlan>> {
  final _databaseService = locator<DatabaseService>();

  List<FilterModel> selectedFilters = [];

  static final sortOptions = [
    SortModel(
      type: "created_date",
      label: "Created Date",
      isAscending: false,
    ),
    SortModel(
      type: "start_date",
      label: "Start Date",
    ),
    SortModel(
      type: "year",
      label: "Year",
    ),
    SortModel(
      type: "month",
      label: "Month",
    ),
  ];

  List<FilterModel> get filterOptions {
    return [
      FilterModel(
        type: FilterType.textField,
        label: "Executive",
      ),
      FilterModel(
        type: FilterType.dropdown,
        label: "Month",
        options: getMonthOptions(),
      ),
      FilterModel(
        type: FilterType.dropdown,
        label: "Year",
        options: getYearOptions(),
      ),
    ];
  }

  SortModel currentSort = sortOptions.first;

  List<VisitPlan>? get filteredOrderedData {
    List<VisitPlan> currentData = data ?? [];
    //Filter
    for (var filter in selectedFilters) {
      switch (filter.label) {
        case "Executive":
          if (filter.value.isNotEmptyOrNull) {
            currentData = currentData.where((element) {
              return element.executiveName != null &&
                  element.executiveName!.toLowerCase().contains(filter.value!);
            }).toList();
          }
          break;
        case "Month":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.month == parseToInt(filter.valueOption!.value!);
            }).toList();
          }
          break;
        case "Year":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.year == parseToInt(filter.valueOption!.value!);
            }).toList();
          }
          break;

        default:
          break;
      }
    }

    //Sort
    switch (currentSort.type) {
      case "created_date":
        currentData.sortByNullableField(
          getField: (e) => e.createdDate,
          isAscending: currentSort.isAscending,
        );
      case "start_date":
        currentData.sortByNullableField(
          getField: (e) => e.startDate,
          isAscending: currentSort.isAscending,
        );
        break;
      case "year":
        currentData.sortByNullableField(
          getField: (e) => e.year,
          isAscending: currentSort.isAscending,
        );
        break;
      case "month":
        currentData.sortByNullableField(
          getField: (e) => e.month,
          isAscending: currentSort.isAscending,
        );
        break;

      default:
        break;
    }

    return currentData;
  }

  Future<void> sort() async {
    var res = await navigationService.navigateToSortView(
      initalValue: currentSort,
      sortOptions: sortOptions,
    );

    if (res is SortModel) {
      setSort(res);
    }
  }

  void setSort(SortModel sort) {
    currentSort = sort;
    notifyListeners();
  }

  Future<void> filter() async {
    var res = await navigationService.navigateToFilterView(
      filters: filterOptions,
      selectedFilters: selectedFilters,
    );

    if (res is List<FilterModel>) {
      selectedFilters = res;
      notifyListeners();
    }
  }

  void goToVisitPlanDetail(VisitPlan item) {
    if (item.appVisitPlanId.isNotEmptyOrNull) {
      navigationService.navigateToVisitPlanDetailsView(
        appVisitPlanId: item.appVisitPlanId!,
      );
    }
  }

  List<FilterOptionModel> getYearOptions() {
    var now = DateTime.now();
    var firstYear = now.year - 3;
    var lastYear = now.year + 3;
    List<FilterOptionModel> options = [];

    for (var i = firstYear; i <= lastYear; i++) {
      options.add(
        FilterOptionModel(label: "$i", value: "$i"),
      );
    }

    return options;
  }

  List<FilterOptionModel> getMonthOptions() {
    List<FilterOptionModel> options = [];

    for (var i = 1; i <= 12; i++) {
      options.add(
        FilterOptionModel(label: DateTimeUtils.monthToLabel(i), value: "$i"),
      );
    }

    return options;
  }

  @override
  Stream<List<VisitPlan>> get stream => _databaseService.watchVisitPlans();
}
