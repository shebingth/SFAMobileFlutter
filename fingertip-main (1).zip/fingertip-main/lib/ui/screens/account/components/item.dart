import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../database/database.dart';
import '../../../../extensions/date_time.dart';
import '../../../common/app_colors.dart';
import '../../../common/app_constants.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/custom_text.dart';
import '../../visit_plan/components/label_value.dart';

class AccountWidget extends StatelessWidget {
  const AccountWidget({
    super.key,
    required this.item,
    required this.onTap,
  });

  final Account item;
  final void Function(Account item) onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onTap(item),
      behavior: HitTestBehavior.translucent,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 15.w),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: EdgeInsets.only(top: 25.h, bottom: 20.h),
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: Palette.divider),
                ),
              ),
              child: CustomText(
                item.name,
                style: TextStyle(
                  fontSize: 15.sp,
                  fontWeight: FontWeight.w600,
                  color: Palette.text08,
                ),
              ),
            ),
            MainListLabelValueWidget(
              top: 20.h,
              label: "Approval",
              value: item.approvalStatus,
              valueColor: AccountStatus.statusColor(item.approvalStatus),
            ),
            MainListLabelValueWidget(
              top: 20.h,
              label: "Mobile",
              value: item.mobile,
            ),
            MainListLabelValueWidget(
              top: 20.h,
              label: "State",
              value: item.state,
            ),
            MainListLabelValueWidget(
              top: 20.h,
              label: "District",
              value: item.district,
            ),
            MainListLabelValueWidget(
              top: 20.h,
              label: "Created At",
              value: item.createdDate.toFormattedDateTime(),
            ),
            MainListLabelValueWidget(
              top: 20.h,
              label: "Last Modified At",
              value: item.lastModifiedDate.toFormattedDateTime(),
            ),
            MainListLabelValueWidget(
              top: 20.h,
              label: "Routes",
              value: item.routesName,
            ),
            MainListLabelValueWidget(
              top: 20.h,
              label: "Latitude",
              value: item.latitude,
            ),
            MainListLabelValueWidget(
              top: 20.h,
              label: "Longitude",
              value: item.longitude,
            ),
            verticalSpace(25.h),
          ],
        ),
      ),
    );
  }
}
