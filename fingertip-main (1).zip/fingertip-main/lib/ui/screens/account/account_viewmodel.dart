import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/date_time.dart';
import '../../../extensions/list.dart';
import '../../../extensions/string.dart';
import '../../../models/sort.dart';
import '../../../models/states.dart';
import '../../common/app_constants.dart';
import '../../common/utils.dart';

class AccountViewModel extends StreamViewModel<List<Account>> {
  final _databaseService = locator<DatabaseService>();

  List<FilterModel> selectedFilters = [];
  List<AccountRoute> routes = [];

  List<FilterModel> get filterOptions {
    return [
      FilterModel(
        type: FilterType.date,
        label: "Created Date",
      ),
      FilterModel(
        type: FilterType.dropdown,
        label: "Approval Status",
        options: [
          "Approved",
          "Pending",
        ].map((e) => FilterOptionModel(label: e, value: e)).toList(),
      ),
      FilterModel(
        type: FilterType.dropdownSearch,
        label: "State",
        options: states.map((e) {
          return FilterOptionModel(label: e.name, value: e.name);
        }).toList(),
      ),
      FilterModel(
        type: FilterType.dropdownSearch,
        label: "Route",
        options: routes.map((e) {
          return FilterOptionModel(label: e.name, value: e.id);
        }).toList(),
      ),
      FilterModel(
        type: FilterType.textField,
        label: "City",
      ),
      FilterModel(
        type: FilterType.dropdown,
        label: "Account Classification",
        options: [
          "Platinum",
          "Gold",
          "Silver",
          "Regular",
        ].map((e) => FilterOptionModel(label: e, value: e)).toList(),
      ),
    ];
  }

  static final sortOptions = [
    SortModel(
      type: "created_date",
      label: "Created Date",
      isAscending: false,
    ),
    SortModel(
      type: "owner",
      label: "Owner",
    ),
    SortModel(
      type: "name",
      label: "Name",
    ),
    SortModel(
      type: "status",
      label: "Approval Status",
    ),
  ];

  SortModel currentSort = sortOptions.first;

  List<Account>? get filteredOrderedData {
    List<Account> currentData = data ?? [];

    //Filter
    for (var filter in selectedFilters) {
      switch (filter.label) {
        case "Created Date":
          if (filter.valueFromDate != null && filter.valueToDate != null) {
            currentData = currentData.where((element) {
              return element.createdDate.isBetweenDates(
                startDate: filter.valueFromDate!,
                endDate: filter.valueToDate!,
              );
            }).toList();
          }
          break;
        case "Approval Status":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.approvalStatus == filter.valueOption!.value!;
            }).toList();
          }
          break;
        case "State":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.state == filter.valueOption!.value!;
            }).toList();
          }
          break;
        case "Route":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.routesId == filter.valueOption!.value!;
            }).toList();
          }
          break;
        case "City":
          if (filter.value.isNotEmptyOrNull) {
            currentData = currentData.where((element) {
              return element.city
                      ?.toLowerCase()
                      .contains(filter.value!.toLowerCase()) ??
                  false;
            }).toList();
          }
          break;
        case "Account Classification":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.accountClassification ==
                  filter.valueOption!.value!;
            }).toList();
          }
          break;
        default:
          break;
      }
    }

    //Sort
    switch (currentSort.type) {
      case "created_date":
        currentData.sortByNullableField(
          getField: (e) => e.createdDate,
          isAscending: currentSort.isAscending,
        );
        break;
      case "owner":
        currentData.sortByNullableField(
          getField: (e) => e.accountOwnerName,
          isAscending: currentSort.isAscending,
        );
        break;
      case "name":
        currentData.sortByNullableField(
          getField: (e) => e.name,
          isAscending: currentSort.isAscending,
        );
        break;
      case "status":
        currentData.sortByNullableField(
          getField: (e) => e.approvalStatus,
          isAscending: currentSort.isAscending,
        );
        break;
      default:
        break;
    }

    return currentData;
  }

  Future<void> init() async {
    routes = await _databaseService.getRoutes();
    notifyListeners();
  }

  Future<void> filter() async {
    var res = await navigationService.navigateToFilterView(
      filters: filterOptions,
      selectedFilters: selectedFilters,
    );

    if (res is List<FilterModel>) {
      selectedFilters = res;
      notifyListeners();
    }
  }

  Future<void> sort() async {
    var res = await navigationService.navigateToSortView(
      initalValue: currentSort,
      sortOptions: sortOptions,
    );

    if (res is SortModel) {
      setSort(res);
    }
  }

  void setSort(SortModel sort) {
    currentSort = sort;
    notifyListeners();
  }

  void goToAccountDetailsView(Account item) {
    if (item.appAccountId.isNotEmptyOrNull) {
      navigationService.navigateToAccountDetailsView(
        appAccountId: item.appAccountId!,
        accountId: item.id,
      );
    }
  }

  @override
  Stream<List<Account>> get stream => _databaseService.watchAccounts();
}
