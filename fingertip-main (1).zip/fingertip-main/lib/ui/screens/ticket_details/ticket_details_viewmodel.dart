import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../database/database.dart';

class TicketDetailsViewModel extends StreamViewModel<Ticket> {
  TicketDetailsViewModel({
    required this.ticketId,
  });

  final String ticketId;

  final _databaseService = locator<DatabaseService>();

  @override
  Stream<Ticket> get stream {
    return _databaseService.watchTicketByAppTicketId(ticketId);
  }
}
