import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../tools/conditional_widget.dart';
import '../../tools/model_future_builder.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/details_label_value.dart';

import 'ticket_details_viewmodel.dart';

class TicketDetailsView extends StackedView<TicketDetailsViewModel> {
  const TicketDetailsView({
    super.key,
    required this.ticketId,
  });

  final String ticketId;

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Ticket",
      ),
      body: SizedBox.expand(
        child: IfNotNull(
          value: viewModel.data,
          replacement: ModelErrorWidget(
            error: viewModel.initialised ? "Something went wrong" : "",
          ),
          builder: (context, data) {
            return SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(15.w, 25.h, 15.w, 30.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  DetailsLabelValueWidget(
                    label: "Account",
                    value: data.accountName,
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Status",
                    value: data.status,
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Complaint Type",
                    value: data.complaintType,
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Subject",
                    value: data.subject,
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Description",
                    value: data.description,
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  TicketDetailsViewModel viewModelBuilder(BuildContext context) {
    return TicketDetailsViewModel(
      ticketId: ticketId,
    );
  }
}
