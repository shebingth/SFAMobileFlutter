import 'package:flutter/material.dart';

import 'package:stacked/stacked.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../database/database.dart';
import '../../../models/user.dart';
import '../../../services/user_service.dart';
import '../../common/utils.dart';

class VisitPlanNewViewModel extends BaseViewModel {
  final _databaseService = locator<DatabaseService>();
  final _userService = locator<UserService>();
  final formKey = GlobalKey<FormState>();

  String? name;
  int? month;
  int? year;
  String? frequency;
  var autovalidateMode = AutovalidateMode.disabled;

  AppUser? get user => _userService.user;

  Future<void> addVisitPlan() async {
    if (formKey.currentState?.validate() == true) {
      formKey.currentState!.save();

      bool status = await runBusyFuture(
        _databaseService.addNewVisitPlan(
          name: name,
          month: month,
          year: year,
          frequency: frequency,
          user: user,
        ),
        busyObject: formKey,
      );

      if (status) {
        await dialogService.showCustomDialog(
          variant: DialogType.confirm,
          title: "Visit Plan Added",
          description: "Visit Plan added successfully\nto the list.",
          mainButtonTitle: "Continue",
          secondaryButtonTitle: "Cancel",
        );

        navigationService.back();
      }
    } else {
      setAutovalidateMode(AutovalidateMode.always);
    }
  }

  void setAutovalidateMode(AutovalidateMode mode) {
    autovalidateMode = mode;
    notifyListeners();
  }

  void setMonth(int? value) {
    month = value;
    notifyListeners();
  }

  void setYear(int? value) {
    year = value;
    notifyListeners();
  }

  void setFrequency(String? value) {
    frequency = value;
    notifyListeners();
  }

  void cancel() => navigationService.back();
}
