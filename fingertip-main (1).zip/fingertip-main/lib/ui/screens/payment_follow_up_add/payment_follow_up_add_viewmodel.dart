import 'package:flutter/material.dart';

import 'package:stacked/stacked.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../database/database.dart';
import '../../../models/payment_follow_up.dart';
import '../../common/utils.dart';

class PaymentFollowUpAddViewModel extends BaseViewModel {
  PaymentFollowUpAddViewModel({
    required this.visit,
  }) : data = PaymentFollowUpHelper(
          accountId: visit.accountId,
          accountName: visit.accountName,
          appAccountId: visit.appAccountId,
          visitId: visit.id,
          appVisitId: visit.salesAppId,
          synced: false,
        );

  final Visit visit;
  final _databaseService = locator<DatabaseService>();
  final formKey = GlobalKey<FormState>();

  PaymentFollowUpHelper data;
  var autovalidateMode = AutovalidateMode.disabled;

  Future<void> submit() async {
    if (formKey.currentState?.validate() ?? false) {
      formKey.currentState!.save();

      bool status = await runBusyFuture(
        _databaseService.addNewPaymentFollowUp(data: data),
        busyObject: formKey,
      );

      if (status) {
        await dialogService.showCustomDialog(
          variant: DialogType.confirm,
          title: "Payment Follow Up Added",
          description: "New payment follow up added\nsuccessfully.",
          mainButtonTitle: "Continue",
          secondaryButtonTitle: "Cancel",
        );

        navigationService.back();
      }
    } else {
      setAutovalidateMode(AutovalidateMode.always);
    }
  }

  void setAutovalidateMode(AutovalidateMode mode) {
    autovalidateMode = mode;
    notifyListeners();
  }

  void cancel() => navigationService.back();
}
