import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:date_field/date_field.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../database/database.dart';
import '../../../extensions/string.dart';
import '../../common/app_colors.dart';
import '../../common/ui_helpers.dart';
import '../../tools/dismiss_keyboard.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/button.dart';
import '../../widgets/form_fields/date_picker.dart';
import '../../widgets/form_fields/text_field.dart';

import 'payment_follow_up_add_viewmodel.dart';

class PaymentFollowUpAddView extends StackedView<PaymentFollowUpAddViewModel> {
  const PaymentFollowUpAddView({
    super.key,
    required this.visitMap,
  });

  final Map<String, dynamic> visitMap;

  @override
  Widget builder(context, viewModel, child) {
    var data = viewModel.data;

    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Payment Follow Up",
      ),
      body: SizedBox.expand(
        child: DismissKeyboard(
          child: Form(
            key: viewModel.formKey,
            autovalidateMode: viewModel.autovalidateMode,
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(15.w, 25.h, 15.w, 30.h),
              child: Column(
                children: [
                  CustomTextFormField(
                    labelText: "Expected Amount",
                    keyboardType: TextInputType.number,
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(
                        RegExp(r'^\d*\.?\d*$'),
                      ),
                    ],
                    prefixText: "₹",
                    onSaved: (newValue) {
                      data.expectedAmount = newValue;
                    },
                    validator: (value) {
                      if (value.isEmptyOrNull) {
                        return 'Required';
                      }
                      return null;
                    },
                  ),
                  CustomDateFormField(
                    top: 20.h,
                    labelText: "Expected Payment Date",
                    mode: DateTimeFieldPickerMode.date,
                    hideOuterLabel: true,
                    canClear: false,
                    initialValue: data.expectedPaymentDate,
                    firstDate: DateTime.now(),
                    lastDate: DateTime(DateTime.now().year + 1),
                    onChanged: (d) {},
                    onSaved: (newValue) {
                      data.expectedPaymentDate = newValue;
                    },
                    validator: (value) {
                      if (value == null) {
                        return "Required";
                      }
                      return null;
                    },
                  ),
                  CustomTextFormField(
                    top: 20.h,
                    labelText: "Comments",
                    maxLines: 4,
                    onSaved: (newValue) {
                      data.comment = newValue;
                    },
                    validator: (value) {
                      if (value.isEmptyOrNull) {
                        return 'Required';
                      }
                      return null;
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
        decoration: const BoxDecoration(
          color: Palette.scaffoldBackground,
          boxShadow: [
            BoxShadow(
              color: Palette.shadow3,
              blurRadius: 5,
              offset: Offset(0, -2),
              spreadRadius: 2,
            )
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.cancel,
                label: "Cancel",
                color: Palette.greyBA,
              ),
            ),
            horizontalSpace(15.w),
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.submit,
                isBusy: viewModel.busy(viewModel.formKey),
                label: "Save",
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  PaymentFollowUpAddViewModel viewModelBuilder(BuildContext context) {
    return PaymentFollowUpAddViewModel(
      visit: Visit.fromJson(visitMap),
    );
  }
}
