import 'package:stacked/stacked.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/string.dart';
import '../../common/utils.dart';

class AccountDetailsViewModel extends StreamViewModel<Account?> {
  AccountDetailsViewModel({
    required this.appAccountId,
    this.accountId,
  });

  final String appAccountId;
  final String? accountId;
  final _databaseService = locator<DatabaseService>();

  List<Visit> visits = [];
  List<PaymentFollowUp> paymentFollowUps = [];
  List<PaymentReceipt> paymentReceipts = [];

  Future<void> init() async {
    visits = await _databaseService.getVisitsByAccountId(appAccountId);
    paymentFollowUps = await _databaseService.getPaymentFollowUpsByAccountId(
      appAccountId,
    );
    paymentReceipts = await _databaseService.getPaymentReceiptByAccountId(
      appAccountId: appAccountId,
      accountId: accountId,
    );
    notifyListeners();
  }

  void editAccount() {
    navigationService.navigateToAccountAddView(
      appAccountId: appAccountId,
    );
  }

  void deleteAccount() {}

  void uploadFiles(Account account) {
    if (account.appAccountId.isNotEmptyOrNull) {
      dialogService.showCustomDialog(
        variant: DialogType.accountFileUpload,
        data: account,
      );
    }
  }

  void relatedVisits(Account account) {
    if (account.appAccountId.isNotEmptyOrNull) {
      navigationService.navigateToAccountVisitsView(
        appAccountId: account.appAccountId!,
      );
    }
  }

  void relatedPaymentFollowUps(Account data) {
    if (data.appAccountId.isNotEmptyOrNull) {
      navigationService.navigateToAccountPaymentFollowUpView(
        appAccountId: data.appAccountId!,
      );
    }
  }

  void relatedPaymentReceipts(Account data) {
    if (data.appAccountId.isNotEmptyOrNull) {
      navigationService.navigateToAccountPaymentReceiptView(
        appAccountId: data.appAccountId!,
        accountId: data.id,
      );
    }
  }

  @override
  Stream<Account?> get stream {
    return _databaseService.watchAccount(appAccountId);
  }
}
