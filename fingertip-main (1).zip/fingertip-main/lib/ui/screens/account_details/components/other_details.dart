import 'dart:math';

import 'package:flutter/material.dart';

import 'package:configurable_expansion_tile_null_safety/configurable_expansion_tile_null_safety.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../database/database.dart';
import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../tools/screen_size.dart';
import '../../../widgets/custom_text.dart';
import '../../visit_plan_visits/components/item.dart';

class AccountDetailsOtherDetails extends StatelessWidget {
  const AccountDetailsOtherDetails({
    super.key,
    required this.data,
  });

  final Account data;

  @override
  Widget build(BuildContext context) {
    return ConfigurableExpansionTile(
      initiallyExpanded: true,
      header: (isExpanded, _, __, ___) {
        return Container(
          padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 20.h),
          width: ScreenSize.width,
          child: Row(
            children: [
              Expanded(
                child: CustomText(
                  "Contact Information",
                  style: TextStyle(
                    fontSize: 15.sp,
                    fontWeight: FontWeight.bold,
                    color: Palette.text,
                  ),
                ),
              ),
              Transform.rotate(
                angle: isExpanded ? pi : 0,
                child: Assets.images.angleDown24.image(),
              ),
            ],
          ),
        );
      },
      childrenBody: Container(
        padding: EdgeInsets.fromLTRB(15.w, 5.h, 15.w, 25.h),
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DetailPageLabelValue(
              label: "Contact Person",
              value: data.contactPersonName,
            ),
            DetailPageLabelValue(
              top: 20.h,
              label: "Alternate Mobile",
              value: data.alternateMobile,
            ),
            DetailPageLabelValue(
              top: 20.h,
              label: "Email",
              value: data.email,
            ),
            DetailPageLabelValue(
              top: 20.h,
              label: "Description",
              value: data.description,
            ),
          ],
        ),
      ),
    );
  }
}
