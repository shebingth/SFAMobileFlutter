import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

import 'package:configurable_expansion_tile_null_safety/configurable_expansion_tile_null_safety.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../database/database.dart';
import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../tools/screen_size.dart';
import '../../../widgets/custom_text.dart';
import '../../visit_plan_visits/components/item.dart';

class AccountDetailsAddress extends StatelessWidget {
  const AccountDetailsAddress({
    super.key,
    required this.data,
  });

  final Account data;

  @override
  Widget build(BuildContext context) {
    return ConfigurableExpansionTile(
      header: (isExpanded, _, __, ___) {
        return Container(
          padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 20.h),
          width: ScreenSize.width,
          child: Row(
            children: [
              Expanded(
                child: CustomText(
                  "Address",
                  style: TextStyle(
                    fontSize: 15.sp,
                    fontWeight: FontWeight.bold,
                    color: Palette.text,
                  ),
                ),
              ),
              Transform.rotate(
                angle: isExpanded ? pi : 0,
                child: Assets.images.angleDown24.image(),
              ),
            ],
          ),
        );
      },
      childrenBody: Container(
        padding: EdgeInsets.fromLTRB(15.w, 5.h, 15.w, 25.h),
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: DetailPageLabelValue(
                    label: "Street Name",
                    value: data.streetName,
                  ),
                ),
                Expanded(
                  child: DetailPageLabelValue(
                    label: "Panchayath",
                    value: data.panchayat,
                  ),
                ),
              ],
            ),
            DetailPageLabelValue(
              top: 20.h,
              label: "City",
              value: data.city,
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: DetailPageLabelValue(
                    top: 20.h,
                    label: "State",
                    value: data.state,
                  ),
                ),
                Expanded(
                  child: DetailPageLabelValue(
                    top: 20.h,
                    label: "District",
                    value: data.district,
                  ),
                ),
              ],
            ),
            DetailPageLabelValue(
              top: 20.h,
              label: "Pin Code",
              value: data.pincode,
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: DetailPageLabelValue(
                    top: 20.h,
                    label: "Latitude",
                    value: data.latitude,
                  ),
                ),
                Expanded(
                  child: DetailPageLabelValue(
                    top: 20.h,
                    label: "Longitude",
                    value: data.longitude,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
