import 'dart:math';

import 'package:flutter/material.dart';

import 'package:configurable_expansion_tile_null_safety/configurable_expansion_tile_null_safety.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../database/database.dart';
import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../tools/screen_size.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/network_image.dart';
import '../../visit_plan_visits/components/item.dart';

class AccountDetailsBasicDetails extends StatelessWidget {
  const AccountDetailsBasicDetails({
    super.key,
    required this.data,
  });

  final Account data;

  @override
  Widget build(BuildContext context) {
    return ConfigurableExpansionTile(
      initiallyExpanded: true,
      header: (isExpanded, _, __, ___) {
        return Container(
          padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 20.h),
          width: ScreenSize.width,
          child: Row(
            children: [
              Expanded(
                child: CustomText(
                  "Basic Information",
                  style: TextStyle(
                    fontSize: 15.sp,
                    fontWeight: FontWeight.bold,
                    color: Palette.text,
                  ),
                ),
              ),
              Transform.rotate(
                angle: isExpanded ? pi : 0,
                child: Assets.images.angleDown24.image(),
              ),
            ],
          ),
        );
      },
      childrenBody: Container(
        padding: EdgeInsets.fromLTRB(15.w, 5.h, 15.w, 25.h),
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    color: Colors.white,
                    boxShadow: const [
                      BoxShadow(
                        color: Palette.shadow1A,
                        offset: Offset(0, 0),
                        blurRadius: 6,
                        spreadRadius: 0,
                      )
                    ],
                    image: decorationImage(
                      image: Assets.images.user.path,
                      isAsset: true,
                    ),
                  ),
                ),
                horizontalSpace(12.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(
                        "Account",
                        style: TextStyle(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.normal,
                          color: Palette.text58,
                        ),
                      ),
                      CustomText(
                        data.name,
                        top: 7.h,
                        style: TextStyle(
                          fontSize: 15.sp,
                          fontWeight: FontWeight.bold,
                          color: Palette.text,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            DetailPageLabelValue(
              top: 20.h,
              label: "Mobile",
              value: data.mobile,
            ),
            // DetailPageLabelValue(
            //   top: 20.h,
            //   label: "Email",
            //   value: data.email,
            // ),
            DetailPageLabelValue(
              top: 20.h,
              label: "Account Owner",
              value: data.accountOwnerName,
            ),
            DetailPageLabelValue(
              top: 20.h,
              label: "Parent Account",
              value: data.parentAccountName,
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: DetailPageLabelValue(
                    top: 20.h,
                    label: "Account Classification",
                    value: data.accountClassification,
                  ),
                ),
                Expanded(
                  child: DetailPageLabelValue(
                    top: 20.h,
                    label: "Grade",
                    value: data.grade,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
