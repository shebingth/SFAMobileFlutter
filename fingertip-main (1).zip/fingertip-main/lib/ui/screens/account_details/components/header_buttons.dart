import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../visit_plan/components/header_button.dart';
import '../account_details_viewmodel.dart';

class AccountDetailsHeaderButtons
    extends ViewModelWidget<AccountDetailsViewModel> {
  const AccountDetailsHeaderButtons({
    super.key,
  });

  @override
  Widget build(BuildContext context, AccountDetailsViewModel viewModel) {
    return Container(
      width: double.infinity,
      color: Palette.greyF5,
      padding: EdgeInsets.fromLTRB(20.w, 11.5.h, 20.w, 11.5.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          HeaderButtonWidget(
            onTap: viewModel.editAccount,
            icon: Assets.images.edit.image(),
            label: "Edit",
          ),
          HeaderButtonWidget(
            onTap: viewModel.deleteAccount,
            icon: Assets.images.trashCircle.image(),
            label: "Delete",
          ),
          const SizedBox.shrink(),
        ],
      ),
    );
  }
}
