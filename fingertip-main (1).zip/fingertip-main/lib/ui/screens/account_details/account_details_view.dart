import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_colors.dart';
import '../../common/assets.gen.dart';
import '../../common/ui_helpers.dart';
import '../../tools/conditional_widget.dart';
import '../../tools/model_future_builder.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/divider.dart';

import 'account_details_viewmodel.dart';
import 'components/address.dart';
import 'components/basic_details.dart';
import 'components/header_buttons.dart';
import 'components/information.dart';
import 'components/other_details.dart';

class AccountDetailsView extends StackedView<AccountDetailsViewModel> {
  const AccountDetailsView({
    super.key,
    required this.appAccountId,
    this.accountId,
  });

  final String appAccountId;
  final String? accountId;

  @override
  void onViewModelReady(AccountDetailsViewModel viewModel) {
    viewModel.init();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Account Details",
      ),
      body: SizedBox.expand(
        child: IfNotNull(
          value: viewModel.data,
          replacement: ModelErrorWidget(
            error: viewModel.initialised ? "Something went wrong" : "",
          ),
          builder: (context, data) {
            return SingleChildScrollView(
              child: Column(
                children: [
                  const AccountDetailsHeaderButtons(),
                  AccountDetailsBasicDetails(data: data),
                  const DividerWidget(),
                  AccountDetailsOtherDetails(data: data),
                  const DividerWidget(),
                  AccountDetailsAddress(data: data),
                  const DividerWidget(),
                  AccountDetailsSystemInformation(data: data),
                  const DividerWidget(),
                  RelatedItemWidget(
                    top: 15.h,
                    icon: Assets.images.pinBlue.image(),
                    title: "Visits",
                    count: viewModel.visits.length,
                    onTap: () => viewModel.relatedVisits(data),
                  ),
                  RelatedItemWidget(
                    top: 15.h,
                    icon: Assets.images.creditCards.image(),
                    title: "Payment Receipts",
                    count: viewModel.paymentReceipts.length,
                    onTap: () => viewModel.relatedPaymentReceipts(data),
                  ),
                  RelatedItemWidget(
                    top: 15.h,
                    icon: Assets.images.creditCard.image(),
                    title: "Payment Follow Up",
                    count: viewModel.paymentFollowUps.length,
                    onTap: () => viewModel.relatedPaymentFollowUps(data),
                  ),
                  RelatedItemWidget(
                    top: 15.h,
                    bottom: 32.h,
                    icon: Assets.images.blankPage.image(),
                    title: "File Upload",
                    onTap: () => viewModel.uploadFiles(data),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  AccountDetailsViewModel viewModelBuilder(BuildContext context) {
    return AccountDetailsViewModel(
      appAccountId: appAccountId,
      accountId: accountId,
    );
  }
}

class RelatedItemWidget extends StatelessWidget {
  const RelatedItemWidget({
    super.key,
    required this.title,
    this.count,
    this.icon,
    this.top,
    this.bottom,
    this.onTap,
  });

  final String title;
  final int? count;
  final Widget? icon;
  final double? top;
  final double? bottom;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.translucent,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.fromLTRB(20.w, 15.h, 20.w, 15.h),
        margin: EdgeInsets.fromLTRB(15.w, top ?? 0, 15.w, bottom ?? 0),
        decoration: BoxDecoration(
          color: Palette.scaffoldBackground,
          borderRadius: BorderRadius.circular(10),
          boxShadow: const [
            BoxShadow(
              color: Palette.shadow1A,
              offset: Offset(0, 1),
              blurRadius: 9,
              spreadRadius: -1,
            ),
          ],
        ),
        child: Row(
          children: [
            if (icon != null) icon!,
            if (icon != null) horizontalSpace(8.w),
            Expanded(
              child: CustomText(
                '$title ${count != null ? "($count)" : ""}',
                style: TextStyle(
                  color: Palette.text09,
                  fontSize: 17.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            Assets.images.angleRightBlack.image(),
          ],
        ),
      ),
    );
  }
}
