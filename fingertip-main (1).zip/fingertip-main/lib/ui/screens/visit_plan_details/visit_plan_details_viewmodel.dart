import 'package:flutter/material.dart';

import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../models/visit_plan.dart';
import '../../common/date_time_utils.dart';
import '../../common/utils.dart';

class VisitPlanDetailsViewModel extends StreamViewModel<List<Visit>> {
  VisitPlanDetailsViewModel({
    required this.appVisitPlanId,
  });

  final String appVisitPlanId;
  final _databaseService = locator<DatabaseService>();

  VisitPlan? visitPlan;

  Future<void> init() async {
    visitPlan = await runBusyFuture(
      _databaseService.getVisitPlan(appVisitPlanId: appVisitPlanId),
    );
  }

  Future<void> addVisit(BuildContext context) async {
    if (visitPlan?.startDate != null && visitPlan?.endDate != null) {
      var date = await showDatePicker(
        context: context,
        initialDate: DateTimeUtils.isTodayBetweenDates(
          startDate: visitPlan!.startDate!,
          endDate: visitPlan!.endDate!,
        )
            ? DateTime.now()
            : visitPlan!.startDate!.toLocal(),
        firstDate: DateTimeUtils.isTodayBetweenDates(
          startDate: visitPlan!.startDate!,
          endDate: visitPlan!.endDate!,
        )
            ? DateTime.now()
            : visitPlan!.startDate!.toLocal(),
        lastDate: visitPlan!.endDate!.toLocal(),
      );

      if (date != null) {
        navigationService.navigateToVisitPlanAddOneView(
          params: VisitPlanAddParams(
            visitPlanId: appVisitPlanId,
            visitPlan: visitPlan!,
            date: date,
            accounts: [],
            visits: [],
          ),
        );
      }
    }
  }

  void onDayTap(DateTime date) {
    if (visitsOfDay(date).isNotEmpty) {
      navigationService.navigateToVisitPlanVisitsView(
        appVisitPlanId: appVisitPlanId,
        date: date,
      );
    }
  }

  List<Visit> visitsOfDay(DateTime date) {
    if (data != null) {
      return data!.where((element) {
        return DateTimeUtils.isSameDate(element.plannedStartTime, date);
      }).toList();
    }
    return [];
  }

  @override
  Stream<List<Visit>> get stream {
    return _databaseService.watchVisitsByAppVisitPlanId(appVisitPlanId);
  }
}
