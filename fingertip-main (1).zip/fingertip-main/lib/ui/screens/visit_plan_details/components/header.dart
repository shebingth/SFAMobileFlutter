import 'package:flutter/material.dart';

import 'package:dotted_border/dotted_border.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../database/database.dart';
import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/network_image.dart';

class VisitPlanDetailsHeader extends StatelessWidget {
  const VisitPlanDetailsHeader({
    super.key,
    required this.data,
    required this.addVisit,
  });

  final VisitPlan data;
  final VoidCallback addVisit;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            color: Colors.white,
            boxShadow: const [
              BoxShadow(
                color: Palette.shadow1A,
                offset: Offset(0, 0),
                blurRadius: 6,
                spreadRadius: 0,
              )
            ],
            image: decorationImage(
              image: Assets.images.clipboard.path,
              isAsset: true,
            ),
          ),
        ),
        horizontalSpace(12.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomText(
                "Visit Plan",
                style: TextStyle(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.normal,
                  color: Palette.text58,
                ),
              ),
              verticalSpace(7.h),
              CustomText(
                data.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 15.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
        horizontalSpace(5.w),
        DottedBorder(
          color: Palette.primary,
          radius: const Radius.circular(8),
          borderType: BorderType.RRect,
          dashPattern: const [5],
          child: PrimaryButton(
            onPressed: addVisit,
            visualDensity: VisualDensity.compact,
            padding: EdgeInsets.symmetric(horizontal: 20.w),
            color: Colors.transparent,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Assets.images.calendarBlueFilled.image(),
                horizontalSpace(5.w),
                CustomText(
                  "Add Visit",
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                    color: Palette.primary,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
