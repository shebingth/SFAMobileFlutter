import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../database/database.dart';
import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../tools/separated_list.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/network_image.dart';

class VisitPlanDetailDayWidget extends StatelessWidget {
  const VisitPlanDetailDayWidget({
    super.key,
    required this.date,
    required this.visitsOfDay,
    required this.onDayTap,
  });

  final DateTime date;
  final List<Visit> visitsOfDay;
  final void Function(DateTime date) onDayTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onDayTap(date),
      behavior: HitTestBehavior.translucent,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(vertical: 25.h),
        alignment: Alignment.center,
        decoration: const BoxDecoration(
          border: Border(
            top: BorderSide(color: Palette.greyEF),
            bottom: BorderSide(color: Palette.greyEF),
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 26,
              height: 26,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                image: decorationImage(
                  image: Assets.images.calendarBlueEmpty.path,
                  isAsset: true,
                ),
              ),
              child: CustomText(
                "${date.day}",
                style: TextStyle(
                  fontSize: 12.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            horizontalSpace(24.w),
            Expanded(
              child: Visibility(
                visible: visitsOfDay.isNotEmpty,
                replacement: CustomText(
                  "No visits added",
                  top: 2.h,
                  style: TextStyle(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.normal,
                    color: Colors.grey[500],
                    height: 1.4,
                  ),
                ),
                child: SeparatedWidgetList(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  list: visitsOfDay,
                  builder: (item, index) {
                    return CustomText(
                      item.accountName,
                      style: TextStyle(
                        fontSize: 15.sp,
                        fontWeight: FontWeight.normal,
                        color: Palette.primary,
                        height: 1.4,
                      ),
                    );
                  },
                  separation: 11.h,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
