import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_colors.dart';
import '../../common/date_time_utils.dart';
import '../../common/ui_helpers.dart';
import '../../tools/model_future_builder.dart';
import '../../tools/separated_list.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/custom_text.dart';

import 'components/header.dart';
import 'components/item.dart';
import 'visit_plan_details_viewmodel.dart';

class VisitPlanDetailsView extends StackedView<VisitPlanDetailsViewModel> {
  const VisitPlanDetailsView({
    super.key,
    required this.appVisitPlanId,
  });

  final String appVisitPlanId;

  @override
  void onViewModelReady(VisitPlanDetailsViewModel viewModel) {
    viewModel.init();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: CustomAppBar(
        titleText: viewModel.visitPlan?.name,
      ),
      body: SizedBox.expand(
        child: ModelFutureBuilder(
          data: viewModel.visitPlan,
          busy: viewModel.isBusy,
          error: viewModel.modelError,
          builder: (context, data, child) {
            return SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(15.w, 25.h, 15.w, 30.h),
              child: Column(
                children: [
                  VisitPlanDetailsHeader(
                    data: data,
                    addVisit: () => viewModel.addVisit(context),
                  ),
                  verticalSpace(25.h),
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.fromLTRB(20.w, 9.h, 20.w, 8.h),
                    color: Palette.greyF5,
                    child: CustomText(
                      "${DateTimeUtils.monthToLabel(data.month)} - ${data.year}",
                      style: TextStyle(
                        fontSize: 15.sp,
                        fontWeight: FontWeight.w500,
                        color: Palette.text58,
                      ),
                    ),
                  ),
                  SeparatedWidgetList(
                    list: DateTimeUtils.getDatesInMonth(
                      month: data.month,
                      year: data.year,
                    ),
                    builder: (date, index) {
                      return VisitPlanDetailDayWidget(
                        date: date,
                        visitsOfDay: viewModel.visitsOfDay(date),
                        onDayTap: viewModel.onDayTap,
                      );
                    },
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  VisitPlanDetailsViewModel viewModelBuilder(BuildContext context) {
    return VisitPlanDetailsViewModel(
      appVisitPlanId: appVisitPlanId,
    );
  }
}
