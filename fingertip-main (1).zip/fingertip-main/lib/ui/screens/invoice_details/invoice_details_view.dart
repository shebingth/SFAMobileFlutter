import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../extensions/date_time.dart';
import '../../../extensions/double.dart';
import '../../common/assets.gen.dart';
import '../../tools/conditional_widget.dart';
import '../../tools/model_future_builder.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/details_label_value.dart';
import '../account_details/account_details_view.dart';

import 'invoice_details_viewmodel.dart';

class InvoiceDetailsView extends StackedView<InvoiceDetailsViewModel> {
  const InvoiceDetailsView({
    super.key,
    required this.appInvoiceId,
  });

  final String appInvoiceId;

  @override
  void onViewModelReady(InvoiceDetailsViewModel viewModel) {
    viewModel.init();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Invoice",
      ),
      body: SizedBox.expand(
        child: IfNotNull(
          value: viewModel.data,
          replacement: ModelErrorWidget(
            error: viewModel.initialised ? "Something went wrong" : "",
          ),
          builder: (context, data) {
            return SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  DetailsLabelValueWidget(
                    margin: EdgeInsets.fromLTRB(15.w, 25.h, 15.w, 0),
                    label: "Invoice Number",
                    value: data.name,
                  ),
                  DetailsLabelValueWidget(
                    margin: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 0),
                    label: "Account",
                    value: data.accountName,
                  ),
                  DetailsLabelValueWidget(
                    margin: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 0),
                    label: "Invoice Date",
                    value: data.invoiceDate.toFormattedDate(),
                  ),
                  DetailsLabelValueWidget(
                    margin: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 0),
                    label: "Total Amount",
                    value: data.totalAmount?.toPrice,
                  ),
                  DetailsLabelValueWidget(
                    margin: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 0),
                    label: "Total Quantity",
                    value: data.totalQuantity?.toString(),
                  ),
                  DetailsLabelValueWidget(
                    margin: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 0),
                    label: "Grand Total",
                    value: data.grandTotal?.toPrice,
                  ),
                  DetailsLabelValueWidget(
                    margin: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 0),
                    label: "Balance",
                    value: data.balance?.removeTrailingZeros,
                  ),
                  DetailsLabelValueWidget(
                    margin: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 0),
                    label: "Due Date",
                    value: data.dueDate.toFormattedDate(),
                  ),
                  DetailsLabelValueWidget(
                    margin: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 0),
                    label: "Status",
                    value: data.status,
                  ),
                  RelatedItemWidget(
                    top: 20.h,
                    bottom: 32.h,
                    icon: Assets.images.settings.image(),
                    title: "Invoice Line Items",
                    count: viewModel.invoiceItems.length,
                    onTap: viewModel.onInvoiceLineItemsTap,
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  InvoiceDetailsViewModel viewModelBuilder(BuildContext context) {
    return InvoiceDetailsViewModel(
      appInvoiceId: appInvoiceId,
    );
  }
}
