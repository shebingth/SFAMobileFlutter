import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../common/utils.dart';

class InvoiceDetailsViewModel extends StreamViewModel<Invoice> {
  InvoiceDetailsViewModel({
    required this.appInvoiceId,
  });

  final String appInvoiceId;
  final _databaseService = locator<DatabaseService>();

  List<InvoiceItem> invoiceItems = [];

  Future<void> init() async {
    invoiceItems =
        await _databaseService.getInvoiceItemsByInvoiceId(appInvoiceId);
    notifyListeners();
  }

  void onInvoiceLineItemsTap() {
    if (invoiceItems.isNotEmpty) {
      navigationService.navigateToInvoiceLineItemView(
        appInvoiceId: appInvoiceId,
      );
    }
  }

  @override
  Stream<Invoice> get stream {
    return _databaseService.watchInvoiceByInvoiceId(appInvoiceId);
  }
}
