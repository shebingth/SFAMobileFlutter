import 'dart:io';

import 'package:flutter/foundation.dart';

import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:flutter_smart_dialog/flutter_smart_dialog.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:stacked/stacked.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../app/app.logger.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/string.dart';
import '../../common/app_constants.dart';
import '../../common/utils.dart';
import '../../tools/smart_dialog_config.dart';

const busyOrder = "bust_order";

class VisitViewModel extends StreamViewModel<Visit> {
  VisitViewModel({
    required this.visit,
  });

  final Visit visit;
  final _databaseService = locator<DatabaseService>();
  final picker = ImagePicker();
  final logger = getLogger("VisitViewModel");

  Visit? lastVisit;

  Future<void> init() async {
    setBusy(true);

    try {
      if (visit.salesAppId != null && visit.accountId != null) {
        lastVisit = await _databaseService.getLastVisit(
          salesAppId: visit.salesAppId!,
          accountId: visit.accountId!,
        );
      } else {
        logger.e(
          "SalesAppId ${visit.salesAppId} or AccountId ${visit.accountId} is null",
        );
      }
    } catch (e) {
      debugPrint("$e");
      setError(e.toString());
    }

    setBusy(false);
  }

  Future<void> order() async {
    if (data?.salesAppId != null) {
      navigationService.navigateToProductsView(visitMap: data!.toJson());
    }
  }

  void goToCompetition() {
    navigationService.navigateToCompetitionView(
      visitMap: visit.toJson(),
    );
  }

  void goToStock() {
    navigationService.navigateToStockView(
      visitMap: visit.toJson(),
    );
  }

  void goToTicket() {
    navigationService.navigateToTicketNewView(
      visitMap: visit.toJson(),
    );
  }

  void addPaymentFollowUp() {
    navigationService.navigateToPaymentFollowUpAddView(
      visitMap: visit.toJson(),
    );
  }

  Future<void> takePhoto() async {
    try {
      var res = await picker.pickImage(source: ImageSource.camera);

      SmartDialog.showLoading(msg: "");
      if (res != null) {
        final tempDir = await getTemporaryDirectory();
        var file = File(res.path);
        var fileName = file.path.split('/').last;
        var cRes = await compressImageFile(
          file,
          "${tempDir.path}/c_$fileName",
        );

        if (cRes != null) {
          var compressedFile = File(cRes.path);

          bool status = await _databaseService.addVisitFile(
            file: compressedFile,
            salesAppId: visit.salesAppId!,
          );

          if (status) {
            showToast("Photo added successfully", type: ToastType.success);
          }
        }
      }
      SmartDialog.dismiss();
    } catch (e) {
      showToast("Error adding photo");
      if (e is CompressError) {
        CompressError error = e;
        debugPrint("CompressError: ${error.message}");
      } else {
        debugPrint("Camera Image Pick Error: ${e.toString()}");
      }
    }
  }

  void lastVisitOrders() {
    if (lastVisit?.salesAppId != null) {
      navigationService.navigateToLastOrdersView(
        lastVisitMap: lastVisit!.toJson(),
      );
    } else {
      showToast("No orders found");
    }
  }

  Future<void> checkout() async {
    var res = await dialogService.showCustomDialog(
      variant: DialogType.checkout,
      data: visit,
    );

    if (res?.confirmed == true) {
      navigationService.back();
    }
  }

  String? get lastVisitComment {
    if (data?.lastVisitComment.isNotEmptyOrNull == true) {
      return data!.lastVisitComment;
    } else {
      return lastVisit?.comments;
    }
  }

  String? get lastVisitCommentDate {
    if (data?.lastVisitComment.isNotEmptyOrNull == true &&
        data?.lastVisitDate != null) {
      return DateFormat("dd MMM yyyy").format(data!.lastVisitDate!);
    } else if (lastVisit?.plannedStartTime != null &&
        lastVisit?.comments.isNotEmptyOrNull == true) {
      return DateFormat("dd MMM yyyy").format(lastVisit!.plannedStartTime);
    }
    return null;
  }

  @override
  Stream<Visit> get stream {
    return _databaseService.watchVisitBySalesAppId(visit.salesAppId!);
  }
}
