import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../tools/conditional_widget.dart';
import '../../../widgets/custom_text.dart';

class LastVisitCommentWidget extends StatelessWidget {
  const LastVisitCommentWidget({
    super.key,
    required this.lastVisitComment,
    required this.lastVisitCommentDate,
  });

  final String? lastVisitComment;
  final String? lastVisitCommentDate;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 20.h),
      child: Column(
        children: [
          Row(
            children: [
              Assets.images.message.image(),
              horizontalSpace(8.w),
              Container(
                margin: EdgeInsets.only(bottom: 3.h),
                child: CustomText(
                  'Last visit comment',
                  style: TextStyle(
                    color: Palette.text08,
                    fontSize: 17.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          verticalSpace(15.h),
          Container(
            width: double.infinity,
            padding: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 15.h),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: Palette.scaffoldBackground,
              boxShadow: const [
                BoxShadow(
                  color: Palette.shadow1,
                  blurRadius: 9,
                  offset: Offset(0, 1),
                  spreadRadius: -1,
                )
              ],
            ),
            child: IfNotNull(
              value: lastVisitComment,
              condition: (value) => value.isNotEmpty,
              builder: (context, lastVisitComment) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomText(
                      lastVisitComment,
                      style: TextStyle(
                        color: Palette.text08,
                        fontSize: 14.sp,
                        height: 1.5,
                      ),
                    ),
                    verticalSpace(8.h),
                    Align(
                      alignment: Alignment.centerRight,
                      child: CustomText(
                        lastVisitCommentDate ?? " ",
                        textAlign: TextAlign.right,
                        style: TextStyle(
                          color: Palette.text08,
                          fontSize: 14.sp,
                        ),
                      ),
                    ),
                  ],
                );
              },
              replacement: Container(
                width: double.infinity,
                alignment: Alignment.center,
                child: CustomText(
                  '--',
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 13.sp,
                    fontWeight: FontWeight.normal,
                    color: Colors.grey[500],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
