import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../database/database.dart';
import '../../../../extensions/string.dart';
import '../../../common/app_colors.dart';
import '../../../common/app_constants.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/custom_text.dart';

class ShopDetailsWidget extends StatelessWidget {
  const ShopDetailsWidget({
    super.key,
    required this.visit,
    this.fromPreview = false,
  });

  final Visit visit;
  final bool fromPreview;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(5.w, 20.h, 10.w, 20.h),
      decoration: BoxDecoration(
        color: Palette.primaryLite,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Palette.primaryLite2,
            ),
            alignment: Alignment.center,
            child: CustomText(
              visit.accountName.toFirstLetters,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.clip,
              style: TextStyle(
                fontSize: 18.sp,
                fontWeight: FontWeight.w600,
                color: Palette.primary,
                height: 0,
              ),
            ),
          ),
          horizontalSpace(8.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                verticalSpace(4.h),
                CustomText(
                  visit.accountName,
                  style: TextStyle(
                    color: Palette.text08,
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                verticalSpace(12.h),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: CustomText(
                        "Visit Type",
                        style: TextStyle(
                          color: Palette.text58,
                          fontSize: 15.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    CustomText(
                      "   :   ",
                      style: TextStyle(
                        color: Palette.text58,
                        fontSize: 15.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Expanded(
                      child: CustomText(
                        visit.typeofVisit ?? "--",
                        style: TextStyle(
                          color: Palette.text58,
                          fontSize: 15.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
                if (fromPreview) verticalSpace(10.h),
                Visibility(
                  visible: fromPreview,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: CustomText(
                          "Status",
                          style: TextStyle(
                            color: Palette.text58,
                            fontSize: 15.sp,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      CustomText(
                        "   :   ",
                        style: TextStyle(
                          color: Palette.text58,
                          fontSize: 15.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Expanded(
                        child: CustomText(
                          visit.status ?? "--",
                          style: TextStyle(
                            color: VisitStatus.colorOf(visit.status),
                            fontSize: 15.sp,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                verticalSpace(10.h),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: CustomText(
                        "Outstanding",
                        style: TextStyle(
                          color: Palette.text58,
                          fontSize: 15.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    CustomText(
                      "   :   ",
                      style: TextStyle(
                        color: Palette.text58,
                        fontSize: 15.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Expanded(
                      child: CustomText(
                        visit.outstanding?.toString() ?? "--",
                        style: TextStyle(
                          color: Palette.text58,
                          fontSize: 15.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
