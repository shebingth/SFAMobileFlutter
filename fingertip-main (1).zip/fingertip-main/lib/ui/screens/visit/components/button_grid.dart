import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/button.dart';
import '../../../widgets/custom_text.dart';
import '../visit_viewmodel.dart';

class VisitButtonGrid extends ViewModelWidget<VisitViewModel> {
  const VisitButtonGrid({super.key});

  @override
  Widget build(BuildContext context, VisitViewModel viewModel) {
    return Column(
      children: [
        verticalSpace(50.h),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.goToCompetition,
                radius: 8,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Assets.images.competition.image(),
                    horizontalSpace(8.w),
                    CustomText(
                      "Competition",
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            horizontalSpace(15.w),
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.goToStock,
                radius: 8,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Assets.images.stock.image(),
                    horizontalSpace(8.w),
                    CustomText(
                      "Stock",
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        verticalSpace(15.h),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.takePhoto,
                radius: 8,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Assets.images.cameraWhite.image(),
                    horizontalSpace(8.w),
                    CustomText(
                      "Take Photo",
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            horizontalSpace(15.w),
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.goToTicket,
                radius: 8,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Assets.images.ticketWhite.image(),
                    horizontalSpace(8.w),
                    CustomText(
                      "Ticket",
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        verticalSpace(15.h),
        PrimaryButton(
          onPressed: viewModel.addPaymentFollowUp,
          radius: 8,
          minWidth: double.infinity,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Assets.images.creditCard.image(
                color: Colors.white,
              ),
              horizontalSpace(8.w),
              CustomText(
                "Payment Follow Up",
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
        verticalSpace(50.h),
      ],
    );
  }
}
