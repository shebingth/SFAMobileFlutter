import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../database/database.dart';
import '../../../../extensions/double.dart';
import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/custom_text.dart';

class OutstandingWidget extends StatelessWidget {
  const OutstandingWidget({
    super.key,
    required this.visit,
  });

  final Visit visit;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 15.h),
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 15.h),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Palette.scaffoldBackground,
        boxShadow: const [
          BoxShadow(
            color: Palette.shadow1,
            blurRadius: 9,
            offset: Offset(0, 1),
            spreadRadius: -1,
          )
        ],
      ),
      child: Row(
        children: [
          Assets.images.money.image(),
          horizontalSpace(8.w),
          Expanded(
            child: Container(
              margin: EdgeInsets.only(bottom: 3.h),
              child: CustomText(
                'Outstanding',
                style: TextStyle(
                  color: Palette.text08,
                  fontSize: 17.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
          horizontalSpace(8.w),
          Container(
            margin: EdgeInsets.only(bottom: 3.h),
            child: CustomText(
              visit.outstanding != null ? visit.outstanding!.toPrice : "--",
              textAlign: TextAlign.right,
              style: TextStyle(
                color: Palette.text08,
                fontSize: 17.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
