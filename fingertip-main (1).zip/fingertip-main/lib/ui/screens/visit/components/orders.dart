import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/custom_text.dart';

class LastVisitOrdersWidget extends StatelessWidget {
  const LastVisitOrdersWidget({
    super.key,
    required this.lastVisitOrders,
  });

  final VoidCallback lastVisitOrders;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: lastVisitOrders,
      behavior: HitTestBehavior.translucent,
      child: Container(
        margin: EdgeInsets.only(top: 15.h),
        width: double.infinity,
        padding: EdgeInsets.fromLTRB(15.w, 15.h, 15.w, 15.h),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Palette.scaffoldBackground,
          boxShadow: const [
            BoxShadow(
              color: Palette.shadow1,
              blurRadius: 9,
              offset: Offset(0, 1),
              spreadRadius: -1,
            )
          ],
        ),
        child: Row(
          children: [
            Assets.images.orderBlue.image(),
            horizontalSpace(8.w),
            Expanded(
              child: Container(
                margin: EdgeInsets.only(bottom: 3.h),
                child: CustomText(
                  'Last visit order',
                  style: TextStyle(
                    color: Palette.text08,
                    fontSize: 17.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
            horizontalSpace(8.w),
            Assets.images.angleRightBlack.image(),
          ],
        ),
      ),
    );
  }
}
