import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/button.dart';
import '../../../widgets/custom_text.dart';
import '../visit_viewmodel.dart';

class VisitBottomButtonsWidget extends ViewModelWidget<VisitViewModel> {
  const VisitBottomButtonsWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, VisitViewModel viewModel) {
    return Container(
      padding: EdgeInsets.fromLTRB(15.w, 10.h, 15.w, 30.h),
      color: Palette.scaffoldBackground,
      child: Row(
        children: [
          Expanded(
            child: PrimaryButton(
              onPressed: viewModel.checkout,
              color: Palette.pink1,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Assets.images.checkOut.image(),
                  horizontalSpace(5.w),
                  CustomText(
                    'Checkout',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15.sp,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ),
          horizontalSpace(18.w),
          Expanded(
            child: PrimaryButton(
              onPressed: viewModel.order,
              isBusy: viewModel.busy(busyOrder),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Assets.images.orderWhite.image(),
                  horizontalSpace(5.w),
                  CustomText(
                    'Order',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15.sp,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
