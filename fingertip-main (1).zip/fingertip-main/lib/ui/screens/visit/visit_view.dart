import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../database/database.dart';
import '../../tools/model_future_builder.dart';
import '../../widgets/app_bar.dart';

import 'components/bottom_buttons.dart';
import 'components/button_grid.dart';
import 'components/comment.dart';
import 'components/orders.dart';
import 'components/outstanding.dart';
import 'components/shop_details.dart';
import 'visit_viewmodel.dart';

class VisitView extends StackedView<VisitViewModel> {
  const VisitView({
    super.key,
    required this.visitMap,
  });

  final Map<String, dynamic> visitMap;

  @override
  void onViewModelReady(VisitViewModel viewModel) {
    viewModel.init();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Visit",
      ),
      body: SizedBox.expand(
        child: ModelFutureBuilder<Visit>(
          data: viewModel.data,
          busy: viewModel.isBusy,
          error: viewModel.modelError?.toString(),
          builder: (context, visit, child) {
            return SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 30.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ShopDetailsWidget(
                    visit: visit,
                  ),
                  LastVisitCommentWidget(
                    lastVisitComment: viewModel.lastVisitComment,
                    lastVisitCommentDate: viewModel.lastVisitCommentDate,
                  ),
                  LastVisitOrdersWidget(
                    lastVisitOrders: viewModel.lastVisitOrders,
                  ),
                  OutstandingWidget(visit: visit),
                  const VisitButtonGrid(),
                ],
              ),
            );
          },
        ),
      ),
      bottomNavigationBar: const VisitBottomButtonsWidget(),
    );
  }

  @override
  VisitViewModel viewModelBuilder(context) {
    return VisitViewModel(
      visit: Visit.fromJson(visitMap),
    );
  }
}
