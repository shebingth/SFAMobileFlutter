import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

class ForgotPasswordViewModel extends BaseViewModel {
  ForgotPasswordViewModel({
    this.userName,
  });

  final formKey = GlobalKey<FormState>();

  var autovalidateMode = AutovalidateMode.disabled;
  String? userName;

  void submit() {
    if (formKey.currentState!.validate()) {
      formKey.currentState!.save();
    } else {
      setAutovalidateMode(AutovalidateMode.always);
    }
  }

  void setAutovalidateMode(AutovalidateMode mode) {
    autovalidateMode = mode;
    notifyListeners();
  }
}
