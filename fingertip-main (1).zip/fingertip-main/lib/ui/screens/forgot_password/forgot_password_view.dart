import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_colors.dart';
import '../../common/fonts.gen.dart';
import '../../common/ui_helpers.dart';
import '../../tools/dismiss_keyboard.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/button.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/form_fields/text_field.dart';

import 'forgot_password_viewmodel.dart';

class ForgotPasswordView extends StackedView<ForgotPasswordViewModel> {
  const ForgotPasswordView({
    super.key,
    this.userName,
  });

  final String? userName;

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        elevation: 0,
      ),
      body: SizedBox.expand(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 16.w),
          child: DismissKeyboard(
            child: Form(
              key: viewModel.formKey,
              autovalidateMode: viewModel.autovalidateMode,
              child: Column(
                children: [
                  verticalSpace(25.h),
                  SizedBox(
                    width: double.infinity,
                    child: CustomText(
                      'Forgot Password',
                      style: TextStyle(
                        color: Palette.text08,
                        fontSize: 24.sp,
                        fontFamily: FontFamily.manrope,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Container(
                    width: double.infinity,
                    margin: EdgeInsets.only(top: 6.h),
                    child: CustomText(
                      'Send a password change request for\nthis account',
                      style: TextStyle(
                        color: Palette.text08,
                        fontSize: 15.sp,
                        fontFamily: FontFamily.manrope,
                      ),
                    ),
                  ),
                  CustomTextFormField(
                    top: 20.h,
                    fillColor: Palette.greyF4,
                    borderColor: Palette.greyF4,
                    initialValue: viewModel.userName,
                    labelText: "User name",
                    fontFamily: FontFamily.manrope,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Required";
                      }
                      return null;
                    },
                    onSaved: (newValue) {
                      viewModel.userName = newValue;
                    },
                  ),
                  verticalSpace(20.h),
                  PrimaryButton(
                    onPressed: viewModel.submit,
                    isBusy: viewModel.isBusy,
                    label: "Send Request",
                    isExpanded: true,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  ForgotPasswordViewModel viewModelBuilder(context) {
    return ForgotPasswordViewModel(userName: userName);
  }
}
