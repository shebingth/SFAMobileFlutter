import 'package:flutter/material.dart';

import 'package:date_field/date_field.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../models/visit_plan.dart';
import '../../../common/app_colors.dart';
import '../../../common/app_constants.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/form_fields/date_picker.dart';
import '../../../widgets/form_fields/dropdown_field.dart';

class VisitPlanVisitWidget extends StatelessWidget {
  const VisitPlanVisitWidget({
    super.key,
    required this.visit,
    required this.notifyListeners,
  });

  final VisitCustomModel visit;
  final VoidCallback notifyListeners;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 20.h),
      decoration: BoxDecoration(
        color: Palette.scaffoldBackground,
        borderRadius: BorderRadius.circular(10),
        boxShadow: const [
          BoxShadow(
            color: Palette.shadow1A,
            offset: Offset(0, 1),
            blurRadius: 9,
            spreadRadius: -1,
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Assets.images.pinBlue.image(),
              horizontalSpace(5.w),
              Expanded(
                child: CustomText(
                  visit.account.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 15.sp,
                    fontWeight: FontWeight.bold,
                    color: Palette.text58,
                  ),
                ),
              ),
            ],
          ),
          CustomDateFormField(
            top: 20.h,
            labelText: "Time",
            mode: DateTimeFieldPickerMode.time,
            hideOuterLabel: true,
            canClear: false,
            initialValue: visit.hasTimeSet ? visit.dateTime : null,
            validator: (value) {
              if (value == null) {
                return "Required";
              }
              return null;
            },
            onSaved: (newValue) {
              if (newValue != null) {
                visit.dateTime = visit.dateTime.copyWith(
                  hour: newValue.hour,
                  minute: newValue.minute,
                  second: newValue.second,
                );
              }
            },
            onChanged: (value) {
              if (value != null) {
                visit.dateTime = visit.dateTime.copyWith(
                  hour: value.hour,
                  minute: value.minute,
                  second: value.second,
                );
                visit.hasTimeSet = true;
                notifyListeners();
              }
            },
          ),
          CustomDropdownFormField(
            top: 20.h,
            labelText: "Visit Type",
            items: VisitType.values,
            hideOuterLabel: true,
            itemAsString: (item) => item,
            value: visit.visitType,
            validator: (value) {
              if (value == null) {
                return "Required";
              }
              return null;
            },
            onSaved: (newValue) {
              visit.visitType = newValue;
            },
            onChanged: (value) {
              visit.visitType = value;
              notifyListeners();
            },
          ),
        ],
      ),
    );
  }
}
