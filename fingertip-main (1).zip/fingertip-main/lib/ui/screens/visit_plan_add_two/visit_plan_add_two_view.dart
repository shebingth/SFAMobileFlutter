import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../extensions/date_time.dart';
import '../../../models/visit_plan.dart';
import '../../common/app_colors.dart';
import '../../common/ui_helpers.dart';
import '../../tools/dismiss_keyboard.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/button.dart';

import 'components/item.dart';
import 'visit_plan_add_two_viewmodel.dart';

class VisitPlanAddTwoView extends StackedView<VisitPlanAddTwoViewModel> {
  const VisitPlanAddTwoView({
    super.key,
    required this.params,
  });

  final VisitPlanAddParams params;

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: CustomAppBar(
        titleText: viewModel.params.date.toFormattedDate(),
      ),
      body: SizedBox.expand(
        child: DismissKeyboard(
          child: Form(
            key: viewModel.formKey,
            autovalidateMode: viewModel.autovalidateMode,
            child: ListView.separated(
              padding: EdgeInsets.fromLTRB(15.w, 25.h, 15.w, 30.h),
              itemCount: viewModel.params.visits.length,
              itemBuilder: (context, index) {
                var visit = viewModel.params.visits[index];

                return VisitPlanVisitWidget(
                  visit: visit,
                  notifyListeners: viewModel.notifyListeners,
                );
              },
              separatorBuilder: (context, index) {
                return verticalSpace(20.h);
              },
            ),
          ),
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
        decoration: const BoxDecoration(
          color: Palette.scaffoldBackground,
          boxShadow: [
            BoxShadow(
              color: Palette.shadow3,
              blurRadius: 5,
              offset: Offset(0, -2),
              spreadRadius: 2,
            )
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.cancel,
                label: "Cancel",
                color: Palette.greyBA,
              ),
            ),
            horizontalSpace(15.w),
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.addVisits,
                isBusy: viewModel.isBusy,
                label: "Next",
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  VisitPlanAddTwoViewModel viewModelBuilder(BuildContext context) {
    return VisitPlanAddTwoViewModel(
      params: params,
    );
  }
}
