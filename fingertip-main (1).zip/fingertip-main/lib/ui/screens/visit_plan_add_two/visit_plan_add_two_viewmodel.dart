import 'package:flutter/material.dart';

import 'package:stacked/stacked.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../database/database.dart';
import '../../../models/visit_plan.dart';
import '../../common/utils.dart';
import '../../tools/smart_dialog_config.dart';

class VisitPlanAddTwoViewModel extends BaseViewModel {
  VisitPlanAddTwoViewModel({
    required this.params,
  });

  final VisitPlanAddParams params;
  final formKey = GlobalKey<FormState>();
  final _databaseService = locator<DatabaseService>();

  var autovalidateMode = AutovalidateMode.disabled;

  Future<void> addVisits() async {
    if (formKey.currentState?.validate() == true) {
      formKey.currentState!.save();

      bool status = await runBusyFuture(
        _databaseService.addVisitsToVisitPlan(params: params),
      );

      if (status) {
        await dialogService.showCustomDialog(
          variant: DialogType.confirm,
          title: "Visit Saved",
          description: "Visit saved successfully\nto the list.",
          mainButtonTitle: "Continue",
          secondaryButtonTitle: "Cancel",
        );

        navigationService.back();
      }
    } else {
      showToast("Please select time & visit type for all visits");
      setAutovalidateMode(AutovalidateMode.always);
    }
  }

  void cancel() => navigationService.back();

  void setAutovalidateMode(AutovalidateMode mode) {
    autovalidateMode = mode;
    notifyListeners();
  }
}
