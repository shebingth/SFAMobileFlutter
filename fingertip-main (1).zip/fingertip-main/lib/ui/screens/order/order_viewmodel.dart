import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/date_time.dart';
import '../../../extensions/list.dart';
import '../../../extensions/string.dart';
import '../../../models/sort.dart';
import '../../common/app_constants.dart';
import '../../common/utils.dart';

class OrderViewModel extends StreamViewModel<List<Order>> {
  final _databaseService = locator<DatabaseService>();

  List<FilterModel> selectedFilters = [];
  List<Account> accounts = [];

  List<FilterModel> get filterOptions {
    return [
      FilterModel(
        type: FilterType.date,
        label: "Order Date",
      ),
      FilterModel(
        type: FilterType.dropdown,
        label: "Status",
        options: OrderStatus.values.map((e) {
          return FilterOptionModel(label: e, value: e);
        }).toList(),
      ),
      FilterModel(
        type: FilterType.dropdownSearch,
        label: "Account",
        options: accounts.map((e) {
          return FilterOptionModel(
            label: e.name,
            value: e.id.isNotEmptyOrNull ? e.id : e.appAccountId,
          );
        }).toList(),
      ),
    ];
  }

  static final sortOptions = [
    SortModel(
      type: "created_date",
      label: "Created Date",
      isAscending: false,
    ),
    SortModel(
      type: "order_date",
      label: "Order Date",
    ),
    SortModel(
      type: "order_number",
      label: "Order Number",
    ),
    SortModel(
      type: "grand_total",
      label: "Grand Total",
    ),
    SortModel(
      type: "order_status",
      label: "Order Status",
    ),
    SortModel(
      type: "account_name",
      label: "Account Name",
    ),
  ];

  SortModel currentSort = sortOptions.first;

  List<Order>? get filteredOrderedData {
    List<Order> currentData = data ?? [];

    //Filter
    for (var filter in selectedFilters) {
      switch (filter.label) {
        case "Order Date":
          if (filter.valueFromDate != null && filter.valueToDate != null) {
            currentData = currentData.where((element) {
              return element.orderDate.isBetweenDates(
                startDate: filter.valueFromDate!,
                endDate: filter.valueToDate!,
              );
            }).toList();
          }
          break;
        case "Status":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.status == filter.valueOption!.value!;
            }).toList();
          }
          break;
        case "Account":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.accountId == filter.valueOption!.value! ||
                  element.appAccountId == filter.valueOption!.value!;
            }).toList();
          }
          break;

        default:
          break;
      }
    }

    //Sort
    switch (currentSort.type) {
      case "created_date":
        currentData.sortByNullableField(
          getField: (e) => e.createdDate,
          isAscending: currentSort.isAscending,
        );
        break;
      case "order_number":
        currentData.sortByNullableField(
          getField: (e) => e.name,
          isAscending: currentSort.isAscending,
        );
        break;
      case "order_date":
        currentData.sortByNullableField(
          getField: (e) => e.orderDate,
          isAscending: currentSort.isAscending,
        );
        break;
      case "grand_total":
        currentData.sortByNullableField(
          getField: (e) => e.grandTotal,
          isAscending: currentSort.isAscending,
        );
        break;
      case "status":
        currentData.sortByNullableField(
          getField: (e) => e.status,
          isAscending: currentSort.isAscending,
        );
        break;
      case "account_name":
        currentData.sortByNullableField(
          getField: (e) => e.accountName,
          isAscending: currentSort.isAscending,
        );
        break;
      default:
        break;
    }

    return currentData;
  }

  Future<void> init() async {
    accounts = await _databaseService.getAccounts();
    notifyListeners();
  }

  Future<void> filter() async {
    var res = await navigationService.navigateToFilterView(
      filters: filterOptions,
      selectedFilters: selectedFilters,
    );

    if (res is List<FilterModel>) {
      selectedFilters = res;
      notifyListeners();
    }
  }

  Future<void> sort() async {
    var res = await navigationService.navigateToSortView(
      initalValue: currentSort,
      sortOptions: sortOptions,
    );

    if (res is SortModel) {
      setSort(res);
    }
  }

  void setSort(SortModel sort) {
    currentSort = sort;
    notifyListeners();
  }

  void goToOrderDetailsView(Order item) {
    if (item.appOrderId.isNotEmptyOrNull) {
      navigationService.navigateToOrderDetailsView(
        appOrderId: item.appOrderId!,
      );
    }
  }

  void addNewOrder() {
    navigationService.navigateToProductsView();
  }

  @override
  Stream<List<Order>> get stream => _databaseService.watchOrders();
}
