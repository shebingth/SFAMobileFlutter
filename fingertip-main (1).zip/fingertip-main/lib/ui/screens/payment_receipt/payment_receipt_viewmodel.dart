import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/date_time.dart';
import '../../../extensions/list.dart';
import '../../../extensions/string.dart';
import '../../../models/sort.dart';
import '../../common/app_constants.dart';
import '../../common/utils.dart';

class PaymentReceiptViewModel extends StreamViewModel<List<PaymentReceipt>> {
  final _databaseService = locator<DatabaseService>();

  List<FilterModel> selectedFilters = [];

  List<FilterModel> get filterOptions {
    return [
      FilterModel(
        type: FilterType.dropdown,
        label: "Status",
        options: [
          "Payment Done",
          "Confirmed",
          "Pending",
        ].map((e) => FilterOptionModel(label: e, value: e)).toList(),
      ),
      FilterModel(
        type: FilterType.date,
        label: "Payment Date",
      ),
      FilterModel(
        type: FilterType.dropdown,
        label: "Payment Type",
        options: [
          "Cash",
          "Online",
          "Cheque",
          "Card",
        ].map((e) => FilterOptionModel(label: e, value: e)).toList(),
      ),
    ];
  }

  static final sortOptions = [
    SortModel(
      type: "created_date",
      label: "Created Date",
      isAscending: false,
    ),
    SortModel(
      type: "payment_date",
      label: "Payment Date",
    ),
    SortModel(
      type: "name",
      label: "Name",
    ),
    SortModel(
      type: "status",
      label: "Status",
    ),
    SortModel(
      type: "payment_type",
      label: "Payment Type",
    ),
  ];

  SortModel currentSort = sortOptions.first;

  List<PaymentReceipt>? get filteredOrderedData {
    List<PaymentReceipt> currentData = data ?? [];

    //Filter
    for (var filter in selectedFilters) {
      switch (filter.label) {
        case "Status":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.status == filter.valueOption!.value!;
            }).toList();
          }
          break;
        case "Payment Date":
          if (filter.valueFromDate != null && filter.valueToDate != null) {
            currentData = currentData.where((element) {
              return element.paymentDate.isBetweenDates(
                startDate: filter.valueFromDate!,
                endDate: filter.valueToDate!,
              );
            }).toList();
          }
          break;
        case "Payment Type":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.paymentType == filter.valueOption!.value!;
            }).toList();
          }
          break;
        default:
          break;
      }
    }

    //Sort
    switch (currentSort.type) {
      case "created_date":
        currentData.sortByNullableField(
          getField: (e) => e.createdDate,
          isAscending: currentSort.isAscending,
        );
        break;
      case "name":
        currentData.sortByNullableField(
          getField: (e) => e.name,
          isAscending: currentSort.isAscending,
        );
        break;
      case "status":
        currentData.sortByNullableField(
          getField: (e) => e.status,
          isAscending: currentSort.isAscending,
        );
        break;
      case "payment_type":
        currentData.sortByNullableField(
          getField: (e) => e.paymentType,
          isAscending: currentSort.isAscending,
        );
        break;
      case "payment_date":
        currentData.sortByNullableField(
          getField: (e) => e.paymentDate,
          isAscending: currentSort.isAscending,
        );
        break;

      default:
        break;
    }

    return currentData;
  }

  Future<void> filter() async {
    var res = await navigationService.navigateToFilterView(
      filters: filterOptions,
      selectedFilters: selectedFilters,
    );

    if (res is List<FilterModel>) {
      selectedFilters = res;
      notifyListeners();
    }
  }

  Future<void> sort() async {
    var res = await navigationService.navigateToSortView(
      initalValue: currentSort,
      sortOptions: sortOptions,
    );

    if (res is SortModel) {
      setSort(res);
    }
  }

  void setSort(SortModel sort) {
    currentSort = sort;
    notifyListeners();
  }

  void goToPaymentReceiptDetailsView(PaymentReceipt item) {
    if (item.id.isNotEmptyOrNull) {
      navigationService.navigateToPaymentReceiptDetailsView(
        paymentReceiptId: item.id!,
      );
    }
  }

  @override
  Stream<List<PaymentReceipt>> get stream {
    return _databaseService.watchPaymentReceipts();
  }
}
