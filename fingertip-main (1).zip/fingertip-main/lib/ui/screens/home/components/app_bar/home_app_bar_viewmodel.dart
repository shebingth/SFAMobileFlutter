import 'package:stacked/stacked.dart';

import '../../../../../app/app.dialogs.dart';
import '../../../../../app/app.locator.dart';
import '../../../../../database/database.dart';
import '../../../../../models/user.dart';
import '../../../../../services/location_service.dart';
import '../../../../../services/user_service.dart';
import '../../../../common/app_constants.dart';
import '../../../../common/utils.dart';
import '../../../../tools/smart_dialog_config.dart';
import '../../home_viewmodel.dart';

class HomeAppBarViewModel extends StreamViewModel<DayLog?> {
  HomeAppBarViewModel({
    required this.homeViewModel,
  });

  final HomeViewModel homeViewModel;
  final _databaseService = locator<DatabaseService>();
  final _locationService = locator<LocationService>();
  final _userService = locator<UserService>();

  AppUser? get user => _userService.user;

  bool get hasStarted {
    if (data != null) {
      return true;
    }
    return false;
  }

  bool get hasEnded {
    if (data?.dayEndTime != null) {
      return true;
    }
    return false;
  }

  @override
  void onData(DayLog? data) {
    homeViewModel.hasStarted = hasStarted;
    homeViewModel.hasEnded = hasEnded;
  }

  Future<void> startDay() async {
    var res = await dialogService.showCustomDialog(
      variant: DialogType.confirm,
      title: "Start Day",
      description: "Are you sure you want to start your day?",
      mainButtonTitle: "Yes",
      secondaryButtonTitle: "No",
    );

    if (res?.confirmed == true) {
      setBusy(true);
      try {
        var latLng = await _locationService.getLocation();
        if (latLng?.hasData == true) {
          bool status = await _databaseService.startDayLog(latLng!);

          if (status == true) {
            showToast("Day started successfully", type: ToastType.success);
          } else {
            showToast("Error starting day");
          }
        } else {
          showToast("Error fetching location, Please try again");
        }
      } catch (e) {
        showToast("Error starting day");
      }
      setBusy(false);
    }
  }

  Future<void> endDay() async {
    var res = await dialogService.showCustomDialog(
      variant: DialogType.confirm,
      title: "End Day",
      description: "Are you sure you want to end your day?",
      mainButtonTitle: "Yes",
      secondaryButtonTitle: "No",
    );

    if (res?.confirmed == true) {
      setBusy(true);
      if (data != null) {
        try {
          if (homeViewModel.data?.any(
                  (element) => element.status == VisitStatus.inProgress) ??
              false) {
            showToast(
              "Checkout from the visit in progress before ending your day",
            );
            setBusy(false);
            return;
          }
          var latLng = await _locationService.getLocation();
          if (latLng?.hasData == true) {
            bool status = await _databaseService.endDayLog(data!.day, latLng!);

            if (status == true) {
              showToast("Day ended successfully", type: ToastType.success);
            } else {
              showToast("Error ending day");
            }
          } else {
            showToast("Error fetching location, Please try again");
          }
        } catch (e) {
          showToast("Error ending day");
        }
      }
      setBusy(false);
    }
  }

  @override
  Stream<DayLog?> get stream => _databaseService.watchCurrentDayLog();
}
