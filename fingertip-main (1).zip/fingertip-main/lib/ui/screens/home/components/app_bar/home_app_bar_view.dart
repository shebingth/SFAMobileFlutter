import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

import '../../../../../app/app.router.dart';
import '../../../../common/app_colors.dart';
import '../../../../common/assets.gen.dart';
import '../../../../common/fonts.gen.dart';
import '../../../../common/ui_helpers.dart';
import '../../../../common/utils.dart';
import '../../../../tools/conditional_widget.dart';
import '../../../../widgets/button.dart';
import '../../../../widgets/custom_text.dart';
import '../../../../widgets/network_image.dart';

import 'home_app_bar_viewmodel.dart';

class HomeAppBarView extends StackedView<HomeAppBarViewModel>
    implements PreferredSizeWidget {
  const HomeAppBarView({
    super.key,
    required this.isHomeBusy,
  });

  final bool isHomeBusy;

  @override
  Widget builder(context, viewModel, child) {
    return AppBar(
      automaticallyImplyLeading: false,
      backgroundColor: Palette.primary,
      toolbarHeight: preferredSize.height,
      elevation: 0,
      systemOverlayStyle: kcSystemUiOverlayLight,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(15),
          bottomRight: Radius.circular(15),
        ),
      ),
      title: Container(
        width: double.infinity,
        padding: EdgeInsets.fromLTRB(15.w, 9.h, 15.w, 9.h),
        margin: EdgeInsets.only(bottom: 5.h),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Palette.scaffoldBackground,
        ),
        child: Row(
          children: [
            GestureDetector(
              onTap: () {
                navigationService.navigateToProfileView();
              },
              behavior: HitTestBehavior.translucent,
              child: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Palette.primary,
                  image: decorationImage(
                    isAsset: true,
                    image: Assets.images.profile.path,
                  ),
                ),
              ),
            ),
            horizontalSpace(8.w),
            Expanded(
              child: CustomText(
                viewModel.user?.name ?? "",
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: Palette.text58,
                  fontSize: 15.sp,
                  fontFamily: FontFamily.manrope,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            horizontalSpace(5.w),
            If(
              condition: !isHomeBusy,
              builder: (context, value) {
                if (viewModel.hasStarted) {
                  if (!viewModel.hasEnded) {
                    return PrimaryButton(
                      onPressed: () {
                        viewModel.endDay();
                      },
                      color: Colors.red,
                      label: "End Day",
                      isBusy: viewModel.isBusy,
                      minWidth: 100.w,
                      visualDensity: VisualDensity.comfortable,
                    );
                  } else {
                    return const SizedBox.shrink();
                  }
                } else {
                  return PrimaryButton(
                    onPressed: () {
                      viewModel.startDay();
                    },
                    label: "Start Day",
                    isBusy: viewModel.isBusy,
                    minWidth: 100.w,
                    visualDensity: VisualDensity.comfortable,
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  HomeAppBarViewModel viewModelBuilder(BuildContext context) {
    return HomeAppBarViewModel(
      homeViewModel: Provider.of(context),
    );
  }

  @override
  Size get preferredSize {
    return const Size.fromHeight(90);
  }
}
