import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';

import '../../../common/app_colors.dart';
import '../../../widgets/custom_text.dart';

class TodaysVisitHeaderWidget extends StatelessWidget {
  const TodaysVisitHeaderWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: CustomText(
            'Today’s Visit',
            style: TextStyle(
              color: Palette.text08,
              fontSize: 18.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        Expanded(
          child: CustomText(
            DateFormat('dd MMM yyyy').format(DateTime.now()),
            textAlign: TextAlign.end,
            style: TextStyle(
              color: Palette.text08,
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }
}
