import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../database/database.dart';
import '../../../common/app_colors.dart';
import '../../../common/app_constants.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../tools/conditional_widget.dart';
import '../../../widgets/button.dart';
import '../../../widgets/custom_text.dart';

class ShopWidget extends StatelessWidget {
  const ShopWidget({
    super.key,
    required this.visit,
    required this.open,
    required this.checkIn,
    required this.markAsMissed,
    this.isBusy = false,
  });

  final Visit visit;
  final void Function(Visit visit) open;
  final void Function(Visit visit) checkIn;
  final void Function(Visit visit) markAsMissed;
  final bool isBusy;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Colors.white,
        boxShadow: const [kcBoxShadow],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomText(
            visit.accountName,
            style: TextStyle(
              color: Palette.text08,
              fontSize: 15.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
          verticalSpace(15.h),
          Row(
            children: [
              Expanded(
                flex: 2,
                child: CustomText(
                  'Visit Type',
                  style: TextStyle(
                    color: Palette.text58,
                    fontSize: 15.sp,
                  ),
                ),
              ),
              CustomText(
                ':',
                style: TextStyle(
                  color: Palette.text58,
                  fontSize: 15.sp,
                ),
              ),
              horizontalSpace(15.w),
              Expanded(
                flex: 3,
                child: CustomText(
                  visit.typeofVisit ?? "--",
                  style: TextStyle(
                    color: Palette.text58,
                    fontSize: 15.sp,
                  ),
                ),
              ),
            ],
          ),
          verticalSpace(12.h),
          Row(
            children: [
              Expanded(
                flex: 2,
                child: CustomText(
                  'Status',
                  style: TextStyle(
                    color: Palette.text58,
                    fontSize: 15.sp,
                  ),
                ),
              ),
              CustomText(
                ':',
                style: TextStyle(
                  color: Palette.text58,
                  fontSize: 15.sp,
                ),
              ),
              horizontalSpace(15.w),
              Expanded(
                flex: 3,
                child: CustomText(
                  visit.status ?? "",
                  style: TextStyle(
                    color: VisitStatus.colorOf(visit.status),
                    fontSize: 15.sp,
                  ),
                ),
              ),
            ],
          ),
          const Divider(
            height: 25,
            thickness: 1,
            color: Palette.border,
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: If(
                  condition: visit.status == VisitStatus.inProgress,
                  builder: (context, value) {
                    return PrimaryButton(
                      onPressed: () => open(visit),
                      visualDensity: VisualDensity.compact,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Assets.images.checkIn.image(),
                          horizontalSpace(5.w),
                          CustomText(
                            'Open',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 15.sp,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                  replacement: PrimaryButton(
                    onPressed: visit.status == VisitStatus.planned
                        ? () => checkIn(visit)
                        : null,
                    visualDensity: VisualDensity.compact,
                    isBusy: isBusy,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Assets.images.checkIn.image(),
                        horizontalSpace(5.w),
                        CustomText(
                          'Check-in',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 15.sp,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              horizontalSpace(15.w),
              Expanded(
                child: PrimaryButton(
                  onPressed: visit.status == VisitStatus.planned
                      ? () => markAsMissed(visit)
                      : null,
                  color: Palette.orange,
                  visualDensity: VisualDensity.compact,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Assets.images.cancel.image(),
                      horizontalSpace(5.w),
                      CustomText(
                        'Missed',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 15.sp,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
