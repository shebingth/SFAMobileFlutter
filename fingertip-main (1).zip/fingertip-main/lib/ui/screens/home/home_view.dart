import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../app/app.router.dart';
import '../../../extensions/list.dart';
import '../../common/app_colors.dart';
import '../../common/assets.gen.dart';
import '../../common/ui_helpers.dart';
import '../../common/utils.dart';
import '../../tools/model_future_builder.dart';
import '../../tools/screen_size.dart';
import '../../tools/separated_list.dart';

import 'components/app_bar/home_app_bar_view.dart';
import 'components/header.dart';
import 'components/menu_item.dart';
import 'components/shop.dart';
import 'home_viewmodel.dart';

class HomeView extends StackedView<HomeViewModel> {
  const HomeView({super.key});

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      backgroundColor: Palette.scaffoldBackground,
      appBar: HomeAppBarView(
        isHomeBusy: viewModel.isBusy,
      ),
      body: SizedBox.expand(
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(15.w, 30.h, 15.w, 50.h),
          child: Column(
            children: [
              Assets.images.logoDummy.image(),
              verticalSpace(30.h),
              GridView(
                padding: EdgeInsets.zero,
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  mainAxisSpacing: 10.w,
                  crossAxisSpacing: 10.h,
                  childAspectRatio: 1,
                ),
                children: [
                  HomeMenuItemWidget(
                    onTap: viewModel.goToKeyKpiView,
                    label: "Key KPIs",
                    icon: Assets.images.flagBlue.image(),
                  ),
                  HomeMenuItemWidget(
                    onTap: navigationService.navigateToAccountView,
                    label: "Accounts",
                    icon: Assets.images.user2.image(),
                  ),
                  HomeMenuItemWidget(
                    onTap: navigationService.navigateToTodaysVisitView,
                    label: "Today's Visit",
                    icon: Assets.images.pin.image(),
                  ),
                  HomeMenuItemWidget(
                    onTap: navigationService.navigateToVisitPlanView,
                    label: "Visit Plans",
                    icon: Assets.images.clipboard.image(),
                  ),
                  HomeMenuItemWidget(
                    onTap: navigationService.navigateToExpenseView,
                    label: "Expenses",
                    icon: Assets.images.doller.image(),
                  ),
                  HomeMenuItemWidget(
                    onTap: navigationService.navigateToOrderView,
                    label: "Orders",
                    icon: Assets.images.orders.image(),
                  ),
                  HomeMenuItemWidget(
                    onTap: navigationService.navigateToInvoiceView,
                    label: "Invoices",
                    icon: Assets.images.receipt.image(),
                  ),
                  HomeMenuItemWidget(
                    onTap: navigationService.navigateToPaymentReceiptView,
                    label: "Receipts",
                    icon: Assets.images.invoice.image(),
                  ),
                  HomeMenuItemWidget(
                    onTap: navigationService.navigateToLeaveView,
                    label: "Leaves",
                    icon: Assets.images.calendarRedCheck.image(),
                  ),
                  // HomeMenuItemWidget(
                  //   onTap: () {},
                  //   label: "Tasks",
                  //   icon: Assets.images.task.image(),
                  // ),
                  HomeMenuItemWidget(
                    onTap: navigationService.navigateToTicketView,
                    label: "Tickets",
                    icon: Assets.images.ticket.image(),
                  ),
                ],
              ),
              verticalSpace(25.h),
              const TodaysVisitHeaderWidget(),
              verticalSpace(26.h),
              Visibility(
                visible: viewModel.sortedVisits.isNotEmptyOrNull,
                replacement: ModelErrorWidget(
                  height: ScreenSize.height * 0.2,
                  error: "No visits available for today",
                ),
                child: SeparatedWidgetList(
                  list: viewModel.sortedVisits,
                  builder: (visit, index) {
                    return ShopWidget(
                      visit: visit,
                      checkIn: viewModel.checkIn,
                      open: viewModel.open,
                      markAsMissed: viewModel.markAsMissed,
                      isBusy: viewModel.busy(visit),
                    );
                  },
                  separation: 15.h,
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => viewModel.refreshData(),
        splashColor: Palette.primary,
        mini: true,
        child: Visibility(
          visible: !viewModel.busy(busyRefresh),
          replacement: const SizedBox(
            width: 20,
            height: 20,
            child: CircularProgressIndicator(
              color: Colors.white,
              strokeWidth: 1.5,
            ),
          ),
          child: Assets.images.refresh2.image(height: 30),
        ),
      ),
    );
  }

  Widget homeErrorWidget(HomeViewModel viewModel) {
    return Container(
      padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 50.h),
      child: Column(
        children: [
          const TodaysVisitHeaderWidget(),
          Expanded(
            child: ModelErrorWidget(
              error: viewModel.modelError?.toString() ??
                  "No visits available for today",
            ),
          ),
        ],
      ),
    );
  }

  @override
  HomeViewModel viewModelBuilder(BuildContext context) {
    return HomeViewModel();
  }
}
