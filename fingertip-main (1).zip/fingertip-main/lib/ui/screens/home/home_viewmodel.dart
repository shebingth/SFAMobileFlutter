import 'package:internet_connection_checker_plus/internet_connection_checker_plus.dart';
import 'package:stacked/stacked.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/string.dart';
import '../../../services/location_service.dart';
import '../../common/app_constants.dart';
import '../../common/utils.dart';
import '../../tools/smart_dialog_config.dart';
import '../dashboard/dashboard_viewmodel.dart';

const String busyRefresh = "busyRefresh";

class HomeViewModel extends StreamViewModel<List<Visit>> {
  final _databaseService = locator<DatabaseService>();
  final _locationService = locator<LocationService>();
  final _internetChecker = InternetConnection();

  bool hasStarted = false;
  bool hasEnded = false;

  List<Visit>? get sortedVisits {
    if (data != null) {
      data!.sort((a, b) {
        final statusComparison =
            VisitStatus.sortOrder(a.status) - VisitStatus.sortOrder(b.status);
        if (statusComparison != 0) {
          return statusComparison;
        } else {
          return a.plannedStartTime.compareTo(b.plannedStartTime);
        }
      });

      return data;
    }
    return null;
  }

  Future<void> checkIn(Visit visit) async {
    if (visit.salesAppId.isEmptyOrNull) return;
    if (hasStarted) {
      if (!hasEnded) {
        if (data?.any((element) => element.status == VisitStatus.inProgress) ??
            false) {
          showToast("Another visit is in progress");
          return;
        }
        setBusyForObject(visit, true);
        try {
          var latLng = await _locationService.getLocation();
          if (latLng?.hasData == true) {
            bool status = await _databaseService.checkIn(
              visit.salesAppId!,
              latLng!,
            );

            if (status) {
              showToast("Checked in successfully", type: ToastType.success);
              navigationService.navigateToVisitView(
                visitMap: visit.toJson(),
              );
            } else {
              showToast("Error checking in");
            }
          } else {
            showToast("Error fetching location, Please try again");
          }
        } catch (e) {
          showToast("Error starting day");
        }
        setBusyForObject(visit, false);
      } else {
        showToast("Day already ended");
      }
    } else {
      showToast("Start day before checking in");
    }
  }

  void open(Visit visit) {
    if (visit.salesAppId.isNotEmptyOrNull) {
      navigationService.navigateToVisitView(
        visitMap: visit.toJson(),
      );
    }
  }

  void markAsMissed(Visit visit) {
    if (hasStarted) {
      if (!hasEnded) {
        if (data?.any((element) => element.status == VisitStatus.inProgress) ??
            false) {
          showToast("Another visit is in progress");
          return;
        }
        if (visit.salesAppId.isNotEmptyOrNull) {
          dialogService.showCustomDialog(
            variant: DialogType.missed,
            data: visit,
          );
        }
      } else {
        showToast("Day already ended");
      }
    } else {
      showToast("Start day before mark as missed");
    }
  }

  void goToKeyKpiView() => locator<DashboardViewModel>().setIndex(0);

  Future<void> refreshData() async {
    if (busy(busyRefresh)) return;

    setBusyForObject(busyRefresh, true);
    var internetStatus = await _internetChecker.internetStatus;
    setBusyForObject(busyRefresh, false);

    if (internetStatus == InternetStatus.connected) {
      var res = await dialogService.showCustomDialog(
        variant: DialogType.confirm,
        title: "Refresh",
        description: "Are you sure you want to refresh the data?",
        mainButtonTitle: "Yes",
        secondaryButtonTitle: "No",
      );

      if (res?.confirmed == true) {
        navigationService.navigateToFetchView(clearSyncedData: true);
      }
    } else {
      showToast("No internet connection");
    }
  }

  @override
  Stream<List<Visit>> get stream => _databaseService.watchTodaysVisits();
}
