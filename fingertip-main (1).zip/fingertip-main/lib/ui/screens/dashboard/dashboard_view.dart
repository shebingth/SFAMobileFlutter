import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../common/app_colors.dart';
import '../../common/assets.gen.dart';
import '../../common/ui_helpers.dart';

import 'dashboard_viewmodel.dart';

class DashboardView extends StackedView<DashboardViewModel> {
  const DashboardView({
    super.key,
  });

  @override
  bool get disposeViewModel => false;

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      body: SizedBox.expand(
        child: viewModel.screens.elementAt(viewModel.currentIndex),
      ),
      bottomNavigationBar: Container(
        height: 70,
        width: double.infinity,
        decoration: const BoxDecoration(
          color: Palette.scaffoldBackground,
          boxShadow: [
            BoxShadow(
              color: Palette.shadow0F,
              offset: Offset(0, -3),
              blurRadius: 11,
              spreadRadius: 0,
            )
          ],
        ),
        child: BottomNavigationBar(
          backgroundColor: Palette.scaffoldBackground,
          type: BottomNavigationBarType.fixed,
          currentIndex: viewModel.currentIndex,
          onTap: viewModel.setIndex,
          selectedFontSize: 12.sp,
          unselectedFontSize: 12.sp,
          elevation: 0,
          items: [
            BottomNavigationBarItem(
              icon: iconWidget(
                icon: Assets.images.flag.path,
              ),
              activeIcon: iconWidget(
                icon: Assets.images.flag.path,
                isActive: true,
              ),
              label: "Key KPI's",
            ),
            BottomNavigationBarItem(
              icon: iconWidget(
                icon: Assets.images.home.path,
              ),
              activeIcon: iconWidget(
                icon: Assets.images.home.path,
                isActive: true,
              ),
              label: "Home",
            ),
            BottomNavigationBarItem(
              icon: iconWidget(
                icon: Assets.images.search3.path,
              ),
              activeIcon: iconWidget(
                icon: Assets.images.search3.path,
                isActive: true,
              ),
              label: "Search",
            ),
            BottomNavigationBarItem(
              icon: iconWidget(
                icon: Assets.images.menu.path,
              ),
              activeIcon: iconWidget(
                icon: Assets.images.menu.path,
                isActive: true,
              ),
              label: "Menu",
            ),
          ],
        ),
      ),
    );
  }

  Widget iconWidget({
    required String icon,
    bool isActive = false,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Image.asset(
          icon,
          color: isActive ? Palette.primary : null,
        ),
        verticalSpace(5.h),
      ],
    );
  }

  @override
  DashboardViewModel viewModelBuilder(BuildContext context) {
    return locator<DashboardViewModel>();
  }
}
