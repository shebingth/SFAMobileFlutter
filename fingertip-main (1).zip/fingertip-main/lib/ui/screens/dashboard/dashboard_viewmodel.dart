import 'package:stacked/stacked.dart';

import '../home/home_view.dart';
import '../kpi/kpi_view.dart';
import '../menu/menu_view.dart';
import '../search/search_view.dart';

class DashboardViewModel extends BaseViewModel {
  int currentIndex = 1;

  void setIndex(int index) {
    currentIndex = index;
    notifyListeners();
  }

  final screens = [
    const KpiView(),
    const HomeView(),
    const SearchView(),
    const MenuView(),
  ];
}
