import 'package:flutter/material.dart';

import 'package:date_field/date_field.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../extensions/date_time.dart';
import '../../../extensions/string.dart';
import '../../common/app_colors.dart';
import '../../common/app_constants.dart';
import '../../common/ui_helpers.dart';
import '../../tools/dismiss_keyboard.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/button.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/form_fields/date_picker.dart';
import '../../widgets/form_fields/dropdown_field.dart';
import '../../widgets/form_fields/text_field.dart';

import 'leave_new_viewmodel.dart';

class LeaveNewView extends StackedView<LeaveNewViewModel> {
  const LeaveNewView({super.key});

  @override
  Widget builder(context, viewModel, child) {
    var data = viewModel.data;
    var now = DateTime.now();
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Add Leave",
      ),
      body: DismissKeyboard(
        child: SizedBox.expand(
          child: Form(
            key: viewModel.formKey,
            autovalidateMode: viewModel.autovalidateMode,
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(15.w, 25.h, 15.w, 30.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CustomText(
                    "Information",
                    style: TextStyle(
                      fontSize: 15.sp,
                      fontWeight: FontWeight.bold,
                      color: Palette.grey09,
                    ),
                  ),
                  CustomDropdownFormField(
                    top: 18.h,
                    labelText: "Leave Type",
                    hideOuterLabel: true,
                    isRequired: true,
                    value: data.leaveType,
                    items: LeaveTypes.values,
                    itemAsString: (item) => item,
                    onSaved: (newValue) {
                      data.leaveType = newValue;
                    },
                    onChanged: viewModel.setLeaveType,
                    validator: (value) {
                      if (value == null) {
                        return "Required";
                      }
                      return null;
                    },
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: CustomDropdownFormField(
                          top: 18.h,
                          labelText: "Duration",
                          hideOuterLabel: true,
                          isRequired: true,
                          value: data.duration,
                          items: LeaveDuration.values,
                          itemAsString: (item) => item,
                          onSaved: (newValue) {
                            data.duration = newValue;
                          },
                          onChanged: viewModel.setDuration,
                          validator: (value) {
                            if (value == null) {
                              return "Required";
                            }
                            return null;
                          },
                        ),
                      ),
                      Visibility(
                        visible: data.duration == LeaveDuration.halfDay,
                        child: horizontalSpace(15.w),
                      ),
                      Visibility(
                        visible: data.duration == LeaveDuration.halfDay,
                        child: Expanded(
                          child: CustomDropdownFormField(
                            top: 18.h,
                            labelText: "First/Second",
                            hideOuterLabel: true,
                            isRequired: data.duration == LeaveDuration.halfDay,
                            enabled: data.duration == LeaveDuration.halfDay,
                            value: data.firstSecond,
                            items: LeaveFirstSecond.values,
                            itemAsString: (item) => item,
                            onSaved: (newValue) {
                              data.firstSecond = newValue;
                            },
                            onChanged: viewModel.setFirstSecond,
                            validator: (value) {
                              if (data.duration == LeaveDuration.halfDay) {
                                if (value == null) {
                                  return "Required";
                                }
                              }
                              return null;
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: CustomDateFormField(
                          top: 18.h,
                          labelText: data.duration == LeaveDuration.multipleDays
                              ? "From"
                              : "Date",
                          mode: DateTimeFieldPickerMode.date,
                          hideOuterLabel: true,
                          canClear: false,
                          initialValue: data.startDate,
                          isRequired: true,
                          firstDate: DateTime(now.year - 1),
                          lastDate: DateTime(now.year + 1),
                          onChanged: viewModel.setStartDate,
                          onSaved: (newValue) {
                            data.startDate = newValue;
                          },
                          validator: (value) {
                            if (value == null) {
                              return "Required";
                            }

                            return null;
                          },
                        ),
                      ),
                      Visibility(
                        visible: data.duration == LeaveDuration.multipleDays,
                        child: horizontalSpace(15.w),
                      ),
                      Visibility(
                        visible: data.duration == LeaveDuration.multipleDays,
                        child: Expanded(
                          child: CustomDateFormField(
                            top: 18.h,
                            labelText: "To",
                            mode: DateTimeFieldPickerMode.date,
                            hideOuterLabel: true,
                            canClear: false,
                            initialValue: data.endDate,
                            enabled:
                                data.duration == LeaveDuration.multipleDays,
                            isRequired:
                                data.duration == LeaveDuration.multipleDays,
                            firstDate: DateTime(now.year - 1),
                            lastDate: DateTime(now.year + 1),
                            onChanged: viewModel.setEndDate,
                            onSaved: (newValue) {
                              data.endDate = newValue;
                            },
                            validator: (value) {
                              if (data.duration == LeaveDuration.multipleDays) {
                                if (value == null) {
                                  return "Required";
                                }
                                if (data.startDate != null) {
                                  if (value.isBefore(data.startDate!) ||
                                      value.isDateEqual(
                                        date: data.startDate!,
                                      )) {
                                    return "Invalid To Date";
                                  }
                                }
                              }
                              return null;
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                  CustomTextFormField(
                    top: 18.h,
                    labelText: "Reason",
                    initialValue: data.reason,
                    onSaved: (newValue) {
                      data.reason = newValue;
                    },
                    validator: (value) {
                      if (value.isEmptyOrNull) {
                        return 'Required';
                      }
                      return null;
                    },
                  ),
                  CustomTextFormField(
                    top: 18.h,
                    labelText: "Comments",
                    initialValue: data.comments,
                    maxLines: 4,
                    onSaved: (newValue) {
                      data.comments = newValue;
                    },
                    validator: (value) {
                      return null;
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
        decoration: const BoxDecoration(
          color: Palette.scaffoldBackground,
          boxShadow: [
            BoxShadow(
              color: Palette.shadow3,
              blurRadius: 5,
              offset: Offset(0, -2),
              spreadRadius: 2,
            )
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.cancel,
                label: "Cancel",
                color: Palette.greyBA,
              ),
            ),
            horizontalSpace(15.w),
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.submit,
                isBusy: viewModel.busy(viewModel.formKey),
                label: "Save",
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  LeaveNewViewModel viewModelBuilder(BuildContext context) {
    return LeaveNewViewModel();
  }
}
