import 'package:flutter/material.dart';

import 'package:stacked/stacked.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../database/database.dart';
import '../../../models/leaves.dart';
import '../../../models/user.dart';
import '../../../services/user_service.dart';
import '../../common/utils.dart';

class LeaveNewViewModel extends BaseViewModel {
  final data = LeaveHelper();
  final _databaseService = locator<DatabaseService>();
  final _userService = locator<UserService>();
  final formKey = GlobalKey<FormState>();

  var autovalidateMode = AutovalidateMode.disabled;

  AppUser? get user => _userService.user;

  void submit() async {
    if (formKey.currentState?.validate() ?? false) {
      formKey.currentState!.save();

      bool status = await runBusyFuture(
        _databaseService.addNewLeave(data: data, user: user),
        busyObject: formKey,
      );

      if (status) {
        await dialogService.showCustomDialog(
          variant: DialogType.confirm,
          title: "Leave Added",
          description: "Leave added successfully.",
          mainButtonTitle: "Continue",
          secondaryButtonTitle: "Cancel",
        );

        navigationService.back();
      }
    } else {
      setAutovalidateMode(AutovalidateMode.always);
    }
  }

  void setAutovalidateMode(AutovalidateMode value) {
    autovalidateMode = value;
    notifyListeners();
  }

  void setLeaveType(String? value) {
    data.leaveType = value;
    data.startDate = null;
    data.endDate = null;
    notifyListeners();
  }

  void setDuration(String? value) {
    data.duration = value;
    data.firstSecond = null;
    notifyListeners();
  }

  void setFirstSecond(String? value) {
    data.firstSecond = value;
    notifyListeners();
  }

  void setStartDate(DateTime? value) {
    data.startDate = value;
    notifyListeners();
  }

  void setEndDate(DateTime? value) {
    data.endDate = value;
    notifyListeners();
  }

  void cancel() => navigationService.back();
}
