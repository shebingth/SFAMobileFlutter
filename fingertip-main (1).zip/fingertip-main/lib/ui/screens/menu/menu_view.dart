import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../app/app.router.dart';
import '../../common/assets.gen.dart';
import '../../common/utils.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/custom_back_button.dart';

import 'components/list_tile.dart';
import 'menu_viewmodel.dart';

class MenuView extends StackedView<MenuViewModel> {
  const MenuView({super.key});

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        leading: CustomBackButton(
          color: Colors.black,
          forceVisible: true,
        ),
        titleText: "Menu",
      ),
      body: SizedBox.expand(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(vertical: 10.h),
          child: Column(
            children: [
              MenuListTile(
                onTap: viewModel.goToKeyKpiView,
                label: "Key KPIs",
                icon: Assets.images.flagBlue.image(),
              ),
              const MenuDivider(),
              MenuListTile(
                onTap: navigationService.navigateToAccountView,
                label: "Accounts",
                icon: Assets.images.user2.image(),
              ),
              const MenuDivider(),
              MenuListTile(
                onTap: navigationService.navigateToTodaysVisitView,
                label: "Today's Visit",
                icon: Assets.images.pin.image(),
              ),
              const MenuDivider(),
              MenuListTile(
                onTap: navigationService.navigateToVisitPlanView,
                label: "Visit Plans",
                icon: Assets.images.clipboard.image(),
              ),
              const MenuDivider(),
              MenuListTile(
                onTap: navigationService.navigateToExpenseView,
                label: "Expenses",
                icon: Assets.images.doller.image(),
              ),
              const MenuDivider(),
              MenuListTile(
                onTap: navigationService.navigateToOrderView,
                label: "Orders",
                icon: Assets.images.orders.image(),
              ),
              const MenuDivider(),
              MenuListTile(
                onTap: navigationService.navigateToInvoiceView,
                label: "Invoices",
                icon: Assets.images.receipt.image(),
              ),
              const MenuDivider(),
              MenuListTile(
                onTap: navigationService.navigateToPaymentReceiptView,
                label: "Receipts",
                icon: Assets.images.invoice.image(),
              ),
              const MenuDivider(),
              MenuListTile(
                onTap: navigationService.navigateToLeaveView,
                label: "Leaves",
                icon: Assets.images.calendarRedCheck.image(),
              ),
              const MenuDivider(),
              // MenuListTile(
              //   onTap: () {},
              //   label: "Tasks",
              //   icon: Assets.images.task.image(),
              // ),
              // const MenuDivider(),
              MenuListTile(
                onTap: navigationService.navigateToTicketView,
                label: "Tickets",
                icon: Assets.images.ticket.image(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  MenuViewModel viewModelBuilder(context) {
    return MenuViewModel();
  }
}
