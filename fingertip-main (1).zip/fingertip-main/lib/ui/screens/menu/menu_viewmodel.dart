import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../dashboard/dashboard_viewmodel.dart';

class MenuViewModel extends BaseViewModel {
  void goToKeyKpiView() => locator<DashboardViewModel>().setIndex(0);
}
