import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../database/database.dart';
import '../../tools/model_future_builder.dart';
import '../../widgets/app_bar.dart';
import '../visit/components/comment.dart';
import '../visit/components/orders.dart';
import '../visit/components/outstanding.dart';
import '../visit/components/shop_details.dart';

import 'visit_preview_viewmodel.dart';

class VisitPreviewView extends StackedView<VisitPreviewViewModel> {
  const VisitPreviewView({
    super.key,
    required this.salesAppId,
    this.accountId,
  });

  final String salesAppId;
  final String? accountId;

  @override
  void onViewModelReady(VisitPreviewViewModel viewModel) {
    viewModel.init();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Visit",
      ),
      body: SizedBox.expand(
        child: ModelFutureBuilder<Visit>(
          data: viewModel.data,
          busy: viewModel.isBusy,
          error: viewModel.modelError?.toString(),
          builder: (context, visit, child) {
            return SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 30.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ShopDetailsWidget(
                    visit: visit,
                    fromPreview: true,
                  ),
                  LastVisitCommentWidget(
                    lastVisitComment: viewModel.lastVisitComment,
                    lastVisitCommentDate: viewModel.lastVisitCommentDate,
                  ),
                  LastVisitOrdersWidget(
                    lastVisitOrders: viewModel.lastVisitOrders,
                  ),
                  OutstandingWidget(visit: visit),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  VisitPreviewViewModel viewModelBuilder(BuildContext context) {
    return VisitPreviewViewModel(
      salesAppId: salesAppId,
      accountId: accountId,
    );
  }
}
