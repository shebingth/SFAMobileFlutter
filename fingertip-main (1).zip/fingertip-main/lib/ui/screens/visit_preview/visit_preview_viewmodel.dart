import 'package:intl/intl.dart';
import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.logger.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/string.dart';
import '../../common/utils.dart';
import '../../tools/smart_dialog_config.dart';

class VisitPreviewViewModel extends StreamViewModel<Visit> {
  VisitPreviewViewModel({
    required this.salesAppId,
    required this.accountId,
  });

  final String salesAppId;
  final String? accountId;
  final _databaseService = locator<DatabaseService>();
  final logger = getLogger('VisitPreviewViewModel');

  Visit? lastVisit;

  Future<void> init() async {
    setBusy(true);

    try {
      if (accountId != null) {
        lastVisit = await _databaseService.getLastVisit(
          salesAppId: salesAppId,
          accountId: accountId!,
        );
      } else {
        logger.e("AccountId $accountId is null");
      }
    } catch (e) {
      logger.e(e);
    }

    setBusy(false);
  }

  void lastVisitOrders() {
    if (lastVisit?.salesAppId != null) {
      navigationService.navigateToLastOrdersView(
        lastVisitMap: lastVisit!.toJson(),
      );
    } else {
      showToast("No orders found");
    }
  }

  String? get lastVisitComment {
    if (data?.lastVisitComment.isNotEmptyOrNull == true) {
      return data!.lastVisitComment;
    } else {
      return lastVisit?.comments;
    }
  }

  String? get lastVisitCommentDate {
    if (data?.lastVisitComment.isNotEmptyOrNull == true &&
        data?.lastVisitDate != null) {
      return DateFormat("dd MMM yyyy").format(data!.lastVisitDate!);
    } else if (lastVisit?.plannedStartTime != null &&
        lastVisit?.comments.isNotEmptyOrNull == true) {
      return DateFormat("dd MMM yyyy").format(lastVisit!.plannedStartTime);
    }
    return null;
  }

  @override
  Stream<Visit> get stream {
    return _databaseService.watchVisitBySalesAppId(salesAppId);
  }
}
