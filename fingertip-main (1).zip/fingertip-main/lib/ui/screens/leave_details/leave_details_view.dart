import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../extensions/date_time.dart';
import '../../tools/conditional_widget.dart';
import '../../tools/model_future_builder.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/details_label_value.dart';

import 'leave_details_viewmodel.dart';

class LeaveDetailsView extends StackedView<LeaveDetailsViewModel> {
  const LeaveDetailsView({
    super.key,
    required this.appLeaveId,
  });

  final String appLeaveId;

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Leave",
      ),
      body: SizedBox.expand(
        child: IfNotNull(
          value: viewModel.data,
          replacement: ModelErrorWidget(
            error: viewModel.initialised ? "Something went wrong" : "",
          ),
          builder: (context, data) {
            return SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(15.w, 25.h, 15.w, 30.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  DetailsLabelValueWidget(
                    label: "Leave Number",
                    value: data.name,
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Leave Status",
                    value: data.leaveStatus,
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Leave Type",
                    value: data.leaveType,
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Duration",
                    value: data.duration,
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "First/Second",
                    value: data.firstSecond,
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "From Date",
                    value: data.startDate.toFormattedDate(),
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "To Date",
                    value: data.endDate.toFormattedDate(),
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Reason",
                    value: data.reason,
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Comments",
                    value: data.comments,
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Last Modified On",
                    value: data.lastModifiedDate.toFormattedDateTime(),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  LeaveDetailsViewModel viewModelBuilder(BuildContext context) {
    return LeaveDetailsViewModel(
      appLeaveId: appLeaveId,
    );
  }
}
