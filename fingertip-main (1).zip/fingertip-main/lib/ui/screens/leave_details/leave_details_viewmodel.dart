import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../database/database.dart';

class LeaveDetailsViewModel extends StreamViewModel<Leave> {
  LeaveDetailsViewModel({
    required this.appLeaveId,
  });

  final String appLeaveId;
  final _databaseService = locator<DatabaseService>();

  @override
  Stream<Leave> get stream {
    return _databaseService.watchLeaveByLeaveId(appLeaveId);
  }
}
