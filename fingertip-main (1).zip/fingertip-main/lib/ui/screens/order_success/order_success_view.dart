import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_colors.dart';
import '../../common/assets.gen.dart';
import '../../common/fonts.gen.dart';
import '../../common/ui_helpers.dart';
import '../../common/utils.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/custom_text.dart';

import 'order_success_viewmodel.dart';

class OrderSuccessView extends StackedView<OrderSuccessViewModel> {
  const OrderSuccessView({super.key});

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const EmptyAppBar(),
      extendBodyBehindAppBar: true,
      body: SizedBox.expand(
        child: Column(
          children: [
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Assets.images.orderSuccess.image(),
                  verticalSpace(44.h),
                  CustomText(
                    'Order Saved Successfully',
                    style: TextStyle(
                      color: Palette.text08,
                      fontSize: 18.sp,
                      fontFamily: FontFamily.manrope,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  verticalSpace(15.h),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 40.w),
                    child: CustomText(
                      'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Palette.text3D,
                        fontSize: 15.sp,
                        height: 1.5,
                      ),
                    ),
                  )
                ],
              ),
            ),
            Container(
              width: double.infinity,
              margin: EdgeInsets.only(top: 10.h, bottom: 50.h),
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () => navigationService.back(),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CustomText(
                      "Back to shop",
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w600,
                        height: 0.9,
                      ),
                    ),
                    horizontalSpace(5.w),
                    Assets.images.arrowRight.image(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  OrderSuccessViewModel viewModelBuilder(context) {
    return OrderSuccessViewModel();
  }
}
