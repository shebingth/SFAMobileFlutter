import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/list.dart';
import '../../../extensions/string.dart';
import '../../../models/sort.dart';
import '../../common/utils.dart';

class AccountPaymentFollowUpViewModel
    extends StreamViewModel<List<PaymentFollowUp>> {
  AccountPaymentFollowUpViewModel({
    required this.appAccountId,
  });

  final String appAccountId;
  final _databaseService = locator<DatabaseService>();

  static final sortOptions = [
    SortModel(
      type: "name",
      label: "Name",
    ),
    SortModel(
      type: "expected_payment_date",
      label: "Expected Payment Date",
    ),
  ];

  SortModel currentSort = sortOptions.first;

  List<PaymentFollowUp>? get filteredOrderedData {
    if (data == null) {
      return null;
    }

    switch (currentSort.type) {
      case "name":
        data!.sortByNullableField(
          getField: (e) => e.name,
          isAscending: currentSort.isAscending,
        );
        break;
      case "expected_payment_date":
        data!.sortByNullableField(
          getField: (e) => e.expectedPaymentDate,
          isAscending: currentSort.isAscending,
        );
        break;

      default:
    }

    return data!;
  }

  Future<void> sort() async {
    var res = await navigationService.navigateToSortView(
      initalValue: currentSort,
      sortOptions: sortOptions,
    );

    if (res is SortModel) {
      setSort(res);
    }
  }

  void setSort(SortModel sort) {
    currentSort = sort;
    notifyListeners();
  }

  void goToAccountPaymentFollowUpDetailsView(PaymentFollowUp item) {
    if (item.appPaymentFollowUpId.isNotEmptyOrNull) {
      navigationService.navigateTo(
        Routes.accountPaymentFollowUpDetailsView,
        arguments: AccountPaymentFollowUpDetailsViewArguments(
          appPaymentFollowUpId: item.appPaymentFollowUpId!,
        ),
      );
    }
  }

  @override
  Stream<List<PaymentFollowUp>> get stream {
    return _databaseService.watchPaymentFollowUpsByAccountId(appAccountId);
  }
}
