import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_colors.dart';
import '../../common/assets.gen.dart';
import '../../tools/conditional_widget.dart';
import '../../tools/model_future_builder.dart';
import '../../tools/screen_size.dart';
import '../../widgets/app_bar.dart';
import '../visit_plan/components/header_button.dart';

import 'account_payment_follow_up_viewmodel.dart';
import 'components/item.dart';

class AccountPaymentFollowUpView
    extends StackedView<AccountPaymentFollowUpViewModel> {
  const AccountPaymentFollowUpView({
    super.key,
    required this.appAccountId,
  });

  final String appAccountId;

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: CustomAppBar(
        titleText: "Payment Follow Up",
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(70),
          child: Container(
            width: double.infinity,
            height: 70,
            color: Palette.greyF5,
            padding: EdgeInsets.symmetric(horizontal: 20.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                HeaderButtonWidget(
                  onTap: viewModel.sort,
                  icon: Assets.images.sort.image(),
                  label: "Sort",
                ),
                const SizedBox.shrink(),
                const SizedBox.shrink(),
              ],
            ),
          ),
        ),
      ),
      body: SizedBox.expand(
        child: IfNotNull(
          value: viewModel.filteredOrderedData,
          condition: (value) => value.isNotEmpty,
          replacement: ModelErrorWidget(
            error: "No payment follow up available",
            height: ScreenSize.height * 0.7,
          ),
          builder: (context, visits) {
            return ListView.separated(
              itemCount: visits.length,
              itemBuilder: (context, index) {
                final item = visits[index];

                return AccountPaymentFollowUpItemWidget(
                  item: item,
                  onTap: viewModel.goToAccountPaymentFollowUpDetailsView,
                );
              },
              separatorBuilder: (context, index) {
                return Container(
                  width: double.infinity,
                  height: 6,
                  color: Palette.greyF5,
                );
              },
            );
          },
        ),
      ),
    );
  }

  @override
  AccountPaymentFollowUpViewModel viewModelBuilder(BuildContext context) {
    return AccountPaymentFollowUpViewModel(
      appAccountId: appAccountId,
    );
  }
}
