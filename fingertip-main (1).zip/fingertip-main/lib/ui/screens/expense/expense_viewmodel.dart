import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/date_time.dart';
import '../../../extensions/list.dart';
import '../../../models/expense.dart';
import '../../../models/sort.dart';
import '../../common/app_constants.dart';
import '../../common/utils.dart';

class ExpenseViewModel extends MultipleStreamViewModel {
  final _databaseService = locator<DatabaseService>();

  List<FilterModel> selectedFilters = [];

  List<FilterModel> get filterOptions {
    return [
      FilterModel(
        type: FilterType.date,
        label: "Date",
      ),
      FilterModel(
        type: FilterType.dropdown,
        label: "Status",
        options: [
          "Approved",
          "Pending",
        ].map((e) => FilterOptionModel(label: e, value: e)).toList(),
      ),
    ];
  }

  static final sortOptions = [
    SortModel(
      type: "created_date",
      label: "Created Date",
      isAscending: false,
    ),
    SortModel(
      type: "date",
      label: "Date",
    ),
    SortModel(
      type: "status",
      label: "Status",
    ),
  ];

  SortModel currentSort = sortOptions.first;

  List<ExpenseHelper> get filteredExpenses {
    List<ExpenseHelper> currentData = [];

    for (var element in expenses) {
      var expence = element.copyWith();
      expence.items = [];
      expence.items!.addAll(
        expenceItems.where((element) => element.appExpId == expence.appExpId),
      );

      currentData.add(expence);
    }

    //Filter
    for (var filter in selectedFilters) {
      switch (filter.label) {
        case "Date":
          if (filter.valueFromDate != null && filter.valueToDate != null) {
            currentData = currentData.where((element) {
              return element.expenseDate.isBetweenDates(
                startDate: filter.valueFromDate!,
                endDate: filter.valueToDate!,
              );
            }).toList();
          }
          break;
        case "Status":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.approvalStatus == filter.valueOption!.value!;
            }).toList();
          }
          break;
        default:
          break;
      }
    }

    //Sort
    switch (currentSort.type) {
      case "created_date":
        currentData.sortByNullableField(
          getField: (e) => e.createdDate,
          isAscending: currentSort.isAscending,
        );
      case "date":
        currentData.sortByNullableField(
          getField: (e) => e.expenseDate,
          isAscending: currentSort.isAscending,
        );
        break;
      case "status":
        currentData.sortByNullableField(
          getField: (e) => e.approvalStatus,
          isAscending: currentSort.isAscending,
        );
        break;
      default:
        break;
    }

    return currentData;
  }

  Future<void> filter() async {
    var res = await navigationService.navigateToFilterView(
      filters: filterOptions,
      selectedFilters: selectedFilters,
    );

    if (res is List<FilterModel>) {
      selectedFilters = res;
      notifyListeners();
    }
  }

  Future<void> sort() async {
    var res = await navigationService.navigateToSortView(
      initalValue: currentSort,
      sortOptions: sortOptions,
    );

    if (res is SortModel) {
      setSort(res);
    }
  }

  void setSort(SortModel sort) {
    currentSort = sort;
    notifyListeners();
  }

  void goToExpenseDetailsView(ExpenseHelper item) {
    if (item.appExpId != null) {
      navigationService.navigateToExpenseNewView(
        appExpId: item.appExpId,
      );
    }
  }

  List<ExpenseHelper> get expenses {
    List<ExpenseHelper>? list = dataMap?["expenses"];
    return list ?? [];
  }

  List<ExpenseItemHelper> get expenceItems {
    List<ExpenseItemHelper>? list = dataMap?["expenceItems"];
    return list ?? [];
  }

  @override
  Map<String, StreamData> get streamsMap {
    return {
      "expenses": StreamData<List<ExpenseHelper>>(
        _databaseService.watchExpenses(),
      ),
      "expenceItems": StreamData<List<ExpenseItemHelper>>(
        _databaseService.watchExpenseItems(),
      ),
    };
  }
}
