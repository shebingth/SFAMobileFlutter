import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../app/app.router.dart';
import '../../common/app_colors.dart';
import '../../common/assets.gen.dart';
import '../../common/utils.dart';
import '../../tools/conditional_widget.dart';
import '../../tools/model_future_builder.dart';
import '../../tools/screen_size.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/divider.dart';
import '../visit_plan/components/header_button.dart';

import 'components/item.dart';
import 'expense_viewmodel.dart';

class ExpenseView extends StackedView<ExpenseViewModel> {
  const ExpenseView({super.key});

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: CustomAppBar(
        titleText: "Expenses",
        actions: [
          IconButton(
            onPressed: navigationService.navigateToSearchView,
            icon: Assets.images.search.image(),
          )
        ],
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(70),
          child: Container(
            width: double.infinity,
            height: 70,
            color: Palette.greyF5,
            padding: EdgeInsets.symmetric(horizontal: 20.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                HeaderButtonWidget(
                  onTap: viewModel.filter,
                  icon: Assets.images.filter2.image(),
                  label: "Filter",
                ),
                HeaderButtonWidget(
                  onTap: viewModel.sort,
                  icon: Assets.images.sort.image(),
                  label: "Sort",
                ),
                HeaderButtonWidget(
                  onTap: navigationService.navigateToExpenseNewView,
                  icon: Assets.images.addRed.image(),
                  label: "New",
                ),
              ],
            ),
          ),
        ),
      ),
      body: SizedBox.expand(
        child: IfNotNull(
          value: viewModel.filteredExpenses,
          condition: (value) => value.isNotEmpty,
          replacement: ModelErrorWidget(
            error: "No expenses available",
            height: ScreenSize.height * 0.7,
          ),
          builder: (context, expences) {
            return ListView.separated(
              itemCount: expences.length,
              itemBuilder: (context, index) {
                final item = expences[index];

                return ExpenseWidget(
                  item: item,
                  onTap: viewModel.goToExpenseDetailsView,
                );
              },
              separatorBuilder: (context, index) {
                return const DividerWidget();
              },
            );
          },
        ),
      ),
    );
  }

  @override
  ExpenseViewModel viewModelBuilder(BuildContext context) {
    return ExpenseViewModel();
  }
}
