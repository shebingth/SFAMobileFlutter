import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../extensions/date_time.dart';
import '../../../../extensions/double.dart';
import '../../../../models/expense.dart';
import '../../../common/app_colors.dart';
import '../../../common/app_constants.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/custom_text.dart';
import '../../visit_plan/components/label_value.dart';

class ExpenseWidget extends StatelessWidget {
  const ExpenseWidget({
    super.key,
    required this.item,
    required this.onTap,
  });

  final ExpenseHelper item;
  final void Function(ExpenseHelper item) onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onTap(item),
      behavior: HitTestBehavior.translucent,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 15.w),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: EdgeInsets.only(top: 25.h, bottom: 20.h),
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: Palette.divider),
                ),
              ),
              child: CustomText(
                item.expenseName,
                style: TextStyle(
                  fontSize: 15.sp,
                  fontWeight: FontWeight.w600,
                  color: Palette.text08,
                ),
              ),
            ),
            MainListLabelValueWidget(
              top: 20.h,
              label: "Status",
              value: item.approvalStatus,
              valueColor: ExpenseStatus.statusColor(item.approvalStatus),
            ),
            MainListLabelValueWidget(
              top: 20.h,
              label: "Date",
              value: item.expenseDate.toFormattedDate(),
            ),
            MainListLabelValueWidget(
              top: 20.h,
              label: "Total",
              value: "₹ ${item.totalAmount.removeTrailingZeros}",
            ),
            verticalSpace(25.h),
          ],
        ),
      ),
    );
  }
}
