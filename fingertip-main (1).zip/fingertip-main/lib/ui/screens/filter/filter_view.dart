import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:date_field/date_field.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../extensions/string.dart';
import '../../../models/sort.dart';
import '../../common/app_colors.dart';
import '../../common/app_constants.dart';
import '../../common/ui_helpers.dart';
import '../../tools/dismiss_keyboard.dart';
import '../../tools/separated_list.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/button.dart';
import '../../widgets/divider.dart';
import '../../widgets/form_fields/date_picker.dart';
import '../../widgets/form_fields/dropdown_field.dart';
import '../../widgets/form_fields/text_field.dart';

import 'components/field_header.dart';
import 'components/header.dart';
import 'filter_viewmodel.dart';

class FilterView extends StackedView<FilterViewModel> {
  const FilterView({
    super.key,
    required this.filters,
    required this.selectedFilters,
  });

  final List<FilterModel> filters;
  final List<FilterModel> selectedFilters;

  @override
  Widget builder(context, viewModel, child) {
    var now = DateTime.now();

    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Filter",
      ),
      body: SizedBox.expand(
        child: DismissKeyboard(
          child: Form(
            key: viewModel.formKey,
            autovalidateMode: viewModel.autovalidateMode,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  const FilterHeaderWidget(),
                  SeparatedWidgetList(
                    list: viewModel.selectedFilters,
                    headerBuilder: () => const DividerWidget(),
                    footerBuilder: () => const DividerWidget(),
                    builder: (filter, index) {
                      switch (filter.type) {
                        case FilterType.textField:
                          return FilterFieldHeader(
                            filter: filter,
                            onDelete: viewModel.onDeleteField,
                            child: CustomTextFormField(
                              labelText: filter.label,
                              initialValue: filter.value,
                              keyboardType: filter.isNumeric
                                  ? TextInputType.number
                                  : TextInputType.text,
                              inputFormatters: [
                                if (filter.isNumeric)
                                  FilteringTextInputFormatter.allow(
                                    RegExp(r'^\d*\.?\d*$'),
                                  ),
                              ],
                              onSaved: (newValue) {
                                filter.value = newValue;
                              },
                              validator: (value) {
                                if (value.isEmptyOrNull) {
                                  return 'Required';
                                }
                                return null;
                              },
                            ),
                          );
                        case FilterType.dropdown:
                          return FilterFieldHeader(
                            filter: filter,
                            onDelete: viewModel.onDeleteField,
                            child: CustomDropdownFormField(
                              labelText: filter.label,
                              hideOuterLabel: true,
                              value: filter.valueOption,
                              items: filter.options ?? [],
                              itemAsString: (item) => item.label ?? "",
                              onSaved: (newValue) {
                                filter.valueOption = newValue;
                              },
                              onChanged: (v) {},
                              validator: (value) {
                                if (value == null) {
                                  return "Required";
                                }
                                return null;
                              },
                            ),
                          );
                        case FilterType.dropdownSearch:
                          return FilterFieldHeader(
                            filter: filter,
                            onDelete: viewModel.onDeleteField,
                            child: CustomDropdownSearchFormField(
                              hintText: filter.label,
                              labelText: filter.label,
                              value: filter.valueOption,
                              items: filter.options ?? [],
                              itemAsString: (item) => item.label ?? "",
                              compareFn: (item1, item2) => item1 == item2,
                              onSaved: (newValue) {
                                filter.valueOption = newValue;
                              },
                              onChanged: (v) {},
                              validator: (value) {
                                if (value == null) {
                                  return "Required";
                                }
                                return null;
                              },
                            ),
                          );
                        case FilterType.date:
                          return FilterFieldHeader(
                            filter: filter,
                            onDelete: viewModel.onDeleteField,
                            child: Column(
                              children: [
                                CustomDateFormField(
                                  labelText: "From",
                                  mode: DateTimeFieldPickerMode.date,
                                  hideOuterLabel: true,
                                  canClear: false,
                                  hideSuffixIcon: true,
                                  initialValue: filter.valueFromDate,
                                  firstDate: DateTime(now.year - 5),
                                  lastDate: filter.lastDate ?? now,
                                  onChanged: (newValue) {
                                    filter.valueFromDate = newValue;
                                  },
                                  onSaved: (newValue) {
                                    filter.valueFromDate = newValue;
                                  },
                                  validator: (value) {
                                    if (value == null) {
                                      return "Required";
                                    }
                                    return null;
                                  },
                                ),
                                CustomDateFormField(
                                  top: 15.h,
                                  labelText: "To",
                                  mode: DateTimeFieldPickerMode.date,
                                  hideOuterLabel: true,
                                  canClear: false,
                                  hideSuffixIcon: true,
                                  initialValue: filter.valueToDate,
                                  firstDate: DateTime(now.year - 5),
                                  lastDate: filter.lastDate ?? now,
                                  onChanged: (newValue) {},
                                  onSaved: (newValue) {
                                    filter.valueToDate = newValue;
                                  },
                                  validator: (value) {
                                    if (value == null) {
                                      return "Required";
                                    }
                                    if (filter.valueFromDate != null) {
                                      if (value
                                          .isBefore(filter.valueFromDate!)) {
                                        return "To date must greater than From date";
                                      }
                                    }
                                    return null;
                                  },
                                ),
                              ],
                            ),
                          );
                        case FilterType.minMax:
                          return FilterFieldHeader(
                            filter: filter,
                            onDelete: viewModel.onDeleteField,
                            child: Column(
                              children: [
                                CustomTextFormField(
                                  labelText: "Min",
                                  initialValue: filter.minValue,
                                  keyboardType: TextInputType.number,
                                  inputFormatters: [
                                    FilteringTextInputFormatter.allow(
                                      RegExp(r'^\d*\.?\d*$'),
                                    ),
                                  ],
                                  onSaved: (newValue) {
                                    filter.minValue = newValue;
                                  },
                                  validator: (value) {
                                    return null;
                                  },
                                ),
                                CustomTextFormField(
                                  top: 15.h,
                                  labelText: "Max",
                                  initialValue: filter.maxValue,
                                  keyboardType: TextInputType.number,
                                  inputFormatters: [
                                    FilteringTextInputFormatter.allow(
                                      RegExp(r'^\d*\.?\d*$'),
                                    ),
                                  ],
                                  onSaved: (newValue) {
                                    filter.maxValue = newValue;
                                  },
                                  validator: (value) {
                                    return null;
                                  },
                                ),
                              ],
                            ),
                          );

                        default:
                          return const SizedBox.shrink();
                      }
                    },
                    separationBuilder: (index) {
                      return const DividerWidget();
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
        decoration: const BoxDecoration(
          color: Palette.scaffoldBackground,
          boxShadow: [
            BoxShadow(
              color: Palette.shadow3,
              blurRadius: 5,
              offset: Offset(0, -2),
              spreadRadius: 2,
            )
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.cancel,
                label: "Cancel",
                color: Palette.greyBA,
              ),
            ),
            horizontalSpace(15.w),
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.applyFilter,
                label: "Apply",
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  FilterViewModel viewModelBuilder(BuildContext context) {
    return FilterViewModel(
      filters: filters,
      selectedFilters: selectedFilters,
    );
  }
}
