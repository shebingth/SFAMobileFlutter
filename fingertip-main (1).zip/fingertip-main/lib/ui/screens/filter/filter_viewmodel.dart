import 'package:flutter/material.dart';

import 'package:stacked/stacked.dart';

import '../../../app/app.dialogs.dart';
import '../../../models/sort.dart';
import '../../common/utils.dart';

class FilterViewModel extends BaseViewModel {
  FilterViewModel({
    required this.filters,
    required List<FilterModel> selectedFilters,
  }) : selectedFilters = List.from(selectedFilters.map((e) => e.copyWith()));

  final List<FilterModel> filters;
  final List<FilterModel> selectedFilters;
  final formKey = GlobalKey<FormState>();

  var autovalidateMode = AutovalidateMode.disabled;

  void applyFilter() {
    if (formKey.currentState?.validate() == true) {
      formKey.currentState!.save();

      navigationService.back(result: selectedFilters);
    } else {
      setAutovalidateMode(AutovalidateMode.always);
    }
  }

  void setAutovalidateMode(AutovalidateMode mode) {
    autovalidateMode = mode;
    notifyListeners();
  }

  void clearAll() {
    selectedFilters.clear();
    notifyListeners();
  }

  Future<void> addFilter() async {
    var res = await dialogService.showCustomDialog(
      variant: DialogType.addFilter,
      data: filters.where((element) {
        return !selectedFilters.contains(element);
      }).toList(),
    );

    if (res?.data is FilterModel) {
      FilterModel f = res!.data;
      selectedFilters.add(f.copyWith());
      notifyListeners();
    }
  }

  void onDeleteField(FilterModel filter) {
    selectedFilters.remove(filter);
    notifyListeners();
  }

  void cancel() {
    navigationService.back();
  }
}
