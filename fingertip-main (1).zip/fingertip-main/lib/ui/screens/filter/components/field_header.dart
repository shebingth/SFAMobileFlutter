import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../models/sort.dart';
import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/custom_text.dart';

class FilterFieldHeader extends StatelessWidget {
  const FilterFieldHeader({
    super.key,
    required this.filter,
    required this.child,
    required this.onDelete,
  });

  final FilterModel filter;
  final Widget child;
  final void Function(FilterModel filter) onDelete;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 25.h),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: CustomText(
                  filter.label,
                  style: TextStyle(
                    fontSize: 15.sp,
                    fontWeight: FontWeight.bold,
                    color: Palette.text58,
                  ),
                ),
              ),
              IconButton(
                onPressed: () => onDelete(filter),
                visualDensity: VisualDensity.compact,
                icon: Assets.images.trashFilled.image(),
                splashRadius: kTextTabBarHeight / 2,
              ),
            ],
          ),
          verticalSpace(13.h),
          child,
        ],
      ),
    );
  }
}
