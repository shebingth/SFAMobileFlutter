import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/button.dart';
import '../../../widgets/custom_text.dart';
import '../filter_viewmodel.dart';

class FilterHeaderWidget extends ViewModelWidget<FilterViewModel> {
  const FilterHeaderWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, FilterViewModel viewModel) {
    return Container(
      padding: EdgeInsets.fromLTRB(15.w, 25.h, 15.w, 21.h),
      child: Row(
        children: [
          Expanded(
            child: PrimaryButton(
              onPressed: viewModel.clearAll,
              color: Palette.scaffoldBackground,
              borderColor: Palette.red,
              radius: 4,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Assets.images.broom.image(),
                  horizontalSpace(5.w),
                  CustomText(
                    "Clear All",
                    style: TextStyle(
                      fontSize: 15.sp,
                      fontWeight: FontWeight.normal,
                      color: Palette.red,
                    ),
                  ),
                ],
              ),
            ),
          ),
          horizontalSpace(15.w),
          Expanded(
            child: PrimaryButton(
              onPressed: viewModel.addFilter,
              color: Palette.scaffoldBackground,
              borderColor: Palette.primary,
              radius: 4,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Assets.images.addCircle.image(),
                  horizontalSpace(5.w),
                  CustomText(
                    "Add Filter",
                    style: TextStyle(
                      fontSize: 15.sp,
                      fontWeight: FontWeight.normal,
                      color: Palette.primary,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
