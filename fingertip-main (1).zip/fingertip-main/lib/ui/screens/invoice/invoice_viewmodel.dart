import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/date_time.dart';
import '../../../extensions/list.dart';
import '../../../extensions/string.dart';
import '../../../models/sort.dart';
import '../../common/app_constants.dart';
import '../../common/utils.dart';
import '../../tools/parse.dart';

class InvoiceViewModel extends StreamViewModel<List<Invoice>> {
  final _databaseService = locator<DatabaseService>();

  List<FilterModel> selectedFilters = [];
  List<Account> accounts = [];

  List<FilterModel> get filterOptions {
    return [
      FilterModel(
        type: FilterType.textField,
        label: "Invoice Number",
      ),
      FilterModel(
        type: FilterType.dropdownSearch,
        label: "Account",
        options: accounts.map((e) {
          return FilterOptionModel(label: e.name, value: e.id);
        }).toList(),
      ),
      FilterModel(
        type: FilterType.date,
        label: "Invoice Date",
      ),
      FilterModel(
        type: FilterType.textField,
        label: "Grand Total",
        isNumeric: true,
      ),
      FilterModel(
        type: FilterType.minMax,
        label: "Balance",
      ),
      FilterModel(
        type: FilterType.date,
        label: "Due Date",
      ),
      FilterModel(
        type: FilterType.dropdown,
        label: "Status",
        options: ["Pending", "Paid", "Raised", "Overdue"].map((e) {
          return FilterOptionModel(label: e, value: e);
        }).toList(),
      ),
    ];
  }

  static final sortOptions = [
    SortModel(
      type: "created_date",
      label: "Created Date",
      isAscending: false,
    ),
    SortModel(
      type: "invoice_number",
      label: "Invoice Number",
    ),
    SortModel(
      type: "account",
      label: "Account",
    ),
    SortModel(
      type: "invoice_date",
      label: "Invoice Date",
    ),
    SortModel(
      type: "grand_total",
      label: "Grand Total",
    ),
    SortModel(
      type: "due_date",
      label: "Due Date",
    ),
    SortModel(
      type: "status",
      label: "Status",
    ),
  ];

  SortModel currentSort = sortOptions.first;

  List<Invoice>? get filteredOrderedData {
    List<Invoice> currentData = data ?? [];

    //Filter
    for (var filter in selectedFilters) {
      switch (filter.label) {
        case "Invoice Number":
          if (filter.value.isNotEmptyOrNull) {
            currentData = currentData.where((element) {
              return element.name
                      ?.toLowerCase()
                      .contains(filter.value!.toLowerCase()) ??
                  false;
            }).toList();
          }
          break;
        case "Account":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.accountId == filter.valueOption!.value!;
            }).toList();
          }
          break;
        case "Invoice Date":
          if (filter.valueFromDate != null && filter.valueToDate != null) {
            currentData = currentData.where((element) {
              return element.invoiceDate.isBetweenDates(
                startDate: filter.valueFromDate!,
                endDate: filter.valueToDate!,
              );
            }).toList();
          }
          break;
        case "Grand Total":
          double? value = parseToDouble(filter.value);
          if (value != null) {
            currentData = currentData.where((element) {
              return element.grandTotal == value;
            }).toList();
          }
          break;
        case "Due Date":
          if (filter.valueFromDate != null && filter.valueToDate != null) {
            currentData = currentData.where((element) {
              return element.dueDate.isBetweenDates(
                startDate: filter.valueFromDate!,
                endDate: filter.valueToDate!,
              );
            }).toList();
          }
          break;
        case "Status":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.status == filter.valueOption!.value!;
            }).toList();
          }
          break;
        case "Balance":
          if (filter.minValue != null) {
            currentData = currentData.where((element) {
              return element.balance != null &&
                  element.balance! >= filter.minValueAsDouble!;
            }).toList();
          }
          if (filter.maxValue != null) {
            currentData = currentData.where((element) {
              return element.balance != null &&
                  element.balance! <= filter.maxValueAsDouble!;
            }).toList();
          }
          break;
        default:
          break;
      }
    }

    //Sort
    switch (currentSort.type) {
      case "created_date":
        currentData.sortByNullableField(
          getField: (e) => e.createdDate,
          isAscending: currentSort.isAscending,
        );
        break;
      case "invoice_number":
        currentData.sortByNullableField(
          getField: (e) => e.name,
          isAscending: currentSort.isAscending,
        );
        break;
      case "account":
        currentData.sortByNullableField(
          getField: (e) => e.accountName,
          isAscending: currentSort.isAscending,
        );
        break;
      case "invoice_date":
        currentData.sortByNullableField(
          getField: (e) => e.invoiceDate,
          isAscending: currentSort.isAscending,
        );
        break;
      case "grand_total":
        currentData.sortByNullableField(
          getField: (e) => e.grandTotal,
          isAscending: currentSort.isAscending,
        );
        break;
      case "due_date":
        currentData.sortByNullableField(
          getField: (e) => e.dueDate,
          isAscending: currentSort.isAscending,
        );
        break;
      case "status":
        currentData.sortByNullableField(
          getField: (e) => e.status,
          isAscending: currentSort.isAscending,
        );
        break;
      default:
        break;
    }

    return currentData;
  }

  Future<void> init() async {
    accounts = await _databaseService.getAccounts();
    notifyListeners();
  }

  Future<void> filter() async {
    var res = await navigationService.navigateToFilterView(
      filters: filterOptions,
      selectedFilters: selectedFilters,
    );

    if (res is List<FilterModel>) {
      selectedFilters = res;
      notifyListeners();
    }
  }

  Future<void> sort() async {
    var res = await navigationService.navigateToSortView(
      initalValue: currentSort,
      sortOptions: sortOptions,
    );

    if (res is SortModel) {
      setSort(res);
    }
  }

  void setSort(SortModel sort) {
    currentSort = sort;
    notifyListeners();
  }

  void goToInvoicesDetailsView(Invoice item) {
    if (item.appInvoiceId.isNotEmptyOrNull) {
      navigationService.navigateToInvoiceDetailsView(
        appInvoiceId: item.appInvoiceId!,
      );
    }
  }

  @override
  Stream<List<Invoice>> get stream {
    return _databaseService.watchInvoices();
  }
}
