import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.logger.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../services/api_service.dart';
import '../../../services/upload_service.dart';
import '../../../services/user_service.dart';
import '../../common/utils.dart';

class FetchViewModel extends BaseViewModel {
  FetchViewModel({
    required this.clearData,
    required this.clearSyncedData,
  });

  final bool clearData;
  final bool clearSyncedData;
  final _apiService = locator<ApiService>();
  final _databaseService = locator<DatabaseService>();
  final _uploadService = locator<UploadService>();
  final _userService = locator<UserService>();
  final logger = getLogger('FetchViewModel');

  Future<void> fetchData() async {
    setBusy(true);
    await _uploadService.stopStream();

    try {
      if (clearData) {
        await _databaseService.clearTables();
      }
      if (clearSyncedData) {
        await _databaseService.clearSyncedData();
      }

      var data = await _apiService.fetchData();
      if (data != null) {
        await _databaseService.addNewData(data);
      }
    } catch (e) {
      logger.e(e);
    }

    setBusy(false);

    if (_userService.user?.hasUser == true) {
      _uploadService.registerStreams();

      navigationService.clearStackAndShow(Routes.dashboardView);
    }
  }
}
