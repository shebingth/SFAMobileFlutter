import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_colors.dart';
import '../../common/assets.gen.dart';
import '../../common/fonts.gen.dart';
import '../../common/ui_helpers.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/network_image.dart';

import 'fetch_viewmodel.dart';

class FetchView extends StackedView<FetchViewModel> {
  const FetchView({
    super.key,
    this.clearData = false,
    this.clearSyncedData = false,
  });

  final bool clearData;
  final bool clearSyncedData;

  @override
  void onViewModelReady(FetchViewModel viewModel) {
    viewModel.fetchData();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Palette.primary,
        toolbarHeight: 90,
        elevation: 0,
        systemOverlayStyle: kcSystemUiOverlayLight,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(15),
            bottomRight: Radius.circular(15),
          ),
        ),
        title: Container(
          width: double.infinity,
          padding: EdgeInsets.fromLTRB(15.w, 9.h, 15.w, 9.h),
          margin: EdgeInsets.only(bottom: 5.h),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Palette.scaffoldBackground,
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Palette.primary,
                  image: decorationImage(
                    isAsset: true,
                    image: Assets.images.profile.path,
                  ),
                ),
              ),
              horizontalSpace(8.w),
              Expanded(
                child: CustomText(
                  'Hello',
                  style: TextStyle(
                    color: Palette.text58,
                    fontSize: 15.sp,
                    fontFamily: FontFamily.manrope,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      body: SizedBox.expand(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(),
            verticalSpace(15.h),
            CustomText(
              "Fetching data...",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14.sp,
                color: Colors.black54,
                fontWeight: FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  FetchViewModel viewModelBuilder(BuildContext context) {
    return FetchViewModel(
      clearData: clearData,
      clearSyncedData: clearSyncedData,
    );
  }
}
