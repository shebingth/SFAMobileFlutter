import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../database/database.dart';

class AccountVisitsDetailsViewModel extends StreamViewModel<Visit> {
  AccountVisitsDetailsViewModel({
    required this.salesAppId,
  });

  final String salesAppId;
  final _databaseService = locator<DatabaseService>();

  @override
  Stream<Visit> get stream {
    return _databaseService.watchVisitBySalesAppId(salesAppId);
  }
}
