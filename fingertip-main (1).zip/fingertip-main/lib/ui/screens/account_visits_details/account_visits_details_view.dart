import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../extensions/date_time.dart';
import '../../common/app_constants.dart';
import '../../tools/conditional_widget.dart';
import '../../tools/model_future_builder.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/details_label_value.dart';

import 'account_visits_details_viewmodel.dart';

class AccountVisitsDetailsView
    extends StackedView<AccountVisitsDetailsViewModel> {
  const AccountVisitsDetailsView({
    super.key,
    required this.salesAppId,
  });

  final String salesAppId;

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Visit",
      ),
      body: SizedBox.expand(
        child: IfNotNull(
          value: viewModel.data,
          replacement: ModelErrorWidget(
            error: viewModel.initialised ? "Something went wrong" : "",
          ),
          builder: (context, data) {
            return SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(15.w, 25.h, 15.w, 30.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  DetailsLabelValueWidget(
                    label: "Account",
                    value: data.accountName,
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Status",
                    value: data.status,
                    valueColor: VisitStatus.colorOf(data.status),
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Visit Type",
                    value: data.typeofVisit,
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Planned Start Time",
                    value: data.plannedStartTime.toFormattedDateTime(),
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Actual Start Time",
                    value: data.actualStartTime.toFormattedDateTime(),
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Missed Reason",
                    value: data.missedReason,
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Latitude",
                    value: data.geoLocation?.lat.toString(),
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Longitude",
                    value: data.geoLocation?.lng.toString(),
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Checkout Latitude",
                    value: data.checkoutLocation?.lat.toString(),
                  ),
                  DetailsLabelValueWidget(
                    top: 15.h,
                    label: "Checkout Longitude",
                    value: data.checkoutLocation?.lng.toString(),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  AccountVisitsDetailsViewModel viewModelBuilder(BuildContext context) {
    return AccountVisitsDetailsViewModel(
      salesAppId: salesAppId,
    );
  }
}
