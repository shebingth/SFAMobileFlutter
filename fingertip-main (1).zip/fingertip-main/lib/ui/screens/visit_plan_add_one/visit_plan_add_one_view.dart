import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../models/visit_plan.dart';
import '../../common/app_colors.dart';
import '../../common/ui_helpers.dart';
import '../../tools/dismiss_keyboard.dart';
import '../../tools/model_future_builder.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/button.dart';

import 'components/header.dart';
import 'components/item.dart';
import 'visit_plan_add_one_viewmodel.dart';

class VisitPlanAddOneView extends StackedView<VisitPlanAddOneViewModel> {
  const VisitPlanAddOneView({
    super.key,
    required this.params,
  });

  final VisitPlanAddParams params;

  @override
  void onViewModelReady(VisitPlanAddOneViewModel viewModel) {
    viewModel.init();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Add Visit",
      ),
      body: SizedBox.expand(
        child: DismissKeyboard(
          child: NestedScrollView(
            headerSliverBuilder: (context, innerBoxIsScrolled) {
              return <Widget>[
                const SliverToBoxAdapter(
                  child: VisitPlanAddHeader(),
                ),
                SliverToBoxAdapter(
                  child: Container(
                    width: double.infinity,
                    height: 6,
                    color: Palette.greyF5,
                  ),
                ),
              ];
            },
            body: SizedBox.expand(
              child: ModelFutureListBuilder(
                data: viewModel.filteredAccounts,
                busy: viewModel.isBusy,
                error: "No accounts available",
                builder: (context, accounts, child) {
                  return ListView.separated(
                    padding: EdgeInsets.fromLTRB(15.w, 25.h, 15.w, 30.h),
                    itemCount: accounts.length,
                    itemBuilder: (context, index) {
                      var account = accounts[index];

                      return VisitPlanAccountWidget(
                        account: account,
                        onAdd: viewModel.onAdd,
                        onDelete: viewModel.onDelete,
                        isAdded: viewModel.isAdded(account),
                        numberOfVisits: viewModel.numberOfVisits(account),
                      );
                    },
                    separatorBuilder: (context, index) {
                      return verticalSpace(20.h);
                    },
                  );
                },
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
        decoration: const BoxDecoration(
          color: Palette.scaffoldBackground,
          boxShadow: [
            BoxShadow(
              color: Palette.shadow3,
              blurRadius: 5,
              offset: Offset(0, -2),
              spreadRadius: 2,
            )
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.cancel,
                label: "Cancel",
                color: Palette.greyBA,
              ),
            ),
            horizontalSpace(15.w),
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.addVisitPlanNext,
                label: "Next",
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  VisitPlanAddOneViewModel viewModelBuilder(BuildContext context) {
    return VisitPlanAddOneViewModel(
      params: params,
    );
  }
}
