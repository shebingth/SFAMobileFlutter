import 'package:flutter/material.dart';

import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/string.dart';
import '../../../models/visit_plan.dart';
import '../../common/utils.dart';
import '../../tools/smart_dialog_config.dart';

class VisitPlanAddOneViewModel extends BaseViewModel {
  VisitPlanAddOneViewModel({
    required this.params,
  });

  final VisitPlanAddParams params;
  final _databaseService = locator<DatabaseService>();
  final searchController = TextEditingController();

  List<Account> accounts = [];
  List<Visit> visits = [];

  List<Account> get filteredAccounts {
    if (searchController.text.isNotEmpty) {
      return accounts.where((element) {
        if (element.name.isNotEmptyOrNull) {
          return element.name!.toLowerCase().contains(
                searchController.text.toLowerCase(),
              );
        }
        return false;
      }).toList();
    }
    return accounts;
  }

  Future<void> init() async {
    setBusy(true);
    visits = await _databaseService.getVisits();
    accounts = await _databaseService.getAccounts();
    setBusy(false);
  }

  void onAdd(Account account) {
    params.accounts.add(account);
    notifyListeners();
  }

  void onDelete(Account account) {
    params.accounts.remove(account);
    notifyListeners();
  }

  bool isAdded(Account account) {
    if (params.accounts.contains(account)) {
      return true;
    }
    return false;
  }

  void onDateChanged(DateTime? value) {
    if (value != null) {
      params.date = value;
      notifyListeners();
    }
  }

  void cancel() {
    navigationService.back();
  }

  void addVisitPlanNext() {
    if (params.accounts.isNotEmpty) {
      params.visits.addAll(
        params.accounts.map((account) {
          return VisitCustomModel(
            account: account,
            dateTime: params.date,
          );
        }),
      );
      navigationService.replaceWithVisitPlanAddTwoView(
        params: params,
      );
    } else {
      showToast("Please add some accounts to continue");
    }
  }

  int numberOfVisits(Account account) {
    return visits.where((element) {
      return element.appAccountId == account.appAccountId;
    }).length;
  }
}
