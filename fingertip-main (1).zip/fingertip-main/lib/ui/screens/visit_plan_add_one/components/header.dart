import 'package:flutter/material.dart';

import 'package:date_field/date_field.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../common/date_time_utils.dart';
import '../../../widgets/form_fields/date_picker.dart';
import '../../../widgets/form_fields/text_field.dart';
import '../visit_plan_add_one_viewmodel.dart';

class VisitPlanAddHeader extends ViewModelWidget<VisitPlanAddOneViewModel> {
  const VisitPlanAddHeader({
    super.key,
  });

  @override
  Widget build(BuildContext context, VisitPlanAddOneViewModel viewModel) {
    return Container(
      padding: EdgeInsets.fromLTRB(15.w, 25.h, 15.w, 25.h),
      child: Column(
        children: [
          CustomDateFormField(
            top: 15.h,
            labelText: "Select Date",
            mode: DateTimeFieldPickerMode.date,
            hideOuterLabel: true,
            canClear: false,
            initialValue: viewModel.params.date,
            firstDate: DateTimeUtils.isTodayBetweenDates(
              startDate: viewModel.params.visitPlan.startDate,
              endDate: viewModel.params.visitPlan.endDate,
            )
                ? DateTime.now()
                : viewModel.params.visitPlan.startDate?.toLocal(),
            lastDate: viewModel.params.visitPlan.endDate?.toLocal(),
            onChanged: viewModel.onDateChanged,
          ),
          CustomTextFormField(
            top: 20.h,
            controller: viewModel.searchController,
            onChanged: (_) => viewModel.notifyListeners(),
            labelText: "Search By Name",
            hintText: "Enter Name",
            floatingLabelBehavior: FloatingLabelBehavior.always,
          ),
        ],
      ),
    );
  }
}
