import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../database/database.dart';
import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/button.dart';
import '../../../widgets/custom_text.dart';

import 'label_value.dart';

class VisitPlanAccountWidget extends StatelessWidget {
  const VisitPlanAccountWidget({
    super.key,
    required this.account,
    required this.onAdd,
    required this.onDelete,
    required this.isAdded,
    this.numberOfVisits = 0,
  });

  final Account account;
  final void Function(Account account) onAdd;
  final void Function(Account account) onDelete;
  final bool isAdded;
  final int numberOfVisits;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(15.w, 13.h, 15.w, 20.h),
      decoration: BoxDecoration(
        color: Palette.scaffoldBackground,
        borderRadius: BorderRadius.circular(10),
        boxShadow: const [
          BoxShadow(
            color: Palette.shadow1A,
            offset: Offset(0, 1),
            blurRadius: 9,
            spreadRadius: -1,
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: CustomText(
                  account.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 15.sp,
                    fontWeight: FontWeight.bold,
                    color: Palette.text08,
                  ),
                ),
              ),
              Visibility(
                visible: isAdded,
                replacement: PrimaryButton(
                  onPressed: () => onAdd(account),
                  visualDensity: VisualDensity.compact,
                  padding: EdgeInsets.only(left: 20.w, right: 25.w),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Assets.images.addSquare.image(),
                      horizontalSpace(5.w),
                      CustomText(
                        "Add",
                        top: 2.h,
                        style: TextStyle(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          height: 1,
                        ),
                      ),
                    ],
                  ),
                ),
                child: PrimaryButton(
                  onPressed: () => onDelete(account),
                  visualDensity: VisualDensity.compact,
                  color: Palette.red,
                  padding: EdgeInsets.only(left: 15.w, right: 20.w),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Assets.images.trashFilledSmallWhite.image(),
                      horizontalSpace(5.w),
                      CustomText(
                        "Delete",
                        style: TextStyle(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          // VisitPlanAddLabelValueWidget(
          //   top: 8.h,
          //   label: "Visit Plan",
          //   value: null,
          // ),
          VisitPlanAddLabelValueWidget(
            top: 8.h,
            label: "Number of Visit Scheduled",
            value: "$numberOfVisits",
          ),
          VisitPlanAddLabelValueWidget(
            top: 15.h,
            label: "Owner",
            value: account.accountOwnerName,
          ),
        ],
      ),
    );
  }
}
