import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/list.dart';
import '../../../extensions/string.dart';
import '../../../models/sort.dart';
import '../../common/utils.dart';

class AccountPaymentReceiptViewModel
    extends StreamViewModel<List<PaymentReceipt>> {
  AccountPaymentReceiptViewModel({
    required this.appAccountId,
    this.accountId,
  });

  final String appAccountId;
  final String? accountId;
  final _databaseService = locator<DatabaseService>();

  static final sortOptions = [
    SortModel(
      type: "name",
      label: "Name",
    ),
    SortModel(
      type: "status",
      label: "Status",
    ),
    SortModel(
      type: "payment_type",
      label: "Payment Type",
    ),
    SortModel(
      type: "payment_date",
      label: "Payment Date",
    ),
  ];

  SortModel currentSort = sortOptions.first;

  List<PaymentReceipt>? get filteredOrderedData {
    if (data == null) {
      return null;
    }

    switch (currentSort.type) {
      case "name":
        data!.sortByNullableField(
          getField: (e) => e.name,
          isAscending: currentSort.isAscending,
        );
        break;
      case "status":
        data!.sortByNullableField(
          getField: (e) => e.status,
          isAscending: currentSort.isAscending,
        );
        break;
      case "payment_type":
        data!.sortByNullableField(
          getField: (e) => e.paymentType,
          isAscending: currentSort.isAscending,
        );
        break;
      case "payment_date":
        data!.sortByNullableField(
          getField: (e) => e.paymentDate,
          isAscending: currentSort.isAscending,
        );
        break;

      default:
        break;
    }

    return data!;
  }

  Future<void> sort() async {
    var res = await navigationService.navigateToSortView(
      initalValue: currentSort,
      sortOptions: sortOptions,
    );

    if (res is SortModel) {
      setSort(res);
    }
  }

  void setSort(SortModel sort) {
    currentSort = sort;
    notifyListeners();
  }

  void goToAccountPaymentReceiptDetailsView(PaymentReceipt item) {
    if (item.id.isNotEmptyOrNull) {
      navigationService.navigateToPaymentReceiptDetailsView(
        paymentReceiptId: item.id!,
      );
    }
  }

  @override
  Stream<List<PaymentReceipt>> get stream {
    return _databaseService.watchPaymentReceiptByAccountId(
      appAccountId: appAccountId,
      accountId: accountId,
    );
  }
}
