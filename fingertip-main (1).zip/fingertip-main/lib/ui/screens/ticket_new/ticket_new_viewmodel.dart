import 'package:flutter/material.dart';

import 'package:stacked/stacked.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../database/database.dart';
import '../../../models/ticket.dart';
import '../../common/utils.dart';

class TicketNewViewModel extends BaseViewModel {
  TicketNewViewModel({
    required this.visit,
  }) : data = TicketHelper(
          accountId: visit.accountId,
          accountName: visit.accountName,
          salesAppId: visit.salesAppId,
          visitId: visit.id,
        );

  final Visit visit;
  final _databaseService = locator<DatabaseService>();
  final formKey = GlobalKey<FormState>();

  TicketHelper data;
  var autovalidateMode = AutovalidateMode.disabled;

  Future<void> submit() async {
    if (formKey.currentState?.validate() ?? false) {
      formKey.currentState!.save();

      bool status = await runBusyFuture(
        _databaseService.addNewTicket(data: data),
        busyObject: formKey,
      );

      if (status) {
        await dialogService.showCustomDialog(
          variant: DialogType.confirm,
          title: "Ticket Added",
          description: "New Ticket added\nsuccessfully.",
          mainButtonTitle: "Continue",
          secondaryButtonTitle: "Cancel",
        );

        navigationService.back();
      }
    } else {
      setAutovalidateMode(AutovalidateMode.always);
    }
  }

  void setAutovalidateMode(AutovalidateMode mode) {
    autovalidateMode = mode;
    notifyListeners();
  }

  void cancel() => navigationService.back();
}
