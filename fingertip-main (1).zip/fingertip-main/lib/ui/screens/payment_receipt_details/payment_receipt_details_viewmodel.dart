import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../database/database.dart';

class PaymentReceiptDetailsViewModel extends StreamViewModel<PaymentReceipt> {
  PaymentReceiptDetailsViewModel({
    required this.paymentReceiptId,
  });

  final String paymentReceiptId;

  final _databaseService = locator<DatabaseService>();

  @override
  Stream<PaymentReceipt> get stream {
    return _databaseService.watchPaymentReceiptByPaymentReceiptId(
      paymentReceiptId,
    );
  }
}
