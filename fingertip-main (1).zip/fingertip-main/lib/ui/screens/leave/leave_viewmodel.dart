import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/date_time.dart';
import '../../../extensions/list.dart';
import '../../../extensions/string.dart';
import '../../../models/sort.dart';
import '../../common/app_constants.dart';
import '../../common/utils.dart';

class LeaveViewModel extends StreamViewModel<List<Leave>> {
  final _databaseService = locator<DatabaseService>();

  List<FilterModel> selectedFilters = [];

  List<FilterModel> get filterOptions {
    return [
      FilterModel(
        type: FilterType.textField,
        label: "Executive Name",
      ),
      FilterModel(
        type: FilterType.date,
        label: "From Date",
        lastDate: DateTime(DateTime.now().year + 1),
      ),
      FilterModel(
        type: FilterType.date,
        label: "To Date",
        lastDate: DateTime(DateTime.now().year + 1),
      ),
      FilterModel(
        type: FilterType.dropdown,
        label: "Leave Type",
        options: ["Casual", "Sick"].map((e) {
          return FilterOptionModel(label: e, value: e);
        }).toList(),
      ),
      FilterModel(
        type: FilterType.dropdown,
        label: "Duration",
        options: ["Half Day", "Full Day"].map((e) {
          return FilterOptionModel(label: e, value: e);
        }).toList(),
      ),
      FilterModel(
        type: FilterType.dropdown,
        label: "First/Second",
        options: ["First Half", "Second Half"].map((e) {
          return FilterOptionModel(label: e, value: e);
        }).toList(),
      ),
      FilterModel(
        type: FilterType.dropdown,
        label: "Leave Status",
        options: ["Pending", "Approved", "Rejected"].map((e) {
          return FilterOptionModel(label: e, value: e);
        }).toList(),
      ),
    ];
  }

  static final sortOptions = [
    SortModel(
      type: "created_date",
      label: "Created Date",
      isAscending: false,
    ),
    SortModel(
      type: "from_date",
      label: "From Date",
    ),
    SortModel(
      type: "to_date",
      label: "To Date",
    ),
    SortModel(
      type: "duration",
      label: "Duration",
    ),
    SortModel(
      type: "first_second",
      label: "First/Second",
    ),
    SortModel(
      type: "leave_type",
      label: "Leave Type",
    ),
    SortModel(
      type: "last_modified_date",
      label: "Last Modified Date",
    ),
  ];

  SortModel currentSort = sortOptions.first;

  List<Leave>? get filteredOrderedData {
    List<Leave> currentData = data ?? [];

    //Filter
    for (var filter in selectedFilters) {
      switch (filter.label) {
        case "Executive Name":
          if (filter.value.isNotEmptyOrNull) {
            currentData = currentData.where((element) {
              return element.executiveName
                      ?.toLowerCase()
                      .contains(filter.value!.toLowerCase()) ??
                  false;
            }).toList();
          }
          break;
        case "From Date":
          if (filter.valueFromDate != null && filter.valueToDate != null) {
            currentData = currentData.where((element) {
              return element.startDate.isBetweenDates(
                startDate: filter.valueFromDate!,
                endDate: filter.valueToDate!,
              );
            }).toList();
          }
          break;
        case "To Date":
          if (filter.valueFromDate != null && filter.valueToDate != null) {
            currentData = currentData.where((element) {
              return element.endDate.isBetweenDates(
                startDate: filter.valueFromDate!,
                endDate: filter.valueToDate!,
              );
            }).toList();
          }
          break;
        case "Leave Type":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.leaveType == filter.valueOption!.value!;
            }).toList();
          }
          break;
        case "Duration":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.duration == filter.valueOption!.value!;
            }).toList();
          }
          break;
        case "First/Second":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.firstSecond == filter.valueOption!.value!;
            }).toList();
          }
          break;
        case "Leave Status":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.leaveStatus == filter.valueOption!.value!;
            }).toList();
          }
          break;

        default:
          break;
      }
    }

    //Sort
    switch (currentSort.type) {
      case "created_date":
        currentData.sortByNullableField(
          getField: (e) => e.createdDate,
          isAscending: currentSort.isAscending,
        );
        break;
      case "duration":
        currentData.sortByNullableField(
          getField: (e) => e.duration,
          isAscending: currentSort.isAscending,
        );
        break;
      case "first_second":
        currentData.sortByNullableField(
          getField: (e) => e.firstSecond,
          isAscending: currentSort.isAscending,
        );
        break;
      case "leave_type":
        currentData.sortByNullableField(
          getField: (e) => e.leaveType,
          isAscending: currentSort.isAscending,
        );
        break;
      case "from_date":
        currentData.sortByNullableField(
          getField: (e) => e.startDate,
          isAscending: currentSort.isAscending,
        );
        break;
      case "to_date":
        currentData.sortByNullableField(
          getField: (e) => e.endDate,
          isAscending: currentSort.isAscending,
        );
        break;
      case "last_modified_date":
        currentData.sortByNullableField(
          getField: (e) => e.lastModifiedDate,
          isAscending: currentSort.isAscending,
        );
        break;
      default:
        break;
    }

    return currentData;
  }

  Future<void> filter() async {
    var res = await navigationService.navigateToFilterView(
      filters: filterOptions,
      selectedFilters: selectedFilters,
    );

    if (res is List<FilterModel>) {
      selectedFilters = res;
      notifyListeners();
    }
  }

  Future<void> sort() async {
    var res = await navigationService.navigateToSortView(
      initalValue: currentSort,
      sortOptions: sortOptions,
    );

    if (res is SortModel) {
      setSort(res);
    }
  }

  void setSort(SortModel sort) {
    currentSort = sort;
    notifyListeners();
  }

  void goToLeaveDetailsView(Leave item) {
    if (item.appLeaveId.isNotEmptyOrNull) {
      navigationService.navigateToLeaveDetailsView(
        appLeaveId: item.appLeaveId!,
      );
    }
  }

  void goToLeaveAddView() {
    navigationService.navigateToLeaveNewView();
  }

  @override
  Stream<List<Leave>> get stream {
    return _databaseService.watchLeaves();
  }
}
