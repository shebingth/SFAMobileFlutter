import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_colors.dart';
import '../../tools/conditional_widget.dart';
import '../../tools/model_future_builder.dart';
import '../../widgets/app_bar.dart';

import 'components/item.dart';
import 'invoice_line_item_viewmodel.dart';

class InvoiceLineItemView extends StackedView<InvoiceLineItemViewModel> {
  const InvoiceLineItemView({
    super.key,
    required this.appInvoiceId,
  });

  final String appInvoiceId;

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Invoice Line Items",
      ),
      body: SizedBox.expand(
        child: IfNotNull(
          value: viewModel.data,
          replacement: ModelErrorWidget(
            error: viewModel.initialised ? "Something went wrong" : "",
          ),
          builder: (context, invoiceItems) {
            return ListView.separated(
              padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 30.h),
              itemCount: invoiceItems.length,
              itemBuilder: (context, index) {
                final invoiceItem = invoiceItems[index];

                return InvoiceLineItemWidget(
                  invoiceItem: invoiceItem,
                );
              },
              separatorBuilder: (context, index) {
                return const Divider(
                  color: Palette.divider,
                  height: 40,
                  thickness: 1,
                );
              },
            );
          },
        ),
      ),
    );
  }

  @override
  InvoiceLineItemViewModel viewModelBuilder(BuildContext context) {
    return InvoiceLineItemViewModel(
      appInvoiceId: appInvoiceId,
    );
  }
}
