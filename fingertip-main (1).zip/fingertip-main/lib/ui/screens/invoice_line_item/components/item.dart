import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../database/database.dart';
import '../../../../extensions/double.dart';
import '../../../common/app_colors.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/custom_text.dart';
import '../../last_orders/components/order_item.dart';

class InvoiceLineItemWidget extends StatelessWidget {
  const InvoiceLineItemWidget({
    super.key,
    required this.invoiceItem,
  });

  final InvoiceItem invoiceItem;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomText(
          invoiceItem.productName,
          style: TextStyle(
            color: Palette.text08,
            fontSize: 15.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        verticalSpace(14.h),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: OrderLabelValueWidget(
                label: "Quantity",
                value: invoiceItem.quantity?.toString() ?? "",
              ),
            ),
            horizontalSpace(20.w),
            Expanded(
              child: OrderLabelValueWidget(
                label: "Rate",
                value: invoiceItem.unitPrice?.toPrice ?? "",
              ),
            ),
          ],
        ),
        verticalSpace(22.h),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: OrderLabelValueWidget(
                label: "Tax",
                value: invoiceItem.taxAmount?.toPrice ?? "",
              ),
            ),
            horizontalSpace(20.w),
            Expanded(
              child: OrderLabelValueWidget(
                label: "Total",
                value: invoiceItem.totalAmount?.toPrice ?? "",
              ),
            ),
          ],
        )
      ],
    );
  }
}
