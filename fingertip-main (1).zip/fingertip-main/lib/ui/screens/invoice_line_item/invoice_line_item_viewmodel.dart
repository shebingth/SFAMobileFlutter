import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../database/database.dart';

class InvoiceLineItemViewModel extends StreamViewModel<List<InvoiceItem>?> {
  InvoiceLineItemViewModel({
    required this.appInvoiceId,
  });

  final String appInvoiceId;
  final _databaseService = locator<DatabaseService>();

  @override
  Stream<List<InvoiceItem>?> get stream {
    return _databaseService.watchInvoiceItemsByInvoiceId(appInvoiceId);
  }
}
