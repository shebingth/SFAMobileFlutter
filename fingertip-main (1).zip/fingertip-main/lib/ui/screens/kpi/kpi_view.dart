import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../tools/model_future_builder.dart';
import '../../tools/separated_list.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/custom_back_button.dart';

import 'components/header.dart';
import 'components/section.dart';
import 'kpi_viewmodel.dart';

class KpiView extends StackedView<KpiViewModel> {
  const KpiView({super.key});

  @override
  void onViewModelReady(KpiViewModel viewModel) {
    viewModel.init();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        leading: CustomBackButton(
          color: Colors.black,
          forceVisible: true,
        ),
        titleText: "KPI Dashboard",
      ),
      body: SizedBox.expand(
        child: ModelFutureBuilder(
          busy: viewModel.isBusy,
          data: viewModel.data,
          builder: (context, data, child) {
            return SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(15.w, 25.h, 15.w, 30.h),
              child: Column(
                children: [
                  KpiHeaderWidget(data: data),
                  SeparatedWidgetList(
                    list: data.sections,
                    builder: (section, index) {
                      return KpiSectionWidget(
                        section: section,
                      );
                    },
                    separation: 20.h,
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  KpiViewModel viewModelBuilder(BuildContext context) {
    return KpiViewModel();
  }
}
