import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../models/home.dart';
import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../tools/conditional_widget.dart';
import '../../../tools/separated_list.dart';
import '../../../widgets/custom_text.dart';

class KpiSectionWidget extends StatelessWidget {
  const KpiSectionWidget({
    super.key,
    required this.section,
  });

  final KpiSectionModel section;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Palette.scaffoldBackground,
        borderRadius: BorderRadius.circular(10),
        boxShadow: const [
          BoxShadow(
            color: Palette.shadow1A,
            offset: Offset(0, 0),
            blurRadius: 14,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.fromLTRB(20.w, 20.h, 20.w, 12.h),
            child: Row(
              children: [
                Assets.images.scale.image(),
                horizontalSpace(13.w),
                Expanded(
                  child: CustomText(
                    section.sectionheader,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: Palette.text,
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
          IfNotNull(
            value: section.columnHeaders,
            condition: (value) => value.isNotEmpty,
            builder: (context, value) {
              return Container(
                width: double.infinity,
                color: Palette.greyF5,
                padding: EdgeInsets.fromLTRB(20.w, 8.h, 20.w, 8.h),
                child: SeparatedWidgetList(
                  direction: Axis.horizontal,
                  list: section.columnHeaders,
                  builder: (header, index) {
                    return Expanded(
                      child: CustomText(
                        header,
                        style: TextStyle(
                          color: Palette.text58,
                          fontSize: 15.sp,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    );
                  },
                  separation: 10.w,
                ),
              );
            },
          ),
          SeparatedWidgetList(
            list: section.rows,
            builder: (row, index) {
              return KpiRowWidget(row: row);
            },
            separationBuilder: (index) {
              return Container(
                width: double.infinity,
                height: 1,
                margin: EdgeInsets.symmetric(horizontal: 20.w),
                color: Palette.greyEF,
              );
            },
          ),
          verticalSpace(20.h),
        ],
      ),
    );
  }
}

class KpiRowWidget extends StatelessWidget {
  const KpiRowWidget({
    super.key,
    required this.row,
  });

  final KpiRowModel row;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(20.w, 12.h, 20.w, 12.h),
      child: Row(
        children: [
          IfNotNull(
            value: row.rowName,
            condition: (value) => value.isNotEmpty,
            builder: (context, rowName) => Expanded(
              child: CustomText(
                rowName,
                style: TextStyle(
                  color: Palette.text,
                  fontSize: 15.sp,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
          horizontalSpace(10.w),
          IfNotNull(
            value: row.targetValue,
            condition: (value) => value.isNotEmpty,
            builder: (context, targetValue) => Expanded(
              child: CustomText.rich(
                TextSpan(
                  children: [
                    WidgetSpan(
                      child: Container(
                        margin: EdgeInsets.only(bottom: 1.5.h, right: 5.w),
                        child: Assets.images.target.image(),
                      ),
                    ),
                    TextSpan(text: targetValue),
                  ],
                ),
                style: TextStyle(
                  color: Palette.text,
                  fontSize: 15.sp,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
          horizontalSpace(10.w),
          IfNotNull(
            value: row.actualvalue,
            condition: (value) => value.isNotEmpty,
            builder: (context, actualvalue) => Expanded(
              child: CustomText.rich(
                TextSpan(
                  children: [
                    WidgetSpan(
                      child: Container(
                        margin: EdgeInsets.only(bottom: 1.5.h, right: 5.w),
                        child: Assets.images.trophy.image(),
                      ),
                    ),
                    TextSpan(text: actualvalue),
                  ],
                ),
                style: TextStyle(
                  color: Palette.text,
                  fontSize: 15.sp,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
