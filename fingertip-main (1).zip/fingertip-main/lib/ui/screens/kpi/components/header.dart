import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../extensions/list.dart';
import '../../../../models/home.dart';
import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../tools/separated_list.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/network_image.dart';

class KpiHeaderWidget extends StatelessWidget {
  const KpiHeaderWidget({
    super.key,
    required this.data,
  });

  final KpiModel data;

  @override
  Widget build(BuildContext context) {
    if (data.names.isEmptyOrNull) return const SizedBox.shrink();

    return Stack(
      fit: StackFit.passthrough,
      children: [
        Container(
          width: double.infinity,
          margin: EdgeInsets.only(top: 25.h, bottom: 20.h),
          padding: EdgeInsets.fromLTRB(15.w, 40.h, 15.w, 22.h),
          decoration: BoxDecoration(
            color: Palette.scaffoldBackground,
            borderRadius: BorderRadius.circular(10),
            boxShadow: const [
              BoxShadow(
                color: Palette.shadow1A,
                offset: Offset(0, 0),
                blurRadius: 14,
                spreadRadius: 0,
              ),
            ],
          ),
          child: Column(
            children: [
              CustomText(
                data.pageheader,
                style: TextStyle(
                  color: Palette.text,
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
              verticalSpace(11.h),
              SeparatedWidgetList(
                list: data.names,
                builder: (name, index) {
                  return Container(
                    padding: EdgeInsets.only(bottom: 4.h),
                    decoration: const BoxDecoration(
                      border: Border(
                        bottom: BorderSide(color: Palette.orangeLite),
                      ),
                    ),
                    child: CustomText.rich(
                      TextSpan(
                        children: [
                          WidgetSpan(
                            child: Container(
                              margin: EdgeInsets.only(
                                bottom: 1.5.h,
                                right: 5.w,
                              ),
                              child: Assets.images.crown.image(),
                            ),
                          ),
                          TextSpan(text: name),
                        ],
                      ),
                      style: TextStyle(
                        color: Palette.grey3E,
                        fontSize: 20.sp,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  );
                },
                separation: 5.h,
              ),
            ],
          ),
        ),
        Align(
          alignment: Alignment.topCenter,
          child: Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: Colors.black12,
              shape: BoxShape.circle,
              image: decorationImage(
                image: Assets.images.trophyConfetti.path,
                isAsset: true,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
