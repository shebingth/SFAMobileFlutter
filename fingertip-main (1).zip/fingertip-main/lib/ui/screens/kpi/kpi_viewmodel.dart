import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.logger.dart';
import '../../../models/home.dart';
import '../../../models/user.dart';
import '../../../services/json_cache_service.dart';
import '../../../services/user_service.dart';
import '../../tools/parse.dart';

class KpiViewModel extends BaseViewModel {
  final _jsonCacheService = locator<JsonCacheSevice>();
  final _userService = locator<UserService>();
  final logger = getLogger("KpiViewModel");

  KpiModel? data;

  AppUser get user => _userService.user!;

  Future<void> init() async {
    setBusy(true);
    try {
      if (await _jsonCacheService.contains("kpi")) {
        var res = await _jsonCacheService.getJson("kpi");
        if (res != null && res.userId == user.userId) {
          data = parseToObject(res.response, KpiModel.fromJson);
        }
      }
    } catch (e) {
      logger.e(e);
    }
    setBusy(false);
  }
}
