import 'dart:io';

import 'package:flutter/material.dart';

import 'package:file_picker/file_picker.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:stacked/stacked.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../database/database.dart';
import '../../../extensions/date_time.dart';
import '../../../extensions/list.dart';
import '../../../models/basics.dart';
import '../../../models/expense.dart';
import '../../../models/user.dart';
import '../../../services/user_service.dart';
import '../../common/utils.dart';
import '../../tools/smart_dialog_config.dart';

class ExpenseNewViewModel extends BaseViewModel {
  ExpenseNewViewModel({
    this.appExpId,
  }) : isReadOnly = appExpId != null;

  final String? appExpId;
  final bool isReadOnly;
  final formKey = GlobalKey<FormState>();
  final _databaseService = locator<DatabaseService>();
  final _userService = locator<UserService>();
  final picker = ImagePicker();

  ExpenseHelper? data;
  var autovalidateMode = AutovalidateMode.disabled;
  List<ExpenseHelper> expenses = [];

  AppUser? get user => _userService.user;

  Future<void> init() async {
    setBusy(true);

    if (isReadOnly) {
      data = await _databaseService.getExpenseById(appExpId!);
    } else {
      data = ExpenseHelper(
        items: [
          ExpenseItemHelper(
            type: "TA",
          ),
          ExpenseItemHelper(
            type: "DA",
          ),
        ],
      );
    }
    expenses = await _databaseService.getExpenseHelpers();
    setBusy(false);
  }

  Future<void> submit() async {
    if (isReadOnly) return;
    if (formKey.currentState?.validate() == true) {
      formKey.currentState!.save();

      if (data != null) {
        if (expenses.any((e) {
          return e.expenseDate.isDateEqual(date: data!.expenseDate) &&
              e.executiveId == user?.userId;
        })) {
          showToast("You already have an expense for this date");
          return;
        }

        bool status = await runBusyFuture(
          _databaseService.addNewExpense(data: data!, user: user),
          busyObject: formKey,
        );

        if (status) {
          await dialogService.showCustomDialog(
            variant: DialogType.confirm,
            title: "Expense Added",
            description: "Expense added successfully.",
            mainButtonTitle: "Continue",
            secondaryButtonTitle: "Cancel",
          );

          navigationService.back();
        }
      }
    } else {
      setAutovalidateMode(AutovalidateMode.always);
    }
  }

  void addRow() {
    if (data?.items != null) {
      data!.items!.add(ExpenseItemHelper(type: "Other"));
    }
    notifyListeners();
  }

  Future<void> pickFile(ExpenseItemHelper item) async {
    var res = await dialogService.showCustomDialog(
      variant: DialogType.choice,
      data: [
        OptionModel(label: "Take a photo", value: "camera"),
        OptionModel(label: "Pick a document", value: "document"),
      ],
    );

    if (res?.data is String) {
      switch (res!.data) {
        case "camera":
          await pickFromCamera(item, ImageSource.camera);
          break;
        case "document":
          await pickFromDocuments(item);
          break;
      }
    }
  }

  Future<void> pickFromDocuments(ExpenseItemHelper item) async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();

    if (result?.files.isNotEmpty == true) {
      File file = File(result!.files.single.path!);

      item.files ??= [];
      item.files!.add(file);
      notifyListeners();
    }
  }

  Future<void> pickFromCamera(
    ExpenseItemHelper item,
    ImageSource source,
  ) async {
    try {
      var res = await picker.pickImage(source: source);

      if (res != null) {
        final tempDir = await getTemporaryDirectory();
        var file = File(res.path);
        var fileName = file.path.split('/').last;
        var cRes = await compressImageFile(
          file,
          "${tempDir.path}/c_$fileName",
        );

        if (cRes != null) {
          var compressedFile = File(cRes.path);
          item.files ??= [];
          item.files!.add(compressedFile);
          notifyListeners();
        }
      }
    } catch (e) {
      if (e is CompressError) {
        CompressError error = e;
        debugPrint("CompressError: ${error.message}");
      } else {
        debugPrint("Camera Image Pick Error: ${e.toString()}");
      }
    }
  }

  void deleteFile(ExpenseItemHelper item, File file) {
    item.files?.remove(file);
    notifyListeners();
  }

  void setAutovalidateMode(AutovalidateMode mode) {
    autovalidateMode = mode;
    notifyListeners();
  }

  void cancel() => navigationService.back();

  void deleteItem(ExpenseItemHelper item) {
    data?.items?.remove(item);
    notifyListeners();
  }

  bool alreadyExists(String value) {
    if (data?.items?.isNotEmptyOrNull == true) {
      var existing = data!.items!.where((e) {
        return e.type == value;
      }).map((e) {
        return e.type!;
      }).toList();

      return existing.length > 1;
    }
    return false;
  }

  void onTypeChanged(ExpenseItemHelper item, String? value) {
    item.type = value;
    setAutovalidateMode(AutovalidateMode.always);
    notifyListeners();
  }
}
