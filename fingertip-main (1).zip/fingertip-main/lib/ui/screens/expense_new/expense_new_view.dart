import 'package:flutter/material.dart';

import 'package:date_field/date_field.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../extensions/double.dart';
import '../../common/app_colors.dart';
import '../../common/assets.gen.dart';
import '../../common/ui_helpers.dart';
import '../../tools/dismiss_keyboard.dart';
import '../../tools/model_future_builder.dart';
import '../../tools/separated_list.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/button.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/divider.dart';
import '../../widgets/form_fields/date_picker.dart';

import 'components/item.dart';
import 'expense_new_viewmodel.dart';

class ExpenseNewView extends StackedView<ExpenseNewViewModel> {
  const ExpenseNewView({
    super.key,
    this.appExpId,
  });

  final String? appExpId;

  @override
  void onViewModelReady(ExpenseNewViewModel viewModel) {
    viewModel.init();
  }

  @override
  Widget builder(context, viewModel, child) {
    var isReadOnly = viewModel.isReadOnly;
    return Scaffold(
      appBar: CustomAppBar(
        titleText: isReadOnly ? viewModel.data?.expenseName : "Expense Request",
      ),
      body: SizedBox.expand(
        child: DismissKeyboard(
          child: Form(
            key: viewModel.formKey,
            autovalidateMode: viewModel.autovalidateMode,
            child: ModelFutureBuilder(
              busy: viewModel.isBusy,
              data: viewModel.data,
              error: "Something went wrong",
              builder: (context, data, child) {
                return SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: EdgeInsets.fromLTRB(15.w, 25.h, 15.w, 25.h),
                        child: CustomDateFormField(
                          labelText: "Expense Date",
                          mode: DateTimeFieldPickerMode.date,
                          hideOuterLabel: true,
                          canClear: false,
                          initialValue: isReadOnly
                              ? data.expenseDate?.toLocal()
                              : data.expenseDate,
                          enabled: !isReadOnly,
                          firstDate: DateTime(DateTime.now().year - 1),
                          lastDate: DateTime.now(),
                          onChanged: (d) {},
                          onSaved: (newValue) {
                            data.expenseDate = newValue;
                          },
                          validator: (value) {
                            if (value == null) {
                              return "Required";
                            }
                            return null;
                          },
                        ),
                      ),
                      SeparatedWidgetList(
                        list: data.items,
                        headerBuilder: () => const DividerWidget(),
                        footerBuilder: () => const DividerWidget(),
                        builder: (item, index) {
                          return ExpenseItemWidget(
                            item: item,
                            notifyListeners: viewModel.notifyListeners,
                            pickFile: viewModel.pickFile,
                            deleteFile: viewModel.deleteFile,
                            isReadOnly: isReadOnly,
                            canDelete: index > 1,
                            deleteItem: viewModel.deleteItem,
                            alreadyExists: viewModel.alreadyExists,
                            onTypeChanged: viewModel.onTypeChanged,
                          );
                        },
                        separationBuilder: (index) {
                          return const DividerWidget();
                        },
                      ),
                      Visibility(
                        visible: !isReadOnly,
                        child: Container(
                          margin: EdgeInsets.only(top: 25.h, bottom: 30.h),
                          padding: EdgeInsets.symmetric(horizontal: 15.w),
                          child: TextButton(
                            onPressed: viewModel.addRow,
                            style: TextButton.styleFrom(
                              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Assets.images.addCircle.image(),
                                horizontalSpace(10.w),
                                CustomText(
                                  "Add Row",
                                  style: TextStyle(
                                    fontSize: 15.sp,
                                    fontWeight: FontWeight.normal,
                                    color: Palette.text58,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.fromLTRB(15.w, 16.h, 15.w, 10.h),
        decoration: const BoxDecoration(
          color: Palette.scaffoldBackground,
          boxShadow: [
            BoxShadow(
              color: Palette.shadow3,
              blurRadius: 5,
              offset: Offset(0, -2),
              spreadRadius: 2,
            )
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomText(
              "Total Amount: ₹ ${viewModel.data?.totalAmount.removeTrailingZeros}",
              bottom: 17.h,
              style: TextStyle(
                fontSize: 15.sp,
                fontWeight: FontWeight.normal,
                color: Colors.black,
              ),
            ),
            Visibility(
              visible: !isReadOnly,
              child: Row(
                children: [
                  Expanded(
                    child: PrimaryButton(
                      onPressed: viewModel.cancel,
                      label: "Cancel",
                      color: Palette.greyBA,
                    ),
                  ),
                  horizontalSpace(15.w),
                  Expanded(
                    child: PrimaryButton(
                      onPressed: viewModel.submit,
                      isBusy: viewModel.busy(viewModel.formKey),
                      label: "Submit ",
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  ExpenseNewViewModel viewModelBuilder(BuildContext context) {
    return ExpenseNewViewModel(
      appExpId: appExpId,
    );
  }
}
