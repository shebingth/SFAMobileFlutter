import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../extensions/file.dart';
import '../../../../extensions/string.dart';
import '../../../../models/expense.dart';
import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/fonts.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../tools/separated_list.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/form_fields/dropdown_field.dart';
import '../../../widgets/form_fields/text_field.dart';

class ExpenseItemWidget extends StatelessWidget {
  const ExpenseItemWidget({
    super.key,
    required this.item,
    required this.notifyListeners,
    required this.pickFile,
    required this.deleteFile,
    required this.isReadOnly,
    required this.canDelete,
    required this.deleteItem,
    required this.alreadyExists,
    required this.onTypeChanged,
  });

  final ExpenseItemHelper item;
  final VoidCallback notifyListeners;
  final void Function(ExpenseItemHelper item) pickFile;
  final void Function(ExpenseItemHelper item, File file) deleteFile;
  final bool isReadOnly;
  final bool canDelete;
  final void Function(ExpenseItemHelper item) deleteItem;
  final bool Function(String value) alreadyExists;
  final void Function(ExpenseItemHelper item, String? value) onTypeChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(15.w, 10.h, 15.w, 25.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            alignment: Alignment.centerRight,
            margin: EdgeInsets.only(bottom: 10.h),
            child: Visibility(
              visible: !isReadOnly && canDelete,
              replacement: verticalSpace(20.h),
              child: IconButton(
                onPressed: () => deleteItem(item),
                icon: Assets.images.trash.image(),
                visualDensity: VisualDensity.compact,
                splashRadius: kToolbarHeight / 2,
              ),
            ),
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: CustomDropdownFormField(
                  labelText: "Type",
                  hideOuterLabel: true,
                  value: item.type,
                  enabled: !isReadOnly,
                  items: const ["TA", "DA", "Other"],
                  itemAsString: (item) => item,
                  onChanged: (v) {
                    onTypeChanged(item, v);
                  },
                  onSaved: (newValue) {
                    item.type = newValue;
                  },
                  validator: (value) {
                    if (value.isEmptyOrNull) {
                      return "Required";
                    }
                    if (value != "Other") {
                      if (alreadyExists(value!)) {
                        return "Type already exists";
                      }
                    }
                    return null;
                  },
                ),
              ),
              horizontalSpace(15.w),
              Expanded(
                child: CustomTextFormField(
                  labelText: "Amount",
                  enabled: !isReadOnly,
                  initialValue: item.amount,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                    signed: false,
                  ),
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(
                      RegExp(r'^\d*\.?\d*$'),
                    ),
                  ],
                  hasPrefixTestSeparator: false,
                  prefixText: "₹",
                  onChanged: (newValue) {
                    item.amount = newValue;
                    notifyListeners();
                  },
                  onSaved: (newValue) {
                    item.amount = newValue;
                  },
                  validator: (value) {
                    if (value.isEmptyOrNull) {
                      return 'Required';
                    }
                    return null;
                  },
                ),
              ),
            ],
          ),
          CustomTextFormField(
            top: 20.h,
            labelText: "Description",
            enabled: !isReadOnly,
            initialValue: item.description,
            maxLines: 4,
            onSaved: (newValue) {
              item.description = newValue;
            },
            validator: (value) {
              return null;
            },
          ),
          verticalSpace(20.h),
          Visibility(
            visible: !isReadOnly,
            child: TextButton(
              onPressed: () => pickFile(item),
              style: TextButton.styleFrom(
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Assets.images.documentUploadBlue.image(),
                  horizontalSpace(10.w),
                  CustomText(
                    "Upload Files",
                    style: TextStyle(
                      fontSize: 15.sp,
                      fontWeight: FontWeight.normal,
                      color: Palette.text58,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Visibility(
            visible: !isReadOnly,
            child: verticalSpace(20.h),
          ),
          SeparatedWidgetList(
            list: item.files,
            builder: (file, index) {
              return Row(
                children: [
                  Expanded(
                    child: RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(text: file.fileName),
                          const TextSpan(text: "  "),
                          TextSpan(
                            text: "(${file.formatedSize})",
                            style: TextStyle(
                              color: Palette.text7F,
                              fontSize: 13.sp,
                            ),
                          ),
                        ],
                        style: TextStyle(
                          color: Palette.text08,
                          fontSize: 14.sp,
                          fontFamily: FontFamily.lato,
                        ),
                      ),
                    ),
                  ),
                  horizontalSpace(10.w),
                  Visibility(
                    visible: !isReadOnly,
                    child: IconButton(
                      onPressed: () => deleteFile(item, file),
                      color: Palette.error,
                      icon: const Icon(Icons.delete),
                      splashRadius: kToolbarHeight / 2,
                    ),
                  ),
                ],
              );
            },
            separation: isReadOnly ? 20 : 0,
          ),
        ],
      ),
    );
  }
}
