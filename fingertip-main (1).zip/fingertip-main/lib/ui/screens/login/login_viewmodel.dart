import 'package:flutter/material.dart';

import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../extensions/string.dart';
import '../../../services/api_service.dart';
import '../../common/utils.dart';

class LoginViewModel extends BaseViewModel {
  final formKey = GlobalKey<FormState>();
  final _apiService = locator<ApiService>();

  var autovalidateMode = AutovalidateMode.disabled;
  String? userName;
  String? password;

  Future<void> login() async {
    if (formKey.currentState!.validate()) {
      formKey.currentState!.save();

      if (userName.isNotEmptyOrNull && password.isNotEmptyOrNull) {
        bool? status = await runBusyFuture(
          _apiService.login(userName: userName!, password: password!),
        );

        if (status == true) {
          navigationService.clearStackAndShow(
            Routes.fetchView,
            arguments: const FetchViewArguments(
              clearData: true,
            ),
          );
        }
      }
    } else {
      setAutovalidateMode(AutovalidateMode.always);
    }
  }

  void forgotPassword() {
    navigationService.navigateToForgotPasswordView(userName: userName);
  }

  void setAutovalidateMode(AutovalidateMode mode) {
    autovalidateMode = mode;
    notifyListeners();
  }
}
