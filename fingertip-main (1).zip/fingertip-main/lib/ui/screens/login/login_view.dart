import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_colors.dart';
import '../../common/assets.gen.dart';
import '../../common/fonts.gen.dart';
import '../../common/ui_helpers.dart';
import '../../tools/dismiss_keyboard.dart';
import '../../tools/screen_size.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/button.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/form_fields/text_field.dart';

import 'login_viewmodel.dart';

class LoginView extends StackedView<LoginViewModel> {
  const LoginView({super.key});

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        child: SizedBox(
          width: double.infinity,
          height: ScreenSize.height - kTextTabBarHeight - 30.h,
          child: DismissKeyboard(
            child: Form(
              key: viewModel.formKey,
              autovalidateMode: viewModel.autovalidateMode,
              child: Column(
                children: [
                  verticalSpace(26.h),
                  Assets.images.logoHeader2.image(),
                  verticalSpace(30.h),
                  SizedBox(
                    width: double.infinity,
                    child: CustomText(
                      'Login Now',
                      style: TextStyle(
                        color: Palette.text08,
                        fontSize: 24.sp,
                        fontFamily: FontFamily.manrope,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  CustomTextFormField(
                    top: 20.h,
                    fillColor: Palette.greyF4,
                    borderColor: Palette.greyF4,
                    labelText: "User name",
                    fontFamily: FontFamily.manrope,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Required";
                      }
                      return null;
                    },
                    onSaved: (newValue) {
                      viewModel.userName = newValue;
                    },
                  ),
                  CustomTextFormField(
                    top: 20.h,
                    fillColor: Palette.greyF4,
                    borderColor: Palette.greyF4,
                    labelText: "Password",
                    fontFamily: FontFamily.manrope,
                    isPassword: true,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Required";
                      }
                      return null;
                    },
                    onSaved: (newValue) {
                      viewModel.password = newValue;
                    },
                  ),
                  verticalSpace(10.h),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: viewModel.forgotPassword,
                      child: CustomText(
                        "Forgot Password?",
                        style: TextStyle(
                          fontSize: 15.sp,
                          color: Palette.text7F,
                        ),
                      ),
                    ),
                  ),
                  const Spacer(),
                  PrimaryButton(
                    onPressed: viewModel.login,
                    isBusy: viewModel.isBusy,
                    label: "Login",
                    isExpanded: true,
                  ),
                  verticalSpace(42.h),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  LoginViewModel viewModelBuilder(context) {
    return LoginViewModel();
  }
}
