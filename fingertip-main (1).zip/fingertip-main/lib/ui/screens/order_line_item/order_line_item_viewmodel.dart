import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../database/database.dart';

class OrderLineItemViewModel extends StreamViewModel<List<OrderItem>?> {
  OrderLineItemViewModel({
    required this.appOrderId,
  });

  final String appOrderId;
  final _databaseService = locator<DatabaseService>();

  @override
  Stream<List<OrderItem>?> get stream {
    return _databaseService.watchOrderItemsByAppOrderId(appOrderId);
  }
}
