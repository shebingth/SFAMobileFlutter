import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_colors.dart';
import '../../tools/conditional_widget.dart';
import '../../tools/model_future_builder.dart';
import '../../widgets/app_bar.dart';
import '../last_orders/components/order_item.dart';

import 'order_line_item_viewmodel.dart';

class OrderLineItemView extends StackedView<OrderLineItemViewModel> {
  const OrderLineItemView({
    super.key,
    required this.appOrderId,
  });

  final String appOrderId;

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Order Line Items",
      ),
      body: SizedBox.expand(
        child: IfNotNull(
          value: viewModel.data,
          replacement: ModelErrorWidget(
            error: viewModel.initialised ? "Something went wrong" : "",
          ),
          builder: (context, orderItems) {
            return ListView.separated(
              padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 30.h),
              itemCount: orderItems.length,
              itemBuilder: (context, index) {
                final orderItem = orderItems[index];

                return OrderLineItemWidget(
                  orderItem: orderItem,
                );
              },
              separatorBuilder: (context, index) {
                return const Divider(
                  color: Palette.divider,
                  height: 40,
                  thickness: 1,
                );
              },
            );
          },
        ),
      ),
    );
  }

  @override
  OrderLineItemViewModel viewModelBuilder(BuildContext context) {
    return OrderLineItemViewModel(
      appOrderId: appOrderId,
    );
  }
}
