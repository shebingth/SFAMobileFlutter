import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../models/sort.dart';
import '../../common/app_colors.dart';
import '../../common/ui_helpers.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/button.dart';
import '../../widgets/custom_text.dart';

import 'sort_viewmodel.dart';

class SortView extends StackedView<SortViewModel> {
  const SortView({
    super.key,
    required this.initalValue,
    required this.sortOptions,
  });

  final SortModel initalValue;
  final List<SortModel> sortOptions;

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Sort",
      ),
      body: SizedBox.expand(
        child: ListView.separated(
          padding: EdgeInsets.fromLTRB(15.w, 5.h, 15.w, 30.h),
          itemBuilder: (context, index) {
            final item = viewModel.sortOptions[index];

            return SortWidget(
              item: item,
              selectedSort: viewModel.selectedSort,
              onTap: viewModel.setSort,
            );
          },
          separatorBuilder: (context, index) {
            return Container(
              width: double.infinity,
              height: 1,
              color: Palette.divider,
            );
          },
          itemCount: viewModel.sortOptions.length,
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
        decoration: const BoxDecoration(
          color: Palette.scaffoldBackground,
          boxShadow: [
            BoxShadow(
              color: Palette.shadow3,
              blurRadius: 5,
              offset: Offset(0, -2),
              spreadRadius: 2,
            )
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.cancel,
                label: "Cancel",
                color: Palette.greyBA,
              ),
            ),
            horizontalSpace(15.w),
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.apply,
                label: "Apply",
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  SortViewModel viewModelBuilder(BuildContext context) {
    return SortViewModel(
      initalValue: initalValue,
      sortOptions: sortOptions,
    );
  }
}

class SortWidget extends StatelessWidget {
  const SortWidget({
    super.key,
    required this.item,
    required this.onTap,
    required this.selectedSort,
  });

  final SortModel item;
  final void Function(SortModel item) onTap;
  final SortModel selectedSort;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onTap(item),
      behavior: HitTestBehavior.translucent,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(vertical: 15.h),
        child: Row(
          children: [
            Expanded(
              child: CustomText(
                item.label,
                style: TextStyle(
                  fontSize: 15.sp,
                  fontWeight: item.type == selectedSort.type
                      ? FontWeight.bold
                      : FontWeight.normal,
                  color: Palette.text,
                ),
              ),
            ),
            Opacity(
              opacity: item.type == selectedSort.type ? 1 : 0,
              child: Container(
                padding: EdgeInsets.fromLTRB(10.w, 6.h, 15.w, 6.h),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: Palette.green1,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      item.isAscending
                          ? CupertinoIcons.arrow_up
                          : CupertinoIcons.arrow_down,
                      color: Colors.white,
                      size: 16,
                    ),
                    horizontalSpace(5.w),
                    CustomText(
                      item.isAscending ? "Ascending" : "Descending",
                      bottom: 1,
                      style: TextStyle(
                        fontSize: 15.sp,
                        fontWeight: FontWeight.normal,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
