import 'package:stacked/stacked.dart';

import '../../../models/sort.dart';
import '../../common/utils.dart';

class SortViewModel extends BaseViewModel {
  SortViewModel({
    required SortModel initalValue,
    required this.sortOptions,
  }) : selectedSort = initalValue;

  final List<SortModel> sortOptions;

  SortModel selectedSort;

  void setSort(SortModel value) {
    if (value.type != selectedSort.type) {
      selectedSort = value;
    } else {
      selectedSort.isAscending = !selectedSort.isAscending;
    }
    notifyListeners();
  }

  void cancel() {
    navigationService.back();
  }

  void apply() {
    navigationService.back(result: selectedSort);
  }
}
