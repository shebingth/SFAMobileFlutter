import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../database/database.dart';
import '../../../extensions/string.dart';
import '../../../models/stock.dart';
import '../../common/app_colors.dart';
import '../../common/assets.gen.dart';
import '../../common/ui_helpers.dart';
import '../../tools/dismiss_keyboard.dart';
import '../../tools/model_future_builder.dart';
import '../../tools/parse.dart';
import '../../tools/separated_list.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/button.dart';
import '../../widgets/divider.dart';
import '../../widgets/form_fields/dropdown_field.dart';
import '../../widgets/form_fields/text_field.dart';

import 'components/footer.dart';
import 'stock_viewmodel.dart';

class StockView extends StackedView<StockViewModel> {
  const StockView({
    super.key,
    required this.visitMap,
  });

  final Map<String, dynamic> visitMap;

  @override
  void onViewModelReady(StockViewModel viewModel) {
    viewModel.init();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Stock",
      ),
      body: SizedBox.expand(
        child: DismissKeyboard(
          child: Form(
            key: viewModel.formKey,
            autovalidateMode: viewModel.autovalidateMode,
            child: ModelFutureListBuilder(
              busy: viewModel.isBusy,
              data: viewModel.products,
              builder: (context, products, child) {
                return SingleChildScrollView(
                  child: SeparatedWidgetList(
                    list: viewModel.data,
                    builder: (item, index) {
                      return StockItemWidget(
                        key: item.widgetKey,
                        item: item,
                        products: products,
                        deleteItem: viewModel.deleteItem,
                      );
                    },
                    footerBuilder: () {
                      return const StockFooterWidget();
                    },
                    separationBuilder: (index) {
                      return const DividerWidget();
                    },
                  ),
                );
              },
            ),
          ),
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
        decoration: const BoxDecoration(
          color: Palette.scaffoldBackground,
          boxShadow: [
            BoxShadow(
              color: Palette.shadow3,
              blurRadius: 5,
              offset: Offset(0, -2),
              spreadRadius: 2,
            )
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.cancel,
                label: "Cancel",
                color: Palette.greyBA,
              ),
            ),
            horizontalSpace(15.w),
            Expanded(
              child: PrimaryButton(
                onPressed: viewModel.submit,
                isBusy: viewModel.busy(viewModel.formKey),
                label: "Save",
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  StockViewModel viewModelBuilder(BuildContext context) {
    return StockViewModel(
      visit: Visit.fromJson(visitMap),
    );
  }
}

class StockItemWidget extends StatelessWidget {
  const StockItemWidget({
    super.key,
    required this.item,
    required this.products,
    required this.deleteItem,
  });

  final StockHelper item;
  final List<Product> products;
  final void Function(StockHelper item) deleteItem;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(15.w, 10.h, 15.w, 25.h),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            alignment: Alignment.centerRight,
            margin: EdgeInsets.only(bottom: 10.h),
            child: IconButton(
              onPressed: () => deleteItem(item),
              icon: Assets.images.trash.image(),
              visualDensity: VisualDensity.compact,
              splashRadius: kToolbarHeight / 2,
            ),
          ),
          CustomDropdownSearchFormField(
            labelText: "Add Product",
            items: products,
            itemAsString: (item) => item.name,
            compareFn: (v1, v2) => v1 == v2,
            onChanged: (value) {},
            onSaved: (newValue) {
              item.productId = newValue?.id;
              item.productName = newValue?.name;
              item.unitPrice = newValue?.unitPrice;
              item.productCategory = newValue?.category;
            },
            validator: (value) {
              if (value == null) {
                return "Required";
              }
              return null;
            },
          ),
          CustomTextFormField(
            top: 20.h,
            labelText: "Quantity",
            keyboardType: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
            ],
            hasPrefixTestSeparator: false,
            onSaved: (newValue) {
              var value = parseToInt(newValue);
              item.quantity = value;
            },
            validator: (value) {
              if (value.isEmptyOrNull) {
                return 'Required';
              }
              return null;
            },
          ),
        ],
      ),
    );
  }
}
