import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/divider.dart';
import '../stock_viewmodel.dart';

class StockFooterWidget extends ViewModelWidget<StockViewModel> {
  const StockFooterWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, StockViewModel viewModel) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const DividerWidget(),
        verticalSpace(25.h),
        Container(
          width: double.infinity,
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 15.w),
          child: TextButton(
            onPressed: viewModel.addAnotherProduct,
            style: TextButton.styleFrom(
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Assets.images.addCircle.image(),
                horizontalSpace(10.w),
                CustomText(
                  "Add Another Product",
                  style: TextStyle(
                    fontSize: 15.sp,
                    fontWeight: FontWeight.normal,
                    color: Palette.text58,
                  ),
                ),
              ],
            ),
          ),
        ),
        verticalSpace(30.h),
      ],
    );
  }
}
