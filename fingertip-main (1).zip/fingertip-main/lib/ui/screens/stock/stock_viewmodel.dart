import 'package:flutter/material.dart';

import 'package:stacked/stacked.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../database/database.dart';
import '../../../models/stock.dart';
import '../../common/utils.dart';

class StockViewModel extends BaseViewModel {
  StockViewModel({
    required this.visit,
  });

  final Visit visit;
  final _databaseService = locator<DatabaseService>();
  final formKey = GlobalKey<FormState>();

  List<Product> products = [];
  List<StockHelper> data = [];
  var autovalidateMode = AutovalidateMode.disabled;

  Future<void> init() async {
    setBusy(true);
    try {
      data = [StockHelper.fromVisit(visit)];
      products = await _databaseService.getProducts();
    } catch (e) {
      setError(e);
    }
    setBusy(false);
  }

  Future<void> submit() async {
    if (formKey.currentState?.validate() ?? false) {
      formKey.currentState!.save();

      bool status = await runBusyFuture(
        _databaseService.addNewStocks(datas: data),
        busyObject: formKey,
      );

      if (status) {
        await dialogService.showCustomDialog(
          variant: DialogType.confirm,
          title: "Stocks Added",
          description: "New Stocks added\nsuccessfully.",
          mainButtonTitle: "Continue",
          secondaryButtonTitle: "Cancel",
        );

        navigationService.back();
      }
    } else {
      setAutovalidateMode(AutovalidateMode.always);
    }
  }

  void setAutovalidateMode(AutovalidateMode mode) {
    autovalidateMode = mode;
    notifyListeners();
  }

  void addAnotherProduct() {
    data.add(StockHelper.fromVisit(visit));
    notifyListeners();
  }

  void cancel() {
    navigationService.back();
  }

  void deleteItem(StockHelper item) {
    data.remove(item);

    if (data.isEmpty) {
      data.add(StockHelper.fromVisit(visit));
    }
    notifyListeners();
  }
}
