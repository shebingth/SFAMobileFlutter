import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_colors.dart';
import '../../common/app_constants.dart';
import '../../tools/model_future_builder.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/button.dart';
import '../../widgets/form_fields/date_picker.dart';
import '../../widgets/form_fields/dropdown_field.dart';

import 'add_visit_viewmodel.dart';

class AddVisitView extends StackedView<AddVisitViewModel> {
  const AddVisitView({super.key});

  @override
  void onViewModelReady(AddVisitViewModel viewModel) {
    viewModel.init();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "New Visit",
      ),
      body: SizedBox.expand(
        child: ModelFutureListBuilder(
          data: viewModel.accounts,
          busy: viewModel.isBusy,
          error: viewModel.modelError?.toString(),
          builder: (context, accounts, child) {
            return SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 30.h),
              child: Form(
                key: viewModel.formKey,
                autovalidateMode: viewModel.autovalidateMode,
                child: Column(
                  children: [
                    CustomDropdownSearchFormField(
                      labelText: "Customer Name",
                      value: viewModel.account,
                      items: accounts,
                      itemAsString: (item) => item.name ?? "",
                      compareFn: (item1, item2) => item1.id == item2.id,
                      onChanged: (value) {
                        viewModel.account = value;
                      },
                      onSaved: (newValue) {
                        viewModel.account = newValue;
                      },
                      validator: (value) {
                        if (value == null) {
                          return "Required";
                        }
                        return null;
                      },
                    ),
                    CustomDateFormField(
                      top: 15.h,
                      labelText: "Selected date",
                      hideOuterLabel: true,
                      initialValue: viewModel.date,
                      firstDate: viewModel.firstDate,
                      lastDate: DateTime(DateTime.now().year + 1),
                      onSaved: (newValue) {
                        if (newValue != null) {
                          viewModel.date = newValue;
                        }
                      },
                      validator: (value) {
                        if (value == null) {
                          return "Required";
                        }
                        if (value.isBefore(DateTime.now())) {
                          return "Please don't select past time";
                        }
                        return null;
                      },
                      onChanged: (value) {
                        if (value != null) {
                          viewModel.date = value;
                        }
                      },
                    ),
                    CustomDropdownFormField(
                      top: 15.h,
                      labelText: "Visit Type",
                      hideOuterLabel: true,
                      value: viewModel.visitType,
                      items: VisitType.values,
                      itemAsString: (item) => item,
                      onChanged: (value) {
                        viewModel.visitType = value;
                      },
                      onSaved: (newValue) {
                        viewModel.visitType = newValue;
                      },
                      validator: (value) {
                        if (value == null) {
                          return "Required";
                        }
                        return null;
                      },
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
        decoration: const BoxDecoration(
          color: Palette.scaffoldBackground,
          boxShadow: [
            BoxShadow(
              color: Palette.shadow3,
              blurRadius: 5,
              offset: Offset(0, -2),
              spreadRadius: 2,
            )
          ],
        ),
        child: PrimaryButton(
          onPressed: viewModel.addVisit,
          isBusy: viewModel.busy(viewModel.formKey),
          label: "Add",
        ),
      ),
    );
  }

  @override
  AddVisitViewModel viewModelBuilder(context) {
    return AddVisitViewModel();
  }
}
