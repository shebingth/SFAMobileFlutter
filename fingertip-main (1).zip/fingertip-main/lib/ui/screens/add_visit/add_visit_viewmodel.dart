import 'package:flutter/material.dart';

import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../database/database.dart';
import '../../common/app_constants.dart';
import '../../common/utils.dart';
import '../../tools/smart_dialog_config.dart';

class AddVisitViewModel extends StreamViewModel<DayLog?> {
  final _databaseService = locator<DatabaseService>();
  final formKey = GlobalKey<FormState>();

  List<Account> accounts = [];
  var autovalidateMode = AutovalidateMode.disabled;

  Account? account;
  DateTime? date;
  String? visitType;
  List<Visit> visits = [];

  bool get hasEnded {
    if (data?.dayEndTime != null) {
      return true;
    }
    return false;
  }

  DateTime get firstDate {
    var now = DateTime.now();
    if (hasEnded) {
      return DateTime(now.year, now.month, now.day + 1);
    }
    return now;
  }

  Future<void> addVisit() async {
    if (formKey.currentState!.validate()) {
      formKey.currentState!.save();

      if (account != null && date != null && visitType != null) {
        /* 
        var length = visits.where((element) {
          return element.accountId == account!.id;
        }).length;

        if (length >= 2) {
          await dialogService.showCustomDialog(
            variant: DialogType.info,
            title: "New Visit",
            description:
                "You already have 2 visits added to ${account!.name} for today. You can't add any more visits for today.",
            mainButtonTitle: "Cancel",
          );

          return;
        } else if (length == 1) {
          var res = await dialogService.showCustomDialog(
            variant: DialogType.confirm,
            title: "New Visit",
            description:
                "You already have a visit added to ${account!.name} for today. Are you sure you want to add another one?",
            mainButtonTitle: "Yes",
            secondaryButtonTitle: "No",
          );

          if (res?.confirmed != true) {
            return;
          }
        } 
        */

        bool status = await runBusyFuture(
          _databaseService.addNewVisit(
            account: account!,
            date: date!,
            visitType: visitType!,
          ),
          busyObject: formKey,
        );

        if (status) {
          showToast("Visit added successfully", type: ToastType.success);
          navigationService.back();
        }
      }
    } else {
      setAutovalidateMode(AutovalidateMode.always);
    }
  }

  void setAutovalidateMode(AutovalidateMode mode) {
    autovalidateMode = mode;
    notifyListeners();
  }

  Future<void> init() async {
    accounts = await runBusyFuture(
      _databaseService.getAprovedAccounts(),
    );

    visits = await _databaseService.getTodaysVisits();
  }

  @override
  Stream<DayLog?> get stream => _databaseService.watchCurrentDayLog();
}
