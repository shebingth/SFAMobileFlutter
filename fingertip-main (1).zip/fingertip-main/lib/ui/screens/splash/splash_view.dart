import 'package:flutter/material.dart';

import 'package:entry/entry.dart';
import 'package:stacked/stacked.dart';

import '../../common/assets.gen.dart';
import '../../tools/screen_size.dart';
import '../../widgets/app_bar.dart';

import 'splash_viewmodel.dart';

class SplashView extends StackedView<SplashViewModel> {
  const SplashView({super.key});

  @override
  void onViewModelReady(SplashViewModel viewModel) {
    viewModel.initialize();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const EmptyAppBar(),
      extendBodyBehindAppBar: true,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        alignment: Alignment.center,
        child: Entry.scale(
          duration: const Duration(seconds: 1),
          curve: Curves.easeInOut,
          child: Assets.images.logo.image(
            width: ScreenSize.width * 0.5,
          ),
        ),
      ),
    );
  }

  @override
  SplashViewModel viewModelBuilder(context) {
    return SplashViewModel();
  }
}
