import 'dart:async';

import 'package:flutter/material.dart';

import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../models/user.dart';
import '../../../services/upload_service.dart';
import '../../../services/user_service.dart';
import '../../common/utils.dart';

class SplashViewModel extends BaseViewModel {
  final _userService = locator<UserService>();
  final _uploadService = locator<UploadService>();

  Timer? _timer;

  Future<void> initialize() async {
    try {
      AppUser? user = await _userService.loadCredential();
      bool hasUser = user?.hasUser ?? false;

      _timer = Timer(const Duration(seconds: 3), () async {
        if (hasUser) {
          _uploadService.registerStreams();
          navigationService.clearStackAndShow(Routes.dashboardView);
        } else {
          navigationService.clearStackAndShow(Routes.loginView);
        }
      });
    } catch (e) {
      debugPrint("$e");
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
