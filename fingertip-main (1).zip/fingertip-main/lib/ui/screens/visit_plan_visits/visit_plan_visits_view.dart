import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:stacked/stacked.dart';

import '../../common/app_colors.dart';
import '../../tools/conditional_widget.dart';
import '../../tools/model_future_builder.dart';
import '../../widgets/app_bar.dart';

import 'components/item.dart';
import 'visit_plan_visits_viewmodel.dart';

class VisitPlanVisitsView extends StackedView<VisitPlanVisitsViewModel> {
  const VisitPlanVisitsView({
    super.key,
    required this.appVisitPlanId,
    required this.date,
  });

  final String appVisitPlanId;
  final DateTime date;

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: CustomAppBar(
        titleText: DateFormat("MMM d, yyyy").format(viewModel.date),
      ),
      body: SizedBox.expand(
        child: IfNotNull(
          value: viewModel.data,
          condition: (value) => value.isNotEmpty,
          builder: (context, visits) {
            return ListView.separated(
              padding: EdgeInsets.only(bottom: 30.h),
              itemCount: visits.length,
              itemBuilder: (context, index) {
                final visit = visits[index];

                return VisitPlanVisitsItem(
                  visit: visit,
                  onDelete: viewModel.deleteVisit,
                );
              },
              separatorBuilder: (context, index) {
                return Container(
                  width: double.infinity,
                  height: 6,
                  color: Palette.greyF5,
                );
              },
            );
          },
          replacement: const ModelErrorWidget(
            error: "No visits found for this visit plan",
          ),
        ),
      ),
    );
  }

  @override
  VisitPlanVisitsViewModel viewModelBuilder(BuildContext context) {
    return VisitPlanVisitsViewModel(
      appVisitPlanId: appVisitPlanId,
      date: date,
    );
  }
}
