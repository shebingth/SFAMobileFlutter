import 'package:flutter_smart_dialog/flutter_smart_dialog.dart';
import 'package:stacked/stacked.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../database/database.dart';
import '../../common/utils.dart';

class VisitPlanVisitsViewModel extends StreamViewModel<List<Visit>> {
  VisitPlanVisitsViewModel({
    required this.appVisitPlanId,
    required this.date,
  });

  final String appVisitPlanId;
  final DateTime date;
  final _databaseService = locator<DatabaseService>();

  @override
  Stream<List<Visit>> get stream {
    return _databaseService.getVisitsByAppVisitPlanIdDate(
      appVisitPlanId: appVisitPlanId,
      date: date,
    );
  }

  Future<void> deleteVisit(Visit visit) async {
    if (visit.salesAppId != null) {
      var res = await dialogService.showCustomDialog(
        variant: DialogType.confirm,
        title: "Confirmation",
        description: "Are you sure you want to delete this\nvisit from list?",
        mainButtonTitle: "Delete",
        secondaryButtonTitle: "Cancel",
      );

      if (res?.confirmed == true) {
        SmartDialog.showLoading(msg: "");
        await _databaseService.deleteVisit(visit.salesAppId!);
        SmartDialog.dismiss();
      }
    }
  }
}
