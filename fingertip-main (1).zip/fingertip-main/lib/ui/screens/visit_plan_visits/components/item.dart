import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../database/database.dart';
import '../../../../extensions/date_time.dart';
import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/custom_text.dart';

class VisitPlanVisitsItem extends StatelessWidget {
  const VisitPlanVisitsItem({
    super.key,
    required this.visit,
    required this.onDelete,
  });

  final Visit visit;
  final void Function(Visit visit) onDelete;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(15.w, 25.h, 11.w, 25.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: DetailPageLabelValue(
                  label: "Customer Name",
                  value: visit.accountName,
                ),
              ),
              IconButton(
                onPressed: () => onDelete(visit),
                icon: Assets.images.trashFilled.image(),
                visualDensity: VisualDensity.compact,
                splashRadius: kToolbarHeight / 2,
              ),
            ],
          ),
          DetailPageLabelValue(
            top: 15.h,
            label: "Date & Time",
            value: visit.plannedStartTime.toFormattedDateTime(),
          ),
          DetailPageLabelValue(
            top: 15.h,
            label: "Purpose of Visit",
            value: visit.typeofVisit,
          ),
        ],
      ),
    );
  }
}

class DetailPageLabelValue extends StatelessWidget {
  const DetailPageLabelValue({
    super.key,
    this.label,
    this.value,
    this.top,
  });

  final String? label;
  final String? value;
  final double? top;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: top ?? 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomText(
            label,
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.normal,
              color: Palette.grey87,
            ),
          ),
          verticalSpace(6.h),
          CustomText(
            value ?? "--",
            style: TextStyle(
              fontSize: 15.sp,
              fontWeight: FontWeight.normal,
              color: Palette.grey3E,
            ),
          ),
        ],
      ),
    );
  }
}
