import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../app/app.router.dart';
import '../../common/app_colors.dart';
import '../../common/assets.gen.dart';
import '../../common/utils.dart';
import '../../tools/conditional_widget.dart';
import '../../tools/model_future_builder.dart';
import '../../tools/screen_size.dart';
import '../../widgets/app_bar.dart';
import '../visit_plan/components/header_button.dart';

import 'components/item.dart';
import 'ticket_viewmodel.dart';

class TicketView extends StackedView<TicketViewModel> {
  const TicketView({
    super.key,
  });

  @override
  void onViewModelReady(TicketViewModel viewModel) {
    viewModel.init();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: CustomAppBar(
        titleText: "Tickets",
        actions: [
          IconButton(
            onPressed: navigationService.navigateToSearchView,
            icon: Assets.images.search.image(),
          )
        ],
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(70),
          child: Container(
            width: double.infinity,
            height: 70,
            color: Palette.greyF5,
            padding: EdgeInsets.symmetric(horizontal: 20.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                HeaderButtonWidget(
                  onTap: viewModel.filter,
                  icon: Assets.images.filter2.image(),
                  label: "Filter",
                ),
                HeaderButtonWidget(
                  onTap: viewModel.sort,
                  icon: Assets.images.sort.image(),
                  label: "Sort",
                ),
                const SizedBox(),
              ],
            ),
          ),
        ),
      ),
      body: SizedBox.expand(
        child: IfNotNull(
          value: viewModel.filteredOrderedData,
          condition: (value) => value.isNotEmpty,
          replacement: ModelErrorWidget(
            error: "No tickets available",
            height: ScreenSize.height * 0.7,
          ),
          builder: (context, tickets) {
            return ListView.separated(
              itemCount: tickets.length,
              itemBuilder: (context, index) {
                final item = tickets[index];

                return TicketItemWidget(
                  item: item,
                  onTap: viewModel.goToTicketDetailsView,
                );
              },
              separatorBuilder: (context, index) {
                return Container(
                  width: double.infinity,
                  height: 6,
                  color: Palette.greyF5,
                );
              },
            );
          },
        ),
      ),
    );
  }

  @override
  TicketViewModel viewModelBuilder(BuildContext context) {
    return TicketViewModel();
  }
}
