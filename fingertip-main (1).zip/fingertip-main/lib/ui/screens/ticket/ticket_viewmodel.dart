import 'package:stacked/stacked.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/list.dart';
import '../../../extensions/string.dart';
import '../../../models/sort.dart';
import '../../common/app_constants.dart';
import '../../common/utils.dart';

class TicketViewModel extends StreamViewModel<List<Ticket>> {
  final _databaseService = locator<DatabaseService>();

  List<FilterModel> selectedFilters = [];
  List<Account> accounts = [];

  List<FilterModel> get filterOptions {
    return [
      FilterModel(
        type: FilterType.dropdown,
        label: "Status",
        options: TicketStatus.values.map((e) {
          return FilterOptionModel(label: e, value: e);
        }).toList(),
      ),
      FilterModel(
        type: FilterType.dropdown,
        label: "Complaint Type",
        options: [
          "Payment Issue",
          "Product Issue",
          "Transport Issue",
          "Weight Shortage",
          "Others",
        ].map((e) => FilterOptionModel(label: e, value: e)).toList(),
      ),
      FilterModel(
        type: FilterType.dropdownSearch,
        label: "Account",
        options: accounts.map((e) {
          return FilterOptionModel(
            label: e.name,
            value: e.id.isNotEmptyOrNull ? e.id : e.appAccountId,
          );
        }).toList(),
      ),
    ];
  }

  static final sortOptions = [
    SortModel(
      type: "created_date",
      label: "Created Date",
      isAscending: false,
    ),
    SortModel(
      type: "status",
      label: "Status",
    ),
    SortModel(
      type: "complaint_type",
      label: "Complaint Type",
    ),
    SortModel(
      type: "account",
      label: "Account",
    ),
  ];

  SortModel currentSort = sortOptions.first;

  List<Ticket>? get filteredOrderedData {
    List<Ticket> currentData = data ?? [];

    //Filter
    for (var filter in selectedFilters) {
      switch (filter.label) {
        case "Status":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.status == filter.valueOption!.value!;
            }).toList();
          }
          break;
        case "Complaint Type":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.complaintType == filter.valueOption!.value!;
            }).toList();
          }
          break;
        case "Account":
          if (filter.valueOption?.value != null) {
            currentData = currentData.where((element) {
              return element.accountId == filter.valueOption!.value! ||
                  element.appAccountId == filter.valueOption!.value!;
            }).toList();
          }
          break;
        default:
          break;
      }
    }

    //Sort
    switch (currentSort.type) {
      case "created_date":
        currentData.sortByNullableField(
          getField: (e) => e.createdDate,
          isAscending: currentSort.isAscending,
        );
        break;
      case "status":
        currentData.sortByNullableField(
          getField: (e) => e.status,
          isAscending: currentSort.isAscending,
        );
        break;
      case "complaint_type":
        currentData.sortByNullableField(
          getField: (e) => e.complaintType,
          isAscending: currentSort.isAscending,
        );
        break;
      case "account":
        currentData.sortByNullableField(
          getField: (e) => e.accountName,
          isAscending: currentSort.isAscending,
        );
        break;
      default:
        break;
    }

    return currentData;
  }

  Future<void> init() async {
    accounts = await _databaseService.getAccounts();
    notifyListeners();
  }

  Future<void> filter() async {
    var res = await navigationService.navigateToFilterView(
      filters: filterOptions,
      selectedFilters: selectedFilters,
    );

    if (res is List<FilterModel>) {
      selectedFilters = res;
      notifyListeners();
    }
  }

  Future<void> sort() async {
    var res = await navigationService.navigateToSortView(
      initalValue: currentSort,
      sortOptions: sortOptions,
    );

    if (res is SortModel) {
      setSort(res);
    }
  }

  void setSort(SortModel sort) {
    currentSort = sort;
    notifyListeners();
  }

  void goToTicketDetailsView(Ticket item) {
    if (item.appTicketId.isNotEmptyOrNull) {
      navigationService.navigateToTicketDetailsView(
        ticketId: item.appTicketId!,
      );
    }
  }

  @override
  Stream<List<Ticket>> get stream {
    return _databaseService.watchTickets();
  }
}
