import 'package:flutter/material.dart';

import 'package:stacked/stacked.dart';

import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../app/app.router.dart';
import '../../../database/database.dart';
import '../../../extensions/list.dart';
import '../../common/app_constants.dart';
import '../../common/utils.dart';
import '../../tools/smart_dialog_config.dart';

class CartViewModel extends StreamViewModel<List<CartItem>> {
  CartViewModel({
    required this.visit,
    required this.account,
  }) : fromVisit = visit != null;

  final Visit? visit;
  final Account account;
  final bool fromVisit;
  final _databaseService = locator<DatabaseService>();

  Future<void> submitOrder() async {
    setBusy(true);
    try {
      if (data.isNotEmptyOrNull) {
        bool status = await _databaseService.createOrder(
          visit: visit,
          account: account,
          items: data!,
          totalRate: totalRate,
          totalTax: totalTax,
          grandTotal: grandTotal,
        );

        if (status) {
          showToast("Order saved successfully", type: ToastType.success);
          if (fromVisit) {
            navigationService.popUntil(ModalRoute.withName(Routes.visitView));
          } else {
            navigationService.popUntil(ModalRoute.withName(Routes.orderView));
          }
        }
      }
    } catch (e) {
      debugPrint("$e");
      setError(e.toString());
    }
    setBusy(false);
  }

  void onItemTap(CartItem item) {
    dialogService.showCustomDialog(
      variant: DialogType.addProduct,
      data: item,
    );
  }

  Future<void> onItemDelete(CartItem item) async {
    var res = await dialogService.showCustomDialog(
      variant: DialogType.confirm,
      title: "Delete Item",
      description:
          "Are you sure you want to delete '${item.productName}' from cart?",
      secondaryButtonTitle: "Cancel",
      mainButtonTitle: "Confirm",
    );
    if (res?.confirmed == true) {
      _databaseService.deleteCartItem(item);
    }
  }

  double get totalRate {
    double value = 0;
    if (data.isNotEmptyOrNull) {
      for (CartItem item in data!) {
        value += item.totalAmount;
      }
    }

    return value;
  }

  double get totalTax {
    double value = 0;
    if (data.isNotEmptyOrNull) {
      for (CartItem item in data!) {
        value += item.totalTax;
      }
    }

    return value;
  }

  double get grandTotal => totalRate + totalTax;

  @override
  Stream<List<CartItem>> get stream {
    return _databaseService.watchCartItems();
  }
}
