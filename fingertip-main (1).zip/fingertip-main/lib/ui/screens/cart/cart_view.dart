import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../database/database.dart';
import '../../common/app_colors.dart';
import '../../common/assets.gen.dart';
import '../../common/ui_helpers.dart';
import '../../common/utils.dart';
import '../../tools/model_future_builder.dart';
import '../../tools/parse.dart';
import '../../tools/separated_list.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/custom_text.dart';

import 'cart_viewmodel.dart';
import 'components/cart_item.dart';
import 'components/error.dart';
import 'components/price_details.dart';

class CartView extends StackedView<CartViewModel> {
  const CartView({
    super.key,
    this.visitMap,
    required this.accountMap,
  });

  final Map<String, dynamic>? visitMap;
  final Map<String, dynamic> accountMap;

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Cart",
      ),
      body: SizedBox.expand(
        child: ModelFutureListBuilder<CartItem>(
          data: viewModel.data,
          busy: false,
          errorBuilder: (c, e) => const CartErrorWidget(),
          builder: (context, items, child) {
            return SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 30.h),
              child: Column(
                children: [
                  SeparatedWidgetList(
                    list: items,
                    builder: (cartItem, index) {
                      return CartItemWidget(
                        cartItem: cartItem,
                        onItemTap: viewModel.onItemTap,
                        onItemDelete: viewModel.onItemDelete,
                      );
                    },
                    separationBuilder: (index) {
                      return const Divider(
                        color: Palette.divider,
                        height: 40,
                        thickness: 1,
                      );
                    },
                  ),
                  Container(
                    width: double.infinity,
                    margin: EdgeInsets.only(top: 5.h),
                    alignment: Alignment.centerLeft,
                    child: TextButton(
                      onPressed: () {
                        navigationService.back();
                      },
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CustomText(
                            "Add More Items",
                            style: TextStyle(
                              fontSize: 13.sp,
                              fontWeight: FontWeight.w600,
                              height: 0.9,
                            ),
                          ),
                          horizontalSpace(5.w),
                          Assets.images.addBlue.image(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
      bottomNavigationBar: const CartPriceDetailsWidget(),
    );
  }

  @override
  CartViewModel viewModelBuilder(context) {
    return CartViewModel(
      visit: parseToObject(visitMap, Visit.fromJson),
      account: parseToObject(accountMap, Account.fromJson)!,
    );
  }
}
