import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../common/app_colors.dart';
import '../../../common/fonts.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../common/utils.dart';
import '../../../tools/conditional_widget.dart';
import '../../../widgets/button.dart';
import '../../../widgets/custom_text.dart';
import '../cart_viewmodel.dart';

class CartErrorWidget extends ViewModelWidget<CartViewModel> {
  const CartErrorWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, CartViewModel viewModel) {
    return If(
      condition: viewModel.hasError,
      builder: (context, value) {
        return CustomText(
          viewModel.modelError ?? "Something went wrong",
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 13.sp,
            fontWeight: FontWeight.normal,
            color: Colors.grey[500],
          ),
        );
      },
      replacement: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomText(
            'Your cart is empty!',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Palette.text08,
              fontSize: 18.sp,
              fontFamily: FontFamily.manrope,
              fontWeight: FontWeight.w700,
            ),
          ),
          verticalSpace(10.h),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 50.w),
            child: CustomText(
              "Currently there are no items in cart, Please add some items to continue.",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13.sp,
                fontWeight: FontWeight.normal,
                color: Colors.grey[500],
              ),
            ),
          ),
          verticalSpace(20.h),
          PrimaryButton(
            onPressed: () => navigationService.back(),
            visualDensity: VisualDensity.compact,
            padding: EdgeInsets.symmetric(horizontal: 30.w),
            label: "Add Items",
          ),
        ],
      ),
    );
  }
}
