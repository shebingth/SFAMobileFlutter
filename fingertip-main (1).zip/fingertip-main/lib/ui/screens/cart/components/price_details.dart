import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../../extensions/double.dart';
import '../../../common/app_colors.dart';
import '../../../common/ui_helpers.dart';
import '../../../tools/conditional_widget.dart';
import '../../../widgets/button.dart';
import '../../../widgets/custom_text.dart';
import '../cart_viewmodel.dart';

class CartPriceDetailsWidget extends ViewModelWidget<CartViewModel> {
  const CartPriceDetailsWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context, CartViewModel viewModel) {
    return IfNotNull(
      value: viewModel.data,
      condition: (value) => value.isNotEmpty,
      builder: (context, value) {
        return Container(
          width: double.infinity,
          padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 15.h),
          decoration: const BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Palette.shadow3,
                blurRadius: 5,
                offset: Offset(0, -2),
                spreadRadius: 2,
              )
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomText(
                'Order Summary',
                style: TextStyle(
                  color: Palette.text08,
                  fontSize: 15.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
              verticalSpace(15.h),
              CartPriceItemWidget(
                label: 'Total Amount',
                value: viewModel.totalRate.toPrice,
              ),
              verticalSpace(12.h),
              CartPriceItemWidget(
                label: 'Total Tax',
                value: viewModel.totalTax.toPrice,
              ),
              // verticalSpace(12.h),
              // CartPriceItemWidget(
              //   label: 'Extra Charges (If any)',
              //   value: 0.0.toPrice,
              // ),
              const Divider(
                color: Palette.divider,
                height: 40,
                thickness: 1,
              ),
              CartPriceItemWidget(
                label: 'Grand Total',
                value: viewModel.grandTotal.toPrice,
              ),
              verticalSpace(15.h),
              PrimaryButton(
                onPressed: viewModel.submitOrder,
                isBusy: viewModel.isBusy,
                isExpanded: true,
                label: "Save and Proceed",
              )
            ],
          ),
        );
      },
    );
  }
}

class CartPriceItemWidget extends StatelessWidget {
  const CartPriceItemWidget({
    super.key,
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: CustomText(
            label,
            style: TextStyle(
              color: Palette.text58,
              fontSize: 15.sp,
            ),
          ),
        ),
        horizontalSpace(20.w),
        CustomText(
          value,
          textAlign: TextAlign.right,
          style: TextStyle(
            color: Palette.text08,
            fontSize: 15.sp,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}
