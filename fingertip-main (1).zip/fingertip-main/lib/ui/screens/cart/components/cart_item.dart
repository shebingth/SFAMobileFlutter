import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../database/database.dart';
import '../../../../extensions/double.dart';
import '../../../common/app_colors.dart';
import '../../../common/assets.gen.dart';
import '../../../common/ui_helpers.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/form_fields/text_field.dart';

class CartItemWidget extends StatelessWidget {
  const CartItemWidget({
    super.key,
    required this.cartItem,
    required this.onItemTap,
    required this.onItemDelete,
  });

  final CartItem cartItem;
  final void Function(CartItem item) onItemTap;
  final void Function(CartItem item) onItemDelete;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: CustomText(
                cartItem.productName,
                style: TextStyle(
                  color: Palette.text08,
                  fontSize: 15.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            GestureDetector(
              onTap: () => onItemDelete(cartItem),
              behavior: HitTestBehavior.translucent,
              child: Container(
                padding: EdgeInsets.fromLTRB(10.w, 3.h, 0, 3.h),
                child: Assets.images.trash.image(),
              ),
            ),
          ],
        ),
        verticalSpace(20.w),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: GestureDetector(
                onTap: () => onItemTap(cartItem),
                child: CustomTextFormField(
                  enabled: false,
                  labelText: "Quantity",
                  controller: TextEditingController(
                    text: cartItem.quantity.toString(),
                  ),
                ),
              ),
            ),
            horizontalSpace(13.w),
            Expanded(
              child: CustomTextFormField(
                enabled: false,
                labelText: "Rate",
                controller: TextEditingController(
                  text: cartItem.unitPrice.toPrice,
                ),
              ),
            ),
          ],
        ),
        verticalSpace(15.w),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: CustomTextFormField(
                enabled: false,
                labelText: "Tax %",
                initialValue: cartItem.taxPercent.toPercentage,
              ),
            ),
            horizontalSpace(13.w),
            Expanded(
              child: CustomTextFormField(
                enabled: false,
                labelText: "Tax",
                controller: TextEditingController(
                  text: cartItem.totalTax.toPrice,
                ),
              ),
            ),
          ],
        ),
        verticalSpace(15.w),
        CustomTextFormField(
          enabled: false,
          labelText: "Total",
          controller: TextEditingController(
            text: cartItem.grandTotal.toPrice,
          ),
        ),
      ],
    );
  }
}
