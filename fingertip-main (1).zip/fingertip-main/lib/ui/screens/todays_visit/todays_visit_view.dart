import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';

import '../../../extensions/list.dart';
import '../../common/assets.gen.dart';
import '../../tools/conditional_widget.dart';
import '../../tools/model_future_builder.dart';
import '../../tools/screen_size.dart';
import '../../tools/separated_list.dart';
import '../../widgets/app_bar.dart';
import '../home/components/shop.dart';

import 'todays_visit_viewmodel.dart';

class TodaysVisitView extends StackedView<TodaysVisitViewModel> {
  const TodaysVisitView({super.key});

  @override
  void onViewModelReady(TodaysVisitViewModel viewModel) {
    viewModel.init();
  }

  @override
  Widget builder(context, viewModel, child) {
    return Scaffold(
      appBar: const CustomAppBar(
        titleText: "Today's Visits",
      ),
      body: SizedBox.expand(
        child: If(
          condition: !viewModel.isBusy,
          builder: (context, value) {
            return Visibility(
              visible: viewModel.sortedVisits.isNotEmptyOrNull,
              replacement: ModelErrorWidget(
                height: ScreenSize.height * 0.2,
                error: "No visits available for today",
              ),
              child: SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 50.h),
                child: SeparatedWidgetList(
                  list: viewModel.sortedVisits,
                  builder: (visit, index) {
                    return ShopWidget(
                      visit: visit,
                      checkIn: viewModel.checkIn,
                      open: viewModel.open,
                      markAsMissed: viewModel.markAsMissed,
                      isBusy: viewModel.busy(visit),
                    );
                  },
                  separation: 15.h,
                ),
              ),
            );
          },
          replacement: const ModelBusyWidget(),
        ),
      ),
      floatingActionButton: If(
        condition: !viewModel.isBusy,
        builder: (context, value) => FloatingActionButton(
          onPressed: () => viewModel.addNewVisit(),
          child: Assets.images.add.image(),
        ),
      ),
    );
  }

  @override
  TodaysVisitViewModel viewModelBuilder(BuildContext context) {
    return TodaysVisitViewModel();
  }
}
