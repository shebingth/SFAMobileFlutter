import 'dart:convert';
import 'dart:developer' as dev;
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'package:flutter_debug_overlay/flutter_debug_overlay.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../app/app.locator.dart';

String get deviceType {
  String deviceType = '';
  if (Platform.isAndroid) {
    deviceType = '1';
  } else if (Platform.isIOS) {
    deviceType = '2';
  }
  return deviceType;
}

NavigationService get navigationService => locator<NavigationService>();
DialogService get dialogService => locator<DialogService>();
BottomSheetService get sheetService => locator<BottomSheetService>();

final logBucket = LogBucket();
final httpBucket = HttpBucket();

String getRandomString(int length) {
  const chars =
      'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890';
  math.Random rnd = math.Random();

  return String.fromCharCodes(
    Iterable.generate(
      length,
      (_) => chars.codeUnitAt(rnd.nextInt(chars.length)),
    ),
  );
}

Color? colorFromString(dynamic value) {
  if (value != null) {
    if (value.toString().contains('#')) {
      return null;
    }
    return Color(int.tryParse(value.toString()) ?? 0x00000000);
  }

  return null;
}

String? colorToString(Color? color) {
  if (color != null) {
    return color.value
        .toRadixString(16)
        .padLeft(6, '0')
        .replaceRange(0, 2, "0xff");
  }
  return null;
}

String listToString(List<String?> list) {
  String s = "";
  for (var i = 0; i < list.length; i++) {
    if (list[i] != null) {
      if (i < list.length - 1) {
        s += '${list[i]!}, ';
      } else {
        s += list[i]!;
      }
    }
  }
  return s;
}

LinearGradient gradientFromColor(
  List<Color>? colors, {
  AlignmentGeometry begin = Alignment.centerLeft,
  AlignmentGeometry end = Alignment.centerRight,
}) {
  if ((colors?.length ?? 0) > 1) {
    return LinearGradient(colors: colors!, begin: begin, end: end);
  }
  return const LinearGradient(
    colors: [
      Colors.transparent,
      Colors.transparent,
    ],
  );
}

Map<String, dynamic> jsonDecodeWithCatch(String source) {
  Map<String, dynamic> data = {};
  try {
    data = jsonDecode(source);
  } on Exception catch (e) {
    debugPrint("$e");
    data = {};
  }

  return data;
}

String secToTime(int sec) {
  String time = Duration(seconds: sec).toString();
  return time.substring(time.indexOf(':') + 1, time.lastIndexOf('.'));
}

void printLog(value, {mode = kDebugMode}) {
  switch (mode) {
    case kDebugMode:
      dev.log("$value");
      break;
    case kReleaseMode:
      dev.log("$value");
      break;
    case kIsWeb:
      dev.log("$value");
      break;
    default:
      dev.log('PrintLog: no mode selected');
  }
}

ColorFilter? colorFilter({Color? color}) {
  return color != null ? ColorFilter.mode(color, BlendMode.srcIn) : null;
}

Future<XFile?> compressImageFile(File file, String targetPath) async {
  var result = await FlutterImageCompress.compressAndGetFile(
    file.path,
    targetPath,
    quality: 60,
  );

  debugPrint(
    "Actual File Size: ${(file.lengthSync() / 1024).toStringAsFixed(2)} KB",
  );
  if (result != null) {
    debugPrint(
      "Compressed File Size: ${(File(result.path).lengthSync() / 1024).toStringAsFixed(2)} KB",
    );
  }

  return result;
}
