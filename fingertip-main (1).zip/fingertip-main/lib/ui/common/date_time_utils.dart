import 'package:drift/drift.dart';

class DateTimeUtils {
  static DateTime? getStartOfMonth({int? month, int? year}) {
    if (year != null && month != null) {
      if (month >= 1 && month <= 12) {
        final firstDayOfMonth = DateTime(year, month, 1).toUtc();

        return firstDayOfMonth;
      }
    }

    return null;
  }

  static DateTime? getEndOfMonth({int? month, int? year}) {
    if (year != null && month != null) {
      if (month >= 1 && month <= 12) {
        final lastDayOfMonth = DateTime(year, month + 1, 0);

        return lastDayOfMonth;
      }
    }

    return null;
  }

  static List<DateTime> getDatesInMonth({int? month, int? year}) {
    final List<DateTime> dates = [];
    if (year != null && month != null) {
      if (month >= 1 && month <= 12) {
        final int daysInMonth = DateTime(year, month + 1, 0).day;

        for (int day = 1; day <= daysInMonth; day++) {
          dates.add(DateTime(year, month, day));
        }
      }
    }
    return dates;
  }

  static bool isTodayBetweenDates({DateTime? startDate, DateTime? endDate}) {
    if (startDate != null && endDate != null) {
      if (isToday(startDate) || isToday(endDate)) {
        return true;
      }
      return startDate.toLocal().isBefore(DateTime.now()) &&
          endDate.toLocal().isAfter(DateTime.now());
    }
    return false;
  }

  static bool hasMonthPassed({int? year, int? month}) {
    if (year != null && month != null) {
      DateTime currentDate = DateTime.now();
      DateTime targetDate = DateTime(year, month);

      if (currentDate.year == year && currentDate.month == month) {
        int lastDayOfMonth = DateTime(year, month + 1, 0).day;
        return currentDate.day > lastDayOfMonth;
      } else if (currentDate.isAfter(targetDate)) {
        return true;
      }
    }
    return false;
  }

  static String monthToLabel(int? item) {
    switch (item) {
      case 1:
        return "January";
      case 2:
        return "February";
      case 3:
        return "March";
      case 4:
        return "April";
      case 5:
        return "May";
      case 6:
        return "June";
      case 7:
        return "July";
      case 8:
        return "August";
      case 9:
        return "September";
      case 10:
        return "October";
      case 11:
        return "November";
      case 12:
        return "December";
      default:
        return "";
    }
  }

  static DateTime tomorrow() {
    var now = DateTime.now();
    return DateTime(now.year, now.month, now.day).add(const Duration(days: 1));
  }

  static DateTime addYear(int year) {
    var now = DateTime.now();
    return DateTime(now.year + year);
  }

  static isToday(DateTime date) {
    var now = DateTime.now();
    return date.year == now.year &&
        date.month == now.month &&
        date.day == now.day;
  }

  //Database Related

  Expression<bool> isCurrentDate(GeneratedColumn<DateTime> dateTime) {
    var now = DateTime.now();
    var utcStart = DateTime(now.year, now.month, now.day).toUtc();
    var utcEnd = DateTime(now.year, now.month, now.day, 23, 59, 59).toUtc();

    return dateTime.isBetweenValues(utcStart, utcEnd);
  }

  Expression<bool> isInDate(
    GeneratedColumn<DateTime> dateTime,
    DateTime date,
  ) {
    var utcStart = DateTime(date.year, date.month, date.day).toUtc();
    var utcEnd = DateTime(date.year, date.month, date.day, 23, 59, 59).toUtc();

    return dateTime.isBetweenValues(utcStart, utcEnd);
  }

  static bool isSameDate(DateTime dateTime, DateTime date) {
    var utcStart = DateTime(date.year, date.month, date.day).toUtc();
    var utcEnd = DateTime(date.year, date.month, date.day, 23, 59, 59).toUtc();

    return dateTime.isAfter(utcStart) && dateTime.isBefore(utcEnd);
  }

  String currentDateString() {
    var now = DateTime.now();

    return "${now.year}${now.month}${now.day}";
  }
}
