const String ksAppTitle = 'Field Sales App';
const String ksConnectionClosedError =
    'Connection closed before full header was received';
