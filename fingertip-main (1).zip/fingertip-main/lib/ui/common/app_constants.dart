import 'package:flutter/material.dart';

import 'app_colors.dart';

abstract class Prefs {
  static const String user = "user";
  static const String lastUser = "last_user";
}

enum ToastType {
  success(0),
  error(1);

  const ToastType(this.value);

  final int value;

  static ToastType fromValue(int? value) {
    switch (value) {
      case 0:
        return success;
      case 1:
        return error;
      default:
        return error;
    }
  }

  Color get toColor {
    if (this == success) {
      return Palette.green1;
    }
    return Palette.orange;
  }
}

abstract class VisitStatus {
  static const String planned = "Planned";
  static const String inProgress = "In Progress";
  static const String completed = "Completed";
  static const String missed = "Missed";

  static const List<String> values = [
    planned,
    inProgress,
    completed,
    missed,
  ];

  static Color colorOf(String? value) {
    switch (value) {
      case VisitStatus.planned:
        return Palette.primary;
      case VisitStatus.inProgress:
        return Palette.orange;
      case VisitStatus.missed:
        return Palette.error;
      case VisitStatus.completed:
        return Palette.green2;

      default:
        return Palette.primary;
    }
  }

  static int sortOrder(String? value) {
    switch (value) {
      case VisitStatus.inProgress:
        return 0;
      case VisitStatus.planned:
        return 1;
      case VisitStatus.completed:
        return 2;
      case VisitStatus.missed:
        return 3;

      default:
        return 0;
    }
  }
}

abstract class OrderStatus {
  static const String orderPlaced = "Order Placed";
  static const String acknowledged = "Acknowledged";
  static const String stockCheck = "Stock Check";
  static const String payment = "Payment";
  static const String billing = "Billing";
  static const String packing = "Packing";
  static const String shipping = "Shipping";
  static const String delivered = "Delivered";
  static const String newOrder = "New";

  static Color statusColor(String? value) {
    switch (value) {
      case orderPlaced:
      case newOrder:
        return Palette.orange;
      case acknowledged:
      case stockCheck:
      case payment:
      case billing:
      case packing:
      case shipping:
        return Palette.primary;
      case delivered:
        return Palette.green2;

      default:
        return Palette.primary;
    }
  }

  static const List<String> values = [
    orderPlaced,
    acknowledged,
    stockCheck,
    payment,
    billing,
    packing,
    shipping,
    delivered,
    newOrder,
  ];
}

abstract class TicketStatus {
  static const String closed = "Closed";
  static const String despatched = "Despatched";
  static const String escallated = "Escallated";
  static const String inspection = "Inspection";
  static const String installed = "Installed";
  static const String onHold = "On-Hold";
  static const String open = "Open";
  static const String returned = "Returned";
  static const String working = "Working";
  static const String pending = "Pending";

  static const List<String> values = [
    closed,
    despatched,
    escallated,
    inspection,
    installed,
    onHold,
    open,
    returned,
    working,
    pending,
  ];
}

abstract class VisitType {
  static const String salesVisit = "Sales Visit";
  static const String serviceVisit = "Service Visit";
  static const String paymentCollection = "Payment Collection";
  static const String other = "Other";

  static const List<String> values = [
    salesVisit,
    serviceVisit,
    paymentCollection,
    other,
  ];
}

abstract class FilterType {
  static const String date = "date";
  static const String textField = "text_field";
  static const String dropdown = "dropdown";
  static const String dropdownSearch = "dropdown_search";
  static const String minMax = "min_max";
}

abstract class LeaveTypes {
  static const String casual = "Casual";
  static const String sick = "Sick";

  static const List<String> values = [casual, sick];
}

abstract class LeaveDuration {
  static const String halfDay = "Half Day";
  static const String fullDay = "Full Day";
  static const String multipleDays = "Multiple Days";

  static const List<String> values = [halfDay, fullDay, multipleDays];
}

abstract class LeaveFirstSecond {
  static const String firstHalf = "First Half";
  static const String secondHalf = "Second Half";

  static const List<String> values = [firstHalf, secondHalf];
}

abstract class LeaveStatus {
  static const String pending = "Pending";
  static const String approved = "Approved";
  static const String rejected = "Rejected";

  static const List<String> values = [
    pending,
    approved,
    rejected,
  ];
}

abstract class AccountStatus {
  static const String approved = "Approved";
  static const String pending = "Pending";

  static Color statusColor(String? value) {
    switch (value) {
      case "Pending":
        return Palette.primary;
      case "Approved":
        return Palette.green2;

      default:
        return Palette.primary;
    }
  }
}

abstract class ExpenseStatus {
  static const String approved = "Approved";
  static const String pending = "Pending";

  static Color statusColor(String? value) {
    switch (value) {
      case "Pending":
        return Palette.primary;
      case "Approved":
        return Palette.green2;

      default:
        return Palette.primary;
    }
  }
}
