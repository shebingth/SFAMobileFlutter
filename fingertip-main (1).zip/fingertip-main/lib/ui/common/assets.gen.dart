/// GENERATED CODE - DO NOT MODIFY BY HAND
/// *****************************************************
///  FlutterGen
/// *****************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: directives_ordering,unnecessary_import,implicit_dynamic_list_literal,deprecated_member_use

import 'package:flutter/widgets.dart';

class $AssetsCaGen {
  const $AssetsCaGen();

  /// File path: assets/ca/lets-encrypt-r3.pem
  String get letsEncryptR3 => 'assets/ca/lets-encrypt-r3.pem';

  /// List of all assets
  List<String> get values => [letsEncryptR3];
}

class $AssetsImagesGen {
  const $AssetsImagesGen();

  /// File path: assets/images/accept.png
  AssetGenImage get accept => const AssetGenImage('assets/images/accept.png');

  /// File path: assets/images/add-blue.png
  AssetGenImage get addBlue =>
      const AssetGenImage('assets/images/add-blue.png');

  /// File path: assets/images/add-circle.png
  AssetGenImage get addCircle =>
      const AssetGenImage('assets/images/add-circle.png');

  /// File path: assets/images/add-circle2.png
  AssetGenImage get addCircle2 =>
      const AssetGenImage('assets/images/add-circle2.png');

  /// File path: assets/images/add-red.png
  AssetGenImage get addRed => const AssetGenImage('assets/images/add-red.png');

  /// File path: assets/images/add-square.png
  AssetGenImage get addSquare =>
      const AssetGenImage('assets/images/add-square.png');

  /// File path: assets/images/add.png
  AssetGenImage get add => const AssetGenImage('assets/images/add.png');

  /// File path: assets/images/angle-down.png
  AssetGenImage get angleDown =>
      const AssetGenImage('assets/images/angle-down.png');

  /// File path: assets/images/angle-down24.png
  AssetGenImage get angleDown24 =>
      const AssetGenImage('assets/images/angle-down24.png');

  /// File path: assets/images/angle-right-black.png
  AssetGenImage get angleRightBlack =>
      const AssetGenImage('assets/images/angle-right-black.png');

  /// File path: assets/images/angle-right.png
  AssetGenImage get angleRight =>
      const AssetGenImage('assets/images/angle-right.png');

  /// File path: assets/images/arrow-back.png
  AssetGenImage get arrowBack =>
      const AssetGenImage('assets/images/arrow-back.png');

  /// File path: assets/images/arrow-right.png
  AssetGenImage get arrowRight =>
      const AssetGenImage('assets/images/arrow-right.png');

  /// File path: assets/images/blank-page.png
  AssetGenImage get blankPage =>
      const AssetGenImage('assets/images/blank-page.png');

  /// File path: assets/images/broom.png
  AssetGenImage get broom => const AssetGenImage('assets/images/broom.png');

  /// File path: assets/images/calendar-blue-empty.png
  AssetGenImage get calendarBlueEmpty =>
      const AssetGenImage('assets/images/calendar-blue-empty.png');

  /// File path: assets/images/calendar-blue-filled.png
  AssetGenImage get calendarBlueFilled =>
      const AssetGenImage('assets/images/calendar-blue-filled.png');

  /// File path: assets/images/calendar-grey-filled.png
  AssetGenImage get calendarGreyFilled =>
      const AssetGenImage('assets/images/calendar-grey-filled.png');

  /// File path: assets/images/calendar-red-check.png
  AssetGenImage get calendarRedCheck =>
      const AssetGenImage('assets/images/calendar-red-check.png');

  /// File path: assets/images/calendar.png
  AssetGenImage get calendar =>
      const AssetGenImage('assets/images/calendar.png');

  /// File path: assets/images/camera-white.png
  AssetGenImage get cameraWhite =>
      const AssetGenImage('assets/images/camera-white.png');

  /// File path: assets/images/camera.png
  AssetGenImage get camera => const AssetGenImage('assets/images/camera.png');

  /// File path: assets/images/cancel.png
  AssetGenImage get cancel => const AssetGenImage('assets/images/cancel.png');

  /// File path: assets/images/cart.png
  AssetGenImage get cart => const AssetGenImage('assets/images/cart.png');

  /// File path: assets/images/check-in.png
  AssetGenImage get checkIn =>
      const AssetGenImage('assets/images/check-in.png');

  /// File path: assets/images/check-out.png
  AssetGenImage get checkOut =>
      const AssetGenImage('assets/images/check-out.png');

  /// File path: assets/images/check.png
  AssetGenImage get check => const AssetGenImage('assets/images/check.png');

  /// File path: assets/images/clipboard-small.png
  AssetGenImage get clipboardSmall =>
      const AssetGenImage('assets/images/clipboard-small.png');

  /// File path: assets/images/clipboard.png
  AssetGenImage get clipboard =>
      const AssetGenImage('assets/images/clipboard.png');

  /// File path: assets/images/clock.png
  AssetGenImage get clock => const AssetGenImage('assets/images/clock.png');

  /// File path: assets/images/close.png
  AssetGenImage get close => const AssetGenImage('assets/images/close.png');

  /// File path: assets/images/competition.png
  AssetGenImage get competition =>
      const AssetGenImage('assets/images/competition.png');

  /// File path: assets/images/credit-card.png
  AssetGenImage get creditCard =>
      const AssetGenImage('assets/images/credit-card.png');

  /// File path: assets/images/credit-cards.png
  AssetGenImage get creditCards =>
      const AssetGenImage('assets/images/credit-cards.png');

  /// File path: assets/images/crown.png
  AssetGenImage get crown => const AssetGenImage('assets/images/crown.png');

  /// File path: assets/images/document-upload-blue.png
  AssetGenImage get documentUploadBlue =>
      const AssetGenImage('assets/images/document-upload-blue.png');

  /// File path: assets/images/document-upload.png
  AssetGenImage get documentUpload =>
      const AssetGenImage('assets/images/document-upload.png');

  /// File path: assets/images/doller.png
  AssetGenImage get doller => const AssetGenImage('assets/images/doller.png');

  /// File path: assets/images/edit.png
  AssetGenImage get edit => const AssetGenImage('assets/images/edit.png');

  /// File path: assets/images/filter.png
  AssetGenImage get filter => const AssetGenImage('assets/images/filter.png');

  /// File path: assets/images/filter2.png
  AssetGenImage get filter2 => const AssetGenImage('assets/images/filter2.png');

  /// File path: assets/images/flag-blue.png
  AssetGenImage get flagBlue =>
      const AssetGenImage('assets/images/flag-blue.png');

  /// File path: assets/images/flag.png
  AssetGenImage get flag => const AssetGenImage('assets/images/flag.png');

  /// File path: assets/images/graph.png
  AssetGenImage get graph => const AssetGenImage('assets/images/graph.png');

  /// File path: assets/images/home.png
  AssetGenImage get home => const AssetGenImage('assets/images/home.png');

  /// File path: assets/images/invoice.png
  AssetGenImage get invoice => const AssetGenImage('assets/images/invoice.png');

  /// File path: assets/images/loan.png
  AssetGenImage get loan => const AssetGenImage('assets/images/loan.png');

  /// File path: assets/images/login-header.png
  AssetGenImage get loginHeader =>
      const AssetGenImage('assets/images/login-header.png');

  /// File path: assets/images/logo-dummy.png
  AssetGenImage get logoDummy =>
      const AssetGenImage('assets/images/logo-dummy.png');

  /// File path: assets/images/logo-header2.png
  AssetGenImage get logoHeader2 =>
      const AssetGenImage('assets/images/logo-header2.png');

  /// File path: assets/images/logo.png
  AssetGenImage get logo => const AssetGenImage('assets/images/logo.png');

  /// File path: assets/images/logout.png
  AssetGenImage get logout => const AssetGenImage('assets/images/logout.png');

  /// File path: assets/images/map-pin.png
  AssetGenImage get mapPin => const AssetGenImage('assets/images/map-pin.png');

  /// File path: assets/images/menu.png
  AssetGenImage get menu => const AssetGenImage('assets/images/menu.png');

  /// File path: assets/images/message.png
  AssetGenImage get message => const AssetGenImage('assets/images/message.png');

  /// File path: assets/images/money.png
  AssetGenImage get money => const AssetGenImage('assets/images/money.png');

  /// File path: assets/images/notification.png
  AssetGenImage get notification =>
      const AssetGenImage('assets/images/notification.png');

  /// File path: assets/images/order-blue.png
  AssetGenImage get orderBlue =>
      const AssetGenImage('assets/images/order-blue.png');

  /// File path: assets/images/order-success.png
  AssetGenImage get orderSuccess =>
      const AssetGenImage('assets/images/order-success.png');

  /// File path: assets/images/order-white.png
  AssetGenImage get orderWhite =>
      const AssetGenImage('assets/images/order-white.png');

  /// File path: assets/images/orders.png
  AssetGenImage get orders => const AssetGenImage('assets/images/orders.png');

  /// File path: assets/images/padlock.png
  AssetGenImage get padlock => const AssetGenImage('assets/images/padlock.png');

  /// File path: assets/images/pin-blue.png
  AssetGenImage get pinBlue =>
      const AssetGenImage('assets/images/pin-blue.png');

  /// File path: assets/images/pin.png
  AssetGenImage get pin => const AssetGenImage('assets/images/pin.png');

  /// File path: assets/images/profile.png
  AssetGenImage get profile => const AssetGenImage('assets/images/profile.png');

  /// File path: assets/images/receipt.png
  AssetGenImage get receipt => const AssetGenImage('assets/images/receipt.png');

  /// File path: assets/images/refresh.png
  AssetGenImage get refresh => const AssetGenImage('assets/images/refresh.png');

  /// File path: assets/images/refresh2.png
  AssetGenImage get refresh2 =>
      const AssetGenImage('assets/images/refresh2.png');

  /// File path: assets/images/scale.png
  AssetGenImage get scale => const AssetGenImage('assets/images/scale.png');

  /// File path: assets/images/search.png
  AssetGenImage get search => const AssetGenImage('assets/images/search.png');

  /// File path: assets/images/search2.png
  AssetGenImage get search2 => const AssetGenImage('assets/images/search2.png');

  /// File path: assets/images/search3.png
  AssetGenImage get search3 => const AssetGenImage('assets/images/search3.png');

  /// File path: assets/images/settings.png
  AssetGenImage get settings =>
      const AssetGenImage('assets/images/settings.png');

  /// File path: assets/images/sort.png
  AssetGenImage get sort => const AssetGenImage('assets/images/sort.png');

  /// File path: assets/images/stock.png
  AssetGenImage get stock => const AssetGenImage('assets/images/stock.png');

  /// File path: assets/images/target.png
  AssetGenImage get target => const AssetGenImage('assets/images/target.png');

  /// File path: assets/images/task.png
  AssetGenImage get task => const AssetGenImage('assets/images/task.png');

  /// File path: assets/images/tick-circle-big.png
  AssetGenImage get tickCircleBig =>
      const AssetGenImage('assets/images/tick-circle-big.png');

  /// File path: assets/images/tick-circle.png
  AssetGenImage get tickCircle =>
      const AssetGenImage('assets/images/tick-circle.png');

  /// File path: assets/images/ticket-white.png
  AssetGenImage get ticketWhite =>
      const AssetGenImage('assets/images/ticket-white.png');

  /// File path: assets/images/ticket.png
  AssetGenImage get ticket => const AssetGenImage('assets/images/ticket.png');

  /// File path: assets/images/trash-circle.png
  AssetGenImage get trashCircle =>
      const AssetGenImage('assets/images/trash-circle.png');

  /// File path: assets/images/trash-filled-small-white.png
  AssetGenImage get trashFilledSmallWhite =>
      const AssetGenImage('assets/images/trash-filled-small-white.png');

  /// File path: assets/images/trash-filled-small.png
  AssetGenImage get trashFilledSmall =>
      const AssetGenImage('assets/images/trash-filled-small.png');

  /// File path: assets/images/trash-filled.png
  AssetGenImage get trashFilled =>
      const AssetGenImage('assets/images/trash-filled.png');

  /// File path: assets/images/trash.png
  AssetGenImage get trash => const AssetGenImage('assets/images/trash.png');

  /// File path: assets/images/trophy-confetti.png
  AssetGenImage get trophyConfetti =>
      const AssetGenImage('assets/images/trophy-confetti.png');

  /// File path: assets/images/trophy.png
  AssetGenImage get trophy => const AssetGenImage('assets/images/trophy.png');

  /// File path: assets/images/user.png
  AssetGenImage get user => const AssetGenImage('assets/images/user.png');

  /// File path: assets/images/user2.png
  AssetGenImage get user2 => const AssetGenImage('assets/images/user2.png');

  /// List of all assets
  List<AssetGenImage> get values => [
        accept,
        addBlue,
        addCircle,
        addCircle2,
        addRed,
        addSquare,
        add,
        angleDown,
        angleDown24,
        angleRightBlack,
        angleRight,
        arrowBack,
        arrowRight,
        blankPage,
        broom,
        calendarBlueEmpty,
        calendarBlueFilled,
        calendarGreyFilled,
        calendarRedCheck,
        calendar,
        cameraWhite,
        camera,
        cancel,
        cart,
        checkIn,
        checkOut,
        check,
        clipboardSmall,
        clipboard,
        clock,
        close,
        competition,
        creditCard,
        creditCards,
        crown,
        documentUploadBlue,
        documentUpload,
        doller,
        edit,
        filter,
        filter2,
        flagBlue,
        flag,
        graph,
        home,
        invoice,
        loan,
        loginHeader,
        logoDummy,
        logoHeader2,
        logo,
        logout,
        mapPin,
        menu,
        message,
        money,
        notification,
        orderBlue,
        orderSuccess,
        orderWhite,
        orders,
        padlock,
        pinBlue,
        pin,
        profile,
        receipt,
        refresh,
        refresh2,
        scale,
        search,
        search2,
        search3,
        settings,
        sort,
        stock,
        target,
        task,
        tickCircleBig,
        tickCircle,
        ticketWhite,
        ticket,
        trashCircle,
        trashFilledSmallWhite,
        trashFilledSmall,
        trashFilled,
        trash,
        trophyConfetti,
        trophy,
        user,
        user2
      ];
}

class Assets {
  Assets._();

  static const $AssetsCaGen ca = $AssetsCaGen();
  static const $AssetsImagesGen images = $AssetsImagesGen();
}

class AssetGenImage {
  const AssetGenImage(this._assetName, {this.size = null});

  final String _assetName;

  final Size? size;

  Image image({
    Key? key,
    AssetBundle? bundle,
    ImageFrameBuilder? frameBuilder,
    ImageErrorWidgetBuilder? errorBuilder,
    String? semanticLabel,
    bool excludeFromSemantics = false,
    double? scale,
    double? width,
    double? height,
    Color? color,
    Animation<double>? opacity,
    BlendMode? colorBlendMode,
    BoxFit? fit,
    AlignmentGeometry alignment = Alignment.center,
    ImageRepeat repeat = ImageRepeat.noRepeat,
    Rect? centerSlice,
    bool matchTextDirection = false,
    bool gaplessPlayback = false,
    bool isAntiAlias = false,
    String? package,
    FilterQuality filterQuality = FilterQuality.low,
    int? cacheWidth,
    int? cacheHeight,
  }) {
    return Image.asset(
      _assetName,
      key: key,
      bundle: bundle,
      frameBuilder: frameBuilder,
      errorBuilder: errorBuilder,
      semanticLabel: semanticLabel,
      excludeFromSemantics: excludeFromSemantics,
      scale: scale,
      width: width,
      height: height,
      color: color,
      opacity: opacity,
      colorBlendMode: colorBlendMode,
      fit: fit,
      alignment: alignment,
      repeat: repeat,
      centerSlice: centerSlice,
      matchTextDirection: matchTextDirection,
      gaplessPlayback: gaplessPlayback,
      isAntiAlias: isAntiAlias,
      package: package,
      filterQuality: filterQuality,
      cacheWidth: cacheWidth,
      cacheHeight: cacheHeight,
    );
  }

  ImageProvider provider({
    AssetBundle? bundle,
    String? package,
  }) {
    return AssetImage(
      _assetName,
      bundle: bundle,
      package: package,
    );
  }

  String get path => _assetName;

  String get keyName => _assetName;
}
