import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

abstract class Palette {
  static const Color primary = Color(0xFF0176D3);
  static const Color primaryLite = Color(0xFFF0F7FD);
  static const Color primaryLite2 = Color(0xFFCEE6FB);
  static const Color orange = Color(0xFFFA8B17);
  static const Color orangeLite = Color(0xFFFABA17);
  static const Color green1 = Color(0xFF06A59A);
  static const Color green2 = Color(0xFF2EBE2B);
  static const Color pink1 = Color(0xFFFF538A);
  static const Color pink2 = Color(0xFFD95879);
  static const Color red = Color(0xFFFC4755);
  static const Color text = Color(0xFF000000);
  static const Color text08 = Color(0xFF080808);
  static const Color text09 = Color(0xFF090909);
  static const Color text58 = Color(0xFF585858);
  static const Color text7F = Color(0xFF7F7F7F);
  static const Color text3D = Color(0xFF3D3D3D);
  static const Color textWhite = Colors.white;
  static const Color scaffoldBackground = Colors.white;
  static const Color greyF4 = Color(0xFFF4F4F4);
  static const Color greyF5 = Color(0xFFF5F5F5);
  static const Color greyB9 = Color(0xFFB9B9B9);
  static const Color greyBA = Color(0xFFBABABA);
  static const Color grey3E = Color(0xFF3E3E3E);
  static const Color greyEF = Color(0xFFEFEFEF);
  static const Color grey09 = Color(0xFF090909);
  static const Color grey87 = Color(0xFF878787);
  static const Color border = Color(0xFFE6EBF0);
  static const Color divider = Color(0xFFEBEBEB);
  static const Color shadow1 = Color(0x19000000);
  static const Color shadow2 = Color(0x0A000000);
  static const Color shadow1A = Color(0x1A000000);
  static const Color shadow3 = Color(0x0C000000);
  static const Color shadow0F = Color(0x0F000000);

  static const Color error = Color.fromARGB(255, 218, 52, 40);
}

const kcBoxShadow = BoxShadow(
  color: Palette.shadow1,
  blurRadius: 9,
  offset: Offset(0, 1),
  spreadRadius: -1,
);

MaterialColor generateMaterialColor(Color color) {
  return MaterialColor(color.value, {
    50: tintColor(color, 0.9),
    100: tintColor(color, 0.8),
    200: tintColor(color, 0.6),
    300: tintColor(color, 0.4),
    400: tintColor(color, 0.2),
    500: color,
    600: shadeColor(color, 0.1),
    700: shadeColor(color, 0.2),
    800: shadeColor(color, 0.3),
    900: shadeColor(color, 0.4),
  });
}

int tintValue(int value, double factor) {
  return max(0, min((value + ((255 - value) * factor)).round(), 255));
}

Color tintColor(Color color, double factor) {
  return Color.fromRGBO(
    tintValue(color.red, factor),
    tintValue(color.green, factor),
    tintValue(color.blue, factor),
    1,
  );
}

int shadeValue(int value, double factor) {
  return max(0, min(value - (value * factor).round(), 255));
}

Color shadeColor(Color color, double factor) {
  return Color.fromRGBO(
    shadeValue(color.red, factor),
    shadeValue(color.green, factor),
    shadeValue(color.blue, factor),
    1,
  );
}

const kcSystemUiOverlayDark = SystemUiOverlayStyle(
  systemNavigationBarColor: Colors.white,
  systemNavigationBarIconBrightness: Brightness.dark,
  statusBarColor: Colors.transparent,
  statusBarBrightness: Brightness.light,
  statusBarIconBrightness: Brightness.dark,
);

const kcSystemUiOverlayLight = SystemUiOverlayStyle(
  systemNavigationBarColor: Colors.white,
  systemNavigationBarIconBrightness: Brightness.dark,
  statusBarColor: Colors.transparent,
  statusBarBrightness: Brightness.dark,
  statusBarIconBrightness: Brightness.light,
);
