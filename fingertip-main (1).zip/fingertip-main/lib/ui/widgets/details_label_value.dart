import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../common/app_colors.dart';

import 'custom_text.dart';

class DetailsLabelValueWidget extends StatelessWidget {
  const DetailsLabelValueWidget({
    super.key,
    required this.label,
    required this.value,
    this.top,
    this.bottom,
    this.valueColor,
    this.margin,
  });

  final String? label;
  final String? value;
  final double? top;
  final double? bottom;
  final Color? valueColor;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: margin ?? EdgeInsets.only(top: top ?? 0, bottom: bottom ?? 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomText(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Palette.grey87,
              fontSize: 14.sp,
            ),
          ),
          CustomText(
            value ?? "--",
            top: 6.h,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: valueColor ?? Palette.text09,
              fontSize: 15.sp,
            ),
          )
        ],
      ),
    );
  }
}
