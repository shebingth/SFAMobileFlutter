import 'dart:ui' as ui show TextHeightBehavior;

import 'package:flutter/material.dart';

import 'package:readmore/readmore.dart';

import '../common/app_colors.dart';
import '../tools/conditional_widget.dart';

class CustomText extends StatelessWidget {
  final String? data;
  final InlineSpan? textSpan;
  final TextStyle? style;
  final StrutStyle? strutStyle;
  final TextAlign? textAlign;
  final TextDirection? textDirection;
  final Locale? locale;
  final bool? softWrap;
  final TextOverflow? overflow;
  final int? maxLines;
  final String? semanticsLabel;
  final TextWidthBasis? textWidthBasis;
  final ui.TextHeightBehavior? textHeightBehavior;
  final Color? selectionColor;
  final TextScaler? textScaler;
  final bool withReadMore;
  final int trimLength;
  final double top;
  final double bottom;
  final EdgeInsets? margin;

  const CustomText(
    this.data, {
    super.key,
    this.style,
    this.strutStyle,
    this.textAlign,
    this.textDirection,
    this.locale,
    this.softWrap,
    this.overflow,
    this.textScaler,
    this.maxLines,
    this.semanticsLabel,
    this.textWidthBasis,
    this.textHeightBehavior,
    this.selectionColor,
    this.withReadMore = false,
    this.trimLength = 70,
    this.top = 0,
    this.bottom = 0,
    this.margin,
  }) : textSpan = null;

  const CustomText.rich(
    InlineSpan this.textSpan, {
    super.key,
    this.style,
    this.strutStyle,
    this.textAlign,
    this.textDirection,
    this.locale,
    this.softWrap,
    this.overflow,
    this.textScaler,
    this.maxLines,
    this.semanticsLabel,
    this.textWidthBasis,
    this.textHeightBehavior,
    this.selectionColor,
    this.top = 0,
    this.bottom = 0,
    this.margin,
  })  : data = null,
        withReadMore = false,
        trimLength = 70;

  @override
  Widget build(BuildContext context) {
    var defaultMargin = EdgeInsets.only(top: top, bottom: bottom);
    if (textSpan != null) {
      return Container(
        margin: margin ?? defaultMargin,
        child: Text.rich(
          textSpan!,
          style: style,
          strutStyle: strutStyle,
          textAlign: textAlign,
          textDirection: textDirection,
          locale: locale,
          softWrap: softWrap,
          overflow: overflow,
          textScaler: textScaler,
          maxLines: maxLines,
          semanticsLabel: semanticsLabel,
          textWidthBasis: textWidthBasis,
          textHeightBehavior: textHeightBehavior,
          selectionColor: selectionColor,
        ),
      );
    }

    return IfNotNull(
      value: data,
      condition: (value) => value.isNotEmpty,
      builder: (context, data) {
        if (withReadMore) {
          return Container(
            margin: margin ?? defaultMargin,
            child: ReadMoreText(
              data,
              style: style,
              textAlign: textAlign,
              textDirection: textDirection,
              locale: locale,
              semanticsLabel: semanticsLabel,
              trimMode: TrimMode.Length,
              trimLength: trimLength,
              lessStyle: style?.copyWith(
                color: Palette.primary,
                fontWeight: FontWeight.w600,
              ),
              moreStyle: style?.copyWith(
                color: Palette.primary,
                fontWeight: FontWeight.w600,
              ),
              trimExpandedText: "  Read Less",
              trimCollapsedText: "Read More",
            ),
          );
        }
        return Container(
          margin: margin ?? defaultMargin,
          child: Text(
            data,
            style: style,
            strutStyle: strutStyle,
            textAlign: textAlign,
            textDirection: textDirection,
            locale: locale,
            softWrap: softWrap,
            overflow: overflow,
            textScaler: textScaler,
            maxLines: maxLines,
            semanticsLabel: semanticsLabel,
            textWidthBasis: textWidthBasis,
            textHeightBehavior: textHeightBehavior,
            selectionColor: selectionColor,
          ),
        );
      },
    );
  }
}
