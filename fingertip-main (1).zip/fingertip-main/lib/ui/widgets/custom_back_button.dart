import 'package:flutter/material.dart';

import 'package:navigation_history_observer/navigation_history_observer.dart';

import '../../app/app.locator.dart';
import '../../app/app.router.dart';
import '../common/assets.gen.dart';
import '../common/utils.dart';
import '../screens/dashboard/dashboard_viewmodel.dart';

class CustomBackButton extends StatelessWidget {
  const CustomBackButton({
    super.key,
    this.onPressed,
    this.color,
    this.forceVisible = false,
  });

  final VoidCallback? onPressed;
  final Color? color;
  final bool forceVisible;

  @override
  Widget build(BuildContext context) {
    if (!forceVisible) {
      if (NavigationHistoryObserver().history.length <= 1) {
        return const SizedBox();
      }
    }

    return IconButton(
      onPressed: onPressed ??
          () {
            if (navigationService.currentRoute == Routes.dashboardView) {
              final dashboardViewModel = locator<DashboardViewModel>();

              dashboardViewModel.setIndex(1);
            } else {
              navigationService.back();
            }
          },
      icon: Assets.images.arrowBack.image(),
      splashRadius: kToolbarHeight / 2,
    );
  }
}
