import 'package:flutter/material.dart';

import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../extensions/string.dart';
import '../../common/app_colors.dart';
import '../../common/assets.gen.dart';
import '../../common/fonts.gen.dart';
import '../../common/ui_helpers.dart';
import '../../common/utils.dart';
import '../../tools/conditional_widget.dart';
import '../../tools/screen_size.dart';
import '../custom_text.dart';

import 'text_field.dart';

class CustomDropdownFormField<T> extends StatelessWidget {
  const CustomDropdownFormField({
    super.key,
    this.hintText,
    this.labelText,
    this.onSaved,
    this.validator,
    this.top = 0,
    this.bottom = 0,
    this.focusNode,
    this.prefixIcon,
    required this.items,
    this.itemAsString,
    this.onChanged,
    this.value,
    this.radius = 8,
    this.hideOuterLabel = false,
    this.enabled = true,
    this.formFieldKey,
    this.isRequired = false,
    this.alignLabelWithHint = false,
    this.fontFamily = FontFamily.lato,
  });

  final String? hintText;
  final String? labelText;
  final FormFieldSetter<T>? onSaved;
  final FormFieldValidator<T>? validator;
  final double top;
  final double bottom;
  final FocusNode? focusNode;
  final Widget? prefixIcon;
  final List<T> items;
  final String Function(T item)? itemAsString;
  final ValueChanged<T?>? onChanged;
  final T? value;
  final double radius;
  final bool hideOuterLabel;
  final bool enabled;
  final GlobalKey<FormFieldState<dynamic>>? formFieldKey;
  final bool isRequired;
  final bool alignLabelWithHint;
  final String fontFamily;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      ignoring: !enabled,
      child: Container(
        margin: EdgeInsets.only(top: top, bottom: bottom),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            IfNotNull(
              value: labelText,
              condition: (value) => hideOuterLabel != true,
              builder: (context, labelText) {
                return Container(
                  margin: EdgeInsets.only(bottom: 10.h),
                  child: CustomText(
                    labelText,
                    style: TextStyle(
                      fontSize: 13.sp,
                      color: Colors.black,
                      height: 1.2,
                      fontWeight: FontWeight.normal,
                      fontFamily: FontFamily.lato,
                    ),
                  ),
                );
              },
            ),
            DropdownButtonFormField<T>(
              key: formFieldKey,
              value: value,
              items: items.map(
                (e) {
                  return DropdownMenuItem<T>(
                    value: e,
                    child: CustomText(itemAsString?.call(e) ?? ""),
                  );
                },
              ).toList(),
              onChanged: onChanged,
              focusNode: focusNode,
              icon: Assets.images.angleDown.image(),
              style: TextStyle(
                fontSize: 15.sp,
                color: Colors.black,
                fontWeight: FontWeight.w500,
                height: 1.3,
                fontFamily: FontFamily.lato,
              ),
              decoration: InputDecoration(
                contentPadding: EdgeInsets.symmetric(
                  vertical: 13.h,
                  horizontal: 15.w,
                ),
                label: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(text: labelText),
                      TextSpan(
                        text: isRequired == true && (labelText.isNotEmptyOrNull)
                            ? "*"
                            : null,
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 16.sp,
                        ),
                      )
                    ],
                    style: TextStyle(
                      fontSize: 15.sp,
                      color: Palette.text58,
                      fontWeight: FontWeight.w500,
                      fontFamily: fontFamily,
                    ),
                  ),
                ),
                alignLabelWithHint: alignLabelWithHint,
                floatingLabelBehavior: FloatingLabelBehavior.auto,
                hintText: hintText,
                hintStyle: TextStyle(
                  fontSize: 15.sp,
                  color: Palette.text58,
                  height: 1.2,
                  fontFamily: FontFamily.lato,
                  fontWeight: FontWeight.normal,
                ),
                border: fieldBorder(radius: radius),
                enabledBorder: fieldBorder(radius: radius),
                disabledBorder: fieldBorder(radius: radius),
                focusedBorder: fieldFocusedBorder(radius: radius),
                errorBorder: fieldErrorBorder(radius: radius),
                focusedErrorBorder: fieldErrorBorder(radius: radius),
                fillColor: Palette.scaffoldBackground,
                filled: true,
                prefixIcon: prefixIcon != null
                    ? Container(
                        padding: EdgeInsets.symmetric(horizontal: 13.w),
                        height: 24.h,
                        child: prefixIcon,
                      )
                    : null,
              ),
              onSaved: onSaved,
              validator: validator,
            ),
          ],
        ),
      ),
    );
  }
}

class CustomDropdownSearchFormField<T> extends StatelessWidget {
  const CustomDropdownSearchFormField({
    super.key,
    this.hintText,
    this.labelText,
    this.onSaved,
    this.validator,
    this.top = 0,
    this.bottom = 0,
    this.focusNode,
    this.prefixIcon,
    required this.items,
    this.itemAsString,
    this.onChanged,
    this.value,
    this.radius = 8,
    this.compareFn,
    this.formFieldKey,
    this.isRequired = false,
    this.fontFamily = FontFamily.lato,
  });

  final GlobalKey<FormFieldState<dynamic>>? formFieldKey;
  final String? hintText;
  final String? labelText;
  final FormFieldSetter<T>? onSaved;
  final FormFieldValidator<T>? validator;
  final double top;
  final double bottom;
  final FocusNode? focusNode;
  final Widget? prefixIcon;
  final List<T> items;
  final String Function(T item)? itemAsString;
  final ValueChanged<T?>? onChanged;
  final T? value;
  final double radius;
  final DropdownSearchCompareFn<T>? compareFn;
  final bool isRequired;
  final String fontFamily;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: top, bottom: bottom),
      child: FormField<T>(
        key: formFieldKey,
        initialValue: value,
        onSaved: onSaved,
        validator: validator,
        builder: (state) {
          return DropdownSearch<T>(
            items: items,
            selectedItem: state.value,
            compareFn: compareFn,
            itemAsString: itemAsString,
            onChanged: (value) {
              state.didChange(value);
              onChanged?.call(value);
            },
            validator: (value) {
              return state.errorText;
            },
            dropdownButtonProps: DropdownButtonProps(
              icon: Assets.images.angleDown.image(),
            ),
            popupProps: PopupProps.modalBottomSheet(
              showSelectedItems: true,
              searchFieldProps: TextFieldProps(
                padding: EdgeInsets.fromLTRB(15.w, 0, 15.w, 10.h),
                style: TextStyle(
                  fontSize: 14.sp,
                  color: Colors.black,
                  fontWeight: FontWeight.w500,
                  height: 1.3,
                ),
                textInputAction: TextInputAction.search,
                decoration: InputDecoration(
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 16.h, horizontal: 15.w),
                  hintText: "Search",
                  hintStyle: TextStyle(
                    fontSize: 14.sp,
                    color: Palette.text7F,
                    height: 1.3,
                    fontWeight: FontWeight.normal,
                  ),
                  border: fieldBorder(radius: radius),
                  enabledBorder: fieldBorder(radius: radius),
                  disabledBorder: fieldBorder(radius: radius),
                  focusedBorder: fieldFocusedBorder(radius: radius),
                  errorBorder: fieldErrorBorder(radius: radius),
                  focusedErrorBorder: fieldErrorBorder(radius: radius),
                  prefixIcon: Assets.images.search.image(),
                ),
              ),
              showSearchBox: true,
              constraints: BoxConstraints(
                minHeight: ScreenSize.height,
                maxWidth: ScreenSize.width,
              ),
              title: IfNotNull(
                value: labelText,
                condition: (value) => value.isNotEmpty,
                builder: (context, labelText) {
                  return Container(
                    margin: EdgeInsets.fromLTRB(15.w, 0, 15.w, 15.h),
                    padding: EdgeInsets.only(bottom: 15.h),
                    decoration: const BoxDecoration(
                      border: Border(
                        bottom: BorderSide(color: Palette.border),
                      ),
                    ),
                    child: Text(
                      labelText,
                      style: TextStyle(
                        color: const Color(0xFF090909),
                        fontSize: 17.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  );
                },
                replacement: verticalSpace(20.h),
              ),
              searchDelay: const Duration(milliseconds: 300),
              containerBuilder: (context, popupWidget) {
                return Column(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => navigationService.back(),
                        child: Container(
                          width: double.infinity,
                          height: double.infinity,
                          color: Colors.black.withOpacity(0),
                        ),
                      ),
                    ),
                    Container(
                      height: ScreenSize.height / 1.8,
                      width: double.infinity,
                      padding: EdgeInsets.fromLTRB(0, 15.h, 0, 0),
                      decoration: const BoxDecoration(
                        color: Palette.scaffoldBackground,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          topRight: Radius.circular(10),
                        ),
                      ),
                      child: popupWidget,
                    ),
                    Container(
                      height: MediaQuery.of(context).viewInsets.bottom,
                      width: double.infinity,
                      color: Palette.scaffoldBackground,
                    ),
                  ],
                );
              },
              modalBottomSheetProps: const ModalBottomSheetProps(
                isScrollControlled: true,
                backgroundColor: Colors.transparent,
              ),
              listViewProps: ListViewProps(
                padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 15.w),
              ),
              itemBuilder: (context, item, isSelected) {
                return Container(
                  padding: EdgeInsets.symmetric(vertical: 15.h),
                  child: Text(
                    itemAsString?.call(item) ?? item.toString(),
                    style: TextStyle(
                      color: isSelected ? Palette.primary : Palette.text3D,
                      fontSize: 15.sp,
                    ),
                  ),
                );
              },
            ),
            dropdownDecoratorProps: DropDownDecoratorProps(
              baseStyle: TextStyle(
                fontSize: 15.sp,
                color: Colors.black,
                fontWeight: FontWeight.w500,
                height: 1.3,
                fontFamily: FontFamily.lato,
              ),
              dropdownSearchDecoration: InputDecoration(
                contentPadding: EdgeInsets.symmetric(
                  vertical: 13.h,
                  horizontal: 15.w,
                ),
                label: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(text: labelText),
                      TextSpan(
                        text: isRequired == true && (labelText.isNotEmptyOrNull)
                            ? "*"
                            : null,
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 16.sp,
                        ),
                      )
                    ],
                    style: TextStyle(
                      fontSize: 15.sp,
                      color: Palette.text58,
                      fontWeight: FontWeight.w500,
                      fontFamily: fontFamily,
                    ),
                  ),
                ),
                floatingLabelBehavior: FloatingLabelBehavior.auto,
                hintText: hintText,
                hintStyle: TextStyle(
                  fontSize: 15.sp,
                  color: Palette.text58,
                  height: 1.2,
                  fontFamily: FontFamily.lato,
                  fontWeight: FontWeight.normal,
                ),
                border: fieldBorder(radius: radius),
                enabledBorder: fieldBorder(radius: radius),
                disabledBorder: fieldBorder(radius: radius),
                focusedBorder: fieldFocusedBorder(radius: radius),
                errorBorder: fieldErrorBorder(radius: radius),
                focusedErrorBorder: fieldErrorBorder(radius: radius),
                fillColor: Palette.scaffoldBackground,
                filled: true,
                prefixIcon: prefixIcon != null
                    ? Container(
                        padding: EdgeInsets.symmetric(horizontal: 13.w),
                        height: 24.h,
                        child: prefixIcon,
                      )
                    : null,
              ),
            ),
          );
        },
      ),
    );
  }
}

class CustomDropdownSearchIconButton<T> extends StatelessWidget {
  const CustomDropdownSearchIconButton({
    super.key,
    required this.items,
    this.itemAsString,
    this.onChanged,
    this.value,
    this.compareFn,
    this.hintText,
    this.labelText,
    this.radius = 8,
  });

  final List<T> items;
  final String Function(T item)? itemAsString;
  final ValueChanged<T?>? onChanged;
  final T? value;
  final DropdownSearchCompareFn<T>? compareFn;
  final String? hintText;
  final String? labelText;
  final double radius;

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Assets.images.filter.image(),
        DropdownSearch<T>(
          items: items,
          selectedItem: value,
          compareFn: compareFn,
          itemAsString: itemAsString,
          onChanged: onChanged,
          popupProps: PopupProps.modalBottomSheet(
            showSelectedItems: true,
            searchFieldProps: TextFieldProps(
              padding: EdgeInsets.fromLTRB(15.w, 0, 15.w, 10.h),
              style: TextStyle(
                fontSize: 14.sp,
                color: Colors.black,
                fontWeight: FontWeight.w500,
                height: 1.3,
              ),
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                contentPadding:
                    EdgeInsets.symmetric(vertical: 16.h, horizontal: 15.w),
                hintText: "Search",
                hintStyle: TextStyle(
                  fontSize: 14.sp,
                  color: Palette.text7F,
                  height: 1.3,
                  fontWeight: FontWeight.normal,
                ),
                border: fieldBorder(radius: radius),
                enabledBorder: fieldBorder(radius: radius),
                disabledBorder: fieldBorder(radius: radius),
                focusedBorder: fieldFocusedBorder(radius: radius),
                errorBorder: fieldErrorBorder(radius: radius),
                focusedErrorBorder: fieldErrorBorder(radius: radius),
                prefixIcon: Assets.images.search.image(),
              ),
            ),
            showSearchBox: true,
            constraints: BoxConstraints(
              minHeight: ScreenSize.height,
              maxWidth: ScreenSize.width,
            ),
            title: IfNotNull(
              value: labelText,
              condition: (value) => value.isNotEmpty,
              builder: (context, labelText) {
                return Container(
                  margin: EdgeInsets.fromLTRB(15.w, 0, 15.w, 15.h),
                  padding: EdgeInsets.only(bottom: 15.h),
                  decoration: const BoxDecoration(
                    border: Border(
                      bottom: BorderSide(color: Palette.border),
                    ),
                  ),
                  child: Text(
                    labelText,
                    style: TextStyle(
                      color: const Color(0xFF090909),
                      fontSize: 17.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                );
              },
              replacement: verticalSpace(20.h),
            ),
            searchDelay: const Duration(milliseconds: 300),
            containerBuilder: (context, popupWidget) {
              return Column(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () => navigationService.back(),
                      child: Container(
                        width: double.infinity,
                        height: double.infinity,
                        color: Colors.black.withOpacity(0),
                      ),
                    ),
                  ),
                  Container(
                    height: ScreenSize.height / 1.8,
                    width: double.infinity,
                    padding: EdgeInsets.fromLTRB(0, 15.h, 0, 0),
                    decoration: const BoxDecoration(
                      color: Palette.scaffoldBackground,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(10),
                        topRight: Radius.circular(10),
                      ),
                    ),
                    child: popupWidget,
                  ),
                  Container(
                    height: MediaQuery.of(context).viewInsets.bottom,
                    width: double.infinity,
                    color: Palette.scaffoldBackground,
                  ),
                ],
              );
            },
            modalBottomSheetProps: const ModalBottomSheetProps(
              isScrollControlled: true,
              backgroundColor: Colors.transparent,
            ),
            listViewProps: ListViewProps(
              padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 15.w),
            ),
            itemBuilder: (context, item, isSelected) {
              return Container(
                padding: EdgeInsets.symmetric(vertical: 15.h),
                child: Text(
                  itemAsString?.call(item) ?? item.toString(),
                  style: TextStyle(
                    color: isSelected ? Palette.primary : Palette.text3D,
                    fontSize: 15.sp,
                  ),
                ),
              );
            },
          ),
          dropdownButtonProps: const DropdownButtonProps(
            isVisible: false,
            iconSize: 0,
            icon: SizedBox.shrink(),
            padding: EdgeInsets.zero,
            visualDensity: VisualDensity.compact,
          ),
          dropdownDecoratorProps: const DropDownDecoratorProps(
            dropdownSearchDecoration: InputDecoration(
              constraints: BoxConstraints(maxWidth: 50),
              border: InputBorder.none,
              contentPadding: EdgeInsets.zero,
              isDense: false,
            ),
          ),
          dropdownBuilder: (context, selectedItem) {
            return const SizedBox.shrink();
          },
        ),
      ],
    );
  }
}
