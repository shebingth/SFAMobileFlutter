import 'package:flutter/material.dart';

import 'package:date_field/date_field.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';

import '../../../extensions/string.dart';
import '../../common/app_colors.dart';
import '../../common/assets.gen.dart';
import '../../common/fonts.gen.dart';
import '../../tools/conditional_widget.dart';
import '../custom_text.dart';

import 'text_field.dart';

final dateTimePickerFormat = DateFormat("dd-MM-yyyy hh:mm a");
final datePickerFormat = DateFormat("dd-MM-yyyy");
final timePickerFormat = DateFormat("hh:mm a");

class CustomDateFormField extends StatelessWidget {
  const CustomDateFormField({
    super.key,
    this.hintText,
    this.labelText,
    this.onSaved,
    this.validator,
    this.top = 0,
    this.bottom = 0,
    this.radius = 8,
    this.prefixIcon,
    this.initialValue,
    this.firstDate,
    this.lastDate,
    this.onChanged,
    this.mode = DateTimeFieldPickerMode.dateAndTime,
    this.hideOuterLabel = false,
    this.canClear = true,
    this.hideSuffixIcon = false,
    this.enabled = true,
    this.isRequired = false,
  });

  final String? hintText;
  final String? labelText;
  final FormFieldSetter<DateTime>? onSaved;
  final FormFieldValidator<DateTime>? validator;
  final ValueChanged<DateTime?>? onChanged;
  final double top;
  final double bottom;
  final double radius;
  final Widget? prefixIcon;
  final DateTime? initialValue;
  final DateTime? firstDate;
  final DateTime? lastDate;
  final DateTimeFieldPickerMode mode;
  final bool hideOuterLabel;
  final bool canClear;
  final bool hideSuffixIcon;
  final bool enabled;
  final bool isRequired;

  DateFormat get getDateFormat {
    switch (mode) {
      case DateTimeFieldPickerMode.date:
        return datePickerFormat;
      case DateTimeFieldPickerMode.time:
        return timePickerFormat;
      case DateTimeFieldPickerMode.dateAndTime:
        return dateTimePickerFormat;
      default:
        return dateTimePickerFormat;
    }
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      ignoring: !enabled,
      child: Container(
        margin: EdgeInsets.only(top: top, bottom: bottom),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            IfNotNull(
              value: labelText,
              condition: (value) => hideOuterLabel != true,
              builder: (context, labelText) {
                return Container(
                  margin: EdgeInsets.only(bottom: 10.h),
                  child: CustomText(
                    labelText,
                    style: TextStyle(
                      fontSize: 13.sp,
                      color: Colors.black,
                      height: 1.2,
                      fontWeight: FontWeight.normal,
                      fontFamily: FontFamily.lato,
                    ),
                  ),
                );
              },
            ),
            DateTimeFormField(
              mode: mode,
              firstDate: firstDate,
              materialDatePickerOptions: const MaterialDatePickerOptions(
                initialDatePickerMode: DatePickerMode.day,
              ),
              lastDate: lastDate,
              dateFormat: getDateFormat,
              hideDefaultSuffixIcon: true,
              style: TextStyle(
                fontSize: 15.sp,
                color: Colors.black,
                fontWeight: FontWeight.w500,
                height: 1.6,
                fontFamily: FontFamily.lato,
              ),
              initialValue: initialValue,
              decoration: InputDecoration(
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 15.w,
                  vertical: 10.h,
                ),
                label: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(text: labelText),
                      TextSpan(
                        text: isRequired == true && (labelText.isNotEmptyOrNull)
                            ? "*"
                            : null,
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 16.sp,
                        ),
                      )
                    ],
                    style: TextStyle(
                      fontSize: 15.sp,
                      color: Palette.text58,
                      fontWeight: FontWeight.w500,
                      fontFamily: FontFamily.lato,
                    ),
                  ),
                ),
                floatingLabelBehavior: FloatingLabelBehavior.auto,
                hintText: hintText,
                hintStyle: TextStyle(
                  fontSize: 15.sp,
                  color: Palette.text58,
                  fontFamily: FontFamily.lato,
                  fontWeight: FontWeight.normal,
                  height: 1.8,
                ),
                border: fieldBorder(radius: radius),
                enabledBorder: fieldBorder(radius: radius),
                disabledBorder: fieldBorder(radius: radius),
                focusedBorder: fieldFocusedBorder(radius: radius),
                errorBorder: fieldErrorBorder(radius: radius),
                focusedErrorBorder: fieldErrorBorder(radius: radius),
                fillColor: Palette.scaffoldBackground,
                filled: true,
                prefixIcon: prefixIcon != null
                    ? Container(
                        padding: EdgeInsets.symmetric(horizontal: 13.w),
                        height: 24.h,
                        child: prefixIcon,
                      )
                    : null,
                suffixIcon: hideSuffixIcon != true
                    ? mode == DateTimeFieldPickerMode.time
                        ? Assets.images.clock.image(height: 20)
                        : Assets.images.calendarGreyFilled.image(height: 20)
                    : null,
              ),
              canClear: canClear,
              onSaved: onSaved,
              validator: validator,
              onChanged: onChanged,
            ),
          ],
        ),
      ),
    );
  }
}
