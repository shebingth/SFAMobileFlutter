import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:ios_keyboard_action/ios_keyboard_action.dart';

import '../../../extensions/string.dart';
import '../../common/app_colors.dart';
import '../../common/fonts.gen.dart';
import '../custom_text.dart';

class CustomTextFormField extends StatelessWidget {
  const CustomTextFormField({
    super.key,
    this.hintText,
    this.labelText,
    this.initialValue,
    this.keyboardType = TextInputType.name,
    this.inputFormatters,
    this.onSaved,
    this.validator,
    this.top = 0,
    this.bottom = 0,
    this.focusNode,
    this.nextNode,
    this.prefixIcon,
    this.suffixIcon,
    this.prefixText,
    this.readOnly = false,
    this.enabled = true,
    this.radius = 6,
    this.contentPadding,
    this.controller,
    this.maxLines = 1,
    this.borderColor,
    this.onTap,
    this.onChanged,
    this.autofocus = false,
    this.fillColor = Palette.scaffoldBackground,
    this.fontFamily = FontFamily.lato,
    this.isPassword = false,
    this.floatingLabelBehavior = FloatingLabelBehavior.auto,
    this.hasPrefixTestSeparator = true,
    this.formFieldKey,
    this.isRequired = false,
  });

  final GlobalKey<FormFieldState>? formFieldKey;
  final String? hintText;
  final String? labelText;
  final String? initialValue;
  final TextInputType keyboardType;
  final List<TextInputFormatter>? inputFormatters;
  final FormFieldSetter<String>? onSaved;
  final FormFieldValidator<String>? validator;
  final double top;
  final double bottom;
  final FocusNode? focusNode;
  final FocusNode? nextNode;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final String? prefixText;
  final bool readOnly;
  final bool enabled;
  final double radius;
  final EdgeInsetsGeometry? contentPadding;
  final TextEditingController? controller;
  final int? maxLines;
  final Color? borderColor;
  final VoidCallback? onTap;
  final void Function(String)? onChanged;
  final bool autofocus;
  final Color fillColor;
  final String fontFamily;
  final bool isPassword;
  final FloatingLabelBehavior floatingLabelBehavior;
  final bool hasPrefixTestSeparator;
  final bool isRequired;

  @override
  Widget build(BuildContext context) {
    ValueNotifier<bool> obscureTextNotifier = ValueNotifier<bool>(true);

    return ValueListenableBuilder(
      valueListenable: obscureTextNotifier,
      builder: (context, obscureText, child) {
        return Container(
          margin: EdgeInsets.only(top: top, bottom: bottom),
          child: IOSKeyboardAction(
            focusNode: focusNode ?? FocusNode(),
            focusActionType: FocusActionType.done,
            label: "Done",
            child: TextFormField(
              key: formFieldKey,
              obscureText: isPassword ? obscureText : false,
              autofocus: autofocus,
              onTap: onTap,
              onChanged: onChanged,
              enabled: enabled,
              initialValue: initialValue,
              controller: controller,
              focusNode: focusNode,
              readOnly: readOnly,
              maxLines: maxLines,
              style: TextStyle(
                fontSize: 14.sp,
                color: Colors.black,
                fontWeight: FontWeight.w500,
                height: 1.3,
                fontFamily: fontFamily,
              ),
              keyboardType: keyboardType,
              inputFormatters: inputFormatters,
              textInputAction: nextNode != null
                  ? TextInputAction.next
                  : TextInputAction.done,
              decoration: InputDecoration(
                alignLabelWithHint: true,
                contentPadding: contentPadding ??
                    EdgeInsets.symmetric(vertical: 14.h, horizontal: 15.w),
                label: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(text: labelText),
                      TextSpan(
                        text: isRequired == true && (labelText.isNotEmptyOrNull)
                            ? "*"
                            : null,
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 15.sp,
                        ),
                      )
                    ],
                    style: TextStyle(
                      fontSize: 15.sp,
                      color: Palette.text58,
                      fontWeight: FontWeight.w500,
                      fontFamily: fontFamily,
                    ),
                  ),
                ),
                floatingLabelBehavior: floatingLabelBehavior,
                hintText: hintText,
                hintStyle: TextStyle(
                  fontSize: 14.sp,
                  color: Palette.text7F,
                  height: 1.3,
                  fontWeight: FontWeight.normal,
                  fontFamily: fontFamily,
                ),
                border: fieldBorder(
                  radius: radius,
                  borderColor: borderColor,
                ),
                enabledBorder: fieldBorder(
                  radius: radius,
                  borderColor: borderColor,
                ),
                disabledBorder: fieldBorder(
                  radius: radius,
                  borderColor: borderColor,
                ),
                focusedBorder: fieldFocusedBorder(
                  radius: radius,
                  borderColor: borderColor,
                ),
                errorBorder: fieldErrorBorder(radius: radius),
                focusedErrorBorder: fieldErrorBorder(radius: radius),
                fillColor: fillColor,
                filled: true,
                prefixIcon: prefixIcon != null
                    ? Container(
                        padding: EdgeInsets.symmetric(horizontal: 13.w),
                        height: 24.h,
                        child: prefixIcon,
                      )
                    : null,
                prefix: prefixText.isNotEmptyOrNull
                    ? Container(
                        padding: EdgeInsets.only(
                            right: hasPrefixTestSeparator ? 10.w : 5.w),
                        margin: EdgeInsets.only(
                            right: hasPrefixTestSeparator ? 10.w : 5.w),
                        decoration: BoxDecoration(
                          border: hasPrefixTestSeparator
                              ? const Border(
                                  right: BorderSide(
                                    color: Palette.border,
                                    width: 1,
                                  ),
                                )
                              : null,
                        ),
                        child: CustomText(
                          prefixText!,
                          style: TextStyle(
                            fontSize: 15.sp,
                            color: Colors.black,
                            fontWeight: FontWeight.w500,
                            height: 1.3,
                            fontFamily: fontFamily,
                          ),
                        ),
                      )
                    : null,
                suffixIcon: isPassword
                    ? Container(
                        width: 50,
                        margin: EdgeInsets.only(right: 5.w),
                        child: IconButton(
                          onPressed: () {
                            obscureTextNotifier.value =
                                !obscureTextNotifier.value;
                          },
                          icon: obscureTextNotifier.value
                              ? const Icon(Icons.visibility)
                              : const Icon(Icons.visibility_off),
                          splashRadius: 25.h,
                        ),
                      )
                    : suffixIcon,
              ),
              onSaved: onSaved,
              validator: validator,
            ),
          ),
        );
      },
    );
  }
}

OutlineInputBorder fieldBorder({
  double radius = 8,
  Color? borderColor,
}) {
  return OutlineInputBorder(
    borderSide: BorderSide(
      width: 1,
      color: borderColor ?? Palette.border,
    ),
    borderRadius: BorderRadius.circular(radius),
  );
}

OutlineInputBorder fieldErrorBorder({
  double radius = 8,
  Color? borderColor,
}) {
  return OutlineInputBorder(
    borderSide: BorderSide(
      width: 1,
      color: borderColor ?? Palette.error,
    ),
    borderRadius: BorderRadius.circular(radius),
  );
}

OutlineInputBorder fieldFocusedBorder({
  double radius = 8,
  Color? borderColor,
}) {
  return OutlineInputBorder(
    borderSide: BorderSide(
      width: 1,
      color: borderColor ?? Palette.border,
    ),
    borderRadius: BorderRadius.circular(radius),
  );
}
