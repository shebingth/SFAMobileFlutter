import 'dart:typed_data';

import 'package:flutter/material.dart';
import '../../extensions/string.dart';

Widget networkImage({
  required String? image,
  double? width,
  double? height,
  Color? color,
  AlignmentGeometry alignment = Alignment.center,
  BoxFit? fit,
}) {
  if (image.isNotEmptyOrNull) {
    return Image.network(
      image!,
      width: width,
      height: height,
      color: color,
      alignment: alignment,
      fit: fit,
      errorBuilder: (context, error, stackTrace) {
        return SizedBox(width: width, height: height);
      },
    );
  }
  return SizedBox(width: width, height: height);
}

ImageProvider networkImageProvider({
  required String? image,
}) {
  if (image.isNotEmptyOrNull) {
    return NetworkImage(image!);
  }
  return MemoryImage(Uint8List(0));
}

DecorationImage? decorationImage({
  String? image,
  AlignmentGeometry alignment = Alignment.center,
  BoxFit? fit,
  bool isAsset = false,
}) {
  if (image.isEmptyOrNull) return null;

  if (isAsset) {
    return DecorationImage(
      image: AssetImage(image!),
      alignment: alignment,
      fit: fit,
    );
  } else {
    return DecorationImage(
      image: networkImageProvider(image: image!),
      alignment: alignment,
      fit: fit,
    );
  }
}
