import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../common/app_colors.dart';
import '../tools/conditional_widget.dart';

import 'custom_back_button.dart';
import 'custom_text.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  const CustomAppBar({
    super.key,
    this.actions,
    this.leading,
    this.title,
    this.titleText,
    this.elevation,
    this.bottom,
    this.centerTitle = true,
    this.backgroundColor,
  });

  final List<Widget>? actions;
  final Widget? leading;
  final Widget? title;
  final String? titleText;
  final double? elevation;
  final PreferredSizeWidget? bottom;
  final bool centerTitle;
  final Color? backgroundColor;

  @override
  Widget build(BuildContext context) {
    return AppBar(
      leading: leading ?? const CustomBackButton(),
      automaticallyImplyLeading: false,
      elevation: elevation,
      shadowColor: Colors.black26,
      titleSpacing: 1,
      centerTitle: centerTitle,
      backgroundColor: backgroundColor,
      title: IfNotNull(
        value: title,
        builder: (context, title) => title,
        replacement: CustomText(
          titleText ?? "",
          style: TextStyle(
            color: Palette.text08,
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
            height: 1,
          ),
        ),
      ),
      actions: actions,
      bottom: bottom,
    );
  }

  @override
  Size get preferredSize {
    if (bottom != null) {
      return Size.fromHeight(
        kToolbarHeight + bottom!.preferredSize.height,
      );
    } else {
      return const Size.fromHeight(kToolbarHeight);
    }
  }
}

class EmptyAppBar extends StatelessWidget implements PreferredSizeWidget {
  const EmptyAppBar({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return AppBar(
      elevation: 0,
      backgroundColor: Colors.transparent,
      automaticallyImplyLeading: false,
    );
  }

  @override
  Size get preferredSize {
    return const Size.fromHeight(kToolbarHeight);
  }
}
