import 'package:flutter/material.dart';

import '../../extensions/string.dart';

// int
int? parseToInt(dynamic value) {
  if (value?.toString().contains('.') == true) {
    return parseToDouble(value)?.toInt();
  }
  return value != null ? int.tryParse(value.toString()) : null;
}

//String
String? parseToString(dynamic value) {
  if (value == null) {
    return null;
  } else if (value is String) {
    return value;
  } else {
    return value!.toString();
  }
}

// double
double? parseToDouble(dynamic value) {
  return value != null ? double.tryParse(value.toString()) : null;
}

// bool
bool? parseToBool(dynamic value) {
  return value != null
      ? bool.tryParse(value.toString(), caseSensitive: false)
      : null;
}

// DateTime
DateTime? parseToDateTime(dynamic value) {
  try {
    if (value is int) {
      return DateTime.fromMillisecondsSinceEpoch(value, isUtc: true);
    } else {
      String? valueString = parseToString(value);
      return valueString.isNotEmptyOrNull
          ? DateTime.tryParse((valueString!))
          : null;
    }
  } catch (e) {
    debugPrint("Error Parsing DateTime: $e");
  }
  return null;
}

// TextInputType
TextInputType? parseToTextInputType(dynamic value) {
  var i = parseToInt(value);

  return i != null && i < TextInputType.values.length
      ? TextInputType.values[i]
      : null;
}

int? formatToTextInputType(TextInputType? value) {
  return (value != null) ? TextInputType.values.indexOf(value) : null;
}

// List of Object
List<T>? parseToList<T>(
  dynamic values,
  T? Function(Map<String, dynamic> map) fromJson,
) {
  List<T> valueList = [];
  if (values is List) {
    for (var v in values) {
      if (v is Map<String, dynamic>) {
        try {
          var item = fromJson(v);
          if (item != null) {
            valueList.add(item);
          }
        } catch (e) {
          debugPrint("Error Parsing Object from List: $v, $e");
        }
      }
    }
    return valueList;
  }
  return null;
}

// Parse to Object
T? parseToObject<T>(
  dynamic value,
  T? Function(Map<String, dynamic> map) fromJson,
) {
  if (value is Map<String, dynamic>) {
    try {
      return fromJson(value);
    } catch (e) {
      debugPrint("Error Parsing Object: $value");
    }
  }
  return null;
}

// List of Data Types, Use this for list of int, String, double
List<T>? parseToListOfField<T>(
  dynamic values,
  T? Function(dynamic) parseValue,
) {
  List<T> valueList = [];
  if (values is List) {
    for (var v in values) {
      var item = parseValue(v);
      if (item != null) {
        valueList.add(item);
      }
    }
    return valueList;
  }
  return null;
}
