import 'package:flutter/material.dart';

import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../database/database.dart';
import '../../../extensions/string.dart';

class MissedDialogModel extends BaseViewModel {
  MissedDialogModel({
    required this.completer,
    required this.visit,
  });

  final Visit visit;
  final Function(DialogResponse) completer;
  final formKey = GlobalKey<FormState>();
  final _databaseService = locator<DatabaseService>();

  var autovalidateMode = AutovalidateMode.disabled;
  String? reason;
  DateTime? dateTime;

  Future<void> submit() async {
    if (visit.salesAppId.isEmptyOrNull) return;

    if (formKey.currentState!.validate()) {
      formKey.currentState!.save();

      if (reason.isNotEmptyOrNull) {
        bool status = await runBusyFuture(
          _databaseService.missedVisit(visit, reason!, dateTime),
        );

        if (status) {
          completer(DialogResponse());
        }
      }
    } else {
      setAutovalidateMode(AutovalidateMode.always);
    }
  }

  void setAutovalidateMode(AutovalidateMode mode) {
    autovalidateMode = mode;
    notifyListeners();
  }
}
