import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../extensions/string.dart';
import '../../common/app_colors.dart';
import '../../common/date_time_utils.dart';
import '../../common/ui_helpers.dart';
import '../../widgets/button.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/form_fields/date_picker.dart';
import '../../widgets/form_fields/text_field.dart';

import 'missed_dialog_model.dart';

class MissedDialog extends StackedView<MissedDialogModel> {
  final DialogRequest request;
  final Function(DialogResponse) completer;

  const MissedDialog({
    super.key,
    required this.request,
    required this.completer,
  });

  @override
  Widget builder(context, viewModel, child) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      insetPadding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 24.h),
      backgroundColor: Palette.scaffoldBackground,
      child: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 20.h),
        child: Form(
          key: viewModel.formKey,
          autovalidateMode: viewModel.autovalidateMode,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomText(
                "Missed Visit",
                style: TextStyle(
                  color: Palette.text08,
                  fontSize: 17.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Container(
                height: 1,
                width: double.infinity,
                margin: EdgeInsets.only(top: 17.h, bottom: 10.h),
                color: Palette.border,
              ),
              CustomTextFormField(
                top: 10.h,
                initialValue: viewModel.visit.accountName,
                labelText: "Store Name",
                enabled: false,
              ),
              CustomTextFormField(
                top: 15.h,
                initialValue: viewModel.reason,
                labelText: "Missed Reason",
                maxLines: 5,
                validator: (value) {
                  if (value.isEmptyOrNull) {
                    return "Required";
                  }
                  return null;
                },
                onSaved: (newValue) {
                  viewModel.reason = newValue;
                },
              ),
              CustomDateFormField(
                top: 15.h,
                labelText: "Postponed Date",
                hideOuterLabel: true,
                firstDate: DateTimeUtils.tomorrow(),
                lastDate: DateTimeUtils.addYear(1),
                initialValue: viewModel.dateTime,
                onChanged: (value) {
                  if (value != null) {
                    viewModel.dateTime = value;
                  }
                },
                onSaved: (newValue) {
                  if (newValue != null) {
                    viewModel.dateTime = newValue;
                  }
                },
                validator: (value) {
                  // if (value.isEmptyOrNull) {
                  //   return "Required";
                  // }
                  return null;
                },
              ),
              verticalSpace(20.h),
              Row(
                children: [
                  Expanded(
                    child: PrimaryButton(
                      onPressed: () => completer(DialogResponse()),
                      color: Palette.greyB9,
                      label: "Cancel",
                    ),
                  ),
                  horizontalSpace(15.w),
                  Expanded(
                    child: PrimaryButton(
                      onPressed: viewModel.submit,
                      isBusy: viewModel.isBusy,
                      label: "Save",
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  MissedDialogModel viewModelBuilder(BuildContext context) {
    return MissedDialogModel(
      visit: request.data,
      completer: completer,
    );
  }
}
