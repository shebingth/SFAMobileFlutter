import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../common/app_colors.dart';
import '../../common/ui_helpers.dart';
import '../../widgets/button.dart';
import '../../widgets/custom_text.dart';

import 'info_dialog_model.dart';

class InfoDialog extends StackedView<InfoDialogModel> {
  final DialogRequest request;
  final Function(DialogResponse) completer;

  const InfoDialog({
    super.key,
    required this.request,
    required this.completer,
  });

  @override
  Widget builder(context, viewModel, child) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      insetPadding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 24.h),
      backgroundColor: Palette.scaffoldBackground,
      child: Container(
        padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 20.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CustomText(
              request.title ?? "",
              style: TextStyle(
                color: Palette.text08,
                fontSize: 17.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
            Container(
              height: 1,
              width: double.infinity,
              margin: EdgeInsets.only(top: 17.h, bottom: 10.h),
              color: Palette.border,
            ),
            CustomText(
              request.description ?? "",
              style: TextStyle(
                color: Palette.text58,
                fontSize: 15.sp,
                height: 1.3,
              ),
            ),
            verticalSpace(25.h),
            Container(
              width: double.infinity,
              alignment: Alignment.center,
              child: PrimaryButton(
                onPressed: () {
                  completer(DialogResponse());
                },
                label: request.mainButtonTitle,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  InfoDialogModel viewModelBuilder(BuildContext context) {
    return InfoDialogModel();
  }
}
