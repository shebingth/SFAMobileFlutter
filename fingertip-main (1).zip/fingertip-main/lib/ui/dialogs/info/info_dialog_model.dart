import 'package:stacked/stacked.dart';

class InfoDialogModel extends BaseViewModel {}
