import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../extensions/file.dart';
import '../../../extensions/string.dart';
import '../../common/app_colors.dart';
import '../../common/assets.gen.dart';
import '../../common/fonts.gen.dart';
import '../../common/ui_helpers.dart';
import '../../tools/conditional_widget.dart';
import '../../tools/separated_list.dart';
import '../../widgets/button.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/form_fields/text_field.dart';

import 'checkout_dialog_model.dart';

class CheckoutDialog extends StackedView<CheckoutDialogModel> {
  final DialogRequest request;
  final Function(DialogResponse) completer;

  const CheckoutDialog({
    super.key,
    required this.request,
    required this.completer,
  });

  @override
  Widget builder(context, viewModel, child) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      insetPadding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 24.h),
      backgroundColor: Palette.scaffoldBackground,
      child: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 20.h),
        child: Form(
          key: viewModel.formKey,
          autovalidateMode: viewModel.autovalidateMode,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomText(
                "You're checking out from the store",
                style: TextStyle(
                  color: Palette.text08,
                  fontSize: 17.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Container(
                height: 1,
                width: double.infinity,
                margin: EdgeInsets.only(top: 17.h, bottom: 10.h),
                color: Palette.border,
              ),
              CustomTextFormField(
                top: 10.h,
                initialValue: viewModel.comment,
                labelText: "Notes",
                maxLines: 5,
                validator: (value) {
                  if (value.isEmptyOrNull) {
                    return "Required";
                  }
                  return null;
                },
                onSaved: (newValue) {
                  viewModel.comment = newValue;
                },
              ),
              GestureDetector(
                onTap: () => viewModel.pickFromCamera(),
                behavior: HitTestBehavior.translucent,
                child: Container(
                  width: double.infinity,
                  margin: EdgeInsets.only(top: 15.h),
                  padding: EdgeInsets.fromLTRB(20.w, 18.h, 20.h, 18.h),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Palette.border),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Assets.images.camera.image(),
                      verticalSpace(4.h),
                      CustomText(
                        "Upload From Camera",
                        style: TextStyle(
                          color: Palette.text7F,
                          fontSize: 14.sp,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              GestureDetector(
                onTap: () => viewModel.pickFromDocuments(),
                child: CustomTextFormField(
                  top: 15.h,
                  enabled: false,
                  labelText: "Upload Documents",
                  suffixIcon: Assets.images.documentUpload.image(),
                ),
              ),
              If(
                condition: viewModel.files.isNotEmpty,
                builder: (context, value) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      verticalSpace(20.h),
                      RichText(
                        text: TextSpan(
                          children: [
                            const TextSpan(text: "Selected Files"),
                            const TextSpan(text: " "),
                            TextSpan(
                              text: "(${viewModel.files.formattedTotalSize})",
                              style: TextStyle(
                                color: Palette.text7F,
                                fontSize: 14.sp,
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ],
                          style: TextStyle(
                            color: Palette.text08,
                            fontSize: 15.sp,
                            fontWeight: FontWeight.w600,
                            fontFamily: FontFamily.lato,
                          ),
                        ),
                      ),
                      verticalSpace(10.h),
                      SeparatedWidgetList(
                        list: viewModel.files,
                        builder: (item, index) {
                          return Row(
                            children: [
                              Expanded(
                                child: RichText(
                                  text: TextSpan(
                                    children: [
                                      TextSpan(text: item.fileName),
                                      const TextSpan(text: "  "),
                                      TextSpan(
                                        text: "(${item.formatedSize})",
                                        style: TextStyle(
                                          color: Palette.text7F,
                                          fontSize: 13.sp,
                                        ),
                                      ),
                                    ],
                                    style: TextStyle(
                                      color: Palette.text08,
                                      fontSize: 14.sp,
                                      fontFamily: FontFamily.lato,
                                    ),
                                  ),
                                ),
                              ),
                              horizontalSpace(10.w),
                              IconButton(
                                onPressed: () => viewModel.deleteFile(item),
                                color: Palette.error,
                                icon: const Icon(Icons.delete),
                                splashRadius: kToolbarHeight / 2,
                              )
                            ],
                          );
                        },
                      ),
                    ],
                  );
                },
              ),
              verticalSpace(20.h),
              Row(
                children: [
                  Expanded(
                    child: PrimaryButton(
                      onPressed: () => completer(DialogResponse()),
                      color: Palette.greyB9,
                      label: "Cancel",
                    ),
                  ),
                  horizontalSpace(15.w),
                  Expanded(
                    child: PrimaryButton(
                      onPressed: viewModel.submit,
                      isBusy: viewModel.isBusy,
                      label: "Save",
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  CheckoutDialogModel viewModelBuilder(context) {
    return CheckoutDialogModel(
      visit: request.data,
      completer: completer,
    );
  }
}
