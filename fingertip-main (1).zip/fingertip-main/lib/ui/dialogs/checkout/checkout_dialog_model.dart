import 'dart:io';

import 'package:flutter/material.dart';

import 'package:file_picker/file_picker.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../database/database.dart';
import '../../../extensions/file.dart';
import '../../../extensions/string.dart';
import '../../../services/location_service.dart';
import '../../common/app_constants.dart';
import '../../common/utils.dart';
import '../../tools/smart_dialog_config.dart';

class CheckoutDialogModel extends BaseViewModel {
  CheckoutDialogModel({
    required this.visit,
    required this.completer,
  });

  final Visit visit;
  final Function(DialogResponse) completer;
  final _databaseService = locator<DatabaseService>();
  final _locationService = locator<LocationService>();
  final formKey = GlobalKey<FormState>();
  final picker = ImagePicker();
  final List<File> files = [];

  var autovalidateMode = AutovalidateMode.disabled;
  String? comment;

  Future<void> submit() async {
    if (visit.salesAppId.isEmptyOrNull) return;

    if (formKey.currentState!.validate()) {
      formKey.currentState!.save();

      if (files.totalSizeInMB > 4.0) {
        showToast("Total file size should not exceed 4MB");
        return;
      }

      setBusy(true);
      var latLng = await _locationService.getLocation();
      if (latLng?.hasData == true) {
        bool status = await _databaseService.checkout(
          files: files,
          salesAppId: visit.salesAppId!,
          comment: comment!,
          latLng: latLng!,
        );

        if (status) {
          showToast("Checked out successfully", type: ToastType.success);
          completer(DialogResponse(confirmed: true));
        }
      }
      setBusy(false);
    } else {
      setAutovalidateMode(AutovalidateMode.always);
    }
  }

  Future<void> pickFromDocuments() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();

    if (result?.files.isNotEmpty == true) {
      File file = File(result!.files.single.path!);

      files.add(file);
      notifyListeners();
    }
  }

  Future<void> pickFromCamera() async {
    try {
      var res = await picker.pickImage(source: ImageSource.camera);

      if (res != null) {
        final tempDir = await getTemporaryDirectory();
        var file = File(res.path);
        var fileName = file.path.split('/').last;
        var cRes = await compressImageFile(
          file,
          "${tempDir.path}/c_$fileName",
        );

        if (cRes != null) {
          var compressedFile = File(cRes.path);
          files.add(compressedFile);
          notifyListeners();
        }
      }
    } catch (e) {
      if (e is CompressError) {
        CompressError error = e;
        debugPrint("CompressError: ${error.message}");
      } else {
        debugPrint("Camera Image Pick Error: ${e.toString()}");
      }
    }
  }

  void deleteFile(File item) {
    files.remove(item);
    notifyListeners();
  }

  void setAutovalidateMode(AutovalidateMode mode) {
    autovalidateMode = mode;
    notifyListeners();
  }
}
