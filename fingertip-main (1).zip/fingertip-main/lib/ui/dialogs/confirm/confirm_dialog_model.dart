import 'package:stacked/stacked.dart';

class ConfirmDialogModel extends BaseViewModel {}
