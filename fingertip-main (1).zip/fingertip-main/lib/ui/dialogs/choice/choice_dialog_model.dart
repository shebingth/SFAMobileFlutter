import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../models/basics.dart';

class ChoiceDialogModel extends BaseViewModel {
  final DialogRequest request;
  final Function(DialogResponse) completer;
  final List<OptionModel> options;

  ChoiceDialogModel({
    required this.request,
    required this.completer,
  }) : options = request.data ?? [];

  void optionSelected(OptionModel option) {
    completer(DialogResponse(data: option.value));
  }

  void cancel() {
    completer(DialogResponse());
  }
}
