import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../common/app_colors.dart';
import '../../common/ui_helpers.dart';
import '../../tools/conditional_widget.dart';
import '../../tools/model_future_builder.dart';
import '../../widgets/custom_text.dart';

import 'choice_dialog_model.dart';

class ChoiceDialog extends StackedView<ChoiceDialogModel> {
  final DialogRequest request;
  final Function(DialogResponse) completer;

  const ChoiceDialog({
    super.key,
    required this.request,
    required this.completer,
  });

  @override
  Widget builder(context, viewModel, child) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      insetPadding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 24.h),
      backgroundColor: Palette.scaffoldBackground,
      clipBehavior: Clip.antiAlias,
      child: IfNotNull(
        value: viewModel.options,
        condition: (value) => value.isNotEmpty,
        builder: (context, options) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  padding: EdgeInsets.only(top: 10.h),
                  itemCount: options.length,
                  itemBuilder: (context, index) {
                    final option = options[index];

                    return ListTile(
                      onTap: () => viewModel.optionSelected(option),
                      titleAlignment: ListTileTitleAlignment.center,
                      title: CustomText(
                        option.label,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 15.sp,
                          fontWeight: FontWeight.w500,
                          color: Colors.black,
                        ),
                      ),
                    );
                  },
                ),
              ),
              ListTile(
                onTap: viewModel.cancel,
                titleAlignment: ListTileTitleAlignment.center,
                title: CustomText(
                  "Cancel",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 15.sp,
                    fontWeight: FontWeight.w500,
                    color: Palette.red,
                  ),
                ),
              ),
              verticalSpace(10.h),
            ],
          );
        },
        replacement: const ModelErrorWidget(
          error: "No options found",
          height: 200,
        ),
      ),
    );
  }

  @override
  ChoiceDialogModel viewModelBuilder(BuildContext context) {
    return ChoiceDialogModel(
      request: request,
      completer: completer,
    );
  }
}
