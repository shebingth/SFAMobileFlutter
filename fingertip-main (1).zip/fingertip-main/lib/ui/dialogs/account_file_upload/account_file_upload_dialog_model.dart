import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../app/app.logger.dart';
import '../../../database/database.dart';
import '../../../extensions/file.dart';
import '../../../extensions/string.dart';
import '../../common/app_constants.dart';
import '../../common/utils.dart';
import '../../tools/smart_dialog_config.dart';

class AccountFileUploadDialogModel extends BaseViewModel {
  AccountFileUploadDialogModel({
    required this.request,
    required this.completer,
  }) : account = request.data;

  final DialogRequest request;
  final Function(DialogResponse) completer;
  final _databaseService = locator<DatabaseService>();
  final Account account;
  final picker = ImagePicker();
  final List<File> files = [];
  final logger = getLogger("AccountFileUploadDialogModel");

  Future<void> submit() async {
    if (account.appAccountId.isEmptyOrNull) return;

    if (files.isEmpty) {
      showToast("Please select files to upload");
      return;
    }

    if (files.totalSizeInMB > 4.0) {
      showToast("Total file size should not exceed 4MB");
      return;
    }

    setBusy(true);

    bool status = await _databaseService.addAccountFiles(
      appAccountId: account.appAccountId!,
      files: files,
    );

    if (status) {
      showToast("File saved successfully", type: ToastType.success);
      completer(DialogResponse(confirmed: true));
    }

    setBusy(false);
  }

  Future<void> pickFromDocuments() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();

    if (result?.files.isNotEmpty == true) {
      File file = File(result!.files.single.path!);

      files.add(file);
      notifyListeners();
    }
  }

  Future<void> pickFromCamera() async {
    try {
      var res = await picker.pickImage(source: ImageSource.camera);

      if (res != null) {
        final tempDir = await getTemporaryDirectory();
        var file = File(res.path);
        var fileName = file.path.split('/').last;
        var cRes = await compressImageFile(
          file,
          "${tempDir.path}/c_$fileName",
        );

        if (cRes != null) {
          var compressedFile = File(cRes.path);
          files.add(compressedFile);
          notifyListeners();
        }
      }
    } catch (e) {
      if (e is CompressError) {
        CompressError error = e;
        logger.e("CompressError: ${error.message}");
      } else {
        logger.e("Camera Image Pick Error: ${e.toString()}");
      }
    }
  }

  void deleteFile(File item) {
    files.remove(item);
    notifyListeners();
  }
}
