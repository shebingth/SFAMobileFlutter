import 'package:flutter/material.dart';

import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';
import '../../../database/database.dart';
import '../../../extensions/cart_item.dart';
import '../../../extensions/double.dart';
import '../../../extensions/string.dart';

class AddProductDialogModel extends BaseViewModel {
  AddProductDialogModel({
    required CartItem cartItem,
    required this.completer,
  })  : cartItem = CartItem.fromJson(cartItem.toJson()),
        totalController = TextEditingController(
          text: cartItem.getGrantTotal().toPrice,
        ),
        totalTaxController = TextEditingController(
          text: cartItem.getTotalTax().toPrice,
        );

  CartItem cartItem;
  final Function(DialogResponse) completer;
  final formKey = GlobalKey<FormState>();
  final TextEditingController totalController;
  final TextEditingController totalTaxController;
  final _databaseService = locator<DatabaseService>();

  var autovalidateMode = AutovalidateMode.disabled;

  Future<void> addProduct() async {
    if (formKey.currentState!.validate()) {
      formKey.currentState!.save();

      if (cartItem.quantity > 0) {
        cartItem = cartItem.copyWith(
          taxAmount: cartItem.getTaxAmount(),
          totalTax: cartItem.getTotalTax(),
          totalAmount: cartItem.getTotalAmount(),
          grandTotal: cartItem.getGrantTotal(),
        );
        bool status = await runBusyFuture(
          _databaseService.addCartItems(cartItem),
        );

        if (status) {
          completer(DialogResponse(confirmed: true));
        }
      }
    } else {
      setAutovalidateMode(AutovalidateMode.always);
    }
  }

  void setAutovalidateMode(AutovalidateMode mode) {
    autovalidateMode = mode;
    notifyListeners();
  }

  void onQuantityChanged(String value) {
    var quantity = int.tryParse(value);
    if (quantity != null) {
      cartItem = cartItem.copyWith(quantity: quantity);
      totalController.text = cartItem.getGrantTotal().toPrice;
      totalTaxController.text = cartItem.getTotalTax().toPrice;
    } else {
      totalController.text = '';
      totalTaxController.text = '';
    }
  }

  void onQuantitySaved(String? newValue) {
    if (newValue.isEmptyOrNull) {
      var quantity = int.tryParse(newValue!);
      if (quantity != null) {
        cartItem = cartItem.copyWith(quantity: quantity);
      }
    }
  }
}
