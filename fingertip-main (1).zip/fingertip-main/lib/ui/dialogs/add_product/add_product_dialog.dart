import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../extensions/double.dart';
import '../../../extensions/string.dart';
import '../../common/app_colors.dart';
import '../../common/ui_helpers.dart';
import '../../tools/dismiss_keyboard.dart';
import '../../widgets/button.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/form_fields/text_field.dart';

import 'add_product_dialog_model.dart';

class AddProductDialog extends StackedView<AddProductDialogModel> {
  final DialogRequest request;
  final Function(DialogResponse) completer;

  const AddProductDialog({
    super.key,
    required this.request,
    required this.completer,
  });

  @override
  Widget builder(context, viewModel, child) {
    var cartItem = viewModel.cartItem;
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      insetPadding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 24.h),
      backgroundColor: Palette.scaffoldBackground,
      child: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(15.w, 20.h, 15.w, 20.h),
        child: DismissKeyboard(
          child: Form(
            key: viewModel.formKey,
            autovalidateMode: viewModel.autovalidateMode,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomText(
                  cartItem.productName,
                  style: TextStyle(
                    color: Palette.text08,
                    fontSize: 17.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Container(
                  height: 1,
                  width: double.infinity,
                  margin: EdgeInsets.only(top: 17.h, bottom: 18.h),
                  color: Palette.border,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: CustomTextFormField(
                        labelText: "Quantity",
                        initialValue: cartItem.quantity.toString(),
                        keyboardType: TextInputType.number,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        onChanged: viewModel.onQuantityChanged,
                        validator: (value) {
                          if (value.isEmptyOrNull) {
                            return "Required";
                          }
                          var q = int.tryParse(value!) ?? 0;
                          if (q < 1) {
                            return "Invalid quantity";
                          }
                          return null;
                        },
                        onSaved: viewModel.onQuantitySaved,
                      ),
                    ),
                    horizontalSpace(13.w),
                    Expanded(
                      child: CustomTextFormField(
                        enabled: false,
                        labelText: "Rate",
                        initialValue: cartItem.unitPrice.toPrice,
                      ),
                    ),
                  ],
                ),
                verticalSpace(15.w),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: CustomTextFormField(
                        enabled: false,
                        labelText: "Tax %",
                        initialValue:
                            viewModel.cartItem.taxPercent.toPercentage,
                      ),
                    ),
                    horizontalSpace(13.w),
                    Expanded(
                      child: CustomTextFormField(
                        enabled: false,
                        labelText: "Tax",
                        controller: viewModel.totalTaxController,
                      ),
                    ),
                  ],
                ),
                verticalSpace(15.w),
                CustomTextFormField(
                  enabled: false,
                  labelText: "Total",
                  controller: viewModel.totalController,
                ),
                verticalSpace(20.h),
                Row(
                  children: [
                    Expanded(
                      child: PrimaryButton(
                        onPressed: () => completer(DialogResponse()),
                        color: Palette.greyB9,
                        label: "Cancel",
                      ),
                    ),
                    horizontalSpace(15.w),
                    Expanded(
                      child: PrimaryButton(
                        onPressed: viewModel.addProduct,
                        isBusy: viewModel.isBusy,
                        label: cartItem.id == null ? "Add" : "Update",
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  AddProductDialogModel viewModelBuilder(context) {
    return AddProductDialogModel(
      cartItem: request.data,
      completer: completer,
    );
  }
}
