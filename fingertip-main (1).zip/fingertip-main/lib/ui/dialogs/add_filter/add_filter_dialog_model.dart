import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../models/sort.dart';
import '../../tools/smart_dialog_config.dart';

class AddFilterDialogModel extends BaseViewModel {
  AddFilterDialogModel({
    required this.request,
    required this.completer,
  }) : filters = request.data;

  final DialogRequest request;
  final Function(DialogResponse) completer;
  final List<FilterModel> filters;

  FilterModel? selectedFilter;

  void onFilterSelected(FilterModel? filter) {
    if (selectedFilter == filter) {
      selectedFilter = null;
    } else {
      selectedFilter = filter;
    }
    notifyListeners();
  }

  void cancel() {
    completer(DialogResponse());
  }

  void apply() {
    if (selectedFilter != null) {
      completer(DialogResponse(data: selectedFilter));
    } else {
      showToast("Please select a filter");
    }
  }
}
