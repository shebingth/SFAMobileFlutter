import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../common/app_colors.dart';
import '../../common/ui_helpers.dart';
import '../../tools/conditional_widget.dart';
import '../../tools/model_future_builder.dart';
import '../../tools/separated_list.dart';
import '../../widgets/button.dart';
import '../../widgets/custom_text.dart';

import 'add_filter_dialog_model.dart';

class AddFilterDialog extends StackedView<AddFilterDialogModel> {
  final DialogRequest request;
  final Function(DialogResponse) completer;

  const AddFilterDialog({
    super.key,
    required this.request,
    required this.completer,
  });

  @override
  Widget builder(context, viewModel, child) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      insetPadding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 24.h),
      backgroundColor: Palette.scaffoldBackground,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: double.infinity,
            margin: EdgeInsets.symmetric(horizontal: 20.w),
            padding: EdgeInsets.only(top: 24.h, bottom: 17.h),
            decoration: const BoxDecoration(
              border: Border(
                bottom: BorderSide(color: Palette.divider),
              ),
            ),
            child: CustomText(
              "Add Filter",
              style: TextStyle(
                fontSize: 18.sp,
                fontWeight: FontWeight.w600,
                color: Palette.text08,
              ),
            ),
          ),
          IfNotNull(
            value: viewModel.filters,
            condition: (value) => value.isNotEmpty,
            builder: (context, value) {
              return SingleChildScrollView(
                child: SeparatedWidgetList(
                  list: viewModel.filters,
                  mainAxisSize: MainAxisSize.min,
                  builder: (item, index) {
                    return InkWell(
                      onTap: () => viewModel.onFilterSelected(item),
                      child: Container(
                        padding: EdgeInsets.symmetric(vertical: 20.h),
                        margin: EdgeInsets.symmetric(horizontal: 20.w),
                        child: Row(
                          children: [
                            Expanded(
                              child: CustomText(
                                item.label,
                                style: TextStyle(
                                  fontSize: 15.sp,
                                  color: Palette.text58,
                                  fontWeight: FontWeight.normal,
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 20,
                              height: 20,
                              child: Radio(
                                value: item,
                                groupValue: viewModel.selectedFilter,
                                onChanged: (value) {
                                  viewModel.onFilterSelected(value);
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                  separationBuilder: (index) {
                    return Container(
                      width: double.infinity,
                      margin: EdgeInsets.symmetric(horizontal: 20.w),
                      height: 1,
                      color: Palette.divider,
                    );
                  },
                ),
              );
            },
            replacement: const ModelErrorWidget(
              error: "No filters found",
              height: 200,
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 10.h),
            padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
            decoration: const BoxDecoration(
              color: Palette.scaffoldBackground,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(10),
                bottomRight: Radius.circular(10),
              ),
              boxShadow: [
                BoxShadow(
                  color: Palette.shadow3,
                  blurRadius: 5,
                  offset: Offset(0, -2),
                  spreadRadius: 2,
                )
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: PrimaryButton(
                    onPressed: viewModel.cancel,
                    label: "Cancel",
                    color: Palette.greyBA,
                  ),
                ),
                horizontalSpace(15.w),
                Expanded(
                  child: PrimaryButton(
                    onPressed: viewModel.apply,
                    label: "Apply",
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  AddFilterDialogModel viewModelBuilder(BuildContext context) {
    return AddFilterDialogModel(
      request: request,
      completer: completer,
    );
  }
}
