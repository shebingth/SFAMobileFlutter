import 'dart:io';

import 'package:stacked/stacked_annotations.dart';

import '../app/app.locator.dart';
import '../database/database.dart';
import '../http/http_helper.dart';
import '../models/home.dart';
import '../models/user.dart';

import 'json_cache_service.dart';
import 'user_service.dart';

class ApiService with InitializableDependency {
  static const environment = ApiEnvironment.dev;
  static bool debugOverlayEnabled = true;

  final _userService = locator<UserService>();
  final HttpHelper http = HttpHelper();
  static String baseUrlLogin = environment.baseUrl;

  AppUser? get user => _userService.user;
  String? get instanceUrl => user?.instanceUrl;

  @override
  Future<void> init() async {
    await http.init();
  }

  Future<bool?> login({
    required String userName,
    required String password,
  }) async {
    bool status = false;

    var (_, response) = await http.post(
      url: Uri.parse(baseUrlLogin),
      body: {
        "username": userName,
        "password": password,
        "client_id":
            "3MVG9fe4g9fhX0E6fsEay5BXGB2FXob3XKj7nSoR0008SfhJHc.EZa7ZVb2ZlDlrKv8tZoX26lNK_dSYNgkxg",
        "client_secret":
            "A685AB61C0ABAC569F144D65BE140F38572494083654102B86E319A2017E1E05",
        "grant_type": "password",
      },
    );

    if (response.isNotEmpty) {
      try {
        AppUser localUser = AppUser.fromJson(response);

        if (localUser.hasUser) {
          await _userService.saveLoginCredential(localUser);

          if (!_userService.isLastUser(userName)) {
            await locator<DatabaseService>().clearTables();
            await _userService.saveLastUser(userName);
          }

          if (user?.hasUser ?? false) {
            status = true;
          }
        }
      } catch (e) {
        throw "Invalid data format\n$e";
      }
    }

    return status;
  }

  Future<HomeDataModel?> fetchData() async {
    HomeDataModel? data;

    var (_, response) = await http.get(
      url: Uri.tryParse(
        "$instanceUrl/services/apexrest/api/all",
      ),
    );

    if (response.isNotEmpty) {
      try {
        data = HomeDataModel.fromJson(response);

        var newUser = user?.copyWith(
          userId: data.userId,
          name: data.name,
        );

        if (newUser?.hasUser == true) {
          await _userService.saveLoginCredential(newUser!);
        }

        locator<JsonCacheSevice>().updateCache(
          url: "kpi",
          method: "GET",
          response: data.kpi?.toJson() ?? {},
          userId: user?.userId,
        );
      } catch (e) {
        throw "FH Invalid data format\n$e";
      }
    }

    return data;
  }

  Future<bool> pushDayLogs({
    required List<Map<String, dynamic>> dayLogs,
  }) async {
    bool status = false;

    var (statusCode, _) = await http.post(
      url: Uri.parse(
        "$instanceUrl/services/apexrest/api/day",
      ),
      body: {
        "dataList": [
          {"day": dayLogs}
        ]
      },
      headers: {
        HttpHeaders.contentTypeHeader: "application/json",
      },
      jsonEncodeBody: true,
      toast: false,
      logResponse: true,
    );

    if (statusCode == HttpStatus.ok) {
      status = true;
    }

    return status;
  }

  Future<(bool, List<PushRecordResponseItemModel>)> pushVisits({
    required List<Map<String, dynamic>> visits,
  }) async {
    bool status = false;
    List<PushRecordResponseItemModel> results = [];

    var (statusCode, response) = await http.post(
      url: Uri.parse(
        "$instanceUrl/services/apexrest/api/visits",
      ),
      body: {
        "dataList": [
          {"visit": visits}
        ]
      },
      headers: {
        HttpHeaders.contentTypeHeader: "application/json",
      },
      jsonEncodeBody: true,
      toast: false,
      logResponse: true,
    );

    if (statusCode == HttpStatus.ok) {
      status = true;

      if (response['results'] is List) {
        for (var item in response['results']) {
          results.add(PushRecordResponseItemModel.fromJson(item));
        }
      }
    }

    return (status, results);
  }

  Future<(bool, List<PushFilesResponseItemModel>)> pushFiles({
    required List<Map<String, dynamic>> filesRecords,
  }) async {
    bool status = false;
    List<PushFilesResponseItemModel> results = [];

    var (statusCode, response) = await http.post(
      url: Uri.parse(
        "$instanceUrl/services/data/v44.0/composite/tree/ContentVersion",
      ),
      body: {
        "records": filesRecords,
      },
      headers: {
        HttpHeaders.contentTypeHeader: "application/json",
      },
      jsonEncodeBody: true,
      toast: false,
      logResponse: true,
    );

    if (statusCode == HttpStatus.ok || statusCode == HttpStatus.created) {
      status = true;

      if (response['results'] is List) {
        for (var item in response['results']) {
          results.add(PushFilesResponseItemModel.fromJson(item));
        }
      }
    }

    return (status, results);
  }

  Future<bool> pushOrders({
    required List<Map<String, dynamic>> orders,
  }) async {
    bool status = false;

    var (statusCode, _) = await http.post(
      url: Uri.parse(
        "$instanceUrl/services/apexrest/api/orders",
      ),
      body: {
        "dataList": [
          {"order": orders}
        ]
      },
      headers: {
        HttpHeaders.contentTypeHeader: "application/json",
      },
      jsonEncodeBody: true,
      toast: false,
      logResponse: true,
    );

    if (statusCode == HttpStatus.ok) {
      status = true;
    }

    return status;
  }

  Future<bool> pushVisitPlans({
    required List<Map<String, dynamic>> visitPlans,
  }) async {
    bool status = false;

    var (statusCode, _) = await http.post(
      url: Uri.parse(
        "$instanceUrl/services/apexrest/api/visitPlan",
      ),
      body: {
        "dataList": [
          {"visitPlan": visitPlans}
        ]
      },
      headers: {
        HttpHeaders.contentTypeHeader: "application/json",
      },
      jsonEncodeBody: true,
      toast: false,
      logResponse: true,
    );

    if (statusCode == HttpStatus.ok) {
      status = true;
    }

    return status;
  }

  Future<bool> pushAccounts({
    required List<Map<String, dynamic>> accounts,
  }) async {
    bool status = false;

    var (statusCode, _) = await http.post(
      url: Uri.parse(
        "$instanceUrl/services/apexrest/api/accounts",
      ),
      body: {
        "dataList": [
          {"account": accounts}
        ]
      },
      headers: {
        HttpHeaders.contentTypeHeader: "application/json",
      },
      jsonEncodeBody: true,
      toast: false,
      logResponse: true,
    );

    if (statusCode == HttpStatus.ok) {
      status = true;
    }

    return status;
  }

  Future<(bool, List<PushRecordResponseItemModel>)> pushExpenses({
    required List<Map<String, dynamic>> expenses,
  }) async {
    bool status = false;
    List<PushRecordResponseItemModel> results = [];

    var (statusCode, response) = await http.post(
      url: Uri.parse(
        "$instanceUrl/services/apexrest/api/expenses",
      ),
      body: {
        "dataList": [
          {"expense": expenses}
        ]
      },
      headers: {
        HttpHeaders.contentTypeHeader: "application/json",
      },
      jsonEncodeBody: true,
      toast: false,
      logResponse: true,
    );

    if (statusCode == HttpStatus.ok) {
      status = true;

      if (response['results'] is List) {
        for (var item in response['results']) {
          results.add(PushRecordResponseItemModel.fromJson(item));
        }
      }
    }

    return (status, results);
  }

  Future<bool> pushStocks({
    required List<Map<String, dynamic>> stocks,
  }) async {
    bool status = false;

    var (statusCode, _) = await http.post(
      url: Uri.parse(
        "$instanceUrl/services/apexrest/api/stocks",
      ),
      body: {
        "dataList": [
          {"stock": stocks}
        ]
      },
      headers: {
        HttpHeaders.contentTypeHeader: "application/json",
      },
      jsonEncodeBody: true,
      toast: false,
      logResponse: true,
    );

    if (statusCode == HttpStatus.ok) {
      status = true;
    }

    return status;
  }

  Future<bool> pushTickets({
    required List<Map<String, dynamic>> tickets,
  }) async {
    bool status = false;

    var (statusCode, _) = await http.post(
      url: Uri.parse(
        "$instanceUrl/services/apexrest/api/tickets",
      ),
      body: {
        "dataList": [
          {"ticket": tickets}
        ]
      },
      headers: {
        HttpHeaders.contentTypeHeader: "application/json",
      },
      jsonEncodeBody: true,
      toast: false,
      logResponse: true,
    );

    if (statusCode == HttpStatus.ok) {
      status = true;
    }

    return status;
  }

  Future<bool> pushCompetition({
    required List<Map<String, dynamic>> competitions,
  }) async {
    bool status = false;

    var (statusCode, _) = await http.post(
      url: Uri.parse(
        "$instanceUrl/services/apexrest/api/competition",
      ),
      body: {
        "dataList": [
          {"competition": competitions}
        ]
      },
      headers: {
        HttpHeaders.contentTypeHeader: "application/json",
      },
      jsonEncodeBody: true,
      toast: false,
      logResponse: true,
    );

    if (statusCode == HttpStatus.ok) {
      status = true;
    }

    return status;
  }

  Future<bool> pushPaymentFollowUp({
    required List<Map<String, dynamic>> paymentFollowUps,
  }) async {
    bool status = false;

    var (statusCode, _) = await http.post(
      url: Uri.parse(
        "$instanceUrl/services/apexrest/api/paymentFollowUp",
      ),
      body: {
        "dataList": [
          {"paymentFollowUp": paymentFollowUps}
        ]
      },
      headers: {
        HttpHeaders.contentTypeHeader: "application/json",
      },
      jsonEncodeBody: true,
      toast: false,
      logResponse: true,
    );

    if (statusCode == HttpStatus.ok) {
      status = true;
    }

    return status;
  }

  Future<bool> pushLeaves({
    required List<Map<String, dynamic>> leaves,
  }) async {
    bool status = false;

    var (statusCode, _) = await http.post(
      url: Uri.parse(
        "$instanceUrl/services/apexrest/api/leaves",
      ),
      body: {
        "dataList": [
          {"leave": leaves}
        ]
      },
      headers: {
        HttpHeaders.contentTypeHeader: "application/json",
      },
      jsonEncodeBody: true,
      toast: false,
      logResponse: true,
    );

    if (statusCode == HttpStatus.ok) {
      status = true;
    }

    return status;
  }

  Future<void> logout() async {
    await http.get(
      url: Uri.tryParse(
        "$instanceUrl/services/oauth2/revoke",
      ),
      body: {"token": user?.accessToken},
    );
  }
}

enum ApiEnvironment {
  dev("https://login.salesforce.com/services/oauth2/token"),
  prod("");

  const ApiEnvironment(this.baseUrl);

  final String baseUrl;
}
