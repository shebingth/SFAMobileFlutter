import 'dart:convert';

import 'package:flutter/material.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked/stacked_annotations.dart';

import '../app/app.locator.dart';
import '../app/app.router.dart';
import '../models/user.dart';
import '../ui/common/app_constants.dart';
import '../ui/common/utils.dart';

import 'api_service.dart';
import 'json_cache_service.dart';
import 'upload_service.dart';

class UserService with InitializableDependency, ListenableServiceMixin {
  late SharedPreferences preferences;
  final _userData = ReactiveValue<AppUser?>(null);

  @override
  Future<void> init() async {
    preferences = await SharedPreferences.getInstance();
  }

  UserService() {
    listenToReactiveValues([_userData]);
  }

  AppUser? get user => _userData.value;

  Future<void> saveLoginCredential(AppUser newUser) async {
    _userData.value = AppUser.fromJson(newUser.toJson());
    await preferences.setString(Prefs.user, jsonEncode(user!.toJson()));
  }

  Future<void> saveLastUser(String userName) async {
    await preferences.setString(Prefs.lastUser, userName);
  }

  bool isLastUser(String userName) {
    return preferences.getString(Prefs.lastUser) == userName;
  }

  Future<AppUser?> loadCredential() async {
    String? value = preferences.getString(Prefs.user);
    if (value != null) {
      _userData.value = AppUser.fromJson(jsonDecode(value));
    } else {
      _userData.value = null;
    }
    return user;
  }

  Future<void> logout({bool callApi = true}) async {
    if (callApi) {
      try {
        await locator<ApiService>().logout();
      } catch (e) {
        debugPrint("$e");
      }
    }
    locator<UploadService>().stopStream();
    locator<JsonCacheSevice>().clearCache();
    clearUser();
    navigationService.clearStackAndShow(Routes.loginView);
  }

  Future<void> clearUser() async {
    _userData.value = null;
    await preferences.remove(Prefs.user);
  }
}
