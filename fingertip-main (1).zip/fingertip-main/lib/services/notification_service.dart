import 'dart:convert';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import '../models/basics.dart';
import '../ui/common/app_colors.dart';

class NotificationService {
  final messaging = FirebaseMessaging.instance;
  final flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  Future<void> registerPushNotificationHandler() async {
    NotificationSettings settings = await messaging.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      debugPrint('User granted permission');
    } else if (settings.authorizationStatus ==
        AuthorizationStatus.provisional) {
      debugPrint('User granted provisional permission');
    } else {
      debugPrint('User declined or has not accepted permission');
    }

    await messaging.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );
    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      'high_importance_channel',
      'High Importance Notifications',
      description: 'This channel is used for important notifications.',
      importance: Importance.max,
    );

    var initializationSettingsAndroid = const AndroidInitializationSettings(
      '@drawable/ic_stat_icon',
    );
    var initializationSettingsIOS = const DarwinInitializationSettings();
    var initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsIOS,
    );
    flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: onSelectNotification,
    );

    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      debugPrint(
          "\nForground message notification: ${message.notification?.title} : "
          "${message.notification?.body}");
      debugPrint("Forground message data: ${message.data.toString()}");

      RemoteNotification? notification = message.notification;
      if (notification != null) {
        flutterLocalNotificationsPlugin.show(
          notification.hashCode,
          notification.title,
          notification.body,
          NotificationDetails(
            android: AndroidNotificationDetails(
              channel.id,
              channel.name,
              channelDescription: channel.description,
              color: Palette.primary,
            ),
          ),
          payload: jsonEncode(message.data),
        );
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      debugPrint("Message Clicked: ${message.data.toString()}");

      var notificationData = PushNotificationModel.fromJson(message.data);

      navigateFromNotification(notificationData: notificationData);
    });

    RemoteMessage? initialMessage = await messaging.getInitialMessage();
    if (initialMessage != null) {
      debugPrint("Initial Message Clicked: ${initialMessage.data.toString()}");

      var notificationData = PushNotificationModel.fromJson(
        initialMessage.data,
      );

      navigateFromNotification(notificationData: notificationData);
    }

    debugPrint("Notification Service Registered");
  }

  void onSelectNotification(NotificationResponse data) {
    debugPrint("Local Message Clicked: ${data.payload}");

    if (data.payload?.isNotEmpty ?? false) {
      Map<String, dynamic> payload = jsonDecode(data.payload!);
      debugPrint("Local Message Clicked: $payload");
      var notificationData = PushNotificationModel.fromJson(payload);

      navigateFromNotification(notificationData: notificationData);
    }
  }

  Future<String> getDeviceToken() async {
    String token = "unknown_token";
    try {
      token = await messaging.getToken() ?? "unknown_token";
      debugPrint('FirebaseToken: $token');
    } catch (e) {
      debugPrint('FirebaseToken Error: $e');
    }
    return token;
  }
}

Future<void> navigateFromNotification({
  required PushNotificationModel notificationData,
}) async {}
