import 'dart:async';
import 'dart:developer';

import 'package:flutter/foundation.dart';

import 'package:collection/collection.dart';
import 'package:internet_connection_checker_plus/internet_connection_checker_plus.dart';
import 'package:rxdart/rxdart.dart';

import '../app/app.locator.dart';
import '../database/database.dart';
import '../database/tools.dart';
import '../extensions/account.dart';
import '../extensions/daylog.dart';
import '../extensions/expense_file.dart';
import '../extensions/payment_follow_up.dart';
import '../extensions/visit.dart';
import '../extensions/visit_file.dart';
import '../extensions/visit_plan.dart';
import '../models/expense.dart';
import '../models/home.dart';
import '../models/leaves.dart';
import '../models/order.dart';
import '../models/stock.dart';
import '../models/ticket.dart';

import 'api_service.dart';
import 'user_service.dart';

class UploadService {
  final _internetChecker = InternetConnection();
  final _databaseService = locator<DatabaseService>();
  final _apiService = locator<ApiService>();
  final _userService = locator<UserService>();
  static const bool disableUpload = false;

  StreamSubscription<StreamCombinedModel>? subscription;
  bool isBusy = false;

  Future<void> registerStreams() async {
    await subscription?.cancel();
    final stream = Rx.combineLatest(
      [
        _internetChecker.onStatusChange,
        Stream.periodic(const Duration(seconds: 10), (int x) => x),
        _databaseService.watchDesyncedDayLogs(),
        _databaseService.watchDesyncedVisits(),
        _databaseService.watchDesyncedOrders(),
        _databaseService.watchDesyncedVisitFiles(),
        _databaseService.watchDesyncedVisitPlans(),
        _databaseService.watchDesyncedAccounts(),
        _databaseService.watchDesyncedExpenses(),
        _databaseService.watchDesyncedStock(),
        _databaseService.watchDesyncedTicket(),
        _databaseService.watchDesyncedCompetition(),
        _databaseService.watchDesyncedExpenseFiles(),
        _databaseService.watchDesyncedAccountFiles(),
        _databaseService.watchDesyncedPaymentFollowUps(),
        _databaseService.watchDesyncedLeaves(),
      ],
      (values) {
        return StreamCombinedModel(
          internetStatus: values[0] as InternetStatus,
          count: values[1] as int,
          dayLogs: values[2] as List<DayLog>,
          visits: values[3] as List<Visit>,
          orders: values[4] as List<Order>,
          visitFiles: values[5] as List<VisitFile>,
          visitPlans: values[6] as List<VisitPlan>,
          accounts: values[7] as List<Account>,
          expenses: values[8] as List<ExpenseHelper>,
          stocks: values[9] as List<StockHelper>,
          tickets: values[10] as List<TicketHelper>,
          competitions: values[11] as List<Competition>,
          expenseItemFiles: values[12] as List<ExpenseItemFile>,
          accountFiles: values[13] as List<AccountFile>,
          paymentFollowUps: values[14] as List<PaymentFollowUp>,
          leaves: values[15] as List<LeaveHelper>,
        );
      },
    );

    subscription = stream.listen(
      (event) {
        lockedExecution(event);
      },
    );

    log("-------Upload Stream Registered-------");
  }

  Future<void> lockedExecution(StreamCombinedModel event) async {
    if (isBusy) return;
    isBusy = true;
    await onData(event);
    isBusy = false;
  }

  Future<void> onData(StreamCombinedModel event) async {
    try {
      if (_userService.user?.hasUser != true) return;

      log(
        "-----Stream Triggered------\n"
        "${event.internetStatus}\t"
        "Count ${event.count}\n"
        "DayLogs ${event.dayLogs.length}\t"
        "Visits ${event.visits.length}\t"
        "Orders ${event.orders.length}\t"
        "Visit Files ${event.visitFiles.length}\t\t"
        "Visit Plans ${event.visitPlans.length}\t"
        "Accounts ${event.accounts.length}\t"
        "Expenses ${event.expenses.length}\n"
        "Stocks ${event.stocks.length}\t"
        "Tickets ${event.tickets.length}\t"
        "Competitions ${event.competitions.length}\t"
        "Expense Item Files ${event.expenseItemFiles.length}\t"
        "Account Files ${event.accountFiles.length}\t"
        "Payment Follow Ups ${event.paymentFollowUps.length}\t"
        "Leaves ${event.leaves.length}\n",
      );

      if (disableUpload) return;

      if (event.internetStatus == InternetStatus.connected) {
        //Upload daylogs
        if (event.dayLogs.isNotEmpty) {
          var dayLogData = event.dayLogs.map((dayLog) {
            return dayLog.toApi();
          }).toList();

          try {
            var status = await _apiService.pushDayLogs(dayLogs: dayLogData);

            if (status) {
              await _databaseService.markDayLogsAsSynced(event.dayLogs);
            }
          } catch (e) {
            debugPrint("$e");
          }
        }

        //Accounts
        if (event.accounts.isNotEmpty) {
          var accountsDataApi = event.accounts.map((account) {
            return account.toApi();
          }).toList();

          try {
            var status = await _apiService.pushAccounts(
              accounts: accountsDataApi,
            );

            if (status) {
              await _databaseService.markAccountsAsSynced(event.accounts);
            }
          } catch (e) {
            debugPrint("$e");
          }
        }

        //Account Files
        if (event.accountFiles.isNotEmpty) {
          var accountsWithFiles =
              await _databaseService.getAccountByAppAccountId(
            event.accountFiles
                .map((e) => e.appAccountId)
                .whereNotNull()
                .toList(),
          );

          List<Map<String, dynamic>> accountFilesRecords = [];

          for (var item in event.accountFiles) {
            var accountRecordId = accountsWithFiles.firstWhereOrNull((element) {
              return element.appAccountId == item.appAccountId;
            })?.id;

            if (accountRecordId != null) {
              accountFilesRecords.add(item.toApi(recordId: accountRecordId));
            }
          }

          if (accountFilesRecords.isNotEmpty) {
            var (status, results) = await _apiService.pushFiles(
              filesRecords: accountFilesRecords,
            );

            if (status && results.isNotEmpty) {
              await _databaseService.markAccountFilesAsSynced(
                results.where((element) {
                  return element.referenceId != null;
                }).map((e) {
                  return e.referenceId!;
                }).toList(),
              );
            }
          }
        }

        //Upload visit plans
        if (event.visitPlans.isNotEmpty) {
          var visitPlanDataApi = event.visitPlans.map((visitPlan) {
            return visitPlan.toApi();
          }).toList();

          try {
            var status = await _apiService.pushVisitPlans(
              visitPlans: visitPlanDataApi,
            );

            if (status) {
              await _databaseService.markVisitPlansAsSynced(event.visitPlans);
            }
          } catch (e) {
            debugPrint("$e");
          }
        }

        //Upload visits
        if (event.visits.isNotEmpty) {
          var visitDataApi = event.visits.map((visit) {
            return visit.toApi();
          }).toList();

          try {
            var (status, results) = await _apiService.pushVisits(
              visits: visitDataApi,
            );

            if (status && results.isNotEmpty) {
              await _databaseService.markVisitAsSyncedAndUpdateId(results);
            }
          } catch (e) {
            debugPrint("$e");
          }
        }

        //Upload visit files
        if (event.visitFiles.isNotEmpty) {
          var visitsWithFiles = await _databaseService.getVisitsBySalesAppIds(
            event.visitFiles.map((e) => e.salesAppId).toList(),
          );

          List<Map<String, dynamic>> visitFilesRecords = [];

          for (var item in event.visitFiles) {
            var visitRecordId = visitsWithFiles.firstWhereOrNull((element) {
              return element.salesAppId == item.salesAppId;
            })?.id;

            if (visitRecordId != null) {
              visitFilesRecords.add(item.toApi(visitRecordId: visitRecordId));
            }
          }

          if (visitFilesRecords.isNotEmpty) {
            var (status, results) = await _apiService.pushFiles(
              filesRecords: visitFilesRecords,
            );

            if (status && results.isNotEmpty) {
              await _databaseService.markVisitFilesAsSynced(
                results.where((element) {
                  return element.referenceId != null;
                }).map((e) {
                  return e.referenceId!;
                }).toList(),
              );
            }
          }
        }

        //Upload orders
        if (event.orders.isNotEmpty) {
          var orderItemsDb = await _databaseService.getOrderItems();
          var orderItems = orderItemsDb.map((e) {
            return OrderItemModel.fromJson(e.toJson());
          }).toList();
          var orderDatas = event.orders.map((e) {
            return OrderModel.fromJson(
              e.toJson(serializer: const CustomValueSerializer()),
            );
          }).toList();

          for (OrderModel order in orderDatas) {
            order.orderItems = orderItems.where((e) {
              return e.appOrderId == order.appOrderId;
            }).toList();
          }

          var orderDataApi = orderDatas.map((e) {
            return e.toPushApi();
          }).toList();

          try {
            var status = await _apiService.pushOrders(orders: orderDataApi);

            if (status) {
              await _databaseService.markOrdersAsSynced(event.orders);
            }
          } catch (e) {
            debugPrint("$e");
          }
        }

        //Expenses
        if (event.expenses.isNotEmpty) {
          var expenseItems = await _databaseService.getExpenseItems();
          for (var expense in event.expenses) {
            expense.items = [];
            expense.items = expenseItems.where((element) {
              return element.appExpId == expense.appExpId;
            }).toList();
          }

          var expensesDataApi = event.expenses.map((expense) {
            return expense.toApi();
          }).toList();

          try {
            var (status, results) = await _apiService.pushExpenses(
              expenses: expensesDataApi,
            );

            if (status && results.isNotEmpty) {
              await _databaseService.markExpenseAsSyncedAndUpdateId(results);
            }
          } catch (e) {
            debugPrint("$e");
          }
        }

        //Expense Item Files
        if (event.expenseItemFiles.isNotEmpty) {
          var expensesWithFiles = await _databaseService.getExpenseByAppExpId(
            event.expenseItemFiles
                .map((e) => e.appExpId)
                .whereNotNull()
                .toList(),
          );

          List<Map<String, dynamic>> expenseFilesRecords = [];

          for (var item in event.expenseItemFiles) {
            var expenseRecordId = expensesWithFiles.firstWhereOrNull((element) {
              return element.appExpId == item.appExpId;
            })?.id;

            if (expenseRecordId != null) {
              expenseFilesRecords.add(item.toApi(recordId: expenseRecordId));
            }
          }

          if (expenseFilesRecords.isNotEmpty) {
            var (status, results) = await _apiService.pushFiles(
              filesRecords: expenseFilesRecords,
            );

            if (status && results.isNotEmpty) {
              await _databaseService.markExpenseItemFilesAsSynced(
                results.where((element) {
                  return element.referenceId != null;
                }).map((e) {
                  return e.referenceId!;
                }).toList(),
              );
            }
          }
        }

        //Stocks
        if (event.stocks.isNotEmpty) {
          var stocksDataApi = event.stocks.map((stock) {
            return stock.toJson();
          }).toList();

          try {
            var status = await _apiService.pushStocks(
              stocks: stocksDataApi,
            );

            if (status) {
              await _databaseService.markStockAsSynced(event.stocks);
            }
          } catch (e) {
            debugPrint("$e");
          }
        }

        //Tickets
        if (event.tickets.isNotEmpty) {
          var ticketsDataApi = event.tickets.map((ticket) {
            return ticket.toJson();
          }).toList();

          try {
            var status = await _apiService.pushTickets(
              tickets: ticketsDataApi,
            );

            if (status) {
              await _databaseService.markTicketAsSynced(event.tickets);
            }
          } catch (e) {
            debugPrint("$e");
          }
        }

        //Competition
        if (event.competitions.isNotEmpty) {
          var competitionDataApi = event.competitions.map((competition) {
            return competition.toJson();
          }).toList();

          try {
            var status = await _apiService.pushCompetition(
              competitions: competitionDataApi,
            );

            if (status) {
              await _databaseService.markCompetitionAsSynced(
                event.competitions,
              );
            }
          } catch (e) {
            debugPrint("$e");
          }
        }

        //Payment Follow Up
        if (event.paymentFollowUps.isNotEmpty) {
          var paymentFollowUpDataApi = event.paymentFollowUps.map((item) {
            return item.toApi();
          }).toList();

          try {
            var status = await _apiService.pushPaymentFollowUp(
              paymentFollowUps: paymentFollowUpDataApi,
            );

            if (status) {
              await _databaseService.markPaymentFollowUpsAsSynced(
                event.paymentFollowUps,
              );
            }
          } catch (e) {
            debugPrint("$e");
          }
        }

        //Leaves
        if (event.leaves.isNotEmpty) {
          var leavesDataApi = event.leaves.map((item) {
            return item.toApi();
          }).toList();

          try {
            var status = await _apiService.pushLeaves(
              leaves: leavesDataApi,
            );

            if (status) {
              await _databaseService.markLeavesAsSynced(event.leaves);
            }
          } catch (e) {
            debugPrint("$e");
          }
        }
      }
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  Future<void> stopStream() async {
    await subscription?.cancel();
  }
}
