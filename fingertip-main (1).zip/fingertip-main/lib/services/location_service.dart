import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:location/location.dart';
import 'package:open_app_settings/open_app_settings.dart';

import '../app/app.dialogs.dart';
import '../extensions/latlng.dart';
import '../models/latlng.dart';
import '../ui/common/utils.dart';

class LocationService {
  Location location = Location();
  bool _serviceEnabled = false;
  PermissionStatus? permissionGranted;

  LocationData? currentLocation;

  Future<bool> requestPermission() async {
    permissionGranted = await location.hasPermission();

    if (permissionGranted == PermissionStatus.granted ||
        permissionGranted == PermissionStatus.grantedLimited) {
      return true;
    }

    if (permissionGranted == PermissionStatus.denied) {
      permissionGranted = await location.requestPermission();

      if (permissionGranted == PermissionStatus.granted ||
          permissionGranted == PermissionStatus.grantedLimited) {
        return true;
      }

      if (permissionGranted == PermissionStatus.denied) {
        var res = await dialogService.showCustomDialog(
          variant: DialogType.confirm,
          title: "Location Permission",
          description:
              "Sorry location permission is required, Please grand location permission to continue.",
          mainButtonTitle: "Ok",
          secondaryButtonTitle: "Cancel",
        );

        if (res?.confirmed == true) {
          return await requestPermission();
        }
      }
    }
    if (permissionGranted == PermissionStatus.deniedForever) {
      var res = await dialogService.showCustomDialog(
        variant: DialogType.confirm,
        title: "Location Permission",
        description:
            "Sorry location permission is required, Please grand location permission from settings to continue.",
        mainButtonTitle: "Go to settings",
        secondaryButtonTitle: "Cancel",
      );

      if (res?.confirmed == true) {
        OpenAppSettings.openAppSettings();
      }
    }
    return false;
  }

  Future<LatLng?> getLocation() async {
    try {
      if (await requestPermission()) {
        _serviceEnabled = await location.serviceEnabled();
        if (!_serviceEnabled) {
          _serviceEnabled = await location.requestService();
        }

        currentLocation =
            await location.getLocation().timeout(const Duration(seconds: 8));
      }
    } catch (e) {
      debugPrint("$e");
    }

    return currentLocation.latLng;
  }
}
