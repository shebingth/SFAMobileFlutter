import 'package:hive_flutter/hive_flutter.dart';
import 'package:json_cache/json_cache.dart';
import 'package:stacked/stacked_annotations.dart';

import '../models/basics.dart';

class JsonCacheSevice with InitializableDependency {
  late final JsonCache jsonCache;

  @override
  Future<void> init() async {
    await Hive.initFlutter();
    final box = await Hive.openBox<String>('jsonCacheBox');
    jsonCache = JsonCacheMem(JsonCacheHive(box));
  }

  Future<bool> contains(String url) async {
    return await jsonCache.contains(url);
  }

  Future<void> updateCache({
    required String url,
    required String method,
    required Map<String, dynamic> response,
    required String? userId,
  }) async {
    var data = JsonCacheModel(
      method: method,
      response: response,
      dateTime: DateTime.now(),
      userId: userId,
    );

    await jsonCache.refresh(url, data.toJson());
  }

  Future<JsonCacheModel?> getJson(String url) async {
    var data = await jsonCache.value(url);
    if (data != null) {
      return JsonCacheModel.fromJson(data);
    }
    return null;
  }

  void remove(String url) async {
    await jsonCache.remove(url);
  }

  Future<void> clearCache() async {
    await jsonCache.clear();
  }
}
