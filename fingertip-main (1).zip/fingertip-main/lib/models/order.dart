import 'package:intl/intl.dart';

import '../database/database.dart';
import '../ui/tools/parse.dart';

class OrderModel {
  String? appOrderId;
  String? id;
  String? salesAppId;
  String? accountName;
  String? accountId;
  double? grandTotal;
  double? totalAmount;
  double? totalTax;
  String? status;
  DateTime? orderDate;
  List<OrderItemModel>? orderItems;
  String? name;

  OrderModel({
    this.appOrderId,
    this.id,
    this.salesAppId,
    this.accountName,
    this.accountId,
    this.grandTotal,
    this.totalAmount,
    this.totalTax,
    this.status,
    this.orderDate,
    this.orderItems,
    this.name,
  });

  OrderModel.fromJson(Map<String, dynamic> json) {
    appOrderId = parseToString(json['appOrderId']);
    id = parseToString(json['id']);
    salesAppId = parseToString(json['salesAppId']);
    accountName = parseToString(json['accountName']);
    accountId = parseToString(json['acccountId']);
    grandTotal = parseToDouble(json['grandTotal']);
    totalAmount = parseToDouble(json['totalAmount']);
    totalTax = parseToDouble(json['totalTax']);
    status = parseToString(json['status']);
    orderDate = parseToDateTime(json['orderDate']);
    orderItems = parseToList<OrderItemModel>(
      json['orderItems'],
      OrderItemModel.fromJson,
    );
    for (OrderItemModel element in orderItems ?? []) {
      element.appOrderId = appOrderId;
    }
    name = parseToString(json['Name']);
  }

  Order toOrder() {
    return Order.fromJson(toJson());
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data['appOrderId'] = appOrderId;
    data['id'] = id;
    data['salesAppId'] = salesAppId;
    data['accountName'] = accountName;
    data['acccountId'] = accountId;
    data['grandTotal'] = grandTotal;
    data['totalAmount'] = totalAmount;
    data['totalTax'] = totalTax;
    data['status'] = status;
    data['orderDate'] = orderDate?.toIso8601String();
    if (orderItems != null) {
      data['orderItems'] = orderItems!.map((v) => v.toJson()).toList();
    }
    data['Name'] = name;

    return data;
  }

  Map<String, dynamic> toPushApi() {
    final data = <String, dynamic>{};
    data['appOrderId'] = appOrderId;
    data['salesAppId'] = salesAppId;
    data['accountName'] = accountName;
    data['acccountId'] = accountId;
    data['grandTotal'] = grandTotal;
    data['totalAmount'] = totalAmount;
    data['totalTax'] = totalTax;
    data['status'] = status;
    if (orderDate != null) {
      data['orderDate'] = DateFormat('yyyy-MM-dd').format(orderDate!);
    }
    if (orderItems != null) {
      data['orderItems'] = orderItems!.map((v) => v.toPushApi()).toList();
    }
    return data;
  }
}

class OrderItemModel {
  int? id;
  String? appOrderId;
  String? productId;
  String? productName;
  int? quantity;
  double? unitPrice;
  double? taxPercent;
  double? taxAmount;
  double? totalAmount;
  double? totalTax;
  double? grandTotal;

  OrderItemModel({
    this.id,
    this.appOrderId,
    this.productId,
    this.productName,
    this.quantity,
    this.unitPrice,
    this.taxPercent,
    this.taxAmount,
    this.totalAmount,
    this.totalTax,
    this.grandTotal,
  });

  OrderItemModel.fromJson(Map<String, dynamic> json) {
    id = parseToInt(json['id']);
    appOrderId = parseToString(json['appOrderId']);
    productId = parseToString(json['productId']);
    productName = parseToString(json['productName']);
    quantity = parseToInt(json['quantity']);
    unitPrice = parseToDouble(json['unitPrice']);
    taxPercent = parseToDouble(json['taxPercent']);
    taxAmount = parseToDouble(json['taxAmount']);
    totalAmount = parseToDouble(json['totalAmount']);
    totalTax = parseToDouble(json['totalTax']);
    grandTotal = parseToDouble(json['grandTotal']);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data['id'] = id;
    data['appOrderId'] = appOrderId;
    data['productId'] = productId;
    data['productName'] = productName;
    data['quantity'] = quantity;
    data['unitPrice'] = unitPrice;
    data['taxPercent'] = taxPercent;
    data['taxAmount'] = taxAmount;
    data['totalAmount'] = totalAmount;
    data['totalTax'] = totalTax;
    data['grandTotal'] = grandTotal;
    return data;
  }

  Map<String, dynamic> toPushApi() {
    final Map<String, dynamic> data = {};
    data['productId'] = productId;
    data['productName'] = productName;
    data['quantity'] = quantity;
    data['unitPrice'] = unitPrice;
    data['taxPercent'] = taxPercent;
    data['taxAmount'] = taxAmount;
    data['totalAmount'] = totalAmount;
    data['totalTax'] = totalTax;
    data['grandTotal'] = grandTotal;
    return data;
  }

  OrderItem toOrderItem() {
    return OrderItem.fromJson(toJson());
  }
}
