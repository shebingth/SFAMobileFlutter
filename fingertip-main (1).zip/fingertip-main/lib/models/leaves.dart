import 'package:drift/drift.dart';

import '../database/database.dart';
import '../extensions/date_time.dart';
import '../ui/tools/parse.dart';

class LeaveHelper {
  String? id;
  String? appLeaveId;
  String? name;
  DateTime? startDate;
  DateTime? endDate;
  String? comments;
  String? reason;
  String? leaveType;
  String? leaveStatus;
  DateTime? lastModifiedDate;
  String? firstSecond;
  String? executiveName;
  String? executiveId;
  String? duration;
  DateTime? createdDate;
  bool? synced;

  LeaveHelper({
    this.id,
    this.appLeaveId,
    this.name,
    this.startDate,
    this.endDate,
    this.comments,
    this.reason,
    this.leaveType,
    this.leaveStatus,
    this.lastModifiedDate,
    this.firstSecond,
    this.executiveName,
    this.executiveId,
    this.duration,
    this.createdDate,
    this.synced,
  });

  LeavesCompanion toCompanion() {
    return LeavesCompanion(
      id: Value.absentIfNull(id),
      appLeaveId: Value.absentIfNull(appLeaveId),
      name: Value.absentIfNull(name),
      startDate: Value.absentIfNull(startDate),
      endDate: Value.absentIfNull(endDate),
      comments: Value.absentIfNull(comments),
      reason: Value.absentIfNull(reason),
      leaveType: Value.absentIfNull(leaveType),
      leaveStatus: Value.absentIfNull(leaveStatus),
      lastModifiedDate: Value.absentIfNull(lastModifiedDate),
      firstSecond: Value.absentIfNull(firstSecond),
      executiveName: Value.absentIfNull(executiveName),
      executiveId: Value.absentIfNull(executiveId),
      duration: Value.absentIfNull(duration),
      createdDate: Value.absentIfNull(createdDate),
      synced: Value.absentIfNull(synced),
    );
  }

  LeaveHelper.fromJson(Map<String, dynamic> json) {
    id = parseToString(json['id']);
    appLeaveId = parseToString(json['appLeaveId']);
    name = parseToString(json['name']);
    startDate = parseToDateTime(json['startDate']);
    endDate = parseToDateTime(json['endDate']);
    comments = parseToString(json['comments']);
    reason = parseToString(json['reason']);
    leaveType = parseToString(json['leaveType']);
    leaveStatus = parseToString(json['leaveStatus']);
    lastModifiedDate = parseToDateTime(json['lastModifiedDate']);
    firstSecond = parseToString(json['firstSecond']);
    executiveName = parseToString(json['executiveName']);
    executiveId = parseToString(json['executiveId']);
    duration = parseToString(json['duration']);
    createdDate = parseToDateTime(json['createdDate']);
    synced = parseToBool(json['synced']);
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['appLeaveId'] = appLeaveId;
    data['name'] = name;
    data['startDate'] = startDate?.toIso8601String();
    data['endDate'] = endDate?.toIso8601String();
    data['comments'] = comments;
    data['reason'] = reason;
    data['leaveType'] = leaveType;
    data['leaveStatus'] = leaveStatus;
    data['lastModifiedDate'] = lastModifiedDate?.toIso8601String();
    data['firstSecond'] = firstSecond;
    data['executiveName'] = executiveName;
    data['executiveId'] = executiveId;
    data['duration'] = duration;
    data['createdDate'] = createdDate?.toIso8601String();
    data['synced'] = synced;
    return data;
  }

  Map<String, dynamic> toApi() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['appLeaveId'] = appLeaveId;
    data['name'] = name;
    data['startDate'] = startDate.toFormattedDate(format: "yyyy-MM-dd");
    data['endDate'] = endDate.toFormattedDate(format: "yyyy-MM-dd");
    data['comments'] = comments;
    data['reason'] = reason;
    data['leaveType'] = leaveType;
    data['leaveStatus'] = leaveStatus;
    data['lastModifiedDate'] = lastModifiedDate?.toIso8601String();
    data['firstSecond'] = firstSecond;
    data['executiveName'] = executiveName;
    data['executiveId'] = executiveId;
    data['createdDate'] = createdDate?.toIso8601String();
    data['duration'] = duration;
    return data;
  }
}
