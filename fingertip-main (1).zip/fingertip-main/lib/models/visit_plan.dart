import '../database/database.dart';

class VisitPlanAddParams {
  String visitPlanId;
  VisitPlan visitPlan;
  DateTime date;
  List<Account> accounts;
  List<VisitCustomModel> visits;

  VisitPlanAddParams({
    required this.visitPlanId,
    required this.visitPlan,
    required this.date,
    required this.accounts,
    required this.visits,
  });
}

class VisitCustomModel {
  Account account;
  DateTime dateTime;
  String? visitType;
  bool hasTimeSet;

  VisitCustomModel({
    required this.account,
    required this.dateTime,
    this.visitType,
    this.hasTimeSet = false,
  });
}
