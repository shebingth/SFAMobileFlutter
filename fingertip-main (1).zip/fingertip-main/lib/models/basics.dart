import 'dart:convert';

import '../ui/common/app_constants.dart';
import '../ui/tools/parse.dart';

class BasicResponse {
  String? error;
  String? errorDescription;
  int? statusCode;

  BasicResponse({
    this.error,
    this.errorDescription,
    this.statusCode,
  });

  BasicResponse.fromJson(Map<String, dynamic> json) {
    error = parseToString(json['error']);
    errorDescription = parseToString(json['error_description']);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data['error'] = error;
    data['error_description'] = errorDescription;
    return data;
  }
}

class JsonCacheModel {
  String method;
  Map<String, dynamic> response;
  DateTime dateTime;
  String? userId;

  JsonCacheModel({
    required this.method,
    required this.response,
    required this.dateTime,
    required this.userId,
  });

  factory JsonCacheModel.fromJson(Map<String, dynamic> json) {
    return JsonCacheModel(
      method: json['method'],
      response: json['response'],
      dateTime: DateTime.parse(json['date_time']),
      userId: parseToString(json['user_id']),
    );
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['method'] = method;
    data['response'] = response;
    data['date_time'] = dateTime.toIso8601String();
    data['user_id'] = userId;
    return data;
  }
}

class ToastModel {
  late String message;
  late ToastType type;

  ToastModel({
    required this.message,
    required this.type,
  });

  ToastModel.fromJson(Map<String, dynamic> json) {
    message = json['message'] ?? "";
    type = ToastType.fromValue(json['type']);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    data['type'] = type.value;
    return data;
  }

  @override
  String toString() {
    return jsonEncode(toJson());
  }

  ToastModel.fromString(String data) {
    var toast = ToastModel.fromJson(jsonDecode(data));
    message = toast.message;
    type = toast.type;
  }
}

class PushNotificationModel {
  String? type;
  int? id;

  PushNotificationModel({
    this.type,
    this.id,
  });

  PushNotificationModel.fromJson(Map<String, dynamic> json) {
    type = parseToString(json['type']);
    id = parseToInt(json['id']);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['type'] = type;
    data['id'] = id;
    return data;
  }
}

class OptionModel {
  String? label;
  String? value;

  OptionModel({
    this.label,
    this.value,
  });

  OptionModel.fromJson(Map<String, dynamic> json) {
    label = parseToString(json['label']);
    value = parseToString(json['value']);
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['label'] = label;
    data['value'] = value;
    return data;
  }
}
