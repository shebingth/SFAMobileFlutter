import '../ui/tools/parse.dart';

class SortModel {
  String type;
  String label;
  bool isAscending;

  SortModel({
    required this.type,
    required this.label,
    this.isAscending = true,
  });
}

class FilterModel {
  String type;
  String label;
  String? value;
  FilterOptionModel? valueOption;
  List<FilterOptionModel>? options;
  DateTime? valueFromDate;
  DateTime? valueToDate;
  bool isNumeric;
  String? minValue;
  String? maxValue;
  DateTime? firstDate;
  DateTime? lastDate;

  FilterModel({
    required this.type,
    required this.label,
    this.value,
    this.valueOption,
    this.options,
    this.valueFromDate,
    this.valueToDate,
    this.isNumeric = false,
    this.minValue,
    this.maxValue,
    this.firstDate,
    this.lastDate,
  });

  double? get minValueAsDouble => parseToDouble(minValue);

  double? get maxValueAsDouble => parseToDouble(maxValue);

  int? get minValueAsInt => parseToInt(minValue);

  int? get maxValueAsInt => parseToInt(maxValue);

  double? get valueAsDouble => parseToDouble(value);

  int? get valueAsInt => parseToInt(value);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is FilterModel && other.type == type && other.label == label;
  }

  @override
  int get hashCode {
    return type.hashCode ^ label.hashCode;
  }

  FilterModel copyWith({
    String? type,
    String? label,
    String? value,
    FilterOptionModel? valueOption,
    List<FilterOptionModel>? options,
    DateTime? valueFromDate,
    DateTime? valueToDate,
    bool? isNumeric,
    String? minValue,
    String? maxValue,
    DateTime? firstDate,
    DateTime? lastDate,
  }) {
    return FilterModel(
      type: type ?? this.type,
      label: label ?? this.label,
      value: value ?? this.value,
      valueOption: valueOption ?? this.valueOption,
      options: options ?? this.options,
      valueFromDate: valueFromDate ?? this.valueFromDate,
      valueToDate: valueToDate ?? this.valueToDate,
      isNumeric: isNumeric ?? this.isNumeric,
      minValue: minValue ?? this.minValue,
      maxValue: maxValue ?? this.maxValue,
      firstDate: firstDate ?? this.firstDate,
      lastDate: lastDate ?? this.lastDate,
    );
  }
}

class FilterOptionModel {
  String? label;
  String? value;

  FilterOptionModel({
    this.label,
    this.value,
  });

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is FilterOptionModel &&
        other.label == label &&
        other.value == value;
  }

  @override
  int get hashCode => label.hashCode ^ value.hashCode;
}
