import 'package:internet_connection_checker_plus/internet_connection_checker_plus.dart';

import '../app/app.logger.dart';
import '../database/database.dart';
import '../database/tools.dart';
import '../ui/tools/parse.dart';

import 'competition.dart';
import 'expense.dart';
import 'invoice.dart';
import 'latlng.dart';
import 'leaves.dart';
import 'order.dart';
import 'payment_follow_up.dart';
import 'product.dart';
import 'stock.dart';
import 'ticket.dart';

class HomeDataModel {
  List<Account>? accounts;
  List<ProductHelper>? products;
  List<Visit>? visits;
  List<OrderModel>? orders;
  DayLogModel? dayLog;
  KpiModel? kpi;
  String? name;
  String? userId;
  List<VisitPlan>? visitPlans;
  List<AccountRoute>? routes;
  List<ExpenseHelper>? expenses;
  List<CompetitiorHelper>? competitiors;
  List<StockHelper>? stocks;
  List<TicketHelper>? tickets;
  List<CompetitionHelper>? competitions;
  List<PaymentFollowUpHelper>? paymentFollowUps;
  List<PaymentReceipt>? paymentReceipts;
  List<InvoiceHelper>? invoices;
  List<LeaveHelper>? leaves;

  HomeDataModel({
    this.accounts,
    this.products,
    this.visits,
    this.orders,
    this.dayLog,
    this.kpi,
    this.name,
    this.userId,
    this.visitPlans,
    this.routes,
    this.expenses,
    this.competitiors,
    this.stocks,
    this.tickets,
    this.competitions,
    this.paymentFollowUps,
    this.paymentReceipts,
    this.invoices,
    this.leaves,
  });

  HomeDataModel.fromJson(Map<String, dynamic> json) {
    accounts = parseToList<Account>(
      json['account'],
      (map) => Account.fromJson(map, serializer: const CustomValueSerializer()),
    );
    products = parseToList<ProductHelper>(
      json['product'],
      ProductHelper.fromJson,
    );
    visits = parseToList<Visit>(
      json['visit'],
      (map) => Visit.fromJson(map, serializer: const CustomValueSerializer()),
    );
    orders = parseToList<OrderModel>(
      json['order'],
      OrderModel.fromJson,
    );
    dayLog = parseToObject<DayLogModel>(
      json,
      DayLogModel.fromJson,
    );
    kpi = parseToObject<KpiModel>(
      json['kpi'],
      KpiModel.fromJson,
    );
    name = parseToString(json['name']);
    userId = parseToString(json['id']);
    visitPlans = parseToList<VisitPlan>(
      json['visitPlan'],
      (map) => VisitPlan.fromJson(
        map,
        serializer: const CustomValueSerializer(),
      ),
    );
    routes = parseToList<AccountRoute>(
      json['route'],
      AccountRoute.fromJson,
    );
    expenses = parseToList<ExpenseHelper>(
      json['expense'],
      ExpenseHelper.fromApi,
    );
    competitiors = parseToList<CompetitiorHelper>(
      json['competitior'],
      CompetitiorHelper.fromJson,
    );
    stocks = parseToList<StockHelper>(
      json['stock'],
      StockHelper.fromJson,
    );
    tickets = parseToList<TicketHelper>(
      json['ticket'],
      TicketHelper.fromJson,
    );
    competitions = parseToList<CompetitionHelper>(
      json['competition'],
      CompetitionHelper.fromJson,
    );
    paymentFollowUps = parseToList<PaymentFollowUpHelper>(
      json['paymentFollowUp'],
      PaymentFollowUpHelper.fromJson,
    );
    paymentReceipts = parseToList<PaymentReceipt>(
      json['paymentReceipt'],
      PaymentReceipt.fromJson,
    );
    invoices = parseToList<InvoiceHelper>(
      json['invoice'],
      InvoiceHelper.fromJson,
    );
    leaves = parseToList<LeaveHelper>(
      json['leave'],
      LeaveHelper.fromJson,
    );
  }

  void logLength() {
    final logger = getLogger('HomeDataModel');
    logger.w(
      "Account: ${accounts?.length ?? 0},\n"
      "Product: ${products?.length ?? 0},\n"
      "Visit: ${visits?.length ?? 0},\n"
      "Order: ${orders?.length ?? 0},\n"
      "VisitPlan: ${visitPlans?.length ?? 0},\n"
      "Route: ${routes?.length ?? 0},\n"
      "Expense: ${expenses?.length ?? 0},\n"
      "Competitior: ${competitiors?.length ?? 0},\n"
      "Stock: ${stocks?.length ?? 0},\n"
      "Ticket: ${tickets?.length ?? 0},\n"
      "Competition: ${competitions?.length ?? 0},\n"
      "PaymentFollowUp: ${paymentFollowUps?.length ?? 0},\n"
      "PaymentReceipt: ${paymentReceipts?.length ?? 0},\n"
      "Invoice: ${invoices?.length ?? 0},\n"
      "Leave: ${leaves?.length ?? 0},\n",
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};

    if (accounts != null) {
      data['account'] = accounts!.map((v) => v.toJson()).toList();
    }
    if (products != null) {
      data['product'] = products!.map((v) => v.toJson()).toList();
    }
    if (visits != null) {
      data['visit'] = visits!
          .map((v) => v.toJson(serializer: const CustomValueSerializer()))
          .toList();
    }
    if (orders != null) {
      data['order'] = orders!.map((v) => v.toJson()).toList();
    }
    if (dayLog != null) {
      data.addAll(dayLog!.toJson());
    }
    if (kpi != null) {
      data.addAll(kpi!.toJson());
    }
    data['name'] = name;
    data['id'] = userId;
    if (visitPlans != null) {
      data['visitPlan'] = visitPlans!.map((v) => v.toJson()).toList();
    }
    if (routes != null) {
      data['route'] = routes!.map((v) => v.toJson()).toList();
    }
    if (expenses != null) {
      data['expense'] = expenses!.map((v) => v.toApi()).toList();
    }
    if (competitiors != null) {
      data['competitior'] = competitiors!.map((v) => v.toJson()).toList();
    }
    if (stocks != null) {
      data['stock'] = stocks!.map((v) => v.toJson()).toList();
    }
    if (tickets != null) {
      data['ticket'] = tickets!.map((v) => v.toJson()).toList();
    }
    if (competitions != null) {
      data['competition'] = competitions!.map((v) => v.toJson()).toList();
    }
    if (paymentFollowUps != null) {
      data['paymentFollowUp'] =
          paymentFollowUps!.map((v) => v.toJson()).toList();
    }
    if (paymentReceipts != null) {
      data['paymentReceipt'] = paymentReceipts!.map((v) => v.toJson()).toList();
    }
    if (invoices != null) {
      data['invoice'] = invoices!.map((v) => v.toJson()).toList();
    }
    if (leaves != null) {
      data['leave'] = leaves!.map((v) => v.toJson()).toList();
    }

    return data;
  }
}

class StreamCombinedModel {
  InternetStatus internetStatus;
  int count;
  List<Visit> visits;
  List<DayLog> dayLogs;
  List<Order> orders;
  List<VisitFile> visitFiles;
  List<VisitPlan> visitPlans;
  List<Account> accounts;
  List<ExpenseHelper> expenses;
  List<StockHelper> stocks;
  List<TicketHelper> tickets;
  List<Competition> competitions;
  List<ExpenseItemFile> expenseItemFiles;
  List<AccountFile> accountFiles;
  List<PaymentFollowUp> paymentFollowUps;
  List<LeaveHelper> leaves;

  StreamCombinedModel({
    required this.internetStatus,
    required this.count,
    required this.visits,
    required this.dayLogs,
    required this.orders,
    required this.visitFiles,
    required this.visitPlans,
    required this.accounts,
    required this.expenses,
    required this.stocks,
    required this.tickets,
    required this.competitions,
    required this.expenseItemFiles,
    required this.accountFiles,
    required this.paymentFollowUps,
    required this.leaves,
  });
}

class DayLogModel {
  String? day;
  DateTime? dayStartTime;
  DateTime? dayEndTime;
  LatLng? startLocation;
  LatLng? endLocation;

  DayLogModel({
    this.day,
    this.dayStartTime,
    this.dayEndTime,
    this.startLocation,
    this.endLocation,
  });

  factory DayLogModel.fromJson(Map<String, dynamic> json) {
    var serializer = const CustomValueSerializer();
    return DayLogModel(
      day: serializer.fromJson<String?>(json['day']),
      dayStartTime: serializer.fromJson<DateTime?>(json['dayStartTime']),
      dayEndTime: serializer.fromJson<DateTime?>(json['dayEndTime']),
      startLocation: serializer.fromJson<LatLng?>(json['startLocation']),
      endLocation: serializer.fromJson<LatLng?>(json['endLocation']),
    );
  }

  Map<String, dynamic> toJson() {
    var serializer = const CustomValueSerializer();
    return <String, dynamic>{
      'day': serializer.toJson<String?>(day),
      'dayStartTime': serializer.toJson<DateTime?>(dayStartTime),
      'dayEndTime': serializer.toJson<DateTime?>(dayEndTime),
      'startLocation': serializer.toJson<LatLng?>(startLocation),
      'endLocation': serializer.toJson<LatLng?>(endLocation),
    };
  }

  bool get isValid {
    return dayStartTime != null &&
        startLocation?.lat != null &&
        startLocation?.lng != null;
  }
}

class PushRecordResponseItemModel {
  String? salesAppId;
  String? recordId;

  PushRecordResponseItemModel({
    this.salesAppId,
    this.recordId,
  });

  PushRecordResponseItemModel.fromJson(Map<String, dynamic> json) {
    salesAppId = parseToString(json['salesAppId']);
    recordId = parseToString(json['recordId']);
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['salesAppId'] = salesAppId;
    data['recordId'] = recordId;
    return data;
  }
}

class PushFilesResponseItemModel {
  String? referenceId;
  String? id;

  PushFilesResponseItemModel({
    this.referenceId,
    this.id,
  });

  PushFilesResponseItemModel.fromJson(Map<String, dynamic> json) {
    referenceId = parseToString(json['referenceId']);
    id = parseToString(json['id']);
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['referenceId'] = referenceId;
    data['id'] = id;
    return data;
  }
}

class KpiModel {
  String? pageheader;
  List<String>? names;
  List<KpiSectionModel>? sections;

  KpiModel({
    this.pageheader,
    this.names,
    this.sections,
  });

  KpiModel.fromJson(Map<String, dynamic> json) {
    pageheader = parseToString(json['pageheader']);
    names = parseToListOfField<String>(
      json['names'],
      parseToString,
    );
    sections = parseToList<KpiSectionModel>(
      json['sections'],
      KpiSectionModel.fromJson,
    );
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['pageheader'] = pageheader;
    data['names'] = names;
    if (sections != null) {
      data['sections'] = sections!.map((e) => e.toJson()).toList();
    }
    return data;
  }
}

class KpiSectionModel {
  String? sectionheader;
  List<KpiRowModel>? rows;
  List<String>? columnHeaders;

  KpiSectionModel({
    this.sectionheader,
    this.rows,
    this.columnHeaders,
  });

  KpiSectionModel.fromJson(Map<String, dynamic> json) {
    sectionheader = parseToString(json['sectionheader']);
    rows = parseToList<KpiRowModel>(
      json['rows'],
      KpiRowModel.fromJson,
    );
    columnHeaders = parseToListOfField<String>(
      json['columnHeaders'],
      parseToString,
    );
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['sectionheader'] = sectionheader;
    if (rows != null) {
      data['rows'] = rows!.map((e) => e.toJson()).toList();
    }
    data['columnHeaders'] = columnHeaders;
    return data;
  }
}

class KpiRowModel {
  String? rowName;
  String? targetValue;
  String? actualvalue;

  KpiRowModel({
    this.rowName,
    this.targetValue,
    this.actualvalue,
  });

  KpiRowModel.fromJson(Map<String, dynamic> json) {
    rowName = parseToString(json['rowName']);
    targetValue = parseToString(json['TargetValue']);
    actualvalue = parseToString(json['actualvalue']);
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['rowName'] = rowName;
    data['TargetValue'] = targetValue;
    data['actualvalue'] = actualvalue;
    return data;
  }
}
