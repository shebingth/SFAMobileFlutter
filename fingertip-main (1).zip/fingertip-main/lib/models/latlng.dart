import 'dart:convert';

import 'package:drift/drift.dart';
import 'package:json_annotation/json_annotation.dart' as j;

part 'latlng.g.dart';

@j.JsonSerializable()
class LatLng {
  double? lat;
  double? lng;

  LatLng({
    this.lat,
    this.lng,
  });

  factory LatLng.fromJson(Map<String, dynamic> json) => _$LatLngFromJson(json);

  Map<String, dynamic> toJson() => _$LatLngToJson(this);

  bool get hasData {
    return lat != null && lng != null;
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is LatLng && other.lat == lat && other.lng == lng;
  }

  @override
  int get hashCode => lat.hashCode ^ lng.hashCode;
}

class LatLngConverter extends TypeConverter<LatLng, String> {
  const LatLngConverter();

  @override
  LatLng fromSql(String fromDb) {
    return LatLng.fromJson(json.decode(fromDb));
  }

  @override
  String toSql(LatLng value) {
    return json.encode(value.toJson());
  }
}
