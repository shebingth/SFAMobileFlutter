import 'package:flutter/material.dart';

import '../database/database.dart';

class SearchItemModel {
  Widget image;
  String module;
  String text;
  String reference;
  VoidCallback onTap;

  SearchItemModel({
    required this.image,
    required this.module,
    required this.text,
    required this.reference,
    required this.onTap,
  });
}

class SearchDataModel {
  List<Account> accounts;
  List<Visit> visits;
  List<VisitPlan> visitPlans;
  List<Expense> expenses;
  List<Order> orders;
  List<Invoice> invoices;
  List<PaymentReceipt> paymentReceipts;
  List<Leave> leaves;
  List<Ticket> tickets;
  List<PaymentFollowUp> paymentFollowUps;
  List<OrderItem> orderItems;
  List<InvoiceItem> invoiceItems;

  SearchDataModel({
    required this.accounts,
    required this.visits,
    required this.visitPlans,
    required this.orders,
    required this.expenses,
    required this.invoices,
    required this.paymentReceipts,
    required this.leaves,
    required this.tickets,
    required this.paymentFollowUps,
    required this.orderItems,
    required this.invoiceItems,
  });

  SearchDataModel.empty({
    this.accounts = const [],
    this.visits = const [],
    this.visitPlans = const [],
    this.orders = const [],
    this.expenses = const [],
    this.invoices = const [],
    this.paymentReceipts = const [],
    this.leaves = const [],
    this.tickets = const [],
    this.paymentFollowUps = const [],
    this.orderItems = const [],
    this.invoiceItems = const [],
  });
}
