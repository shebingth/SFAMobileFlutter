import '../database/database.dart';
import '../ui/tools/parse.dart';

class AccountHelper {
  String? id;
  String? appAccountId;
  String? name;
  String? accountOwnerId;
  String? accountOwnerName;
  String? contactPersonName;
  String? email;
  String? mobile;
  String? alternateMobile;
  String? gstNo;
  String? description;
  String? liquidation;
  String? paymentType;
  String? accountClassification;
  String? grade;
  String? routesId;
  String? routesName;
  String? longitude;
  String? latitude;
  String? parentAccountId;
  String? parentAccountName;
  String? outstanding;
  String? avgCreditDays;
  String? openingBalance;
  String? streetName;
  String? panchayat;
  String? city;
  String? state;
  String? district;
  String? pincode;
  String? approvalStatus;
  DateTime? createdDate;
  String? createdBy;
  DateTime? lastModifiedDate;
  String? lastModifiedBy;
  bool? synced;

  AccountHelper({
    this.id,
    this.appAccountId,
    this.name,
    this.accountOwnerId,
    this.accountOwnerName,
    this.contactPersonName,
    this.email,
    this.mobile,
    this.alternateMobile,
    this.gstNo,
    this.description,
    this.liquidation,
    this.paymentType,
    this.accountClassification,
    this.grade,
    this.routesId,
    this.routesName,
    this.longitude,
    this.latitude,
    this.parentAccountId,
    this.parentAccountName,
    this.outstanding,
    this.avgCreditDays,
    this.openingBalance,
    this.streetName,
    this.panchayat,
    this.city,
    this.state,
    this.district,
    this.pincode,
    this.approvalStatus,
    this.createdDate,
    this.createdBy,
    this.lastModifiedDate,
    this.lastModifiedBy,
    this.synced,
  });

  Account toAccount() {
    return Account.fromJson(toJson());
  }

  AccountHelper.fromJson(Map<String, dynamic> json) {
    id = parseToString(json['id']);
    appAccountId = parseToString(json['appAccountId']);
    name = parseToString(json['name']);
    accountOwnerId = parseToString(json['accountOwnerId']);
    accountOwnerName = parseToString(json['accountOwnerName']);
    contactPersonName = parseToString(json['contactPersonName']);
    email = parseToString(json['email']);
    mobile = parseToString(json['mobile']);
    alternateMobile = parseToString(json['alternateMobile']);
    gstNo = parseToString(json['gstNo']);
    description = parseToString(json['description']);
    liquidation = parseToString(json['liquidation']);
    paymentType = parseToString(json['paymentType']);
    accountClassification = parseToString(json['accountClassification']);
    grade = parseToString(json['grade']);
    routesId = parseToString(json['routesId']);
    routesName = parseToString(json['routesName']);
    longitude = parseToString(json['actlong']);
    latitude = parseToString(json['actlat']);
    parentAccountId = parseToString(json['parentAccountId']);
    parentAccountName = parseToString(json['parentAccountName']);
    outstanding = parseToString(json['outstanding']);
    avgCreditDays = parseToString(json['avgCreditDays']);
    openingBalance = parseToString(json['openingBalance']);
    streetName = parseToString(json['streetName']);
    panchayat = parseToString(json['panchayat']);
    city = parseToString(json['city']);
    state = parseToString(json['state']);
    district = parseToString(json['district']);
    pincode = parseToString(json['pincode']);
    approvalStatus = parseToString(json['approvalStatus']);
    createdDate = parseToDateTime(json['createdDate']);
    createdBy = parseToString(json['createdBy']);
    lastModifiedDate = parseToDateTime(json['lastmodifiedDate']);
    lastModifiedBy = parseToString(json['lastmodifiedBy']);
    synced = parseToBool(json['synced']);
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['appAccountId'] = appAccountId;
    data['name'] = name;
    data['accountOwnerId'] = accountOwnerId;
    data['accountOwnerName'] = accountOwnerName;
    data['contactPersonName'] = contactPersonName;
    data['email'] = email;
    data['mobile'] = mobile;
    data['alternateMobile'] = alternateMobile;
    data['gstNo'] = gstNo;
    data['description'] = description;
    data['liquidation'] = liquidation;
    data['paymentType'] = paymentType;
    data['accountClassification'] = accountClassification;
    data['grade'] = grade;
    data['routesId'] = routesId;
    data['routesName'] = routesName;
    data['actlong'] = longitude;
    data['actlat'] = latitude;
    data['parentAccountId'] = parentAccountId;
    data['parentAccountName'] = parentAccountName;
    data['outstanding'] = outstanding;
    data['avgCreditDays'] = avgCreditDays;
    data['openingBalance'] = openingBalance;
    data['streetName'] = streetName;
    data['panchayat'] = panchayat;
    data['city'] = city;
    data['state'] = state;
    data['district'] = district;
    data['pincode'] = pincode;
    data['approvalStatus'] = approvalStatus;
    data['createdDate'] = createdDate?.toIso8601String();
    data['createdBy'] = createdBy;
    data['lastmodifiedDate'] = lastModifiedDate?.toIso8601String();
    data['lastmodifiedBy'] = lastModifiedBy;
    data['synced'] = synced;
    return data;
  }
}
