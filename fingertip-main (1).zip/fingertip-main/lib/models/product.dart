import '../ui/tools/parse.dart';

class ProductHelper {
  String? id;
  String? name;
  String? category;
  double? unitPrice;
  double? taxPercent;

  ProductHelper({
    this.id,
    this.name,
    this.category,
    this.unitPrice,
    this.taxPercent,
  });

  ProductHelper.fromJson(Map<String, dynamic> json) {
    id = parseToString(json['id']);
    name = parseToString(json['name']);
    category = parseToString(json['category']);
    unitPrice = parseToDouble(json['unitPrice']);
    taxPercent = parseToDouble(json['taxPercent']);
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['category'] = category;
    data['unitPrice'] = unitPrice;
    data['taxPercent'] = taxPercent;
    return data;
  }
}
