import 'package:drift/drift.dart';

import '../database/database.dart';
import '../ui/tools/parse.dart';

class PaymentFollowUpHelper {
  String? id;
  String? appPaymentFollowUpId;
  String? name;
  DateTime? expectedPaymentDate;
  String? expectedAmount;
  String? comment;
  String? appAccountId;
  String? accountId;
  String? accountName;
  bool? synced;
  String? appVisitId;
  String? visitId;

  double get amountDouble => parseToDouble(expectedAmount) ?? 0;

  PaymentFollowUpHelper({
    this.id,
    this.appPaymentFollowUpId,
    this.name,
    this.expectedPaymentDate,
    this.expectedAmount,
    this.comment,
    this.appAccountId,
    this.accountId,
    this.accountName,
    this.synced,
    this.appVisitId,
    this.visitId,
  });

  PaymentFollowUpHelper.fromJson(Map<String, dynamic> data) {
    id = parseToString(data['Id']);
    appPaymentFollowUpId = parseToString(data['appPaymentFollowUpId']);
    name = parseToString(data['name']);
    expectedPaymentDate = parseToDateTime(data['expectedPaymentdate']);
    expectedAmount = parseToString(data['expectedAmount']);
    comment = parseToString(data['comment']);
    appAccountId = parseToString(data['appAccountId']);
    accountId = parseToString(data['accountId']);
    accountName = parseToString(data['accountName']);
    synced = parseToBool(data['synced']);
    visitId = parseToString(data['visitId']);
    appVisitId = parseToString(data['appVisitId']);
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['Id'] = id;
    data['appPaymentFollowUpId'] = appPaymentFollowUpId;
    data['name'] = name;
    data['expectedPaymentdate'] = expectedPaymentDate?.toIso8601String();
    data['expectedAmount'] = expectedAmount;
    data['comment'] = comment;
    data['appAccountId'] = appAccountId;
    data['accountId'] = accountId;
    data['accountName'] = accountName;
    data['synced'] = synced;
    data['visitId'] = visitId;
    data['appVisitId'] = appVisitId;
    return data;
  }

  PaymentFollowUpsCompanion toCompanion() {
    return PaymentFollowUpsCompanion(
      id: Value.absentIfNull(id),
      appPaymentFollowUpId: Value.absentIfNull(appPaymentFollowUpId),
      name: Value.absentIfNull(name),
      expectedPaymentDate: Value.absentIfNull(expectedPaymentDate),
      expectedAmount: Value.absentIfNull(expectedAmount),
      comment: Value.absentIfNull(comment),
      appAccountId: Value.absentIfNull(appAccountId),
      accountId: Value.absentIfNull(accountId),
      accountName: Value.absentIfNull(accountName),
      visitId: Value.absentIfNull(visitId),
      appVisitId: Value.absentIfNull(appVisitId),
      synced: Value.absentIfNull(synced),
    );
  }
}
