import 'package:drift/drift.dart';

import '../database/database.dart';
import '../ui/tools/parse.dart';

class InvoiceHelper {
  String? id;
  String? appInvoiceId;
  String? name;
  String? status;
  int? totalQuantity;
  double? totalAmount;
  double? grandTotal;
  double? balance;
  DateTime? invoiceDate;
  DateTime? dueDate;
  String? accountName;
  String? accountId;
  DateTime? createdDate;
  List<InvoiceItemHelper>? items;

  InvoiceHelper({
    this.id,
    this.appInvoiceId,
    this.name,
    this.status,
    this.totalQuantity,
    this.totalAmount,
    this.grandTotal,
    this.balance,
    this.invoiceDate,
    this.dueDate,
    this.accountName,
    this.accountId,
    this.createdDate,
    this.items,
  });

  InvoicesCompanion toCompanion() {
    return InvoicesCompanion(
      id: Value.absentIfNull(id),
      appInvoiceId: Value.absentIfNull(appInvoiceId),
      name: Value.absentIfNull(name),
      status: Value.absentIfNull(status),
      totalQuantity: Value.absentIfNull(totalQuantity),
      totalAmount: Value.absentIfNull(totalAmount),
      grandTotal: Value.absentIfNull(grandTotal),
      balance: Value.absentIfNull(balance),
      invoiceDate: Value.absentIfNull(invoiceDate),
      dueDate: Value.absentIfNull(dueDate),
      accountName: Value.absentIfNull(accountName),
      accountId: Value.absentIfNull(accountId),
      createdDate: Value.absentIfNull(createdDate),
    );
  }

  InvoiceHelper.fromJson(Map<String, dynamic> json) {
    id = parseToString(json['id']);
    appInvoiceId = parseToString(json['appInvoiceId']);
    name = parseToString(json['Name']);
    status = parseToString(json['status']);
    totalQuantity = parseToInt(json['totalQuantity']);
    totalAmount = parseToDouble(json['totalAmount']);
    grandTotal = parseToDouble(json['grandTotal']);
    balance = parseToDouble(json['balance']);
    invoiceDate = parseToDateTime(json['invoiceDate']);
    dueDate = parseToDateTime(json['dueDate']);
    accountName = parseToString(json['accountName']);
    accountId = parseToString(json['accountId']);
    createdDate = parseToDateTime(json['createdDate']);
    items = parseToList<InvoiceItemHelper>(
      json['invoiceItems'],
      InvoiceItemHelper.fromJson,
    );
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};

    data['id'] = id;
    data['appInvoiceId'] = appInvoiceId;
    data['Name'] = name;
    data['status'] = status;
    data['totalQuantity'] = totalQuantity;
    data['totalAmount'] = totalAmount;
    data['grandTotal'] = grandTotal;
    data['balance'] = balance;
    data['invoiceDate'] = invoiceDate;
    data['dueDate'] = dueDate;
    data['accountName'] = accountName;
    data['accountId'] = accountId;
    data['createdDate'] = createdDate?.toIso8601String();
    if (items != null) {
      data['invoiceItems'] = items!.map((v) => v.toJson()).toList();
    }

    return data;
  }
}

class InvoiceItemHelper {
  int? id;
  String? appInvoiceId;
  String? productId;
  String? productName;
  int? quantity;
  double? unitPrice;
  double? taxPercent;
  double? taxAmount;
  double? totalAmount;
  double? totalTax;
  double? grandTotal;

  InvoiceItemHelper({
    this.id,
    this.appInvoiceId,
    this.productId,
    this.productName,
    this.quantity,
    this.unitPrice,
    this.taxPercent,
    this.taxAmount,
    this.totalAmount,
    this.totalTax,
    this.grandTotal,
  });

  InvoiceItemsCompanion toCompanion() {
    return InvoiceItemsCompanion(
      id: Value.absentIfNull(id),
      appInvoiceId: Value.absentIfNull(appInvoiceId),
      productId: Value.absentIfNull(productId),
      productName: Value.absentIfNull(productName),
      quantity: Value.absentIfNull(quantity),
      unitPrice: Value.absentIfNull(unitPrice),
      taxPercent: Value.absentIfNull(taxPercent),
      taxAmount: Value.absentIfNull(taxAmount),
      totalAmount: Value.absentIfNull(totalAmount),
      totalTax: Value.absentIfNull(totalTax),
      grandTotal: Value.absentIfNull(grandTotal),
    );
  }

  InvoiceItemHelper.fromJson(Map<String, dynamic> json) {
    id = parseToInt(json['id']);
    appInvoiceId = parseToString(json['appInvoiceId']);
    productId = parseToString(json['productId']);
    productName = parseToString(json['productName']);
    quantity = parseToInt(json['quantity']);
    unitPrice = parseToDouble(json['unitPrice']);
    taxPercent = parseToDouble(json['taxPercent']);
    taxAmount = parseToDouble(json['taxAmount']);
    totalAmount = parseToDouble(json['totalAmount']);
    totalTax = parseToDouble(json['totalTax']);
    grandTotal = parseToDouble(json['grandTotal']);
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['appInvoiceId'] = appInvoiceId;
    data['productId'] = productId;
    data['productName'] = productName;
    data['quantity'] = quantity;
    data['unitPrice'] = unitPrice;
    data['taxPercent'] = taxPercent;
    data['taxAmount'] = taxAmount;
    data['totalAmount'] = totalAmount;
    data['totalTax'] = totalTax;
    data['grandTotal'] = grandTotal;
    return data;
  }
}
