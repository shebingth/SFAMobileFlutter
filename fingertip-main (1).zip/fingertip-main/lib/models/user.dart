import '../extensions/string.dart';
import '../ui/tools/parse.dart';

class AppUser {
  String? userId;
  String? name;
  String? accessToken;
  String? instanceUrl;
  String? id;
  String? tokenType;
  String? issuedAt;
  String? signature;

  AppUser({
    this.userId,
    this.name,
    this.accessToken,
    this.instanceUrl,
    this.id,
    this.tokenType,
    this.issuedAt,
    this.signature,
  });

  AppUser.fromJson(Map<String, dynamic> json, {AppUser? oldUser}) {
    userId = json.containsKey('userId')
        ? parseToString(json['userId'])
        : oldUser?.userId;
    name =
        json.containsKey('name') ? parseToString(json['name']) : oldUser?.name;
    accessToken = json.containsKey('access_token')
        ? parseToString(json['access_token'])
        : oldUser?.accessToken;
    instanceUrl = json.containsKey('instance_url')
        ? parseToString(json['instance_url'])
        : oldUser?.instanceUrl;
    id = json.containsKey('id') ? parseToString(json['id']) : oldUser?.id;
    tokenType = json.containsKey('token_type')
        ? parseToString(json['token_type'])
        : oldUser?.tokenType;
    issuedAt = json.containsKey('issued_at')
        ? parseToString(json['issued_at'])
        : oldUser?.issuedAt;
    signature = json.containsKey('signature')
        ? parseToString(json['signature'])
        : oldUser?.signature;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data['userId'] = userId;
    data['name'] = name;
    data['access_token'] = accessToken;
    data['instance_url'] = instanceUrl;
    data['id'] = id;
    data['token_type'] = tokenType;
    data['issued_at'] = issuedAt;
    data['signature'] = signature;
    return data;
  }

  bool get hasUser {
    if (accessToken.isNotEmptyOrNull && instanceUrl.isNotEmptyOrNull) {
      return true;
    }
    return false;
  }

  AppUser copyWith({
    String? userId,
    String? name,
    String? accessToken,
    String? instanceUrl,
    String? id,
    String? tokenType,
    String? issuedAt,
    String? signature,
  }) {
    return AppUser(
      userId: userId ?? this.userId,
      name: name ?? this.name,
      accessToken: accessToken ?? this.accessToken,
      instanceUrl: instanceUrl ?? this.instanceUrl,
      id: id ?? this.id,
      tokenType: tokenType ?? this.tokenType,
      issuedAt: issuedAt ?? this.issuedAt,
      signature: signature ?? this.signature,
    );
  }
}
