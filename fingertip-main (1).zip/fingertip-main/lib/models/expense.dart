import 'dart:io';

import 'package:flutter/foundation.dart';

import 'package:drift/drift.dart';

import '../database/database.dart';
import '../ui/tools/parse.dart';

class ExpenseHelper {
  String? appExpId;
  String? id;
  DateTime? expenseDate;
  String? expenseName;
  String? executiveId;
  String? executiveName;
  String? createdBy;
  bool? synced;
  String? approvalStatus;
  DateTime? createdDate;
  List<ExpenseItemHelper>? items;

  ExpenseHelper({
    this.appExpId,
    this.id,
    this.expenseDate,
    this.expenseName,
    this.executiveId,
    this.executiveName,
    this.createdBy,
    this.synced,
    this.approvalStatus,
    this.createdDate,
    this.items,
  });

  double get totalAmount {
    double total = 0;
    if (items != null) {
      for (var element in items!) {
        total += element.amountDouble;
      }
    }
    return total;
  }

  ExpenseHelper.fromApi(Map<String, dynamic> data) {
    expenseName = parseToString(data['expenseName']);
    id = parseToString(data['expenseId']);
    expenseDate = parseToDateTime(data['expenseDate']);
    executiveId = parseToString(data['executiveId']);
    executiveName = parseToString(data['executiveName']);
    createdBy = parseToString(data['createdBy']);
    approvalStatus = parseToString(data['approvalStatus']);
    appExpId = parseToString(data['appExpId']);
    createdDate = parseToDateTime(data['createdDate']);
    items = parseToList<ExpenseItemHelper>(
      data['expenseItems'],
      ExpenseItemHelper.fromApi,
    );
    items?.forEach((element) {
      element.appExpId = appExpId;
    });
  }

  Map<String, dynamic> toApi() {
    var data = <String, dynamic>{};

    data['appExpId'] = appExpId;
    data['id'] = id;
    data['expenseDate'] = expenseDate?.toIso8601String();
    data['approvalStatus'] = approvalStatus;
    data['executiveId'] = executiveId;
    data['executiveName'] = executiveName;
    data['expenseName'] = expenseName;
    data['createdDate'] = createdDate?.toIso8601String();
    if (items != null) {
      data['expenseItems'] = items!.map((e) => e.toApi()).toList();
    }

    return data;
  }

  ExpenseHelper copyWith({
    String? appExpId,
    String? id,
    DateTime? expenseDate,
    String? expenseName,
    String? executiveId,
    String? executiveName,
    String? createdBy,
    bool? synced,
    String? approvalStatus,
    DateTime? createdDate,
    List<ExpenseItemHelper>? items,
  }) {
    return ExpenseHelper(
      appExpId: appExpId ?? this.appExpId,
      id: id ?? this.id,
      expenseDate: expenseDate ?? this.expenseDate,
      expenseName: expenseName ?? this.expenseName,
      executiveId: executiveId ?? this.executiveId,
      executiveName: executiveName ?? this.executiveName,
      createdBy: createdBy ?? this.createdBy,
      synced: synced ?? this.synced,
      approvalStatus: approvalStatus ?? this.approvalStatus,
      createdDate: createdDate ?? this.createdDate,
      items: items ?? this.items,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is ExpenseHelper &&
        other.appExpId == appExpId &&
        other.id == id &&
        other.expenseDate == expenseDate &&
        other.expenseName == expenseName &&
        other.executiveId == executiveId &&
        other.executiveName == executiveName &&
        other.createdBy == createdBy &&
        other.synced == synced &&
        other.approvalStatus == approvalStatus &&
        listEquals(other.items, items);
  }

  @override
  int get hashCode {
    return appExpId.hashCode ^
        id.hashCode ^
        expenseDate.hashCode ^
        expenseName.hashCode ^
        executiveId.hashCode ^
        executiveName.hashCode ^
        createdBy.hashCode ^
        synced.hashCode ^
        approvalStatus.hashCode ^
        items.hashCode;
  }
}

class ExpenseItemHelper {
  String? appExpItemId;
  String? appExpId;
  String? type;
  String? description;
  String? amount;
  List<File>? files;

  ExpenseItemHelper({
    this.appExpItemId,
    this.appExpId,
    this.type,
    this.description,
    this.amount,
    this.files,
  });

  double get amountDouble => parseToDouble(amount) ?? 0;

  ExpenseItemsCompanion toCompanion() {
    return ExpenseItemsCompanion(
      appExpItemId: Value.absentIfNull(appExpItemId),
      appExpId: Value.absentIfNull(appExpId),
      type: Value.absentIfNull(type),
      description: Value.absentIfNull(description),
      amount: Value.absentIfNull(amount),
    );
  }

  ExpenseItemHelper.fromApi(Map<String, dynamic> data) {
    type = parseToString(data['type']);
    description = parseToString(data['description']);
    appExpItemId = parseToString(data['appExpItemId']);
    amount = parseToString(data['amount']);
  }

  Map<String, dynamic> toApi() {
    var data = <String, dynamic>{};
    data["appExpItemId"] = appExpItemId;
    data["type"] = type;
    data["amount"] = amount;
    data["description"] = description;

    return data;
  }

  ExpenseItemHelper copyWith({
    String? appExpItemId,
    String? appExpId,
    String? type,
    String? description,
    String? amount,
    List<File>? files,
  }) {
    return ExpenseItemHelper(
      appExpItemId: appExpItemId ?? this.appExpItemId,
      appExpId: appExpId ?? this.appExpId,
      type: type ?? this.type,
      description: description ?? this.description,
      amount: amount ?? this.amount,
      files: files ?? this.files,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is ExpenseItemHelper &&
        other.appExpItemId == appExpItemId &&
        other.appExpId == appExpId &&
        other.type == type &&
        other.description == description &&
        other.amount == amount &&
        listEquals(other.files, files);
  }

  @override
  int get hashCode {
    return appExpItemId.hashCode ^
        appExpId.hashCode ^
        type.hashCode ^
        description.hashCode ^
        amount.hashCode ^
        files.hashCode;
  }
}
