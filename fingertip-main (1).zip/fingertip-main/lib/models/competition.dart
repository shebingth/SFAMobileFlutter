import 'package:drift/drift.dart';

import '../database/database.dart';
import '../ui/tools/parse.dart';

class CompetitiorHelper {
  String? id;
  String? name;

  CompetitiorHelper({
    this.id,
    this.name,
  });

  CompetitiorsCompanion toCompanion() {
    return CompetitiorsCompanion(
      id: Value(id),
      name: Value(name),
    );
  }

  CompetitiorHelper.fromJson(Map<String, dynamic> json) {
    id = parseToString(json['id']);
    name = parseToString(json['name']);
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    return data;
  }
}

class CompetitionHelper {
  String? salesAppId;
  double? rate;
  String? productName;
  String? productId;
  String? id;
  String? competitorName;
  String? competitorId;
  String? appCompetitionId;
  String? accountName;
  String? accountId;
  String? currentStock;

  CompetitionHelper({
    this.salesAppId,
    this.rate,
    this.productName,
    this.productId,
    this.id,
    this.competitorName,
    this.competitorId,
    this.appCompetitionId,
    this.accountName,
    this.accountId,
    this.currentStock,
  });

  CompetitionsCompanion toCompanion() {
    return CompetitionsCompanion(
      currentStock: Value.absentIfNull(currentStock),
      salesAppId: Value.absentIfNull(salesAppId),
      rate: Value.absentIfNull(rate),
      productName: Value.absentIfNull(productName),
      productId: Value.absentIfNull(productId),
      id: Value.absentIfNull(id),
      competitorName: Value.absentIfNull(competitorName),
      competitorId: Value.absentIfNull(competitorId),
      appCompetitionId: Value.absentIfNull(appCompetitionId),
      accountName: Value.absentIfNull(accountName),
      accountId: Value.absentIfNull(accountId),
    );
  }

  CompetitionHelper.fromJson(Map<String, dynamic> json) {
    salesAppId = parseToString(json['salesAppId']);
    rate = parseToDouble(json['rate']);
    productName = parseToString(json['productName']);
    productId = parseToString(json['productId']);
    id = parseToString(json['Id']);
    competitorName = parseToString(json['competitorName']);
    competitorId = parseToString(json['competitorId']);
    appCompetitionId = parseToString(json['appCompetitionId']);
    accountName = parseToString(json['accountName']);
    accountId = parseToString(json['accountId']);
    currentStock = parseToString(json['currentStock']);
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['salesAppId'] = salesAppId;
    data['rate'] = rate;
    data['productName'] = productName;
    data['productId'] = productId;
    data['Id'] = id;
    data['competitorName'] = competitorName;
    data['competitorId'] = competitorId;
    data['appCompetitionId'] = appCompetitionId;
    data['accountName'] = accountName;
    data['accountId'] = accountId;
    data['currentStock'] = currentStock;
    return data;
  }
}
