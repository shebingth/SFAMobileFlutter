import 'package:drift/drift.dart';

import '../database/database.dart';
import '../ui/tools/parse.dart';

class TicketHelper {
  String? subject;
  String? status;
  String? salesAppId;
  String? visitId;
  String? id;
  String? description;
  String? complaintType;
  String? appTicketId;
  String? accountName;
  String? accountId;
  DateTime? createdDate;
  bool? synced;

  TicketHelper({
    this.subject,
    this.status,
    this.salesAppId,
    this.visitId,
    this.id,
    this.description,
    this.complaintType,
    this.appTicketId,
    this.accountName,
    this.accountId,
    this.createdDate,
    this.synced,
  });

  TicketsCompanion toCompanion() {
    return TicketsCompanion(
      subject: Value.absentIfNull(subject),
      status: Value.absentIfNull(status),
      salesAppId: Value.absentIfNull(salesAppId),
      visitId: Value.absentIfNull(visitId),
      id: Value.absentIfNull(id),
      description: Value.absentIfNull(description),
      complaintType: Value.absentIfNull(complaintType),
      appTicketId: Value.absentIfNull(appTicketId),
      accountName: Value.absentIfNull(accountName),
      accountId: Value.absentIfNull(accountId),
      createdDate: Value.absentIfNull(createdDate),
      synced: Value.absentIfNull(synced),
    );
  }

  TicketHelper.fromJson(Map<String, dynamic> json) {
    subject = parseToString(json['subject']);
    status = parseToString(json['status']);
    salesAppId = parseToString(json['salesAppId']);
    visitId = parseToString(json['visitId']);
    id = parseToString(json['Id']);
    description = parseToString(json['decription']);
    complaintType = parseToString(json['complaintType']);
    appTicketId = parseToString(json['appTicketId']);
    accountName = parseToString(json['accountName']);
    accountId = parseToString(json['accountId']);
    createdDate = parseToDateTime(json['createdDate']);
    synced = parseToBool(json['synced']);
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['subject'] = subject;
    data['status'] = status;
    data['salesAppId'] = salesAppId;
    data['visitId'] = visitId;
    data['Id'] = id;
    data['decription'] = description;
    data['complaintType'] = complaintType;
    data['appTicketId'] = appTicketId;
    data['accountName'] = accountName;
    data['accountId'] = accountId;
    data['createdDate'] = createdDate?.toIso8601String();
    data['synced'] = synced;
    return data;
  }
}
