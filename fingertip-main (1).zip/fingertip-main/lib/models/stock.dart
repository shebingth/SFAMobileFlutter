import 'package:flutter/material.dart';

import 'package:drift/drift.dart';

import '../database/database.dart';
import '../ui/tools/parse.dart';

class StockHelper {
  double? unitPrice;
  String? salesAppId;
  int? quantity;
  String? productName;
  String? productId;
  String? productCategory;
  String? id;
  String? appStockId;
  String? accountName;
  String? accountId;
  bool? synced;
  UniqueKey? widgetKey;

  StockHelper({
    this.unitPrice,
    this.salesAppId,
    this.quantity,
    this.productName,
    this.productId,
    this.productCategory,
    this.id,
    this.appStockId,
    this.accountName,
    this.accountId,
    this.synced,
    this.widgetKey,
  });

  StocksCompanion toCompanion() {
    return StocksCompanion(
      unitPrice: Value.absentIfNull(unitPrice),
      salesAppId: Value.absentIfNull(salesAppId),
      quantity: Value.absentIfNull(quantity),
      productName: Value.absentIfNull(productName),
      productId: Value.absentIfNull(productId),
      productCategory: Value.absentIfNull(productCategory),
      id: Value.absentIfNull(id),
      appStockId: Value.absentIfNull(appStockId),
      accountName: Value.absentIfNull(accountName),
      accountId: Value.absentIfNull(accountId),
      synced: Value.absentIfNull(synced),
    );
  }

  StockHelper.fromVisit(Visit visit) {
    salesAppId = visit.salesAppId;
    accountId = visit.accountId;
    accountName = visit.accountName;
    widgetKey = UniqueKey();
  }

  StockHelper.fromJson(Map<String, dynamic> json) {
    unitPrice = parseToDouble(json['unitPice']);
    salesAppId = parseToString(json['salesAppId']);
    quantity = parseToInt(json['quantity']);
    productName = parseToString(json['productName']);
    productId = parseToString(json['productId']);
    productCategory = parseToString(json['productCategory']);
    id = parseToString(json['Id']);
    appStockId = parseToString(json['appStockId']);
    accountName = parseToString(json['accountName']);
    accountId = parseToString(json['accountId']);
    synced = parseToBool(json['synced']);
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['unitPice'] = unitPrice;
    data['salesAppId'] = salesAppId;
    data['quantity'] = quantity;
    data['productName'] = productName;
    data['productId'] = productId;
    data['productCategory'] = productCategory;
    data['Id'] = id;
    data['appStockId'] = appStockId;
    data['accountName'] = accountName;
    data['accountId'] = accountId;
    data['synced'] = synced;
    return data;
  }
}
