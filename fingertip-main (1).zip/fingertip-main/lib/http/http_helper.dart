import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/material.dart';

import 'package:collection/collection.dart';
import 'package:flutter_debug_overlay/flutter_debug_overlay.dart';
import 'package:http/http.dart';
import 'package:http/retry.dart';
import 'package:mobile_device_identifier/mobile_device_identifier.dart';

import '../../app/app.locator.dart';
import '../../services/notification_service.dart';
import '../app/app.logger.dart';
import '../extensions/string.dart';
import '../models/basics.dart';
import '../models/user.dart';
import '../services/user_service.dart';
import '../ui/common/app_strings.dart';
import '../ui/common/utils.dart';
import '../ui/tools/smart_dialog_config.dart';

import 'pretty_print_json.dart';

const bool defaultShouldLogResponse = false;

class HttpHelper {
  static final logger = getLogger("HttpHelper");
  final _notificationService = locator<NotificationService>();
  final _userService = locator<UserService>();
  static final client = HttpLogClient(
    httpBucket,
    RetryClient(
      Client(),
      retries: 1,
      when: (response) => response.statusCode == 401,
      whenError: (onError, stackTrace) {
        if (onError.toString().contains(ksConnectionClosedError)) {
          logger.i("Retring....");
          return true;
        }
        return false;
      },
      onRetry: (request, response, retryCount) async {
        if (response?.statusCode == 401) {
          logger.i("Token Expired");
          // locator<UserService>().logout(callApi: false);
        }
      },
    ),
  );

  late String deviceToken;
  late String deviceId;

  AppUser? get user => _userService.user;

  Future<void> init() async {
    try {
      deviceToken = await _notificationService.getDeviceToken();
      deviceId =
          await MobileDeviceIdentifier().getDeviceId() ?? "unknown_device_id";
    } catch (e) {
      deviceToken = "unknown_token";
      deviceId = "unknown_device_id";
    }
  }

  Future<Map<String, dynamic>> commonParams() async {
    // return {
    //   "device_token": deviceToken,
    //   "device_id": deviceId,
    //   "device_type": deviceType,
    // };
    return {};
  }

  Future<(int, Map<String, dynamic>)> get({
    required Uri? url,
    Map<String, String>? headers,
    Map<String, dynamic>? body,
    bool logResponse = defaultShouldLogResponse,
    bool toast = true,
  }) async {
    try {
      if (url == null) {
        throw 'Invalid instance url';
      }

      var newBody = mergeMaps<String, dynamic>(
        body ?? {},
        await commonParams(),
      );
      var newHeaders = createHeaderFields(headers: headers);

      if (newBody.isNotEmpty) {
        url = url.replace(queryParameters: castToMapString(newBody));
      }

      prettyPrintJson({
        "URL": url.toString(),
        "Method": "Get",
      });

      var response = await client.get(
        url,
        headers: newHeaders,
      );

      log("Status Code: ${response.statusCode}");
      if (logResponse) prettyPrintJson(response.body);

      if (response.statusCode == HttpStatus.ok ||
          response.statusCode == HttpStatus.created) {
        return (response.statusCode, jsonDecodeWithCatch(response.body));
      } else if (response.statusCode == HttpStatus.unauthorized) {
        showToast('Session expired!, Please login again');

        _userService.logout(callApi: false);
        throw 'Session expired';
      } else {
        BasicResponse responseBody = BasicResponse.fromJson(
          jsonDecodeWithCatch(response.body),
        );
        responseBody.statusCode = response.statusCode;
        if (toast) {
          showToast(
            responseBody.errorDescription.isNotEmptyOrNull
                ? responseBody.errorDescription!
                : 'Error occured while communicating with server',
          );
        }
        throw ApiException(
          'Error occured while communicating with server\n${response.statusCode}\n${response.body}',
        );
      }
    } on SocketException {
      if (toast) showToast('No Internet connection');
      throw 'No Internet connection';
    } on TimeoutException {
      if (toast) showToast('Connection timed out');
      throw 'Connection timed out';
    } on FormatException {
      if (toast) showToast('Invalid data format');
      throw 'Invalid data format';
    } catch (e) {
      throw 'Something went wrong\n$e';
    }
  }

  Future<(int, Map<String, dynamic>)> post({
    required Uri? url,
    Map<String, String>? headers,
    Map<String, dynamic>? body,
    bool logResponse = defaultShouldLogResponse,
    bool jsonEncodeBody = false,
    bool toast = true,
  }) async {
    try {
      if (url == null) {
        throw 'Invalid instance url';
      }
      var newBody = mergeMaps<String, dynamic>(
        body ?? {},
        await commonParams(),
      );
      var newHeaders = createHeaderFields(headers: headers);

      prettyPrintJson({
        "URL": url.toString(),
        "Method": "Post",
        "Body": newBody,
      });

      final response = await client.post(
        url,
        headers: newHeaders,
        body: jsonEncodeBody ? jsonEncode(newBody) : newBody,
      );

      log("Status Code: ${response.statusCode}");
      if (logResponse) prettyPrintJson(response.body);

      if (response.statusCode == HttpStatus.ok ||
          response.statusCode == HttpStatus.created) {
        return (response.statusCode, jsonDecodeWithCatch(response.body));
      } else if (response.statusCode == HttpStatus.unauthorized) {
        showToast('Session expired!, Please login again');
        _userService.logout(callApi: false);
        throw 'Session expired';
      } else {
        BasicResponse responseBody = BasicResponse.fromJson(
          jsonDecodeWithCatch(response.body),
        );
        responseBody.statusCode = response.statusCode;

        if (toast) {
          showToast(
            responseBody.errorDescription.isNotEmptyOrNull
                ? responseBody.errorDescription!
                : 'Error occured while communicating with server',
          );
        }
        throw ApiException(
          'Error occured while communicating with server\n${response.statusCode}\n${response.body}',
        );
      }
    } on SocketException {
      if (toast) showToast('No Internet connection');
      throw 'No Internet connection';
    } on TimeoutException {
      if (toast) showToast('Connection timed out');
      throw 'Connection timed out';
    } on FormatException {
      if (toast) showToast('Invalid data format');
      throw 'Invalid data format';
    } catch (e) {
      throw 'Something went wrong\n$e';
    }
  }

  Map<String, String> castToMapString(
    Map<String, dynamic>? body,
  ) {
    if (body == null) {
      return {};
    }
    var newBody = body.map(
      (key, value) => MapEntry(key, value == null ? "" : value.toString()),
    );

    return newBody;
  }

  Map<String, String> createHeaderFields({
    required Map<String, String>? headers,
  }) {
    var newHeaders = headers ?? <String, String>{};

    if ((user?.hasUser ?? false)) {
      newHeaders[HttpHeaders.authorizationHeader] =
          'Bearer ${user!.accessToken!}';
    }

    var contentType = newHeaders[HttpHeaders.contentTypeHeader];
    if (contentType.isEmptyOrNull) {
      newHeaders[HttpHeaders.contentTypeHeader] =
          'application/x-www-form-urlencoded';
    }

    if (newHeaders[HttpHeaders.acceptHeader] == null) {
      newHeaders[HttpHeaders.acceptHeader] = 'application/json';
    }

    return newHeaders;
  }

  Map<String, dynamic> jsonDecodeWithCatch(String source) {
    Map<String, dynamic> data = {};
    try {
      var res = jsonDecode(source);
      if (res is Map<String, dynamic>) {
        data = res;
      }
      if (res is List) {
        data = {"results": res};
      }
    } catch (e) {
      debugPrint("$e");
      data = {};
      throw "Invalid data format Decode \n$e";
    }

    return data;
  }
}

class ApiException implements Exception {
  final String? message;

  ApiException([this.message]);

  @override
  String toString() {
    return message ?? 'Error occured while communicating with server';
  }
}
