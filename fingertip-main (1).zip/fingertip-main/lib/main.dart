import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_debug_overlay/flutter_debug_overlay.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_smart_dialog/flutter_smart_dialog.dart';
import 'package:navigation_history_observer/navigation_history_observer.dart';
import 'package:stacked_services/stacked_services.dart';

import 'app/app.bottomsheets.dart';
import 'app/app.dialogs.dart';
import 'app/app.locator.dart';
import 'app/app.router.dart';
import 'firebase_options.dart';
import 'services/api_service.dart';
import 'ui/common/app_colors.dart';
import 'ui/common/app_strings.dart';
import 'ui/common/assets.gen.dart';
import 'ui/common/fonts.gen.dart';
import 'ui/common/utils.dart';
import 'ui/tools/screen_size.dart';
import 'ui/tools/smart_dialog_config.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  if (!kIsWeb) {
    if (Platform.isAndroid) {
      ByteData data = await PlatformAssetBundle().load(
        Assets.ca.letsEncryptR3,
      );
      SecurityContext.defaultContext.setTrustedCertificatesBytes(
        data.buffer.asUint8List(),
      );
    }
  }

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  await setupLocator();
  setupDialogUi();
  setupBottomSheetUi();

  DebugOverlay.enabled = ApiService.debugOverlayEnabled;

  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(375, 812),
      builder: (context, child) {
        return MaterialApp(
          title: ksAppTitle,
          theme: ThemeData(
            useMaterial3: false,
            primarySwatch: generateMaterialColor(Palette.primary),
            fontFamily: FontFamily.lato,
            scaffoldBackgroundColor: Palette.scaffoldBackground,
            appBarTheme: const AppBarTheme(
              backgroundColor: Palette.scaffoldBackground,
              iconTheme: IconThemeData(color: Colors.black),
              systemOverlayStyle: kcSystemUiOverlayDark,
            ),
          ),
          builder: FlutterSmartDialog.init(
            builder: (context, child) {
              ScreenSize.init(context);

              return DebugOverlay(
                httpBucket: httpBucket,
                logBucket: logBucket,
                initialTabIndex: 3,
                opacity: 0.95,
                child: MediaQuery(
                  data: MediaQuery.of(context).copyWith(
                    textScaler: const TextScaler.linear(1),
                  ),
                  child: child!,
                ),
              );
            },
            toastBuilder: toastBuilder,
            loadingBuilder: loadingBuilder,
          ),
          initialRoute: Routes.splashView,
          onGenerateRoute: StackedRouter().onGenerateRoute,
          navigatorKey: StackedService.navigatorKey,
          navigatorObservers: [
            StackedService.routeObserver,
            FlutterSmartDialog.observer,
            NavigationHistoryObserver(),
          ],
        );
      },
    );
  }
}
